"""Metadata for actual Realtime tool-result/followup boundaries, never execution authority."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from enum import StrEnum


class RealtimeToolOperation(StrEnum):
    REQUEST = "tool_request"
    RESULT = "tool_result"
    FOLLOWUP = "tool_followup"


class RealtimeToolPhase(StrEnum):
    ACCEPTED = "accepted"
    SEND_STARTED = "send_started"
    SEND_RETURNED = "send_returned"
    SEND_UNKNOWN = "send_unknown"
    ACK_OBSERVED = "ack_observed"
    ACK_UNKNOWN = "ack_unknown"
    FOLLOWUP_OBSERVED = "followup_observed"


class RealtimeToolLinkBasis(StrEnum):
    REQUEST_IDENTITY = "request_identity"
    LOCAL_SEND_ATTEMPT = "local_send_attempt"
    VERIFIED_TOOL_ACK = "verified_tool_ack"
    SESSION_FOLLOWUP_ORDER = "session_followup_order"
    LOCAL_ACK_WAIT = "local_ack_wait"


class RealtimeToolObservationCode(StrEnum):
    TIMEOUT = "timeout"
    SEND_FAILED = "send_failed"
    CANCELLED = "cancelled"


def _reference(value: object, kind: str, size: int) -> None:
    if not isinstance(value, str) or re.fullmatch(rf"svc_rt_{kind}_[0-9a-f]{{{size}}}", value) is None:
        raise ValueError("invalid realtime audit reference")


def _integer(value: object, *, positive: bool = False) -> None:
    if type(value) is not int or value < int(positive):
        raise ValueError("invalid realtime audit integer")


@dataclass(frozen=True, slots=True)
class RealtimeToolOperationObservation:
    event_ref: str
    session_ref: str
    generation: int
    tool_ref: str
    operation_ref: str
    operation: RealtimeToolOperation
    phase: RealtimeToolPhase
    link_basis: RealtimeToolLinkBasis
    recorded_at_ns: int
    attempt_ref: str | None = None
    attempt_started_at_ns: int | None = None
    duration_ns: int | None = None
    source_ref: str | None = None
    code: RealtimeToolObservationCode | None = None
    schema_version: int = 1
    sdk_run_id: None = None

    def __post_init__(self) -> None:
        for name, kind, size in (
            ("event_ref", "event", 32), ("session_ref", "session", 32),
            ("tool_ref", "tool", 64), ("operation_ref", "operation", 64),
        ):
            _reference(getattr(self, name), kind, size)
        _integer(self.generation, positive=True)
        _integer(self.recorded_at_ns)
        if type(self.schema_version) is not int or self.schema_version != 1 or self.sdk_run_id is not None:
            raise ValueError("invalid realtime audit schema or Run association")
        for name, enum in (("operation", RealtimeToolOperation), ("phase", RealtimeToolPhase),
                           ("link_basis", RealtimeToolLinkBasis)):
            object.__setattr__(self, name, enum(getattr(self, name)))
        if self.code is not None:
            object.__setattr__(self, "code", RealtimeToolObservationCode(self.code))
        send = self.phase in {
            RealtimeToolPhase.SEND_STARTED, RealtimeToolPhase.SEND_RETURNED,
            RealtimeToolPhase.SEND_UNKNOWN,
        }
        if send:
            _reference(self.attempt_ref, "attempt", 32)
            _integer(self.attempt_started_at_ns)
            _integer(self.duration_ns)
            if self.link_basis is not RealtimeToolLinkBasis.LOCAL_SEND_ATTEMPT or self.operation is RealtimeToolOperation.REQUEST:
                raise ValueError("invalid realtime send observation")
        elif any(v is not None for v in (self.attempt_ref, self.attempt_started_at_ns, self.duration_ns)):
            raise ValueError("protocol observation cannot attribute a physical attempt")
        expected = {
            RealtimeToolPhase.ACCEPTED: (RealtimeToolOperation.REQUEST, RealtimeToolLinkBasis.REQUEST_IDENTITY),
            RealtimeToolPhase.ACK_OBSERVED: (RealtimeToolOperation.RESULT, RealtimeToolLinkBasis.VERIFIED_TOOL_ACK),
            RealtimeToolPhase.ACK_UNKNOWN: (RealtimeToolOperation.RESULT, RealtimeToolLinkBasis.LOCAL_ACK_WAIT),
            RealtimeToolPhase.FOLLOWUP_OBSERVED: (RealtimeToolOperation.FOLLOWUP, RealtimeToolLinkBasis.SESSION_FOLLOWUP_ORDER),
        }
        if not send and (self.operation, self.link_basis) != expected[self.phase]:
            raise ValueError("invalid realtime protocol observation")
        if self.source_ref is not None:
            _reference(self.source_ref, "source", 64)
        if self.phase in {RealtimeToolPhase.ACCEPTED, RealtimeToolPhase.ACK_OBSERVED, RealtimeToolPhase.FOLLOWUP_OBSERVED}:
            if self.source_ref is None or self.code is not None:
                raise ValueError("protocol observation requires actual source")
        elif self.source_ref is not None:
            raise ValueError("send or wait cannot manufacture a protocol source")
        if (self.phase in {RealtimeToolPhase.SEND_UNKNOWN, RealtimeToolPhase.ACK_UNKNOWN}) != (self.code is not None):
            raise ValueError("unknown observation requires closed code")

    def to_json(self) -> dict[str, object]:
        return asdict(self)
