"""Reference migration iterator: full trigger bodies, no transaction control.

Not automatically installed in SDK. Uses SQLite to recognize statement boundaries;
connection.execute still validates syntax. Default remains strict for callers of
old reference API; legacy migration adaptation may explicitly allow a final valid
statement without its delimiter. Original Migration.ddl and checksum never change.
"""
from __future__ import annotations
import sqlite3
from collections.abc import Iterator
import re


def comments_only(text: str) -> bool:
    return _first_code_offset(text) == len(text)


def _first_code_offset(text: str) -> int:
    i = 0
    while i < len(text):
        if text[i].isspace():
            i += 1
        elif text.startswith('--', i):
            n = text.find('\n', i + 2)
            i = len(text) if n < 0 else n + 1
        elif text.startswith('/*', i):
            n = text.find('*/', i + 2)
            if n < 0:
                return i  # incomplete comment is not silently discarded
            i = n + 2
        else:
            return i
    return i


def _checked(statement: str) -> str:
    code = statement[_first_code_offset(statement):]
    word = re.match(r'[A-Za-z]+', code)
    if word and word.group().upper() in {
        'BEGIN', 'COMMIT', 'END', 'ROLLBACK', 'SAVEPOINT', 'RELEASE', 'VACUUM', 'ATTACH', 'DETACH'
    }:
        raise ValueError('Migration transaction/connection control must stay in Store, not DDL')
    return statement


def iter_sql_statements(ddl: str, *, allow_unterminated_final: bool = False) -> Iterator[str]:
    if not isinstance(ddl, str):
        raise TypeError('DDL must be a string')
    start = 0
    for i, ch in enumerate(ddl):
        if ch == ';' and sqlite3.complete_statement(ddl[start:i + 1]):
            statement = ddl[start:i + 1]
            if not comments_only(statement):
                yield _checked(statement)
            start = i + 1
    tail = ddl[start:]
    if comments_only(tail):
        return
    if allow_unterminated_final and sqlite3.complete_statement(tail + '\n;'):
        # Execute original bytes, not the extra delimiter used only for boundary detection.
        yield _checked(tail)
        return
    raise ValueError('Incomplete trailing SQL; no silent truncation')
