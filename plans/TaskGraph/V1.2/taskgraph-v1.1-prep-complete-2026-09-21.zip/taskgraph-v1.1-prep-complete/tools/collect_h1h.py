#!/usr/bin/env python3
"""Collect exact registered H1-H targets on a frozen source snapshot; never execute tests.
Requires explicit confirmation that project conftest/imports are safe for offline collection.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from h1h_manifest import verified_snapshot, write_new
from capture_sources import digest

def targets_from_registry(registry: dict, root: Path) -> list[str]:
    if registry.get('status') != 'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED': raise ValueError('incomplete registry')
    targets = sorted({n for row in registry['cases'] for n in row['actual_nodeids']})
    if not targets: raise ValueError('no actual targets')
    for n in targets:
        path = (root / n.split('::', 1)[0]).resolve()
        if not path.is_relative_to(root) or not path.is_file(): raise ValueError('target missing/outside snapshot')
    return targets

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-map', type=Path, required=True)
    p.add_argument('--registry', type=Path, required=True)
    p.add_argument('--out-dir', type=Path, required=True)
    p.add_argument('--collection-imports-reviewed', action='store_true')
    a = p.parse_args()
    if not a.collection_imports_reviewed: raise ValueError('review conftest/imports and offline environment first')
    sm, root = verified_snapshot(a.source_map)
    registry = json.loads(a.registry.read_text())
    fp = sm['repositories']['candidate']['fingerprint']
    if registry.get('candidate_fingerprint') != fp: raise ValueError('registry fingerprint mismatch')
    targets = targets_from_registry(registry, root)
    evidence = a.source_map.resolve().parent; out = a.out_dir.resolve()
    if not out.is_relative_to(evidence) or out.exists(): raise ValueError('new output directory inside evidence required')
    out.mkdir(parents=True)
    tool_dir = Path(__file__).resolve().parent
    argv = [sys.executable, '-m', 'pytest', '--collect-only', '-q', '-p', 'pytest_readiness',
            '-o', 'addopts=', '-o', f'cache_dir={out / "cache"}',
            f'--readiness-source-map={a.source_map.resolve()}',
            f'--readiness-collection-out={out / "collection.json"}', *targets]
    invocation = {'kind': 'H1H_COLLECTION_ONLY', 'candidate_fingerprint': fp, 'argv': argv,
                  'cwd': str(root), 'registry_sha256': digest(a.registry.read_bytes()),
                  'raw_output': 'collection.raw.log', 'tests_executed': False,
                  'policy': 'Offline imports reviewed by operator; plugin is not a network/security sandbox.'}
    write_new(out / 'invocation.json', invocation, evidence)
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONPATH'] = os.pathsep.join([str(tool_dir), str(root / 'src')])
    with (out / 'collection.raw.log').open('xb') as stream:
        done = subprocess.run(argv, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
    # A receipt missing after pytest exits is never invented.
    result_path = out / 'collection.json'
    status = 'COLLECTED_NOT_RUN' if done.returncode == 0 and result_path.is_file() else 'BLOCKED'
    print(json.dumps({'status': status, 'returncode': done.returncode, 'executed_case_count': 0,
                      'production_enablement_allowed': False}))
    return 0 if status == 'COLLECTED_NOT_RUN' else 3

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (ValueError, RuntimeError, OSError, KeyError, subprocess.TimeoutExpired) as err:
        print(json.dumps({'status': 'BLOCKED', 'error': str(err), 'executed_case_count': 0}))
        raise SystemExit(3)
