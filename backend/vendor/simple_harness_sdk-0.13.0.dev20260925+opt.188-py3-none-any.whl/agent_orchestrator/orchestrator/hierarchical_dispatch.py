# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""P2.3b: the assembly layer of the hierarchical mode (§14, §7.2, TG §7/§8).

``event_handler.py`` is a 6000-line single class, and §18.2's line about it is an
instruction not to make that worse: *"only assemble and call the new
planning/repair/commit modules; do not keep piling every algorithm into this
file"*.  So everything the new mode needs between "the Planner answered" and
"one plan revision is committed" lives here, and the event handler holds one
optional collaborator and five ``if hierarchical`` branches.

Four things this module is responsible for, and one it deliberately is not:

* **Committing one planning decision.**  :meth:`HierarchicalDispatch.
  commit_preview_plan_proposal` takes the candidate the pure preview compiled and
  the planning admission it was previewed under, and sends exactly that
  compilation to ``commit_planning_revision``.  A refusal is recorded as
  ``PlanCommitRefused`` and handed back to the proposer; nothing is recompiled or
  rebased on its behalf (ADR-13 / C19).
* **Reading the plan through the projection.**  ``list``, ready, terminal, the
  concurrency count and the root review all go through
  :class:`~..graph.task_network.TaskNetworkSnapshot` and
  :func:`~..graph.eligibility.evaluate_readiness` (TG §7 last paragraph).  The
  string ``TaskStatus.READY`` is a rebuildable display index in this mode and is
  never a criterion — :attr:`TaskView.legacy_status` carries it for diagnostics
  only.
* **Compound tasks advance without a Worker.**  :func:`next_compound_phase` is a
  pure reducer over typed inputs; :meth:`advance_compound_phases` records what it
  says.  No Attempt is created for a compound, ever (TG §7), and
  :meth:`intercept_worker_dispatch` refuses one with ``NEEDS_REFINEMENT`` before
  the allocator's old READY entry can walk it into the Worker path (§18.5 rule 4).
* **Inputs come from the manifest.**  :meth:`attempt_inputs` asks
  :mod:`..artifacts.versioning` for the ``InputManifest`` path, so an ORDER-only
  predecessor contributes nothing (§24.1 decisions 3 and 4).

What it is *not*: an authority.  Every write still goes through
``CommitService``; every judgement still comes from ``graph/``; a missing
semantic binding is reported as :class:`GraphIntegrityError` rather than quietly
handled, because §18.5 calls that corruption and not a legacy fallback.
"""

from __future__ import annotations

import json
from collections.abc import Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from dataclasses import replace as _replace
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Protocol

from ..artifacts.input_bindings import (
    AcceptedOutput,
    AcceptedOutputsIndex,
    DeliveredFile,
    DeliverySources,
    ExplicitPortOrder,
    InputManifest,
    ManifestNotFrozen,
    ResolutionPolicy,
    ResolutionProblemKind,
    ResolutionResult,
    TargetRules,
    resolve_deliveries,
)
from ..artifacts.taskgraph_inputs import decode_frozen_manifest, encode_target_rules
from ..artifacts.versioning import (
    ArtifactConflict,
    UpstreamInput,
    manifest_upstream_inputs,
    resolve_input_manifest,
)
from ..assurance.codec import AssuranceError
from ..contracts import (
    TERMINAL_MISSION,
    ContractError,
    Event,
    TaskStatus,
    ids,
    models,
)
from ..contracts.error_table import RoundFaultCode
from ..contracts.evidence_state import (
    Availability,
    TruthValue,
    Validity,
    ValidityWitness,
    WitnessDecision,
    WitnessPurpose,
    truth_change,
)
from ..contracts.htn import (
    ORDERED_CARDINALITIES,
    GraphStructureBudget,
    MissionRef,
    ObligationId,
    OccurrenceId,
    OccurrenceSpec,
    OutputValue,
    PlanRevision,
    PortCardinality,
    PortOrdering,
    ReadItem,
    ReadItemKind,
    RunningWorkPolicy,
    ScopeEpochRead,
    SemanticReadSet,
    TaskForm,
    TaskRef,
    TaskSemanticBindingV1,
    condition_digest,
)
from ..contracts.obligations import ObligationAccountView
from ..contracts.resolution import (
    CriterionVerdict,
    GoalResolution,
    GoalResolutionId,
    RequirementsRevision,
    ResolutionCriterion,
    ReviewPackage,
    ReviewPurpose,
    ReviewRecord,
    ReviewVerdict,
    WorkspaceAccess,
)
from ..contracts.semantic_base import (
    EvidenceRef,
    EvidenceRefKind,
    TypedRef,
    TypedRefKind,
    VersionedRef,
    content_hash_of,
)
from ..graph.eligibility import (
    ActivePlanView,
    EligiblePrimitiveTask,
    EvidenceView,
    ExecutionFrontier,
    NotEligible,
    OccurrenceOutcome,
    PlanningFrontier,
    ReadinessReason,
    ReadinessReport,
    TaskView,
    admit_for_dispatch,
    evaluate_readiness,
    legacy_ready_is_not_eligibility,
)
from ..graph.network_codec import decode
from ..graph.projection_validation import (
    GraphIntegrityError,
    ordering_of,
    require_topological_order,
)
from ..graph.task_network import GATING_REQUIREDNESS, TaskNetworkSnapshot
from ..knowledge.predicates import proposition_key
from ..knowledge.validity import CONDITION_REASON_PREFIX as WITNESS_CONDITION_PREFIX
from ..knowledge.validity import acceptance_subject, condition_subject
from ..planning import plan_preview
from ..planning.htn.applicability import (
    all_truth,
    assess_method,
    authorization_gate,
    evaluate_condition,
    ground_value,
)
from ..planning.htn.applicability import assess_method as _assess
from ..planning.htn.compiler import (
    RefinementCompilation,
    RootNetwork,
    _derive_requirement_id,
)
from ..planning.htn.evidence_round import (
    EvidenceAsk,
    EvidenceRoundResult,
    asks_for_requests,
    pending_asks,
    run_round,
)
from ..planning.htn.grounding import (
    SharedGoalEntry,
    SharingSignature,
)
from ..planning.htn.method_proposals import MAX_PROPOSED_METHOD_STEPS, build_context
from ..planning.htn.method_selection import MethodSelectionCandidateV1, filter_candidates
from ..planning.htn.observation_pipeline import observe_predicate, record_observation
from ..planning.htn.planner_package import MethodApplicability, applicability_reports, task_type_row
from ..planning.htn.refinement import evidence_requests, unknown_predicates
from ..planning.htn.registry import AdmissionPolicy, iter_predicates, iter_values
from ..planning.htn.repair_adapter import RepairEventAdapter
from ..planning.plan_preview import preview_candidate
from ..runtime.action_schema import is_operation_candidate_path
from ..runtime.planning_operations import SourceUnavailable
from ..storage import planning_decision_store
from ..storage.htn_store import HtnStore, PlanCommitReceipt
from ..storage.obligation_store import ObligationStore
from ..storage.operation_completion_store import OperationCompletionStore
from ..storage.store import StoreError
from ..storage.taskgraph_store import require_bound
from ..verification.acceptance_rules import CompoundFacts, ExecutionPosture, IndependenceFacts
from .accepted_outputs import (
    accepted_output_from_json,
    carried_criteria_for,
    output_ports_in_revision,
)
from .action_commits import parse_action_criterion
from .completion_status import (
    EFFECT_SETTLED_STATES,
    read_current_effect,
    read_occurrence_completion,
)
from .completion_support import current_child_supports
from .method_plan_reviews import seed_keys
from .occurrence_tasks import read_only_leaf
from .operation_completion import OperationCompletionError
from .plan_commits import (
    HIERARCHICAL_SEMANTICS,
    PLAN_REVISION_COMMITTED,
    CommitPlanCommand,
    PlanCommitRejected,
    PlanPrincipal,
    semantics_of,
)
from .planning_admission_commits import PlanningCommitAdmission
from .planning_backend_commit import SolverPlanCommitLane
from .repair_impact import read_repair_impact_indexes
from .resolution_commits import (
    CommitGoalResolutionCommand,
    ResolutionCommitRejected,
    ResolutionPrincipal,
)
from .review_adjudication import accepted_or_adjudicated
from .scoped_composition_review import root_content_projection
from .taskgraph_epochs import current_scope_epochs
from .taskgraph_outcomes import read_taskgraph_outcomes
from .taskgraph_policy import read_installed_graph_policy

if TYPE_CHECKING:  # pragma: no cover - typing only
    from ..contracts import Mission
    from ..contracts.htn import PlanProposal
    from ..planning.plan_preview import CandidatePreview
    from ..storage.store import Store
    from .commit_service import CommitService

#: The two event types this module appends.  Both are *new* names: §18.5 rule 3
#: lets the hierarchical mode add event types and forbids it to change the bytes
#: of an existing one, so nothing here is ever written on a legacy Mission.
PLAN_COMMIT_REFUSED = "PlanCommitRefused"
PLAN_INTEGRITY_FAILED = "PlanIntegrityFailed"
DISPATCH_INTERCEPTED = "HierarchicalDispatchIntercepted"
COMPOUND_PHASE_CHANGED = "CompoundPhaseChanged"
#: P2.3c part 2: one occurrence was *not* dispatched this cycle, and the structured
#: reason why.  A separate name from ``DISPATCH_INTERCEPTED`` because that one is the
#: safety refusal of a compound and this one is the ordinary "not yet" of the readiness
#: gate; an operator reading a Mission that is not moving has to be able to tell
#: "the plan is wrong" from "the producer has not finished".
DISPATCH_WITHHELD = "HierarchicalDispatchWithheld"
#: P2.3c part 2: the Mission's root GoalResolution was offered and refused.  Recorded
#: because "the Mission did not complete" is not a diagnosis — which rule refused it is.
ROOT_RESOLUTION_REFUSED = "RootGoalResolutionRefused"
#: P2.3c part 2c (review F1): a hierarchical Mission reached the scheduler on a
#: deployment that never installed this assembly.  The gates live here and the
#: occurrence rows are written by the Commit Service, so the two can be out of step;
#: when they are, the Mission is refused rather than handed to the legacy allocator,
#: and this is the record of the refusal.  One event per Mission — the condition is a
#: deployment fact, so it does not change from cycle to cycle and repeating it every
#: cycle would drown the log it is supposed to explain.
ASSEMBLY_MISSING = "HierarchicalAssemblyMissing"
#: P2.3c part 2c: the loop went idle while this Mission still had occurrences every
#: gate withheld.  It is a *record*, not a verdict: the Mission is left exactly where
#: it is (no status change, nothing cancelled), because "this process has nothing left
#: to do" and "this Mission can never progress" are different statements and only the
#: first one is known here — a demand admitted, an approval granted or an observation
#: recorded from outside would make the very same plan runnable.  What it does end is
#: the silence: the withheld reasons are written down where an operator reads them
#: rather than left to be re-derived from a Mission that simply stopped moving.
MISSION_STALLED = "HierarchicalMissionStalled"
#: P2.3c part 2c: a licence could not be recorded because the consumer already holds a
#: START row for this scope epoch and support revision.  It is a *storage* limit, not a
#: judgement about the work — and it is recorded rather than swallowed, because the
#: occurrence that needed the licence then waits for a reason nobody could otherwise see.
WITNESS_KEY_TAKEN = "HierarchicalWitnessKeyTaken"

#: P2.3c part 3a.  The root ``MISSION_FINAL`` review package was cut, and an earlier
#: one was retired.  The two names live *here*, beside the reader that has to honour
#: them (:meth:`HierarchicalDispatch.live_root_review_package`), rather than in
#: ``orchestrator.root_review`` which writes them: "which review does the root
#: resolve from" is a question this module already answers, and an answer that could
#: not see a supersede record would resolve from an anchor the world has moved past.
ROOT_REVIEW_CUT = "HierarchicalRootReviewCut"
ROOT_REVIEW_SUPERSEDED = "HierarchicalRootReviewSuperseded"
#: G1 (Host acceptance runner): why each registered method was refused for each still
#: open goal, at the plan revision the Planner was asked against.  The four-axis
#: report was computed for the *prompt* and thrown away, so after a run nobody could
#: say why a method had not been chosen — the runner had to re-derive it with a probe.
#: One record per ``(mission, plan_revision)`` while the library is unchanged.  A method
#: the Planner proposes joins the library *without* moving the plan revision, so the key
#: grows ``:library:{n}`` with the number of proposals; otherwise the round after a
#: proposal would reuse the assessment made before it.
METHOD_APPLICABILITY_ASSESSED = "MethodApplicabilityAssessed"
# H4: the adapter result is a durable handoff record.  The model/compiler may act
# later, but the trigger, program-computed impact and admitted action survive a
# process restart as one idempotent event.
REPAIR_DECISION_DISPATCHED = "RepairDecisionDispatched"

#: How many refusals one :data:`METHOD_APPLICABILITY_ASSESSED` payload carries.  Far
#: larger than the prompt's own cap (that one protects the model's attention; this one
#: only stops a pathological registry from writing an unbounded row), and a payload
#: that hits it says so in ``truncated`` instead of quietly ending.
MAX_RECORDED_REFUSALS = 200

#: Readiness answers that mean "the planner still owes something about the facts
#: or the authority", as opposed to "a method has not been chosen yet".
_WAIT_REASONS: frozenset[ReadinessReason] = frozenset(
    {
        ReadinessReason.WAITING_EVIDENCE,
        ReadinessReason.OBSERVER_UNAVAILABLE,
        ReadinessReason.VALIDITY_RECHECK_PENDING,
        ReadinessReason.WAITING_APPROVAL,
    }
)


def is_hierarchical(mission: Mission) -> bool:
    """Whether one Mission runs under the new semantics (§18.5 rule 1)."""

    return semantics_of(mission) == HIERARCHICAL_SEMANTICS


class WriteConflictPending(ContractError):
    """A step would start from a file the plan lets several versions of reach it — unordered
    producers wrote it differently, or ordered/relayed versions arrive with no proof of which is
    the latest, or two port documents land on one path; it waits for the Planner's answer to the
    write-conflict repair request (阶段 D；2026-10-09 第 4 条)."""

    def __init__(self, conflicts: Sequence[Mapping[str, Any]]) -> None:
        self.conflicts = tuple(dict(item) for item in conflicts)
        super().__init__(
            "WRITE_CONFLICT: "
            + "; ".join(
                f"{item['path']} written by {' and '.join(str(step) for step in item['steps'])}"
                + (f" (both reach {item['consumer']})" if item.get("consumer") else "")
                for item in self.conflicts
            )
        )


class PlanIntegrityError(GraphIntegrityError):
    """Corruption that is *not* a cycle: the plan's meaning is incomplete (§18.5).

    A :class:`~..graph.projection_validation.GraphIntegrityError` so that every
    caller which already stops the scope on a damaged projection stops on this too
    (§24.1 decision 11).  Its message is its own, because the base class's
    "N node(s) could not be ordered; cycle: unknown" would describe the wrong
    defect: nothing here is unordered — a *meaning* is absent, and telling an
    operator to look for a cycle would send them to the wrong place.
    """

    def __init__(self, mission_id: str, code: str, subjects: Sequence[str], message: str) -> None:
        self.mission_id = str(mission_id)
        # 只收登记过的一轮故障码（错误码表 RoundFaultCode）：没登记的当场报错
        self.code = RoundFaultCode(code)
        self.subjects = tuple(sorted(str(item) for item in subjects))
        self._message = str(message)
        super().__init__(self.subjects, ())

    def __str__(self) -> str:
        return self._message

    def diagnose(self) -> str:
        """A description a person can act on.  Never an order a machine can run."""

        return self._message


def missing_bindings(mission_id: str, task_ids: Sequence[str]) -> PlanIntegrityError:
    """§18.5: a Task in the plan with no ``TaskSemanticBindingV1`` is corruption."""

    named = sorted(str(item) for item in task_ids)
    return PlanIntegrityError(
        mission_id,
        "semantic_binding_missing",
        [f"task:{item}" for item in named],
        f"graph integrity failure in mission {mission_id}: {len(named)} task(s) in the plan "
        f"carry no semantic binding [{', '.join(named) or 'none recorded'}]. In the "
        "hierarchical mode that is corruption and not a legacy fallback (§18.5); the plan "
        "cannot be executed until a binding exists for every member.",
    )


def root_not_identified(mission_id: str, task_ids: Sequence[str]) -> PlanIntegrityError:
    """No plan revision, and not exactly one root goal to seed one from."""

    named = sorted(str(item) for item in task_ids)
    return PlanIntegrityError(
        mission_id,
        "root_not_identified",
        [f"task:{item}" for item in named],
        f"graph integrity failure in mission {mission_id}: a Mission with no plan revision "
        f"seeds its network from exactly one root goal, and this one has {len(named)} "
        f"semantic binding(s) [{', '.join(named) or 'none'}]. Choosing one of several would "
        "be this module inventing a root; none at all is the missing-binding corruption.",
    )


# --------------------------------------------------------------------------------------
# compound phases (TG §7)
# --------------------------------------------------------------------------------------


class CompoundPhase(StrEnum):
    """TG §7's typed phase of a compound task.

    The coarse ``TaskStatus`` stays as display; this is the transition function
    ``next_compound_task`` the annex asks for.  It exists so a compound can be
    planned and accepted *without* a Worker Attempt: none of these transitions
    needs one, and creating a fake one to satisfy the old state machine is the
    exact bug TG §7 forbids.
    """

    PLANNING_READY = "planning_ready"
    REFINING = "refining"
    WAITING_CHILDREN = "waiting_children"
    COMPOSITION_REVIEW = "composition_review"
    RESOLUTION_COMMITTED = "resolution_committed"
    EVIDENCE_OR_AUTHORITY_WAIT = "evidence_or_authority_wait"


#: TG §7's display mapping.  Read by an operator and by the API; never by a gate.
COMPOUND_DISPLAY_STATUS: Mapping[CompoundPhase, TaskStatus] = {
    CompoundPhase.PLANNING_READY: TaskStatus.READY,
    CompoundPhase.REFINING: TaskStatus.ACTIVE,
    CompoundPhase.WAITING_CHILDREN: TaskStatus.ACTIVE,
    CompoundPhase.COMPOSITION_REVIEW: TaskStatus.VERIFYING,
    CompoundPhase.RESOLUTION_COMMITTED: TaskStatus.COMPLETED,
    CompoundPhase.EVIDENCE_OR_AUTHORITY_WAIT: TaskStatus.BLOCKED,
}


def next_compound_phase(
    occurrence: OccurrenceSpec,
    network: TaskNetworkSnapshot,
    report: ReadinessReport,
    *,
    child_outcomes: Mapping[OccurrenceId, OccurrenceOutcome],
    resolved: bool,
) -> CompoundPhase:
    """The phase of one compound occurrence, from typed inputs only (TG §7).

    Deliberately total and deliberately ignorant of ``TaskStatus``: the inputs are
    the occurrence's membership, the adopted method instance, the readiness verdict
    and the children's outcomes.  A caller that passes a legacy status string in
    gets the same answer, which is the property the suite pins down.
    """

    if not isinstance(occurrence, OccurrenceSpec):
        raise ContractError("next_compound_phase expects an OccurrenceSpec")
    if occurrence.form is not TaskForm.COMPOUND:
        raise ContractError(
            f"{occurrence.occurrence_id!s} is {occurrence.form!s}; only a compound occurrence "
            "has a typed phase (a primitive is driven by its Attempts, TG §7)"
        )
    if resolved:
        # An adopted GoalResolution is the end of the compound, whatever else is
        # still open: TG §7 says a COMPLETED compound does not go back.
        return CompoundPhase.RESOLUTION_COMMITTED
    if report.reason in _WAIT_REASONS:
        return CompoundPhase.EVIDENCE_OR_AUTHORITY_WAIT
    adopted = network.adopted_instance_for(occurrence.occurrence_id)
    if adopted is None:
        return CompoundPhase.PLANNING_READY
    children = network.adopted_children(occurrence.occurrence_id)
    known = {spec.occurrence_id for spec in network.occurrences}
    if any(binding.occurrence_id not in known for binding in children):
        # A slot the adopted method opened whose occurrence is not in the plan yet:
        # the refinement is committed but not fully expanded.
        return CompoundPhase.REFINING
    gating = [
        binding.occurrence_id for binding in children if binding.requiredness in GATING_REQUIREDNESS
    ]
    if any(
        child_outcomes.get(child, OccurrenceOutcome.UNKNOWN) is not OccurrenceOutcome.ACCEPTED
        for child in gating
    ):
        return CompoundPhase.WAITING_CHILDREN
    # TG §6.2 / §24.1 decision 2: the composition review waits for the *children*,
    # not for the parent, which is what makes it terminate at all.
    return CompoundPhase.COMPOSITION_REVIEW


# --------------------------------------------------------------------------------------
# results
# --------------------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class PlanRefusal:
    """One refused delivery of a plan commit, kept so the round can explain itself."""

    attempt: int
    reason: str
    detail: str
    recompilable: bool

    def to_json(self) -> dict[str, Any]:
        return {
            "attempt": self.attempt,
            "reason": self.reason,
            "detail": self.detail,
            "recompilable": self.recompilable,
        }


@dataclass(frozen=True, slots=True)
class PlanRoundOutcome:
    """What one Planner reply achieved: a receipt, or a named sequence of refusals."""

    proposal_id: str
    receipt: PlanCommitReceipt | None = None
    refusals: tuple[PlanRefusal, ...] = ()

    @property
    def committed(self) -> bool:
        return self.receipt is not None

    @property
    def attempts(self) -> int:
        return len(self.refusals) + (1 if self.committed else 0)

    @property
    def last_reason(self) -> str | None:
        return self.refusals[-1].reason if self.refusals else None


@dataclass(frozen=True, slots=True)
class DispatchInterception:
    """A compound that the old READY entry would have dispatched (§18.5 rule 4)."""

    task_id: str
    occurrence_id: str | None
    reason: str
    explanation: str


@dataclass(frozen=True, slots=True)
class RootResolutionInputs:
    """The read facts one Mission-root ``GoalResolution`` command is built from.

    ``reason`` non-empty means the facts are *not* complete and names which one is
    missing.  A missing review anchor is reported rather than fabricated: the root
    resolution is formed out of the success formula plus the final acceptance, so a
    system that writes its own review package has decided the answer it was meant to
    check (§6.3, §8.1, AER §6.1).
    """

    reason: str = ""
    detail: str = ""
    occurrence_id: str = ""
    task_id: str = ""
    obligation_id: str = ""
    contract_revision: int = 1
    method_instance_id: str | None = None
    requirements: RequirementsRevision | None = None
    package: ReviewPackage | None = None
    record: ReviewRecord | None = None
    contributions: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    #: ``primitive`` / ``compound`` form of the root occurrence (read, never assumed).
    root_form: str = ""

    @property
    def complete(self) -> bool:
        return not self.reason


@dataclass(frozen=True, slots=True)
class RootResolutionOutcome:
    """Whether the Mission's root resolution was formed this cycle, and why not."""

    committed: bool
    reason: str = ""
    detail: str = ""
    resolution_id: str | None = None

    def to_json(self) -> dict[str, Any]:
        return {
            "committed": self.committed,
            "reason": self.reason,
            "detail": self.detail,
            "resolution_id": self.resolution_id,
        }


@dataclass(frozen=True, slots=True)
class DispatchRefusal:
    """Why one occurrence is not competing for a Worker this cycle.

    The reason is a :class:`~..graph.eligibility.ReadinessReason` and the detail codes
    are the gate's own, unmerged: "the producer has not finished" (``WAITING_DATA``),
    "we could not ask" (``OBSERVER_UNAVAILABLE``) and "this compound still needs a
    method" (``NEEDS_REFINEMENT``) call for three different repairs, and the scheduler
    is the wrong place to collapse them into "not ready".
    """

    task_id: str
    occurrence_id: str
    reason: ReadinessReason
    detail_codes: tuple[str, ...] = ()
    detail: str = ""

    def to_json(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "occurrence_id": self.occurrence_id,
            "reason": str(self.reason),
            "detail_codes": list(self.detail_codes),
            "detail": self.detail,
        }


@dataclass(frozen=True, slots=True)
class DispatchAdmissions:
    """What :func:`~..scheduling.allocator.allocate_v2` is handed for one Mission.

    Three maps and nothing else: the semantic binding of every Task row (its absence
    is corruption, not a legacy fallback), the admissions
    :func:`~..graph.eligibility.admit_for_dispatch` built for the occurrences that
    passed every gate, and a named refusal for each one that did not.  Holding the
    refusals beside the admissions is the point — a Mission that is not moving has to
    be able to say why without anybody re-deriving it.
    """

    plan_revision: int
    bindings: Mapping[str, TaskSemanticBindingV1] = field(default_factory=dict)
    readiness: Mapping[str, EligiblePrimitiveTask] = field(default_factory=dict)
    refusals: tuple[DispatchRefusal, ...] = ()

    def admission_for(self, task_id: str) -> EligiblePrimitiveTask | None:
        return self.readiness.get(task_id)

    def refusal_for(self, task_id: str) -> DispatchRefusal | None:
        for item in self.refusals:
            if item.task_id == task_id:
                return item
        return None

    def to_json(self) -> dict[str, Any]:
        return {
            "plan_revision": int(self.plan_revision),
            "admitted": sorted(self.readiness),
            "refusals": [item.to_json() for item in self.refusals],
        }


@dataclass(frozen=True, slots=True)
class NetworkView:
    """One read of a Mission's plan: the snapshot plus what readiness said about it."""

    network: TaskNetworkSnapshot
    plan: ActivePlanView
    views: Mapping[OccurrenceId, TaskView]
    reports: Mapping[OccurrenceId, ReadinessReport]
    outcomes: Mapping[OccurrenceId, OccurrenceOutcome]
    resolved: frozenset[OccurrenceId] = frozenset()
    #: The acceptance projection and the two witness key spaces this read judged the
    #: plan against (review F8).  They used to be computed inside ``read()`` and
    #: dropped on the floor, so ``admissions()`` read them a *second* time and the
    #: readiness report it reported came from one snapshot while the manifest it
    #: hashed came from another.  Carrying them makes the docstring's "one read" a
    #: fact about the code rather than a claim about it.
    accepted: AcceptedOutputsIndex | None = None
    witnesses: Mapping[str, ValidityWitness] = field(default_factory=dict)
    #: consumer task id → condition digest → the START-precondition licence this read
    #: judged against (P2.3c part 2c; the sibling of ``licences`` on the DATA lane).
    starts: Mapping[str, Mapping[str, ValidityWitness]] = field(default_factory=dict)
    licences: Mapping[str, Mapping[str, ValidityWitness]] = field(default_factory=dict)
    #: The input resolution each report was judged against (NEXT-TG-1.0 §5.2).  An
    #: admission takes *this* resolution; it never resolves the inputs a second time
    #: and never stands an empty manifest in for a missing one.
    resolutions: Mapping[OccurrenceId, ResolutionResult] = field(default_factory=dict)

    @property
    def planning_frontier(self) -> PlanningFrontier:
        return PlanningFrontier.compute(self.plan, self.reports)

    @property
    def execution_frontier(self) -> ExecutionFrontier:
        return ExecutionFrontier.compute(self.plan, self.reports)

    def report_for(self, occurrence: OccurrenceId) -> ReadinessReport:
        return self.reports[occurrence]


def _typed(kind: TypedRefKind, identifier: str) -> TypedRef:
    """A typed reference to something this library already holds by id."""

    return TypedRef(
        kind=kind, id=str(identifier), revision=1, content_hash=content_hash_of(str(identifier))
    )


class PlanningWorld(Protocol):
    """The declarations one deployment brings to a compilation.

    A narrow structural type on purpose: this module needs a task-type catalog, a
    schema catalog, a method registry, a predicate registry and the two evidence
    reads — and nothing else.  Anything wider would make the assembly layer depend
    on how a deployment happens to be configured.
    """

    @property
    def catalog(self) -> Any: ...

    @property
    def schemas(self) -> Any: ...

    @property
    def registry(self) -> Any: ...

    @property
    def predicates(self) -> Any: ...

    def snapshot(self) -> Any: ...

    def capabilities(self) -> Any: ...


# --------------------------------------------------------------------------------------
# the dispatcher
# --------------------------------------------------------------------------------------


@dataclass
class HierarchicalDispatch:
    """Assembly for one deployment's hierarchical Missions.

    Holds no state about a Mission: every method reads the store, because the plan
    is the store's and a cached snapshot is exactly the stale read ADR-13 spends a
    whole gate refusing.
    """

    store: Store
    commit: CommitService
    planning: PlanningWorld | None = None
    target_rules: TargetRules | None = None
    resolution_policy: ResolutionPolicy = field(default_factory=ResolutionPolicy)
    _taskgraph_settlement_reader: Any = field(default=None, repr=False)
    _taskgraph_preview: Any = field(default=None, repr=False)
    _taskgraph_history: Any = field(default=None, repr=False)

    # ---------------------------------------------------------------- reading the plan
    @classmethod
    def for_commit(cls, commit: CommitService, mission_id: str) -> HierarchicalDispatch:
        """Use the installed graph readers for an enabled Mission's original commits."""

        require_bound(commit.store, mission_id)
        binding = commit._taskgraph_dispatch
        if binding is None:
            raise StoreError("TASKGRAPH_DISPATCH_ASSEMBLY_REQUIRED")
        dispatch = binding.dispatch_for(mission_id)
        if (
            not isinstance(dispatch, cls)
            or dispatch.store is not commit.store
            or dispatch.commit is not commit
        ):
            raise StoreError("TASKGRAPH_DISPATCH_STORE_MISMATCH")
        return dispatch

    def target_rules_for(self, task_id: str) -> TargetRules:
        """The original workspace destination policy, resolved for one Task."""
        if not isinstance(task_id, str) or not task_id.strip():
            raise ContractError("workspace target requires a Task identity")
        return self.target_rules or TargetRules(namespace=f"workspace:{task_id}")

    def target_rules_policy(self) -> dict[str, Any]:
        """Freeze the installed rule or its original per-Task namespace strategy."""

        if self.target_rules is not None:
            return {"kind": "FIXED", "rules": encode_target_rules(self.target_rules)}
        return {
            "kind": "TASK_WORKSPACE_V1",
            "namespace_prefix": "workspace:",
            "port_prefixes": {},
            "preserve_source_namespace": False,
            "case_insensitive": False,
        }

    def semantics(self) -> HtnStore:
        return HtnStore(self.store)

    def mission(self, mission_id: str) -> Mission:
        found = self.store.get_mission(mission_id)
        if found is None:
            raise ContractError(f"mission {mission_id!r} does not exist")
        return found

    def require_hierarchical(self, mission_id: str) -> Mission:
        mission = self.mission(mission_id)
        if not is_hierarchical(mission):
            raise ContractError(
                f"mission {mission_id!r} runs under {semantics_of(mission)!r}; the hierarchical "
                "assembly is not an entry point for a legacy Mission (§18.5 rule 1)"
            )
        return mission

    def network(self, mission_id: str) -> TaskNetworkSnapshot:
        """The active plan revision, read back as a typed network — or corruption.

        This is the *execution* read, so a task in the plan with no
        ``TaskSemanticBindingV1`` raises :class:`PlanIntegrityError`.  §18.5: in
        this mode a missing binding is corruption, and treating it as "then use the
        legacy rules" is how a Mission silently runs half in each mode.

        The reading side that only has to *explain* a Mission goes through
        :meth:`read` with ``tolerate_integrity=True``, which carries the same error
        on the :class:`ActivePlanView` instead of raising: every verdict in the
        scope then reads ``GRAPH_INTEGRITY`` and nothing is dispatched (§24.1
        decision 11).  Two behaviours, one read, and the caller says which it is.
        """

        snapshot, integrity = self._read_network(mission_id)
        if integrity is not None:
            raise integrity
        return snapshot

    def _read_network(
        self, mission_id: str
    ) -> tuple[TaskNetworkSnapshot, PlanIntegrityError | None]:
        """The plan as it can be read, plus what was wrong with it.

        An occurrence whose task has no meaning cannot be *in* a
        :class:`TaskNetworkSnapshot` — construction checks that every endpoint names
        something the snapshot contains — so it is left out and reported.  Leaving
        it out is not tolerating it: the returned error makes every occurrence in the
        scope refuse, which is a stronger answer than one task failing.
        """

        semantics = self.semantics()
        active = semantics.active_plan_revision(mission_id)
        if active is None:
            # Before the first refinement there is no plan revision yet, and the
            # network is the Mission's own root goal.  Building that seed by hand in
            # every caller is how two callers end up disagreeing about whether the
            # root is its own occurrence, which is why the compiler owns the shape.
            return self._read_seed_network(mission_id)
        revision = int(active.revision)

        require_bound(self.store, mission_id)
        if self._taskgraph_history is None:
            raise SourceUnavailable("taskgraph_history_reader_unavailable")
        frozen = decode(
            self._taskgraph_history.read_revision(mission_id, revision).record.document.to_json()
        ).snapshot
        current_bindings = []
        for original in frozen.task_bindings:
            current = semantics.task_semantics_of(mission_id, str(original.task_id))
            if current is None:
                raise missing_bindings(mission_id, [str(original.task_id)])
            current_bindings.append(current)
        # Roots, memberships, adoptions and declared endpoints come from the
        # verified full record. Current control is a separate binding overlay;
        # never infer new roots or drop dangling edges while reading a graph.
        return replace(frozen, task_bindings=tuple(current_bindings)), None

    def seed_network(self, mission_id: str) -> TaskNetworkSnapshot:
        """The one-occurrence starting network of a Mission with no plan revision.

        Exactly one semantic binding is expected: the root goal the Mission was
        opened for.  Zero is the missing-binding corruption §18.5 names; more than
        one means someone wrote task meanings without a plan to hold them, and
        picking one of them would be this module inventing a root.  Both are
        :class:`PlanIntegrityError`, not a legacy fallback.
        """

        snapshot, integrity = self._read_seed_network(mission_id)
        if integrity is not None:
            raise integrity
        return snapshot

    def _read_seed_network(
        self, mission_id: str
    ) -> tuple[TaskNetworkSnapshot, PlanIntegrityError | None]:
        """The seed, or an empty network plus the reason there is no seed.

        The empty snapshot is what lets the explaining caller answer at all: with
        the error carried beside it, every query over it reports corruption instead
        of raising out of a loop that is also driving other Missions.
        """

        bindings: dict[str, TaskSemanticBindingV1] = {}
        for binding in self.semantics().list_task_semantics(mission_id):
            bindings[str(binding.task_id)] = binding  # ordered by revision: newest wins
        if len(bindings) != 1:
            empty = TaskNetworkSnapshot(
                mission_id=MissionRef(mission_id),
                plan_revision=PlanRevision(0),
                occurrences=(),
                task_bindings=(),
            )
            return empty, root_not_identified(mission_id, sorted(bindings))
        root = next(iter(bindings.values()))
        return RootNetwork(mission_id=MissionRef(mission_id), root_task=root).snapshot(), None

    def plan_view(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot | None = None,
        *,
        integrity: GraphIntegrityError | None = None,
    ) -> ActivePlanView:
        """The frozen read one readiness judgement is made against.

        Both kinds of corruption are *carried* here rather than raised: an
        unorderable projection (``require_topological_order``) and an incomplete
        plan meaning (``integrity``, from :meth:`_read_network`).  §24.1 decision 11
        wants a damaged plan to stop every dispatch in the scope, which is exactly
        what ``ActivePlanView.integrity_error`` does — while the caller that actually
        materialises files gets the exception from :mod:`..artifacts.versioning`.
        """

        mission = self.mission(mission_id)
        if network is None:
            network, carried = self._read_network(mission_id)
            integrity = integrity or carried
        resolved = network
        if integrity is None:
            try:
                require_topological_order(resolved.execution_projection())
            except GraphIntegrityError as error:
                integrity = error
        return ActivePlanView(
            snapshot=resolved,
            # "Admits work" is the *selection* gate's question — is this Mission still
            # one whose plan may be acted on — so the answer is "it has not stopped",
            # not "it is already dispatching".  A Mission that is still being planned
            # admits planning work; a stopped one admits none.  Whether a primitive may
            # actually be dispatched is the dispatch transaction's decision (TG §8.1
            # layer 3), which this view deliberately does not make.
            mission_admits_work=mission.status not in TERMINAL_MISSION,
            # TG decision 9: an active share needs a live demand, and the duty's
            # account is where that is recorded.  Read, never invented: a duty with
            # no account is "no admitted demand", which is the selection gate's
            # NOT_SELECTED and not an implicit permission.
            obligation_accounts=self.obligation_accounts(mission_id, resolved),
            # The epoch barrier the START-precondition gate compares against (§11.5 /
            # I19).  Left empty — as it was — every recorded witness answered
            # ``witness_epoch_unknown``: the view could not confirm the epoch it was
            # taken at, so the one lane that reads ``scope_epochs`` could never open,
            # whatever the deployment had observed.
            scope_epochs=self.scope_epochs(mission_id),
            integrity_error=integrity,
            **self.requirements_revisions(mission_id),
        )

    def requirements_revisions(self, mission_id: str) -> dict[str, int]:
        """Which requirements revision the active plan was made for, and which is current
        (阶段 E).  Before any plan is committed there is nothing to compare."""
        semantics = self.semantics()
        active = semantics.active_plan_revision(mission_id)
        latest = semantics.latest_requirements_revision(mission_id)
        if active is None or latest is None:
            return {}
        return {
            "planned_requirements_revision": int(active.read_set.requirements_revision),
            "current_requirements_revision": int(latest.revision),
        }

    def requirements_changed(self, mission_id: str) -> bool:
        """The user amended the requirements and no plan for the new revision is committed."""
        found = self.requirements_revisions(mission_id)
        return (
            bool(found)
            and bool(found["planned_requirements_revision"])
            and (found["planned_requirements_revision"] != found["current_requirements_revision"])
        )

    def scope_epochs(self, mission_id: str) -> dict[str, int]:
        """The live validity epoch of every scope this Mission's witnesses name.

        ``mission`` is always in it: it is the scope a witness takes by default and
        the one the manager epoch belongs to, and a barrier that is missing reads as
        "unknown", which refuses rather than allows.
        """

        # A newly bumped scope can have no witness yet. Its barrier still belongs in
        # the complete current read token and input policy.

        require_bound(self.store, mission_id)
        return current_scope_epochs(self.store, mission_id)

    def obligation_accounts(
        self, mission_id: str, network: TaskNetworkSnapshot
    ) -> dict[ObligationId, ObligationAccountView]:
        duties = ObligationStore(self.store)
        accounts: dict[ObligationId, ObligationAccountView] = {}
        for spec in network.occurrences:
            if spec.obligation_id in accounts:
                continue
            if duties.exists(mission_id, spec.obligation_id):
                accounts[spec.obligation_id] = duties.account(mission_id, spec.obligation_id)
        return accounts

    def read(
        self, mission_id: str, *, now_ms: int | None = None, tolerate_integrity: bool = False
    ) -> NetworkView:
        """One complete read: snapshot, views, readiness reports, outcomes.

        This is the single place the new mode answers "what is in the plan", so
        ``list_tasks``, the ready set, the concurrency count, the terminal test and
        the root review all end up reading the same thing (TG §7).

        ``tolerate_integrity`` picks which of the two answers decision 11 asks for.
        The default is the execution answer: a plan whose meaning is incomplete
        raises, because acting on the readable part of a damaged plan is exactly the
        silent half-mode §18.5 forbids.  ``True`` is the explaining answer: the same
        error is carried on the view, every occurrence reports ``GRAPH_INTEGRITY``,
        both frontiers come back empty, and an operator can still see the Mission.

        Everything the readiness gates read is fetched **once** here and passed down:
        the acceptance projection, the witnesses and the duty accounts are the same
        for every occurrence in one read, and re-deriving them per occurrence turned
        one read of a plan into a quadratic number of store round-trips.  They are also
        *carried* on the returned view (review F8), so a caller that has to build the
        same manifest again — ``admissions()`` — judges against this snapshot rather
        than taking a second one.
        """

        network, integrity = self._read_network(mission_id)
        if integrity is not None and not tolerate_integrity:
            raise integrity
        plan = self.plan_view(mission_id, network, integrity=integrity)
        outcomes = self.occurrence_outcomes(mission_id, network)
        if not callable(self._taskgraph_settlement_reader):
            raise SourceUnavailable("taskgraph_settlement_reader_unavailable")
        settlements = self._taskgraph_settlement_reader(mission_id, network, outcomes)
        resolved = self.resolved_occurrences(mission_id, network)
        witnesses = self.witnesses(mission_id, network)
        accepted = self.accepted_outputs(mission_id, network, outcomes=outcomes)
        # Two different questions, two different key spaces: ``witnesses()`` answers
        # "which condition was this witness taken for" (the START-precondition lane)
        # and the input index answers "which acceptance did this consumer get a
        # licence over" (the DATA lane, I19).  Feeding the precondition map to the
        # resolver meant no key ever matched and every DATA consumer refused with
        # ``WITNESS_MISSING`` whatever the deployment had accepted.
        licences = self.input_witness_index(mission_id)
        # The START-precondition lane is keyed by *consumer*, not by condition: two
        # occurrences under one method inherit the same digest, and §11.5 says one
        # consumer's permission is not another's.  The mission-wide map from the
        # frozen ``witness_ref`` stays underneath it, so a deployment that recorded
        # the link that way is still read.
        starts = self.start_witness_index(mission_id)
        moment = int(self.store.now * 1000) if now_ms is None else int(now_ms)
        views: dict[OccurrenceId, TaskView] = {}
        reports: dict[OccurrenceId, ReadinessReport] = {}
        resolutions: dict[OccurrenceId, ResolutionResult] = {}
        for spec in network.occurrences:
            view = self.task_view(mission_id, network, spec)
            views[spec.occurrence_id] = view
            resolution = self.resolved_inputs(
                mission_id,
                network,
                spec,
                accepted=accepted,
                witnesses=licences.get(str(spec.task_id), {}),
                now_ms=moment,
            )
            resolutions[spec.occurrence_id] = resolution
            reports[spec.occurrence_id] = evaluate_readiness(
                view,
                plan,
                outcomes,
                EvidenceView(witnesses={**witnesses, **starts.get(str(spec.task_id), {})}),
                resolution,
                now_ms=moment,
                settlements=settlements,
            )
        return NetworkView(
            network=network,
            plan=plan,
            views=views,
            reports=reports,
            outcomes=outcomes,
            resolved=resolved,
            accepted=accepted,
            witnesses=witnesses,
            licences=licences,
            starts=starts,
            resolutions=resolutions,
        )

    def task_view(
        self, mission_id: str, network: TaskNetworkSnapshot, spec: OccurrenceSpec
    ) -> TaskView:
        """The typed read of one occurrence; the legacy status is diagnostics only."""

        task = self.store.get_task(str(spec.task_id))
        try:
            binding: TaskSemanticBindingV1 | None = network.binding_for_occurrence(
                spec.occurrence_id
            )
        except KeyError:  # pragma: no cover - network() refuses this first
            binding = None
        return TaskView(
            occurrence_id=spec.occurrence_id,
            task_id=spec.task_id,
            binding=binding,
            legacy_status="" if task is None else str(task.status),
        )

    def occurrence_outcomes(
        self, mission_id: str, network: TaskNetworkSnapshot
    ) -> dict[OccurrenceId, OccurrenceOutcome]:
        """What the world says about each occurrence, for the ORDER release test.

        A reading, not a status copy: an accepted :class:`Acceptance` is what makes
        an occurrence ``ACCEPTED``, and an occurrence with no Acceptance is
        ``RUNNING`` or ``UNKNOWN`` however its legacy Task row happens to read.
        """

        require_bound(self.store, mission_id)
        return read_taskgraph_outcomes(self.store, mission_id, network)

    def resolved_occurrences(
        self, mission_id: str, network: TaskNetworkSnapshot
    ) -> frozenset[OccurrenceId]:
        """Occurrences whose duty has an *adopted* GoalResolution (§7.2)."""

        if self.semantics().active_plan_revision(mission_id) is None:
            # No plan is committed yet, so nothing has a completion scope or a resolution.
            self.seed_network(mission_id)  # verify the original seed
            return frozenset()

        return frozenset(
            spec.occurrence_id
            for spec in network.occurrences
            if spec.form is TaskForm.COMPOUND
            and read_occurrence_completion(self.store, mission_id, str(spec.occurrence_id)).complete
        )

    def witnesses(
        self, mission_id: str, network: TaskNetworkSnapshot
    ) -> dict[str, ValidityWitness]:
        """The START-precondition witnesses, keyed by condition digest.

        The link is the method instance's own
        :class:`~..contracts.htn.PreconditionWitnessRecord`, which is the only place
        that says *which condition* a stored :class:`ValidityWitness` was taken for.
        Guessing that link from the witness alone would let one witness license a
        precondition it was never computed for.
        """

        by_id = {
            str(witness.witness_id): witness
            for witness in self.semantics().list_validity_witnesses(mission_id)
        }
        found: dict[str, ValidityWitness] = {}
        for draft in network.method_instances:
            for record in draft.precondition_witnesses:
                if record.witness_ref is None:
                    continue
                witness = by_id.get(str(record.witness_ref.id))
                if witness is not None:
                    found[record.condition_digest] = witness
        return found

    def input_result(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        spec: OccurrenceSpec,
        *,
        accepted: AcceptedOutputsIndex | None = None,
        witnesses: Mapping[str, ValidityWitness] | None = None,
        now_ms: int | None = None,
    ) -> ResolutionResult | None:
        """The declared DATA contract of one occurrence, resolved — or None.

        None means "this occurrence declares no data requirement", which is a
        different answer from "its inputs did not resolve"; the DATA gate reads the
        difference, so the two are not collapsed here.
        """

        requirements = [
            item
            for item in network.data_requirements
            if item.consumer_occurrence == spec.occurrence_id
        ]
        binding = network.binding_for_occurrence(spec.occurrence_id)
        # NEXT-TG-1.0 §5.2: "no requirement" is a legitimate no-input only when the
        # contract declares no required input port either.  A required port the plan
        # drew no edge for goes through the resolver, which names it
        # UNBOUND_REQUIRED_PORT, instead of becoming an empty success below.
        if not requirements and not any(port.required for port in binding.input_ports):
            return None
        # P2.3c part 2b: the witnesses this lane needs are keyed by **acceptance
        # id** and issued to *this* consumer (I19), which is a different question
        # from ``witnesses()``'s "which condition was this witness taken for".
        # Passing the precondition map here meant no key ever matched and every
        # DATA consumer refused with ``WITNESS_MISSING`` whatever the deployment
        # had recorded.
        licences = (
            self.input_witnesses(mission_id, str(spec.task_id)) if witnesses is None else witnesses
        )
        policy = self.resolution_policy_for(
            mission_id, now_ms=now_ms, consumer=spec.occurrence_id, network=network
        )
        result = resolve_input_manifest(
            binding,
            network,
            accepted if accepted is not None else self.accepted_outputs(mission_id, network),
            consumer_occurrence=spec.occurrence_id,
            witnesses=licences,
            policy=policy,
        )
        if result.problems or result.manifest is None or not result.manifest.is_frozen:
            return result
        # 2026-10-11 第三批：端口解析完、冻结了，再把这些上游交出的其余文件（交付绑定）按同一份
        # 规则算进清单——每份都带真实产出者那次验收的见证；版本证明不了的报冲突，不替规划器选。
        return resolve_deliveries(
            result.manifest,
            self.delivery_sources(mission_id, result.manifest),
            target_rules=self.target_rules_for(str(spec.task_id)),
            witnesses=licences,
            policy=policy,
        )

    def resolution_policy_for(
        self,
        mission_id: str,
        *,
        now_ms: int | None = None,
        consumer: Any = None,
        network: Any = None,
    ) -> Any:
        """This deployment's resolution policy with the Mission's live epochs in it.

        I19 is a *comparison*, and the policy this class is constructed with does not
        know the scope epochs — so a policy left at its defaults would refuse every
        binding with ``WITNESS_EPOCH_UNKNOWN``.  The epochs are read here rather than
        cached on the dataclass, for the same reason nothing else on this class is
        cached: a bumped epoch has to be visible to the very next read.

        The installed policy is always bound to the actual current epochs and
        evaluation clock.
        """

        policy = self.resolution_policy
        explicit = tuple(policy.explicit_orders)
        if consumer is not None:
            # 2026-10-09 第 4 条：这一步集合端口上各上游的先后，就是规划器在做法里数组写的先后
            explicit = (*explicit, *self._explicit_port_orders(mission_id, consumer, network))
        return _replace(
            policy,
            explicit_orders=explicit,
            scope_epochs=self.scope_epochs(mission_id),
            now_ms=int(self.store.now * 1000) if now_ms is None else int(now_ms),
        )

    def _explicit_port_orders(
        self, mission_id: str, consumer: Any, network: Any = None
    ) -> tuple[Any, ...]:
        """The declared order of each EXPLICIT set input port of ``consumer``: the order the
        adopted method lists the upstream outputs in that port's argument array (TaskGraph §5.5
        "按显式 order 列表").  Read from the plan, decided by nobody here."""

        network = self.network(mission_id) if network is None else network
        binding = network.binding_for_occurrence(consumer)
        ports = [
            port
            for port in binding.input_ports
            if port.cardinality in ORDERED_CARDINALITIES and port.ordering is PortOrdering.EXPLICIT
        ]
        if not ports:
            return ()
        semantics = self.semantics()
        for instance in network.method_instances:
            if not network.is_adopted(instance.instance_id):
                continue
            mine = next(
                (child for child in instance.child_bindings if child.occurrence_id == consumer),
                None,
            )
            if mine is None:
                continue
            entry = semantics.get_method(
                str(instance.method_ref.method_id), int(instance.method_ref.version)
            )
            contract = getattr(entry, "contract", entry)
            step = next((item for item in contract.steps if item.local_id == mine.slot_key), None)
            if step is None:
                continue
            slot_to_occurrence = {
                child.slot_key: child.occurrence_id for child in instance.child_bindings
            }
            live = {item.requirement_id for item in network.data_requirements}
            orders = []
            for port in ports:
                argument = step.arguments.get(port.port_key)
                ids: list[str] = []
                for node in iter_values(argument) if argument is not None else ():
                    if (
                        isinstance(node, OutputValue)
                        and node.step != step.local_id
                        and node.step in slot_to_occurrence
                    ):
                        derived = _derive_requirement_id(
                            slot_to_occurrence[node.step], node.port, consumer, port.port_key
                        )
                        if derived in live:  # an edge a repair replaced is no longer named
                            ids.append(derived)
                # 规划器后来用修复操作改接/加接的边不在做法正文里：排在做法列出的之后，按网络
                # 里的（固定）顺序；这是写明的约定，不是替规划器挑谁先谁后。
                later = [
                    item.requirement_id
                    for item in network.data_requirements
                    if item.consumer_occurrence == consumer
                    and item.input_port == port.port_key
                    and item.requirement_id not in ids
                ]
                orders.append(
                    ExplicitPortOrder(port.port_key, tuple(dict.fromkeys([*ids, *later])))
                )
            return tuple(orders)
        return ()

    #: The purpose a witness must carry to license *binding an accepted output* as an
    #: input.  ``START`` because that is what the use is: starting this consumer's
    #: work on that artifact.  An ``ACCEPT`` witness licensed the producer's
    #: acceptance and is not transferable to the consumer (§11.5).
    INPUT_WITNESS_PURPOSE = WitnessPurpose.START

    def input_witness_index(self, mission_id: str) -> dict[str, dict[str, ValidityWitness]]:
        """consumer task id → acceptance id → the START witness issued for it.

        The link from a witness to the acceptance it covers is the witness's own
        ``support_refs``: a witness that does not name what it was taken over could
        be made to license anything, which is exactly what §11.5 says a witness is
        not.  Witnesses for other consumers land under *their* task id rather than
        being filtered later, because the resolver's consumer check would only be
        able to report the last one it happened to see.

        The whole index is built in one pass for the same reason ``read`` fetches
        the acceptance projection once: the readiness gates ask this question for
        every occurrence in the plan, and asking per occurrence turned one read of
        the witness library into a quadratic number of store round-trips.
        """

        index: dict[str, dict[str, ValidityWitness]] = {}
        for witness in self.semantics().list_validity_witnesses(mission_id):
            if witness.purpose is not self.INPUT_WITNESS_PURPOSE:
                continue
            if witness.consumer_ref.kind is not TypedRefKind.TASK:
                continue
            for reference in witness.support_refs:
                if reference.kind is TypedRefKind.ACCEPTANCE:
                    index.setdefault(str(witness.consumer_ref.id), {})[str(reference.id)] = witness
        return index

    def input_witnesses(self, mission_id: str, task_id: str) -> dict[str, ValidityWitness]:
        """acceptance id → the START witness issued to ``task_id`` for it."""

        return self.input_witness_index(mission_id).get(str(task_id), {})

    def issue_input_witnesses(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        *,
        now_ms: int,
        scope_id: str = "mission",
    ) -> tuple[ValidityWitness, ...]:
        """Re-read each accepted output a consumer depends on and record the licence.

        This is the "recompute rather than reuse the old TRUE" half of I19 on the
        DATA lane: for every declared edge whose producer has a recorded accepted
        output, the acceptance is read *now* and a START witness is written for the
        consumer, carrying the acceptance's own support revision.  An acceptance that
        is no longer ``CURRENT`` produces an ``UNUSABLE`` witness rather than none, so
        the refusal downstream says "this was revoked" and not "nobody looked".
        """

        semantics = self.semantics()
        epoch = semantics.epoch(mission_id, scope_id)
        issued: list[ValidityWitness] = []
        recorded = tuple(self._recorded_outputs(mission_id, network))
        # 片 B：接在中间目标端口上的步骤，见证发给它实际读到的那份验收（收尾步骤的）。
        delivered = self.goal_port_outputs(
            mission_id, network, recorded, complete=self._complete_goals(mission_id, network)
        )
        covered: set[tuple[str, str]] = set()
        for output in (*recorded, *delivered):
            consumers = {
                str(network.binding_for_occurrence(item.consumer_occurrence).task_id)
                for item in network.data_requirements
                if item.producer_occurrence == output.producer_occurrence
                and item.output_port == output.output_port
            }
            # 2026-10-11 第三批：接力文件的真实产出者那次验收也要给这个下游一份见证——与清单构造
            # 同一处枚举（``delivery_sources`` 读的就是这些验收），一个验收一份，不按文件数发。
            sources = [
                (str(output.acceptance_id), int(output.support_revision)),
                *self._carried_acceptances(mission_id, str(output.acceptance_id)),
            ]
            for consumer in sorted(consumers):
                for acceptance_id, support_revision in sources:
                    if (consumer, acceptance_id) in covered:
                        continue
                    covered.add((consumer, acceptance_id))
                    stored = self._issue_acceptance_witness(
                        mission_id,
                        consumer,
                        acceptance_id,
                        support_revision,
                        epoch=epoch,
                        scope_id=scope_id,
                        now_ms=now_ms,
                    )
                    if stored is not None:
                        issued.append(stored)
        return tuple(issued)

    def _issue_acceptance_witness(
        self,
        mission_id: str,
        consumer: str,
        acceptance_id: str,
        support_revision: int,
        *,
        epoch: int,
        scope_id: str,
        now_ms: int,
    ) -> ValidityWitness | None:
        """One START licence for ``consumer`` over ``acceptance_id``, read now (I19)."""

        acceptance = self.semantics().get_acceptance(acceptance_id)
        usable = acceptance.validity is Validity.CURRENT
        witness = ValidityWitness(
            witness_id="wit-in-"
            + content_hash_of({"c": consumer, "a": acceptance_id, "e": epoch})[:28],
            consumer_ref=_typed(TypedRefKind.TASK, consumer),
            purpose=self.INPUT_WITNESS_PURPOSE,
            truth=TruthValue.TRUE if usable else TruthValue.FALSE,
            freshness=Validity.CURRENT if usable else acceptance.validity,
            availability=Availability.READABLE,
            # ``BLOCKED``, not ``UNAVAILABLE``: the acceptance was read and found
            # revoked or superseded, which is a different fact from "the
            # library could not be read".
            decision=WitnessDecision.USABLE if usable else WitnessDecision.BLOCKED,
            scope_id=scope_id,
            scope_epoch=epoch,
            support_revision=int(support_revision),
            as_of_ms=int(now_ms),
            support_refs=(_typed(TypedRefKind.ACCEPTANCE, acceptance_id),),
        )
        subject = acceptance_subject(acceptance_id)
        stored = self._record_witness(mission_id, witness, subject=subject)
        if stored is None:
            # Since migration 18 the subject is part of the key, so this is no
            # longer the DATA lane colliding with the precondition lane: it is
            # this consumer already holding a *different* verdict about this
            # very acceptance at this very reading of the world.  Skipping is
            # the honest answer — the consumer then reports WAITING_DATA,
            # which is true — and the anomaly is written down.
            self._witness_key_taken(mission_id, witness, subject=subject)
            return None
        return stored

    def _carried_acceptances(self, mission_id: str, acceptance_id: str) -> list[tuple[str, int]]:
        """The acceptances a continuation producer's accepted Attempt was frozen with
        (acceptance id, support revision) — the real producers of what it hands on."""

        semantics = self.semantics()
        try:
            acceptance = semantics.get_acceptance(acceptance_id)
        except StoreError:
            return []
        if acceptance.mission_id != mission_id or not _is_continuation(
            semantics.task_semantics_of(mission_id, str(acceptance.task_id))
        ):
            return []
        try:
            frozen = decode_frozen_manifest(
                semantics.get_input_manifest(acceptance.input_manifest_hash)
            )
        except (StoreError, ContractError):
            return []  # the resolution names this source as unavailable; nothing to license
        found: dict[str, int] = {}
        for item in (*frozen.bindings, *frozen.deliveries):
            found.setdefault(item.acceptance_id, int(item.support_revision))
        return sorted(found.items())

    def _record_witness(
        self, mission_id: str, witness: ValidityWitness, *, subject: str
    ) -> ValidityWitness | None:
        """Store one witness, or answer what is already stored under its identity.

        Three outcomes, none of them an exception for the caller to interpret: the
        row is written; the very same row is already there (the same reading of the
        same world, re-issued) and comes back; or the *key* is held by a different
        licence and the answer is None.

        Since migration 18 the key carries ``subject`` — which object this licence was
        issued for — so the DATA lane and the precondition lane no longer contend for
        one row.  ``None`` now means what it always claimed to mean: two different
        conclusions about the *same* subject at the same reading of the world, which
        is a real contradiction and is reported rather than swallowed.

        Third-round review P2-1 closed the way that claim was still escapable.  Both
        production lanes derive ``witness_id`` from the key's own components, so a
        contention shows up as a **primary-key** conflict rather than an index one —
        and the old recovery re-read the row *by id* and returned it, whatever it
        said.  A second, opposite reading of the same world therefore inherited the
        first reading's ``USABLE`` licence in silence (visible the moment a revoke or
        supersede command exists: the same acceptance goes CURRENT → REVOKED and
        ``issue_input_witnesses`` hands back the old permission).  So the row that
        comes back is now *compared*: identical conclusion → the same licence,
        re-issued; different conclusion → ``None``, and the caller records
        :data:`WITNESS_KEY_TAKEN`.
        """

        try:
            semantics = self.semantics()
            semantics.insert_validity_witness(mission_id, witness, subject=subject)
            return witness
        except StoreError:
            for held in self.semantics().list_validity_witnesses(mission_id):
                if held.witness_id != witness.witness_id:
                    continue
                if _same_conclusion(held, witness):
                    return held
                return None
            return None

    def _witness_key_taken(
        self, mission_id: str, witness: ValidityWitness, *, subject: str
    ) -> None:
        """Record, once, that two conclusions were reached about the same subject.

        Before migration 18 this fired whenever the two licence lanes met, which was
        routine rather than exceptional.  With ``subject_digest`` in the key it fires
        only when the *same* consumer reaches a *different* verdict about the *same*
        subject at the same epoch and support revision — one reading of one world
        giving two answers.  That is a genuine anomaly and is written down.
        """

        append_hierarchical_event(
            self.store,
            WITNESS_KEY_TAKEN,
            mission_id,
            key=f"{mission_id}:{witness.consumer_ref.id}:{witness.scope_epoch}:"
            f"{witness.support_revision}:{subject}",
            task_id=str(witness.consumer_ref.id),
            payload={
                "consumer": str(witness.consumer_ref.id),
                "purpose": str(witness.purpose),
                "subject_digest": str(subject),
                "scope_id": witness.scope_id,
                "scope_epoch": int(witness.scope_epoch),
                "support_revision": int(witness.support_revision),
                "reason_codes": list(witness.reason_codes),
                "detail": (
                    "the validity_witnesses unique index holds one licence per "
                    "consumer per purpose per subject per scope epoch and support "
                    "revision, and this consumer already holds a different verdict "
                    "about that same subject at that same reading of the world; the "
                    "licence was not stored and the occurrence stays withheld rather "
                    "than running on a contested one"
                ),
            },
        )

    #: The reason code that records **which condition** a START-precondition witness
    #: was taken for.  The DATA lane answers that question with ``support_refs`` (the
    #: acceptance it covers); a condition is not a stored object and has no
    #: :class:`TypedRefKind`, so the digest travels as a reason code instead — the
    #: only alternative was guessing the link from the witness, which §11.5 calls
    #: exactly the thing a witness must never allow.  ``knowledge.validity`` owns the
    #: prefix so the storage subject and this module agree by construction.
    CONDITION_REASON_PREFIX = WITNESS_CONDITION_PREFIX

    def issue_start_witnesses(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot | None = None,
        *,
        now_ms: int | None = None,
        scope_id: str = "mission",
    ) -> tuple[ValidityWitness, ...]:
        """Re-read every occurrence's START preconditions and record the licence.

        P2.3c part 2c, found by the real-model smoke.  ``grounding.task_binding_for``
        gives every primitive child the *parent method's* ``applicable_when`` as a
        SELECT :class:`~..contracts.htn.PreconditionRef`, and TG §9 refuses to
        dispatch an occurrence whose START precondition has no ``purpose=START``
        :class:`ValidityWitness`.  Nothing issued one: ``issue_input_witnesses``
        covers the DATA lane only and ``grounding`` deliberately leaves
        ``witness_ref`` empty, so under a gated method every leaf sat in
        ``WAITING_EVIDENCE`` / ``witness_missing`` for ever — the plan committed, the
        duty was admitted, and no work was ever dispatched.

        It is the same shape as the DATA lane and for the same reason (I19): the
        conditions are **evaluated again now**, against the deployment's current
        evidence snapshot, and the verdict is written down with the support revision
        it was taken at.  A condition that no longer holds produces a ``BLOCKED``
        witness rather than none, so the refusal downstream says "the world moved"
        and not "nobody looked"; only an evaluation that
        :func:`~..planning.htn.applicability.authorization_gate` admits — TRUE with
        every leaf backed by a real observation or an authoritative denial (§6.6
        rule 2) — is ``USABLE``.

        One witness covers **all** of a consumer's START preconditions, and names
        each of them in its reason codes.  Since migration 18 the row is filed under
        ``conditions:<digest of that set>``, so "this consumer may start, now, on this
        reading of the world, over *these* conditions" is one row by construction —
        and it sits beside, rather than instead of, the DATA lane's licence for the
        same consumer.  ALL semantics make the combination honest — one UNKNOWN
        member is enough to withhold the whole licence (§6.6 rule 1).
        """

        try:
            world = self._world()
        except ContractError:
            # No PlanningWorld: the predicates and the evidence snapshot a condition is
            # judged against do not exist here, so no licence may be issued.  Fail
            # closed and say nothing new — the occurrences stay withheld with
            # ``witness_missing``, and the deployment defect is already reported by
            # ``HierarchicalAssemblyMissing`` / ``require_planning_world``.
            return ()
        semantics = self.semantics()
        snapshot = world.snapshot()
        network = self.network(mission_id) if network is None else network
        epoch = semantics.epoch(mission_id, scope_id)
        moment = int(self.store.now * 1000) if now_ms is None else int(now_ms)
        forms = {spec.occurrence_id: spec.form for spec in network.occurrences}
        issued: list[ValidityWitness] = []
        for draft in sorted(network.method_instances, key=lambda item: str(item.instance_id)):
            contract = world.registry.definition(draft.method_ref)
            if contract is None:
                # The method left the registry.  That is a recheck problem (§6.6 rule
                # 3), not a licence this method may invent from the frozen verdict.
                continue
            by_digest = {condition_digest(item): item for item in contract.applicable_when}
            if not by_digest:
                continue
            parameters = {binding.name: binding.value for binding in draft.grounded_parameters}
            evaluations = {
                digest: evaluate_condition(
                    by_digest[digest],
                    registry=world.predicates,
                    snapshot=snapshot,
                    parameters=parameters,
                    now_ms=moment,
                )
                for digest in sorted(by_digest)
            }
            truth = all_truth(tuple(item.truth for item in evaluations.values()))
            allowed = all(authorization_gate(item).allowed for item in evaluations.values())
            support: list[TypedRef] = []
            seen: set[tuple[str, str]] = set()
            for digest in sorted(by_digest):
                for reference in self._condition_support(
                    by_digest[digest], parameters=parameters, world=world, snapshot=snapshot
                ):
                    key = (str(reference.kind), str(reference.id))
                    if key in seen:
                        continue
                    seen.add(key)
                    support.append(reference)
            reasons = tuple(
                f"{self.CONDITION_REASON_PREFIX}{digest}" for digest in sorted(by_digest)
            )
            # The whole (sorted) condition set is what this licence covers, so it is
            # what the row is filed under.  ``condition_subject`` is the same function
            # the store re-runs over ``reason_codes`` before it writes.
            subject = condition_subject(by_digest)
            for child in sorted(draft.child_bindings, key=lambda item: str(item.occurrence_id)):
                if forms.get(child.occurrence_id) is not TaskForm.PRIMITIVE:
                    continue
                consumer = str(network.binding_for_occurrence(child.occurrence_id).task_id)
                witness = ValidityWitness(
                    witness_id="wit-pre-"
                    + content_hash_of(
                        {
                            "c": consumer,
                            "e": epoch,
                            "s": int(snapshot.support_revision),
                            "p": str(scope_id),
                            # The subject is part of the row's identity since
                            # migration 18, so it is part of the row's name too: a
                            # different condition set is a different licence, not a
                            # second verdict about the same one.
                            "j": subject,
                        }
                    )[:28],
                    consumer_ref=_typed(TypedRefKind.TASK, consumer),
                    purpose=WitnessPurpose.START,
                    truth=truth,
                    freshness=Validity.CURRENT,
                    availability=Availability.READABLE,
                    decision=(WitnessDecision.USABLE if allowed else WitnessDecision.BLOCKED),
                    scope_id=scope_id,
                    scope_epoch=epoch,
                    support_revision=int(snapshot.support_revision),
                    as_of_ms=moment,
                    support_refs=tuple(support),
                    reason_codes=reasons,
                )
                stored = self._record_witness(mission_id, witness, subject=subject)
                if stored is None:
                    self._witness_key_taken(mission_id, witness, subject=subject)
                    continue
                issued.append(stored)
        return tuple(issued)

    def _condition_support(
        self,
        condition: Any,
        *,
        parameters: Mapping[str, Any],
        world: PlanningWorld,
        snapshot: Any,
    ) -> tuple[TypedRef, ...]:
        """The observations the snapshot holds for this condition's own atoms.

        A licence that named nothing could not be audited back to what was read; a
        licence that named every observation of the Mission would say nothing about
        *this* condition.  Only the atoms of this condition are followed, and only
        as far as the snapshot already went — this method never observes.
        """

        refs: list[TypedRef] = []
        seen: set[tuple[str, str]] = set()
        for atom in iter_predicates((condition,)):
            signature = world.predicates.resolve(atom.predicate_ref)
            if signature is None:
                continue
            errors: list[str] = []
            arguments = {
                name: ground_value(item, parameters, path="precondition", errors=errors)
                for name, item in atom.arguments.items()
            }
            if errors or not world.predicates.check_arguments(signature, arguments).ok:
                continue
            entry = snapshot.lookup(proposition_key(signature, arguments))
            if entry is None:
                continue
            for reference in entry.observation_refs:
                key = (str(reference.kind), str(reference.id))
                if key in seen:
                    continue
                seen.add(key)
                refs.append(reference)
        return tuple(refs)

    def start_witness_index(self, mission_id: str) -> dict[str, dict[str, ValidityWitness]]:
        """consumer task id → condition digest → the freshest START witness for it.

        "Freshest" is the support revision the witness was taken at, then its clock:
        re-issuing after new evidence must not leave the earlier verdict in play, and
        a witness is keyed by what it concluded, so both rows exist in the library.
        """

        index: dict[str, dict[str, ValidityWitness]] = {}
        for witness in self.semantics().list_validity_witnesses(mission_id):
            if witness.purpose is not WitnessPurpose.START:
                continue
            if witness.consumer_ref.kind is not TypedRefKind.TASK:
                continue
            digests = [
                code[len(self.CONDITION_REASON_PREFIX) :]
                for code in witness.reason_codes
                if code.startswith(self.CONDITION_REASON_PREFIX)
            ]
            for digest in digests:
                held = index.setdefault(str(witness.consumer_ref.id), {}).get(digest)
                if held is not None and (held.support_revision, held.as_of_ms) >= (
                    witness.support_revision,
                    witness.as_of_ms,
                ):
                    continue
                index.setdefault(str(witness.consumer_ref.id), {})[digest] = witness
        return index

    def start_witnesses(self, mission_id: str, task_id: str) -> dict[str, ValidityWitness]:
        """condition digest → the START witness issued to ``task_id`` for it."""

        return self.start_witness_index(mission_id).get(str(task_id), {})

    def resolved_inputs(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        spec: OccurrenceSpec,
        *,
        accepted: AcceptedOutputsIndex | None = None,
        witnesses: Mapping[str, ValidityWitness] | None = None,
        now_ms: int | None = None,
    ) -> ResolutionResult:
        """The DATA gate's input, never ``None`` (P2.3c part 2).

        ``input_result`` answers ``None`` for an occurrence that declares no data
        requirement, and :func:`~..graph.eligibility.evaluate_readiness` reads ``None``
        as *"no input resolution was supplied"* — which is ``WAITING_DATA``.  That is
        the right answer for a caller that forgot to resolve, and the wrong one for an
        occurrence that has nothing to resolve: before this, every input-less leaf in
        the plan sat in ``WAITING_DATA`` forever and nothing could ever be dispatched.

        So an occurrence with no declared requirement gets an **empty frozen**
        manifest rather than no manifest.  "This dispatch consumed nothing" is a
        statement an ``Acceptance`` can quote and an ``input_manifest_hash`` can
        cover; "nobody resolved the inputs" is not, and the two must not share a
        representation.
        """

        result = self.input_result(
            mission_id, network, spec, accepted=accepted, witnesses=witnesses, now_ms=now_ms
        )
        if result is not None:
            return result
        return ResolutionResult(manifest=InputManifest(consumer_task_ref=spec.task_id))

    def accepted_outputs(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        *,
        outcomes: Mapping[OccurrenceId, OccurrenceOutcome] | None = None,
    ) -> AcceptedOutputsIndex:
        """What the resolver may choose from.

        P2.3b reads the *completed producers* from the completion scopes; a producer
        without an accepted output therefore gives ``WAITING_DATA`` rather than a
        silent all-ancestors sweep.
        """

        del outcomes  # the completion scopes below are the reading, not the projection
        if self.semantics().active_plan_revision(mission_id) is None:
            return AcceptedOutputsIndex(outputs=(), completed_producers=frozenset())

        statuses = {
            spec.occurrence_id: read_occurrence_completion(
                self.store, mission_id, str(spec.occurrence_id)
            )
            for spec in network.occurrences
        }
        prepared = frozenset(key for key, value in statuses.items() if value.preparation_ready)
        allowed_acceptances = {
            acceptance
            for value in statuses.values()
            for acceptance in value.preparation_acceptance_ids
        }

        completion_store = OperationCompletionStore(self.store)
        scoped_outputs = []
        for output in self._recorded_outputs(mission_id, network):
            state = statuses.get(output.producer_occurrence)
            if (
                state is None
                or output.acceptance_id not in allowed_acceptances
                or output.acceptance_id not in state.preparation_acceptance_ids
            ):
                continue
            row = completion_store.get_acceptance_scope_exact(mission_id, output.acceptance_id)
            if row is None:
                continue
            contribution = row["document"]
            if any(
                ref.id == output.artifact_id
                and str(ref.revision) == output.source_revision
                and ref.content_hash == output.content_hash
                for ref in contribution.output_artifact_refs
            ):
                scoped_outputs.append(output)
        # 片 B：完成的中间目标的端口对到它收尾步骤的产出；它也就成了"已完成的生产者"。
        done = frozenset(key for key, value in statuses.items() if value.complete)
        delivered = self.goal_port_outputs(mission_id, network, scoped_outputs, complete=done)
        # 授权版本（阶段 D）：一个生产者端口上"当前计数的那次验收"的产出版本。同一端口出现
        # 两个计数中的版本就不填——跟随的输入会如实报"授权版本读不到"，不任选。
        seen: dict[tuple[Any, str], set[str]] = {}
        for output in (*scoped_outputs, *delivered):
            seen.setdefault((output.producer_occurrence, output.output_port), set()).add(
                output.source_revision
            )
        return AcceptedOutputsIndex(
            outputs=(*scoped_outputs, *delivered),
            completed_producers=prepared | {item.producer_occurrence for item in delivered},
            authorized_revisions={
                key: next(iter(found)) for key, found in seen.items() if len(found) == 1
            },
        )

    def goal_port_outputs(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        outputs: Sequence[Any],
        *,
        complete: Collection[Any],
    ) -> tuple[Any, ...]:
        """片 B：完成的中间目标对外交付什么——它收尾步骤在同名端口上已验收的产出。

        一步执行时只铺通过输入端口接进来的上游产出；中间目标自己不执行、没有产出，接它端口的
        后续步骤要的其实是它下面做出来的东西。规则只有一条：目标的端口 = 采用做法的收尾步骤的
        同名端口（收尾步骤本身是子目标时再往下找）。只有 ``complete`` 里的目标（组合审阅通过、
        结论已形成）才对外交付，所以后续步骤拿到的一定是审过的那一版。

        返回的是别名：原产出记录原样，只把"生产者"换成这个目标，接它的数据依赖于是按原规则
        解析、发见证、冻结输入，文件归属仍是真正写出它的那一步。

        阶段 D（补全方案 2.2）：目标端口与收尾步骤同名端口声明的格式不同就不出别名——接它的步骤
        拿不到数据（数据未绑定），并记一条 ``GoalPortSchemaMismatch`` 说明是哪个目标哪个端口。
        """

        if not complete:
            return ()
        by_place: dict[tuple[str, str], list[Any]] = {}
        for item in outputs:
            by_place.setdefault((str(item.producer_occurrence), str(item.output_port)), []).append(
                item
            )
        roots = {str(item) for item in network.root_occurrence_ids}
        goals: list[tuple[Any, str, tuple[str, ...]]] = []
        for spec in network.occurrences:
            if (
                spec.form is not TaskForm.COMPOUND
                or str(spec.occurrence_id) in roots
                or spec.occurrence_id not in complete
            ):
                continue
            adopted = network.adopted_instance_for(spec.occurrence_id)
            ports = {
                str(port.port_key): port.schema_ref
                for port in network.binding_for_occurrence(spec.occurrence_id).output_ports
            }
            if adopted is None or not ports:
                continue
            try:
                contract = (
                    self.semantics()
                    .get_method(str(adopted.method_ref.method_id), int(adopted.method_ref.version))
                    .contract
                )
            except StoreError:
                continue
            finalizer = next(
                (
                    str(child.occurrence_id)
                    for child in adopted.child_bindings
                    if str(child.slot_key) == str(contract.composition.finalizer_step)
                ),
                None,
            )
            if finalizer is not None:
                goals.append((spec.occurrence_id, finalizer, ports))
        aliases: list[Any] = []
        moved = True
        while moved:  # a finalizer that is itself a sub-goal resolves one level per pass
            moved = False
            for goal, finalizer, ports in goals:
                for port, schema in ports.items():
                    if (str(goal), port) in by_place or (finalizer, port) not in by_place:
                        continue
                    delivered = {
                        str(item.port_key): item.schema_ref
                        for item in network.binding_for_occurrence(
                            OccurrenceId(finalizer)
                        ).output_ports
                    }
                    if delivered.get(port) != schema:
                        try:
                            append_hierarchical_event(
                                self.store,
                                "GoalPortSchemaMismatch",
                                mission_id,
                                key=f"{mission_id}:{goal}:{port}:{int(network.plan_revision)}",
                                payload={
                                    "goal_occurrence": str(goal),
                                    "port": port,
                                    "finalizer_occurrence": finalizer,
                                    "detail": "the goal's port and its finalizer step's port declare "
                                    "different formats; the goal delivers nothing on it",
                                },
                            )
                        except StoreError:
                            pass  # read from a read-only view: the note is written by the next writable read
                        continue
                    named = [
                        replace(item, producer_occurrence=goal)
                        for item in by_place[(finalizer, port)]
                    ]
                    by_place[(str(goal), port)] = named
                    aliases.extend(named)
                    moved = True
        return tuple(aliases)

    def _complete_goals(self, mission_id: str, network: TaskNetworkSnapshot) -> frozenset[Any]:
        """The non-root compound occurrences whose completion is recorded (片 B)."""

        roots = {str(item) for item in network.root_occurrence_ids}
        return frozenset(
            spec.occurrence_id
            for spec in network.occurrences
            if spec.form is TaskForm.COMPOUND
            and str(spec.occurrence_id) not in roots
            and network.binding_for_occurrence(spec.occurrence_id).output_ports
            and read_occurrence_completion(self.store, mission_id, str(spec.occurrence_id)).complete
        )

    def declared_output_ports_for(
        self, mission_id: str, task_id: str, network: TaskNetworkSnapshot | None = None
    ) -> tuple[dict[str, Any], ...]:
        """The output ports this leaf is expected to deliver on, for its own context.

        P2.3c part 2d, decision 4.  Part 2c's smoke ended here: the plan declared one
        output port, the model wrote two files under names of its own, and nothing had
        ever told it that ``repository_facts`` was the name the plan used.  The accept
        side then paired by substring (``artifacts/…`` matches a port called ``facts``)
        or by "one port, one file" — the guess TG design §10.2 forbids — or, honestly
        but uselessly, not at all.

        The ports come from :func:`~.accepted_outputs.output_ports_in_revision`, the
        same function the accept side checks against, so "which ports exist" has one
        answer rather than two.  A port is in this list because a ``DataRequirement``
        consumes it **or** because a ``criterion_link`` of the adopted method points at
        this occurrence (P2.3d / defect D3: the finalizer step's port has no downstream
        edge and the root's success criterion still reads it, so a leaf that was never
        told the port existed delivered nothing and the root review rejected the
        Mission).  An occurrence that is neither consumed nor criterion-linked feeds
        nobody and is not asked for at all.

        Deliberately **not** intersected with the binding's own ``output_ports``.  The
        memo describes the two sources as an intersection, and a port a live edge
        consumes while the producer's contract does not declare it *is* a real defect —
        but it is a defect in the **plan**, and answering it by quietly dropping the
        port here would hide it: the leaf would then be told to produce nothing, the
        consumer would wait for a port nobody was asked for, and the Mission would stall
        with no reason anybody could read.  Plan integrity is where that belongs, and
        until it refuses there, the honest thing is to ask for the port the edge needs
        and let ``OUTPUT_PORT_UNCLAIMED`` name it if it never arrives.  The binding is
        consulted for ``cardinality`` only, because that is where TG §4.3 declares it;
        a port the binding does not list is reported ``single``, the contract's own
        default.
        """

        semantics = self.semantics()
        active = semantics.active_plan_revision(mission_id)
        if active is None:
            return ()
        revision = int(active.revision)
        occurrence = next(
            (
                spec.occurrence_id
                for spec in semantics.list_plan_memberships(mission_id, revision)
                if str(spec.task_id) == str(task_id)
            ),
            None,
        )
        if occurrence is None:
            return ()
        ports = output_ports_in_revision(semantics, mission_id, revision, occurrence, str(task_id))
        binding = semantics.task_semantics_of(mission_id, str(task_id))
        specs = {} if binding is None else {item.port_key: item for item in binding.output_ports}
        del network  # the rows are the authority here; the network is not rebuilt
        return tuple(
            {
                "port": port,
                "required": True,
                "cardinality": (
                    str(specs[port].cardinality) if port in specs else str(PortCardinality.SINGLE)
                ),
                "schema": {"id": schema.id, "version": int(schema.version)},
            }
            for port, schema in sorted(ports.items())
        )

    def carried_root_criteria_for(
        self, mission_id: str, task_id: str
    ) -> tuple[dict[str, Any], ...]:
        """The root criteria this leaf is answerable for, for its own context (P2.3h).

        Read from the adopted method's ``criterion_links`` through
        :func:`~.accepted_outputs.carried_criteria_for` — the same rows the frozen
        completion scope projects the leaf's acceptance criteria from — so what the
        Worker is *told* it carries and what its acceptance is *held to* cannot drift
        apart.  Each entry
        names the root criterion, the leaf criterion it is judged under, the
        ``evidence_requirement`` the method wrote for the link (the sentence the
        leaf's report has to satisfy) and the ports that output is read from.

        The Grok C3 run is why: ``c-change-explained`` hung on a step whose only
        declared port carried code, the Worker was never told it owed an explanation
        anywhere, and the root reviewer correctly found none in the package.
        """

        semantics = self.semantics()
        active = semantics.active_plan_revision(mission_id)
        if active is None:
            return ()
        revision = int(active.revision)
        occurrence = next(
            (
                spec.occurrence_id
                for spec in semantics.list_plan_memberships(mission_id, revision)
                if str(spec.task_id) == str(task_id)
            ),
            None,
        )
        if occurrence is None:
            return ()
        links = carried_criteria_for(semantics, mission_id, revision, occurrence)
        if not links:
            return ()
        ports = sorted(
            output_ports_in_revision(semantics, mission_id, revision, occurrence, str(task_id))
        )
        goals: dict[str, str] = {}
        for item in links:
            parent = str(item.parent_task_id)
            if parent not in goals:
                root = semantics.task_semantics_of(mission_id, parent)
                goals[parent] = "" if root is None else str(root.goal_signature.statement)
        return tuple(
            {
                "root_criterion_id": str(item.parent_criterion_id),
                "root_task_id": str(item.parent_task_id),
                "root_goal_statement": goals[str(item.parent_task_id)],
                "leaf_criterion_id": str(item.leaf_criterion_id),
                "evidence_requirement": str(item.evidence_requirement),
                "ports": list(ports),
            }
            for item in links
        )

    def _recorded_outputs(self, mission_id: str, network: TaskNetworkSnapshot) -> Sequence[Any]:
        """The accepted outputs the resolver may choose from (P2.3c part 2).

        Read from migration 17's ``acceptance_outputs``, which is the *recorded*
        answer to "which artifact did this Acceptance accept, at which output port".
        P2.3b returned nothing here and said why: nothing in the schema held that
        fact, and taking the Attempt's artifacts and guessing the port from the path
        would be the all-ancestors sweep §24.1 decision 4 removed, wearing a typed
        name.

        The one writer is ``ResolutionCommitsMixin.accept_review`` (P2.3c part 2b),
        and it writes inside its own transaction only what
        :func:`.accepted_outputs.check_against_ports` passed — the same rule
        :func:`.accepted_outputs.check_declared` applies to a whole network, read off
        the committed ``DataRequirement`` rows instead of a rebuilt snapshot — so an
        entry exists only where the plan drew an edge.  A static guard in the suite
        keeps that the *only* writer.

        Two rows are dropped rather than offered, for the same reason in two lanes:

        * an occurrence this revision no longer contains — an accepted output of a
          retired branch is history, and the resolver choosing from it would bind a
          consumer to work the current plan does not do;
        * an entry whose ``Acceptance`` is no longer CURRENT — ``list_acceptance_outputs``
          joins ``acceptances`` and filters on validity (review F3), so a supersede or a
          revoke stops feeding consumers at the read rather than after them.
        """

        live = {str(spec.occurrence_id) for spec in network.occurrences}
        outputs: list[AcceptedOutput] = []
        for row in self.semantics().list_acceptance_outputs(mission_id):
            if str(row.get("producer_occurrence")) not in live:
                continue
            outputs.append(accepted_output_from_json(row))
        return tuple(outputs)

    # ------------------------------------------------------------------ the three reads
    def occurrences(self, mission_id: str) -> tuple[TaskView, ...]:
        """The new mode's ``list_tasks``: typed views in projection order."""

        view = self.read(mission_id)
        projection = view.network.execution_projection()
        ordered = [
            occurrence
            for occurrence in view.views
            if occurrence in projection.projected_occurrences
        ]
        unprojected = [
            occurrence
            for occurrence in view.views
            if occurrence not in projection.projected_occurrences
        ]
        order = [*sorted(ordered, key=str), *sorted(unprojected, key=str)]
        return tuple(view.views[occurrence] for occurrence in order)

    def seed_method_keys(self) -> set[tuple[str, int, str]]:
        """The deployment's own seed methods, as the adoption rule keys them (the plan-commit gate
        and the planner's candidate list read this one set)."""

        return seed_keys(getattr(self.require_planning_world(), "seed_methods", ()))

    def ready_occurrences(self, mission_id: str) -> tuple[OccurrenceId, ...]:
        """The ExecutionFrontier — not a ``TaskStatus.READY`` scan (TG §8.1)."""

        return self.read(mission_id).execution_frontier.occurrences

    def running_occurrences(self, mission_id: str) -> tuple[OccurrenceId, ...]:
        """The concurrency count: adopted primitive occurrences with a live Attempt.

        The *set* comes from the projection, so a compound is never counted as
        running work and a retired branch is never counted at all; the liveness
        comes from the Attempt rows, which is where it actually lives.
        """

        view = self.read(mission_id)
        projected = view.network.execution_projection().projected_occurrences
        live: list[OccurrenceId] = []
        for spec in view.network.occurrences:
            if spec.occurrence_id not in projected or spec.form is not TaskForm.PRIMITIVE:
                continue
            attempts = self.store.list_attempts(str(spec.task_id))
            if any(str(attempt.status) == "RUNNING" for attempt in attempts):
                live.append(spec.occurrence_id)
        return tuple(sorted(live, key=str))

    def root_review_ready(self, mission_id: str) -> bool:
        """Whether the root review may run at all (§7.2, TG §6.2).

        Every gating child of every adopted root method needs an accepted outcome
        first.  The parent's own state is deliberately not consulted: a review that
        waits for the parent it is supposed to conclude does not terminate.

        The root's required effects are not waited for to be *accepted* (Assurance 1.1
        §7.2, 2026-10-06 车道 O): the root review judges the content, the root resolution
        records that the business requirement is met, and the closeout converges the
        effects (UNKNOWN → BLOCKED_UNKNOWN) before anything completes.  Each effect is
        judged once, by its own OPERATION_OUTCOME review.  What *is* waited for is an
        effect still **in flight** (awaiting its intent, review, approval, execution or
        outcome review; rejected or failed and so the operation line's to resubmit): a
        root resolution formed then would freeze the content while the operation line
        may still have the planner rewrite it (a rejected publish), and a resolved duty
        admits no new work.  Settled = accepted or result unknown
        (``completion_status.EFFECT_SETTLED_STATES``, the closeout's own vocabulary).
        """

        view = self.read(mission_id)
        if view.plan.integrity_error is not None:
            return False
        roots = view.network.root_occurrence_ids
        if not roots:
            return False

        for root in roots:
            scope = read_occurrence_completion(self.store, mission_id, str(root)).scope
            for effect_key in scope.required_effect_keys:
                effect = read_current_effect(
                    self.store, mission_id, scope.spec_hash, str(effect_key)
                )
                if str(effect["state"]) not in EFFECT_SETTLED_STATES:
                    return False
            spec = view.network.occurrence(root)
            if spec.form is not TaskForm.COMPOUND:
                if view.outcomes.get(root) is not OccurrenceOutcome.ACCEPTED:
                    return False
                continue
            children = view.network.adopted_children(root)
            if not children:
                return False
            for binding in children:
                if binding.requiredness not in GATING_REQUIREDNESS:
                    continue
                if view.outcomes.get(binding.occurrence_id) is not OccurrenceOutcome.ACCEPTED:
                    return False
        return True

    def terminal(self, mission_id: str) -> bool:
        """Whether the Mission's work is finished, read from the resolutions."""

        view = self.read(mission_id)
        required = set(view.network.required_obligations)
        if not required:
            return False

        return all(
            read_occurrence_completion(self.store, mission_id, str(root)).complete
            for root in view.network.root_occurrence_ids
        )

    # --------------------------------------------------------- the root acceptance gate
    def root_contributions(self, mission_id: str) -> dict[str, tuple[str, ...]]:
        """Which occurrences of the adopted root method have a **CURRENT** content Acceptance.

        Read from the ``acceptances`` rows and not from the outcome projection.  They
        usually agree, and where they do not the store is right: an Acceptance that was
        superseded or revoked since the projection was computed is history, and a root
        resolution quoting it would be declaring the Mission complete on the strength
        of work nobody accepts any more (§21.5 "wrongly declared complete = 0").

        Effect acceptances are not contributions to the root review (Assurance §7.2,
        2026-10-06): an effect is judged by its own OPERATION_OUTCOME review and
        converges in the closeout; the root review is cut over the content, and an
        effect landing while it runs does not re-cut it.  The accepted effects' facts
        still reach the reviewer as materials (``_root_effect_materials``).
        """

        network = self.network(mission_id)
        scoped: dict[str, tuple[str, ...]] = {}
        for spec in network.occurrences:
            status = read_occurrence_completion(self.store, mission_id, str(spec.occurrence_id))
            if status.preparation_acceptance_ids:
                scoped[str(spec.occurrence_id)] = tuple(sorted(status.preparation_acceptance_ids))
        return scoped

    def root_resolution_inputs(self, mission_id: str) -> RootResolutionInputs:
        """Everything the root ``commit_goal_resolution`` command is built from.

        Every field is *read*, never invented.  The three that a deployment has to
        have produced beforehand — the ``MISSION_FINAL`` review package, its official
        record, and the ``purpose=ACCEPT`` witness — are reported as missing rather
        than fabricated: a Mission root resolution is formed out of the success
        formula plus the final acceptance (§6.3, §8.1), so a system that writes its
        own review anchor has decided the answer it was supposed to check.
        """

        network = self.network(mission_id)
        roots = network.root_occurrence_ids
        if len(roots) != 1:
            return RootResolutionInputs(
                reason="ROOT_NOT_SINGULAR",
                detail=(
                    f"this plan revision has {len(roots)} root occurrence(s); a Mission root "
                    "resolution is formed for one root goal and choosing among several would "
                    "be this module inventing a root"
                ),
            )
        root = roots[0]
        spec = network.occurrence(root)
        binding = network.binding_for_occurrence(root)
        semantics = self.semantics()
        existing = semantics.adopted_goal_resolution(mission_id, str(spec.obligation_id))
        if existing is not None:
            return RootResolutionInputs(
                reason="ALREADY_RESOLVED",
                detail=(
                    f"duty {spec.obligation_id!s} is already resolved by {existing.resolution_id!s}"
                ),
                occurrence_id=str(root),
            )
        package = self.live_root_review_package(
            mission_id, task_id=str(spec.task_id), obligation_id=str(spec.obligation_id)
        )
        if package is None:
            return RootResolutionInputs(
                reason="ROOT_REVIEW_PACKAGE_MISSING",
                detail=(
                    f"no MISSION_FINAL ReviewPackage is stored for task {spec.task_id!s}; the "
                    "root review has not been cut, so there is nothing to resolve from"
                ),
                occurrence_id=str(root),
            )
        # Review P1-7: the root's requirements are **the ones its review package was
        # cut against**, not whatever revision happens to be latest.
        # ``latest_requirements_revision`` used to answer this, but every leaf
        # acceptance publishes a Mission-level revision carrying *that leaf's*
        # coverage criteria — so one more leaf accepted between cutting the root
        # review and forming the resolution silently moved the Mission's criteria to
        # the last leaf's, and the resolution claimed coverage of something the
        # reviewer never saw.  The package's binding is the only revision that was
        # actually reviewed.
        try:
            requirements = semantics.get_requirements_revision(
                mission_id, int(package.binding.requirements_revision)
            )
        except StoreError:
            requirements = None
        if requirements is None:
            return RootResolutionInputs(
                reason="REQUIREMENTS_MISSING",
                detail=(
                    "the root review package names requirements revision "
                    f"{int(package.binding.requirements_revision)}, which this Mission does not "
                    "hold; there is nothing for the root resolution to claim coverage of (§6.3)"
                ),
                occurrence_id=str(root),
            )
        record = semantics.official_review_record(str(package.package_id))
        if record is None:
            return RootResolutionInputs(
                reason="ROOT_REVIEW_RECORD_MISSING",
                detail=(
                    f"review package {package.package_id!s} has no official ReviewRecord; the "
                    "final review has not concluded"
                ),
                occurrence_id=str(root),
            )
        # Handoff item 7: the root is licensed by the current UseCertificate
        # ``attempt_root_resolution`` prepares.
        instance = network.adopted_instance_for(root)
        # Direct children of the adopted root method, not every Acceptance in the
        # Mission: what supports the root is each direct child's current completion
        # support (a leaf's accepted contribution, an inner goal's resolution).

        contributions = current_child_supports(
            self.store, mission_id, network.adopted_children(root)
        )
        return RootResolutionInputs(
            reason="",
            occurrence_id=str(root),
            task_id=str(spec.task_id),
            obligation_id=str(spec.obligation_id),
            contract_revision=int(binding.contract_revision),
            method_instance_id=None if instance is None else str(instance.instance_id),
            requirements=requirements,
            package=package,
            record=record,
            contributions=contributions,
            root_form=str(spec.form),
        )

    def superseded_review_packages(self, mission_id: str) -> frozenset[str]:
        """The ``MISSION_FINAL`` packages a re-cut has retired (P2.3c part 3a).

        A :class:`~...contracts.resolution.ReviewPackage` is an immutable anchor, so
        "this review no longer counts" cannot be a column on it — it is the
        :data:`ROOT_REVIEW_SUPERSEDED` event, and this is the one reader of it.
        """

        return frozenset(
            str(event.payload.get("package_id", ""))
            for event in self.store.list_events(mission_id)
            if event.type == ROOT_REVIEW_SUPERSEDED
        )

    def live_root_review_package(
        self, mission_id: str, *, task_id: str, obligation_id: str
    ) -> ReviewPackage | None:
        """The ``MISSION_FINAL`` package this root resolves from, or ``None``.

        Three rules, in order, and each of them exists because of a way this could
        answer wrongly:

        1. only packages cut for **this** root, so a Mission with two roots in its
           history cannot have one root's review resolve the other;
        2. never a **superseded** one — the whole point of a re-cut is that the older
           anchor described a world that has moved;
        3. among what is left, the **last one this deployment cut**.  The order comes
           from the :data:`ROOT_REVIEW_CUT` events rather than from ``created_at``,
           because two packages written in the same clock tick have no order in the
           rows at all.  A package nobody recorded a cut for is not ranked against
           one that was: a recorded cut is this deployment saying "this is the anchor
           now", and an unrecorded package is one somebody stored directly — so the
           recorded ones win outright, and the old first-stored answer is kept for a
           Mission that has none.
        """

        semantics = self.semantics()
        retired = self.superseded_review_packages(mission_id)
        candidates = [
            item
            for item in semantics.list_review_packages(
                mission_id, purpose=ReviewPurpose.MISSION_FINAL
            )
            if str(item.binding.subject_ref.id) == str(task_id)
            and str(item.binding.obligation_id) == str(obligation_id)
            and str(item.package_id) not in retired
        ]
        if not candidates:
            return None
        order = {
            str(event.payload.get("package_id", "")): index
            for index, event in enumerate(
                item for item in self.store.list_events(mission_id) if item.type == ROOT_REVIEW_CUT
            )
        }
        recorded = [item for item in candidates if str(item.package_id) in order]
        if not recorded:
            return candidates[0]
        recorded.sort(key=lambda item: order[str(item.package_id)])
        return recorded[-1]

    def attempt_root_resolution(
        self,
        mission_id: str,
        *,
        principal: PlanPrincipal,
        command_id: str,
        resolution_id: str | None = None,
        input_manifest_hash: str | None = None,
        required_delivery_stage: Any = None,
        delivery_receipt_ids: Sequence[str] = (),
        source: Mapping[str, Any] | None = None,
    ) -> RootResolutionOutcome:
        """Form the Mission's root :class:`GoalResolution`, or say why not.

        This is the only place a Mission's root resolution is proposed from, and it is
        deliberately a *proposal*: every rule that decides whether it may be formed —
        the adopted method, a valid Acceptance for every required child, coverage of
        every root criterion, the delivery contract, the witness — lives in
        ``ResolutionCommitsMixin.commit_goal_resolution`` and runs inside its
        transaction.  What this method does is read the facts the command is made of
        and hand them over; if it also decided, there would be two places that could
        declare a Mission complete and §21.5's "wrongly declared complete = 0" would
        depend on both of them agreeing.
        """

        self.require_hierarchical(mission_id)
        if not self.root_review_ready(mission_id):
            return RootResolutionOutcome(
                committed=False,
                reason="ROOT_REVIEW_NOT_READY",
                detail="a gating child of the adopted root method has no accepted outcome yet",
            )
        inputs = self.root_resolution_inputs(mission_id)
        if inputs.reason:
            return RootResolutionOutcome(
                committed=inputs.reason == "ALREADY_RESOLVED",
                reason=inputs.reason,
                detail=inputs.detail,
            )
        requirements = inputs.requirements
        assert requirements is not None and inputs.package is not None
        assert inputs.record is not None
        manifest_hash = input_manifest_hash or inputs.package.binding.input_manifest_hash
        resolution_id = resolution_id or f"res-{inputs.occurrence_id}"
        # Assurance §7.2（2026-10-06 车道 O）：根结论复述的是根的内容投影——根终审判的那一份；
        # 效果判据由各自的结果审阅判、收尾核对收敛，不写进根结论。

        try:
            root_scope = read_occurrence_completion(
                self.store, mission_id, inputs.occurrence_id
            ).scope
            projection = root_content_projection(requirements, root_scope)
        except (ContractError, StoreError) as error:
            return self._refuse_root_resolution(
                mission_id,
                inputs,
                command_id=command_id,
                reason="OP_COMPLETION_SCOPE_UNRESOLVED",
                detail="the root content projection could not be read: " + str(error),
            )
        # Handoff item 7: on the assured lane the licence is the current
        # UseCertificate over the bound MISSION_FINAL manifest, prepared here outside
        # the write lock and committed by ``commit_goal_resolution`` under it. The
        # resolution then restates the manifest's current effective grades.

        validity = getattr(self.commit, "_assurance_validity", None)
        try:
            if validity is None:
                raise AssuranceError("USE_CERTIFICATE_REQUIRED")
            candidate = validity.prepare_root_use(inputs.record, resolution_id=resolution_id)
        except AssuranceError as error:
            return self._refuse_root_resolution(
                mission_id,
                inputs,
                command_id=command_id,
                reason=error.code,
                detail="the current use certificate could not be prepared: " + str(error),
            )
        witness_id = candidate.certificate_id
        effective_grades: Mapping[str, str] | None = candidate.effective_grades
        resolution = GoalResolution(
            resolution_id=GoalResolutionId(resolution_id),
            mission_id=mission_id,
            obligation_id=inputs.obligation_id,
            goal_task_id=inputs.task_id,
            requirements_version=int(requirements.revision),
            contract_revision=int(inputs.contract_revision),
            method_instance_id=inputs.method_instance_id,
            input_manifest_hash=manifest_hash,
            artifact_refs=(),
            child_resolution_ids=tuple(
                str(item.resolution_id)
                for item in self.semantics().list_goal_resolutions(mission_id)
                if str(item.resolution_id)
                in {source_id for ids in inputs.contributions.values() for source_id in ids}
            ),
            # Review F4: every verdict is **read from the official review record**, and
            # a criterion the record did not judge is written ``UNKNOWN``.  Writing
            # ``PASS`` for all of them — what this used to do — put an unevidenced
            # assertion into a permanent record: the accept side only refuses a verdict
            # that *contradicts* the record and a required criterion that is *missing*,
            # so a criterion nobody reviewed and no rule quotes would have been stored
            # as passed forever.  It is the same rule this command already follows for
            # ``composition_obligation_passed``: restate the review, never overrule or
            # extend it.  A required criterion the record left unjudged now shows up as
            # UNKNOWN and the AER §6.2 formula answers for it, instead of the trigger
            # answering on the reviewer's behalf.
            criteria=_root_criteria(
                projection.criteria,
                inputs.record,
                effective_grades=effective_grades,
            ),
            review_receipt_id=str(inputs.record.record_id),
            verdict=ReviewVerdict.ACCEPT,
            validity=Validity.CURRENT,
        )
        command = CommitGoalResolutionCommand(
            command_id=command_id,
            mission_id=mission_id,
            resolution=resolution,
            package=inputs.package,
            record=inputs.record,
            requirements=requirements,
            witness_id=witness_id,
            # No defaults anywhere, and nothing asserted: the facts are **read off
            # the package**, which is the frozen anchor that recorded who produced
            # the candidate at the time it was cut (AER §5.3).  Part 3a's review
            # coordinator fills those in, so a root review whose reviewer is one of
            # the producers now refuses (``INDEPENDENT_REVIEW_MISSING``) instead of
            # passing vacuously on an empty set.  ``reviewer_can_write_candidate`` is
            # derived from the package's own workspace access rather than stated:
            # ``WRITE`` is refused at construction, so this reads False for every
            # package that exists — and it reads it from the anchor instead of from
            # a caller who could say otherwise.
            independence=IndependenceFacts(
                producer_agent_ids=tuple(inputs.package.producer_agent_ids),
                reviewer_can_write_candidate=(
                    inputs.package.reviewer_workspace_access is WorkspaceAccess.WRITE
                ),
            ),
            posture=ExecutionPosture(),
            read_set=self.read_set_for_root(mission_id, inputs),
            decided_at_ms=int(self.store.now * 1000),
            purpose=ReviewPurpose.MISSION_FINAL,
            # ``CompoundFacts`` is "the two things only the caller can know", and both
            # are *read* here rather than asserted.  ``composition_obligation_passed``
            # in particular: hard-coding ``True`` would be this trigger claiming, on
            # the reviewer's behalf, that the composition held — which is precisely the
            # shape "wrongly declared complete = 0" exists to forbid.  It is the
            # official review record's own verdict.  (The *contributions* are never
            # taken from the command either: ``commit_goal_resolution`` re-derives them
            # from the store and refuses a mismatch with
            # ``COMPOUND_FACTS_CONTRADICT_STORE``.)
            # A root that *is* one primitive occurrence (no adopted method and read
            # as ``primitive`` off the network) has no compound facts to state: the
            # accept side would otherwise refuse the statement itself
            # (``METHOD_INSTANCE_NOT_ADOPTED``) before any rule ran.  A compound root
            # without an adopted method still states them and is still refused.
            compound=(
                None
                if inputs.method_instance_id is None and inputs.root_form == str(TaskForm.PRIMITIVE)
                else CompoundFacts(
                    selected_method_legal=inputs.method_instance_id is not None,
                    contributing_occurrence_ids=tuple(sorted(inputs.contributions)),
                    # 2026-09-30 真机第 6 局：两次判不下来、人裁决通过的最终审查同样算组合义务达成
                    composition_obligation_passed=accepted_or_adjudicated(
                        self.store, inputs.record
                    ),
                )
            ),
            is_mission_root=True,
            required_delivery_stage=required_delivery_stage,
            delivery_receipts=tuple(str(item) for item in delivery_receipt_ids),
            issued_by=principal.principal_id,
            scope_id=principal.scope_id,
            source=dict(source or {}),
        )
        # The accept side authenticates against its *own* principal type.  Two types
        # rather than one shared "principal" because the two sides authorise different
        # things: ``PlanPrincipal`` carries the manager epoch a plan commit is checked
        # against, and passing it here would be refused as ``BAD_PRINCIPAL`` — which is
        # exactly what it should be, since the caller would not have said whose accept
        # authority it is claiming.
        accepting = ResolutionPrincipal(
            principal_id=principal.principal_id, scope_id=principal.scope_id
        )
        try:
            receipt = self.commit.commit_goal_resolution(command, accepting)
        except ResolutionCommitRejected as error:
            return self._refuse_root_resolution(
                mission_id, inputs, command_id=command_id, reason=error.reason, detail=error.detail
            )
        finally:
            if candidate is not None:
                # Committed or refused, the candidate is history; the next attempt
                # re-prepares from the current sources (never a licence by retry).
                self.commit._assurance_validity.forget(mission_id, str(inputs.record.record_id))
        return RootResolutionOutcome(
            committed=True,
            reason="",
            resolution_id=str(receipt.resolution_id),
            detail="",
        )

    def _refuse_root_resolution(
        self,
        mission_id: str,
        inputs: RootResolutionInputs,
        *,
        command_id: str,
        reason: str,
        detail: str,
    ) -> RootResolutionOutcome:
        self._append(
            ROOT_RESOLUTION_REFUSED,
            mission_id,
            key=f"{mission_id}:{command_id}:{reason}",
            task_id=inputs.task_id,
            payload={
                "reason": reason,
                "detail": detail,
                "command_id": command_id,
                "occurrence_id": inputs.occurrence_id,
                "obligation_id": inputs.obligation_id,
            },
        )
        return RootResolutionOutcome(committed=False, reason=reason, detail=detail)

    def read_set_for_root(self, mission_id: str, inputs: RootResolutionInputs) -> SemanticReadSet:
        """The semantic read-set the root commit is checked against.

        It names what this proposal actually read: the root task's contract revision,
        the requirements revision, the manager epoch and the mission scope epoch.  The
        commit re-reads every one of them, so an epoch that moved between this read and
        the transaction refuses the command — which is the point of recording it rather
        than letting the commit assume nothing changed.
        """

        semantics = self.semantics()
        binding = semantics.task_semantics_of(mission_id, inputs.task_id)
        goal_reads: tuple[ReadItem, ...] = ()
        if binding is not None:
            goal_reads = (
                ReadItem(
                    kind=ReadItemKind.TASK,
                    id=str(binding.task_id),
                    semantic_revision=int(binding.contract_revision),
                    content_hash=binding.contract_hash,
                ),
            )
        assert inputs.requirements is not None
        return SemanticReadSet(
            requirements_revision=int(inputs.requirements.revision),
            goal_revisions=goal_reads,
            scope_epochs=(
                ScopeEpochRead(
                    scope_id="mission", validity_epoch=semantics.epoch(mission_id, "mission")
                ),
            ),
        )

    # ------------------------------------------------------- the admission transaction
    def admissions(self, mission_id: str, *, now_ms: int | None = None) -> DispatchAdmissions:
        """Run the readiness gate over the whole plan and admit what passed (TG §8.3).

        This is the input :func:`~..scheduling.allocator.allocate_v2` takes, and it is
        the answer to P2.3b's blocker (b): before P2.3c part 2 the event handler only
        asked the *form* gate before creating an Attempt, so a DATA consumer whose
        producer had not been accepted was dispatched with no inputs and ran anyway.
        Now every occurrence goes through ``evaluate_readiness`` first and only a
        ``READY_CANDIDATE`` reaches ``admit_for_dispatch``.

        Three properties worth stating, because each is a way this could have been
        written wrongly:

        * **One read.**  ``self.read()`` fetches the acceptance projection, the
          witnesses and the duty accounts once and every occurrence is judged against
          that same snapshot, so the plan cannot move between two occurrences'
          verdicts — and ``admit_for_dispatch``'s ``_same_origin`` check would refuse
          the admission if it had.
        * **A refusal is never an admission with a flag.**  An occurrence that is not
          ready simply has no :class:`EligiblePrimitiveTask`; the allocator takes only
          admissions, so there is no field a caller could misread as a permission.
        * **``NotEligible`` at this point is fail-closed, not a retry.**  A report that
          said ``READY_CANDIDATE`` and an admission that refuses it means the report
          and the view disagree — a race or a caller bug — and the honest answer is to
          withhold this occurrence with the refusal text, not to admit it anyway.
        """

        view = self.read(mission_id, now_ms=now_ms)
        moment = int(self.store.now * 1000) if now_ms is None else int(now_ms)
        network = view.network
        # Review F8: taken from the view, not read again.  The acceptance projection and
        # the DATA lane's licences (keyed by acceptance id per consumer — see ``read``
        # for why the precondition map cannot answer that question) are what the
        # readiness reports on this view were computed against, and hashing a manifest
        # built from a *second* read would mean the report and the admission describe
        # two different moments.
        accepted = view.accepted
        licences = view.licences
        bindings: dict[str, TaskSemanticBindingV1] = {}
        readiness: dict[str, EligiblePrimitiveTask] = {}
        refusals: list[DispatchRefusal] = []
        for spec in network.occurrences:
            task_id = str(spec.task_id)
            task_view = view.views[spec.occurrence_id]
            if task_view.binding is not None:
                bindings[task_id] = task_view.binding
            task = self.store.get_task(task_id)
            if task is not None and task.accepted_result_id:
                # 阶段 E：这一步已有通过的结果。结果在现行要求下算数 → 等完成，不再派执行者。
                # 是按旧版要求通过的、现在不算数 → 不派执行者：系统请审阅员按新要求重审同一份结果
                # （TaskGraph 补全第四批）；重审没过 → 如实报出来，换掉这一步或换做法由规划器定。
                counts = self._accepted_result_counts(mission_id, str(spec.occurrence_id))
                # 按需导入：循环依赖（hierarchical_dispatch ↔ carried_review）
                from .carried_review import (
                    CARRIED_RESULT_NOT_KEPT,
                    CARRIED_RESULT_REJECTED,
                    CARRIED_REVIEW_PENDING,
                    kept,
                    rejected,
                )

                latest = self.semantics().latest_requirements_revision(mission_id)
                refused = (
                    not counts
                    and latest is not None
                    and rejected(self.store, task.accepted_result_id, int(latest.revision))
                )
                changed = (
                    not counts
                    and not refused
                    and latest is not None
                    and not kept(self.store, task.accepted_result_id, int(latest.revision))
                )
                refusals.append(
                    DispatchRefusal(
                        task_id=task_id,
                        occurrence_id=str(spec.occurrence_id),
                        reason=ReadinessReason.NOT_SELECTED,
                        detail_codes=("PREPARATION_ALREADY_ACCEPTED",)
                        if counts
                        else (CARRIED_RESULT_REJECTED,)
                        if refused
                        else (CARRIED_RESULT_NOT_KEPT,)
                        if changed
                        else (CARRIED_REVIEW_PENDING,),
                        detail="accepted preparation is waiting for completion, not another Worker"
                        if counts
                        else (
                            "this step's result was accepted under an earlier revision of the requirements and "
                            "its review under the current ones ended without an acceptance; it is not re-run "
                            "automatically — replace the step (PROPOSE_SUCCESSOR) or its method"
                        )
                        if refused
                        else (
                            "this step's result was accepted under an earlier revision of the requirements and "
                            "the step itself has changed since (its inputs or contract), so the old result "
                            "cannot be kept — replace the step (PROPOSE_SUCCESSOR) or its method"
                        )
                        if changed
                        else (
                            "this step's result was accepted under an earlier revision of the requirements; "
                            "the reviewer is judging the same result under the current ones (after its "
                            "inputs count) — no Worker runs"
                        ),
                    )
                )
                continue
            report = view.reports[spec.occurrence_id]
            if not report.ready:
                refusals.append(
                    DispatchRefusal(
                        task_id=task_id,
                        occurrence_id=str(spec.occurrence_id),
                        reason=report.reason,
                        detail_codes=report.detail_codes,
                        detail="; ".join(detail.message for detail in report.details),
                    )
                )
                continue
            # NEXT-TG-1.0 §5.2: the resolution the report was judged against — not a
            # second resolution, and never an empty manifest standing in for none.
            result = view.resolutions.get(spec.occurrence_id)
            manifest = None if result is None else result.manifest
            if manifest is None:
                refusals.append(
                    DispatchRefusal(
                        task_id=task_id,
                        occurrence_id=str(spec.occurrence_id),
                        reason=ReadinessReason.STALE_BINDING,
                        detail_codes=("input_resolution_absent",),
                        detail="the read that judged this occurrence ready carries no input manifest",
                    )
                )
                continue
            try:
                readiness[task_id] = admit_for_dispatch(
                    report, task_view, view.plan, manifest, now_ms=moment
                )
            except (NotEligible, ManifestNotFrozen) as error:
                refusals.append(
                    DispatchRefusal(
                        task_id=task_id,
                        occurrence_id=str(spec.occurrence_id),
                        reason=ReadinessReason.STALE_BINDING,
                        detail_codes=("admission_refused",),
                        detail=str(error),
                    )
                )
        return DispatchAdmissions(
            plan_revision=int(network.plan_revision),
            bindings=bindings,
            readiness=readiness,
            refusals=tuple(refusals),
        )

    def _accepted_result_counts(self, mission_id: str, occurrence_id: str) -> bool:
        """Whether this step's completion rests on an acceptance right now — the completion
        reading's answer (the same one the Planner package's ``counts_under_current`` gives)."""

        try:
            return bool(
                read_occurrence_completion(
                    self.store, mission_id, occurrence_id
                ).preparation_acceptance_ids
            )
        except (ContractError, StoreError):
            return (
                True  # unreadable completion is reported by its own path, not as "old requirements"
            )

    def record_withheld(self, mission_id: str, admissions: DispatchAdmissions) -> tuple[Event, ...]:
        """Record every structured refusal once per (occurrence, revision, reason).

        The idempotency key carries the plan revision *and* the reason, and
        ``Store.append_event`` returns the stored row for a key it already holds — so
        a Mission that waits ten cycles for a producer leaves one event rather than
        ten, and a Mission whose reason *changes* leaves the new one beside it.  That
        is the difference between a log an operator can read and a log that drowns the
        one line that mattered.
        """

        return tuple(
            self._append(
                DISPATCH_WITHHELD,
                mission_id,
                key=(
                    f"{mission_id}:{refusal.task_id}:{admissions.plan_revision}:{refusal.reason!s}"
                ),
                task_id=refusal.task_id,
                payload={"plan_revision": int(admissions.plan_revision), **refusal.to_json()},
            )
            for refusal in admissions.refusals
        )

    # -------------------------------------------------------------- the dispatch gate
    def intercept_worker_dispatch(
        self, mission_id: str, task_id: str
    ) -> DispatchInterception | None:
        """Refuse a compound before the old READY entry can dispatch it.

        The gate is ``form`` from the semantic binding (§18.5 rule 4), asked of
        :func:`legacy_ready_is_not_eligibility` so the allocator wiring in P2.3c and
        this one cannot disagree about the answer.  A primitive returns None here —
        which is not a permission, only "this gate has nothing to say".
        """

        binding = self.semantics().task_semantics_of(mission_id, task_id)
        if binding is None:
            raise missing_bindings(mission_id, [task_id])
        task = self.store.get_task(task_id)
        verdict = legacy_ready_is_not_eligibility(
            "" if task is None else str(task.status), form=binding.form
        )
        if verdict.gate_reason is None:
            return None
        occurrence = self._occurrence_of(mission_id, task_id)
        interception = DispatchInterception(
            task_id=task_id,
            occurrence_id=None if occurrence is None else str(occurrence),
            reason=str(verdict.gate_reason),
            explanation=verdict.explanation,
        )
        self._append(
            DISPATCH_INTERCEPTED,
            mission_id,
            key=f"{mission_id}:{task_id}:{interception.reason}",
            task_id=task_id,
            payload={
                "task_id": task_id,
                "occurrence_id": interception.occurrence_id,
                "form": str(binding.form),
                "reason": interception.reason,
                "legacy_status": "" if task is None else str(task.status),
                "explanation": interception.explanation,
            },
        )
        return interception

    def record_integrity_failure(self, mission_id: str, error: GraphIntegrityError) -> Event:
        """Record that one Mission's plan is damaged, with the diagnosis (TG §14.3).

        The durable record is the point: the caller is about to stop *this* Mission
        and leave every other Mission in the run alone, so what went wrong has to be
        readable afterwards without re-deriving it from a traceback that no longer
        exists.  Deliberately no topological order in the payload — a damaged
        projection's healthy prefix is a partial order, not a plan.
        """

        code = str(error.code)
        return self._append(
            PLAN_INTEGRITY_FAILED,
            mission_id,
            key=f"{mission_id}:{code}:{content_hash_of(sorted(error.remaining))[:16]}",
            payload={
                "code": str(code),
                "subjects": sorted(str(item) for item in error.remaining),
                "cycle": [str(item) for item in error.cycle],
                "diagnose": error.diagnose(),
            },
        )

    def _occurrence_of(self, mission_id: str, task_id: str) -> OccurrenceId | None:
        try:
            network = self.network(mission_id)
        except GraphIntegrityError:
            return None
        for spec in network.occurrences:
            if str(spec.task_id) == task_id:
                return spec.occurrence_id
        return None

    # ----------------------------------------------------------- compound phase driver
    def advance_compound_phases(self, mission_id: str) -> dict[OccurrenceId, CompoundPhase]:
        """Run the typed reducer over every compound and record what changed.

        No Attempt is created and no legacy Task row is written: the phase is a
        *projection* of typed state, so the only durable trace is the event.
        """

        view = self.read(mission_id)
        phases: dict[OccurrenceId, CompoundPhase] = {}
        for spec in view.network.occurrences:
            if spec.form is not TaskForm.COMPOUND:
                continue
            children = {
                binding.occurrence_id: view.outcomes.get(
                    binding.occurrence_id, OccurrenceOutcome.UNKNOWN
                )
                for binding in view.network.adopted_children(spec.occurrence_id)
            }
            phase = next_compound_phase(
                spec,
                view.network,
                view.reports[spec.occurrence_id],
                child_outcomes=children,
                resolved=spec.occurrence_id in view.resolved,
            )
            phases[spec.occurrence_id] = phase
            self._append(
                COMPOUND_PHASE_CHANGED,
                mission_id,
                key=f"{mission_id}:{spec.occurrence_id!s}:{int(view.network.plan_revision)}:{phase!s}",
                task_id=str(spec.task_id),
                payload={
                    "occurrence_id": str(spec.occurrence_id),
                    "task_id": str(spec.task_id),
                    "plan_revision": int(view.network.plan_revision),
                    "phase": str(phase),
                    "display_status": str(COMPOUND_DISPLAY_STATUS[phase]),
                    "readiness_reason": str(view.reports[spec.occurrence_id].reason),
                },
            )
        return phases

    # ------------------------------------------------------------------ one plan round
    # ----------------------------------------------- context for proposing a method
    def method_proposal_context(self, mission_id: str, goal_task_id: str) -> dict[str, Any]:
        """What the Planner needs to write a method for this goal (片 A 第 4 项).

        Built from the deployment's own declarations — the operators it really
        registered, the capability table, and the four-axis report explaining why
        each existing method for this goal type does not apply — plus the original
        wording of every requirement the goal covers and the identity a new method
        should take.  Nothing about the principal or any budget account is in it.
        """

        world = self._world()
        network = self.network(mission_id)
        goal = network.binding_for_task(TaskRef(str(goal_task_id)))
        reports: dict[str, Any] = {}
        signature = goal.goal_signature
        for reference in world.registry.method_refs():
            if not world.registry.retrievable(reference, mission_id=MissionRef(mission_id)):
                continue
            contract = world.registry.definition(reference)
            if contract is None or contract.goal_type_ref.id != signature.signature_id:
                continue
            reports[f"{contract.method_id}@{int(contract.method_version)}"] = _assess(
                goal,
                contract,
                world.snapshot(),
                world.capabilities(),
                registry=world.predicates,
            )
        request = build_context(
            goal,
            world.capabilities(),
            world.registry,
            catalog=world.catalog,
            reports=reports,
            mission_id=mission_id,
        )

        # 2026-09-29 第十局：criterion_evidence 原先给每个编号配同一句总目标，模型看不出
        # c-user-3 是"跑测试"、c-user-6 是"写出 README.md"，只能按目标描述自己猜编号，
        # 把文件要求链到了错的步骤。有任务要求原文的编号换成它自己的原文。
        requirements = self.semantics().latest_requirements_revision(mission_id)
        statements = (
            {}
            if requirements is None
            else {str(item.criterion_id): str(item.statement) for item in requirements.criteria}
        )
        if statements:
            request = replace(
                request,
                criterion_evidence=tuple(
                    {
                        "id": item["id"],
                        "evidence_requirement": (
                            criterion_statement(statements[item["id"]])
                            if item["id"] in statements
                            else item["evidence_requirement"]
                        ),
                    }
                    for item in request.criterion_evidence
                ),
            )
        # 片 B：中间目标的类型不声明判据，它负责的是上级做法分给它的要求（原编号、用户原话）。
        # 夜间 N6：读不出分给它的那一份时如实写进材料（criterion_share_unreadable），不当成"没有"。
        # 按需导入：循环依赖（hierarchical_dispatch ↔ assurance_check_policy）
        from .assurance_check_policy import goal_share

        listed = {item["id"] for item in request.criterion_evidence}
        unreadable: dict[str, str] | None = None
        try:
            share = goal_share(self.store, mission_id, goal)
        except OperationCompletionError as error:
            share, unreadable = (), {"code": str(error.code), "detail": str(error)}
        handed = [item for item in share if item in statements and item not in listed]
        if handed:
            request = replace(
                request,
                criterion_evidence=tuple(request.criterion_evidence)
                + tuple(
                    {"id": item, "evidence_requirement": criterion_statement(statements[item])}
                    for item in handed
                ),
            )
        fresh_id = "proposed-" + content_hash_of({"goal_task_id": str(goal_task_id)})[:24]
        occupied = [
            int(item.contract.method_version)
            for item in self.semantics().list_methods()
            if item.contract.method_id == fresh_id
        ]
        document = replace(
            request, new_method_identity=(fresh_id, max(occupied, default=0) + 1)
        ).to_json()
        document["subgoal_types"] = self._subgoal_types(world, signature)
        if unreadable is not None:
            document["criterion_share_unreadable"] = unreadable
        return document

    @staticmethod
    def _subgoal_types(world: Any, signature: Any) -> list[dict[str, Any]]:
        """片 B：这个目标的做法里可以放的子目标类型——比它更深一层的那些。

        层数上限由类型的层级保证（注册检查拒收同层或更浅的子目标），这里只是把"能放什么"
        如实告诉规划器；要不要再拆一层由它判断。目标类型没有层级，或没有更深的类型，就是空。
        """

        owner = next(
            (
                spec
                for spec in world.catalog.task_types()
                if spec.goal_signature.signature_id == signature.signature_id
                and int(spec.goal_signature.version) == int(signature.version)
            ),
            None,
        )
        if owner is None or owner.refinement_level is None:
            return []
        rows = []
        for spec in sorted(
            world.catalog.task_types(),
            key=lambda item: (item.refinement_level or 0, item.task_type_ref.id),
        ):
            if (
                spec.form is not TaskForm.COMPOUND
                or spec.refinement_level is None
                or spec.refinement_level <= owner.refinement_level
            ):
                continue
            rows.append({**task_type_row(spec, world.schemas), "level": int(spec.refinement_level)})
        return rows

    # ------------------------------------------------- rejected refinements (P2.3j)
    def retired_methods(self, mission_id: str) -> tuple[dict[str, Any], ...]:
        """做法在哪个目标上被采用过、又被哪次修复决定退役——事实清单（片 0 第 4 步，2026-10-01）。

        规划包据此在做法库条目上标"被退役过 + 原因"（``rejected_reasons``）。原因是规划器
        自己当时写下的理由和那次决定处理的修复请求，不是 Harness 的结论；Harness 不据此禁止
        再选这个做法。此前这里按原因分成"被最终审查拒绝""被只读步骤越权拒绝"两个标记，由
        Harness 写入并据此拦截再次采用。

        只列目标还在当前计划里的；退役它的那次计划提交找不到的（不是规划决定退役的）不列。
        """

        network = self.network(mission_id)
        present = {str(spec.occurrence_id) for spec in network.occurrences}
        commits: dict[str, Mapping[str, Any]] = {}
        addressed: dict[str, list[str]] = {}
        requests: dict[str, dict[str, Any]] = {}
        for event in self.store.iter_events(mission_id):
            if event.type == PLAN_REVISION_COMMITTED:
                for instance_id in event.payload.get("retired_method_instances", ()):
                    commits[str(instance_id)] = event.payload
            elif event.type == "PlanningRepairAddressed":
                addressed[str(event.payload.get("decision_id"))] = [
                    str(item) for item in event.payload.get("repair_request_ids", ())
                ]
            elif event.type == "PlanningRepairRequested":
                request = event.payload.get("request") or {}
                requests[str(event.payload.get("request_id"))] = {
                    "trigger_source": request.get("trigger_source"),
                    "source_key": event.payload.get("source_key"),
                }
        decisions = planning_decision_store.PlanningDecisionStore(self.store)
        rows: list[dict[str, Any]] = []
        for draft in self.semantics().list_method_instances(mission_id, state="RETIRED"):
            occurrence = str(draft.goal_occurrence_id or draft.goal_id)
            commit = commits.get(str(draft.instance_id))
            if occurrence not in present or commit is None:
                continue
            row: dict[str, Any] = {
                "method_ref": draft.method_ref.to_json(),
                "occurrence_id": occurrence,
                "retired_instance_id": str(draft.instance_id),
                "retired_at_plan_revision": int(commit.get("plan_revision", 0)),
            }
            intent_id = str((commit.get("source") or {}).get("intent_id") or "")
            decision = decisions.committed_decision_for_intent(intent_id) if intent_id else None
            if decision is not None:
                body = json.loads(decision["canonical_json"])
                row["decision_id"] = str(decision["decision_id"])
                row["rationale"] = str(body.get("rationale", ""))[:600]
                row["requests"] = [
                    requests[item]
                    for item in addressed.get(str(decision["decision_id"]), ())
                    if item in requests
                ]
            rows.append(row)
        return tuple(
            sorted(rows, key=lambda item: (item["occurrence_id"], item["retired_instance_id"]))
        )

    def planner_round_in_flight(self, mission_id: str) -> bool:
        """An open ``plan`` intent that is a *Planner* round (not a review)."""

        return any(
            intent.kind == "plan"
            and intent.mission_id == mission_id
            and str(intent.config.get("role", "")) not in {"root_reviewer"}
            for intent in self.store.list_intents(
                "PENDING", "CLAIMED", "AGENT_CREATED", "SUBMITTED"
            )
        )

    def method_applicability(self, mission_id: str) -> tuple[Any, ...]:
        """Why each registered method does or does not apply to each still-open goal.

        Review F16: the hierarchical Planner package always passed ``reports=()``, so
        the ``applicability`` section the package's own docstring calls load-bearing
        was empty in every deployment — the Planner was told "no method fits" with no
        axis and no reason, which is the exact state the section exists to replace.

        P2.3n: applicable verdicts are reported too.  Omitting them left a round-2
        synthesised method (empty ``applicable_when`` → APPLICABLE) present only in
        ``method_library``; the v5 prompt reads "都被 applicability 拒绝" as
        ``no_applicable_method``, and Grok H-L3-C1-r0/r1 ordinal 5 did exactly that
        while the new method sat silently in the library.

        A refined goal that a pending repair request is about is assessed as well, so
        the repair round sees which methods could replace the adopted one.
        """

        world = self._world()
        network = self.network(mission_id)
        snapshot = world.snapshot()
        capabilities = world.capabilities()
        # 按需导入：循环依赖（hierarchical_dispatch ↔ planning_repair_requests）
        from .planning_repair_requests import repair_goal_occurrences

        repair_goals = set(repair_goal_occurrences(self.store, network))
        entries: list[Any] = []
        for spec in sorted(network.occurrences, key=lambda item: str(item.occurrence_id)):
            if spec.form is not TaskForm.COMPOUND:
                continue
            if (
                network.adopted_instance_for(spec.occurrence_id) is not None
                and str(spec.occurrence_id) not in repair_goals
            ):
                continue
            goal = network.binding_for_occurrence(spec.occurrence_id)
            signature = goal.goal_signature.signature_id
            for reference in world.registry.method_refs():
                if not world.registry.retrievable(reference, mission_id=MissionRef(mission_id)):
                    continue
                contract = world.registry.definition(reference)
                if contract is None or str(contract.goal_type_ref.id) != str(signature):
                    continue
                report = assess_method(
                    goal, contract, snapshot, capabilities, registry=world.predicates
                )
                entries.append(
                    MethodApplicability(
                        goal_occurrence_id=str(spec.occurrence_id),
                        goal_signature_id=str(signature),
                        method_ref=contract.method_ref(),
                        report=report,
                    )
                )
        return tuple(entries)

    def dispatch_repair_event(
        self,
        mission_id: str,
        event: Mapping[str, Any] | object,
        *,
        actions: Sequence[Any],
        all_items: Iterable[str] = (),
        plan_revision: int | None = None,
        **impact_indexes: Any,
    ) -> Any:
        """Enter the H4 event adapter from the authoritative dispatch context.

        The adapter remains side-effect free; callers pass the reverse indexes
        owned by their planner store, and the returned audit record is then fed
        to the existing repair/compiler boundary.  Binding the mission and
        current plan revision here prevents a repair event from being evaluated
        against an ambient or stale mission identity.
        """

        del all_items
        with self.store.read_view():
            network = self.network(mission_id)
            if plan_revision is not None and plan_revision != int(network.plan_revision):
                raise ContractError("REQUEST_BINDING_STALE: repair request uses a stale Plan")
            indexes = read_repair_impact_indexes(self.store, network, mission_id)
            # Callers may supply model diagnosis, never substitute a guessed graph.
            for name in (*indexes, "new_work"):
                impact_indexes.pop(name, None)
            result = RepairEventAdapter.dispatch(
                event,
                actions=actions,
                mission_id=mission_id,
                plan_revision=int(network.plan_revision),
                **indexes,
                **impact_indexes,
            )
        append_hierarchical_event(
            self.store,
            REPAIR_DECISION_DISPATCHED,
            mission_id,
            key=result.request.idempotency_key,
            payload=result.audit_json(),
        )
        return result

    def method_candidates(
        self, mission_id: str, *, reports: Sequence[Any] | None = None
    ) -> Mapping[str, Any]:
        """Per open goal: its candidates after the program filter (片 A 第 3 项).

        Every compound occurrence with no adopted method is listed, including one with
        no candidate at all.  The filter is capability and type only (the applicability
        read); which candidate to use, or whether to propose a new method, is the
        Planner's.  No model call, no plan mutation, nothing persisted.
        """

        network = self.network(mission_id)
        current_reports = (
            tuple(reports) if reports is not None else self.method_applicability(mission_id)
        )
        by_occurrence: dict[str, list[MethodSelectionCandidateV1]] = {}
        for entry in current_reports:
            reference = entry.method_ref
            by_occurrence.setdefault(str(entry.goal_occurrence_id), []).append(
                MethodSelectionCandidateV1(
                    method_id=str(reference.method_id),
                    method_version=int(reference.version),
                    method_content_hash=str(reference.content_hash),
                    report=entry.report,
                    bindings=dict(
                        network.binding_for_occurrence(entry.goal_occurrence_id).typed_parameters
                    ),
                )
            )
        return {
            str(spec.occurrence_id): filter_candidates(
                by_occurrence.get(str(spec.occurrence_id), ())
            )
            for spec in sorted(network.occurrences, key=lambda item: str(item.occurrence_id))
            if spec.form is TaskForm.COMPOUND
            and network.adopted_instance_for(spec.occurrence_id) is None
        }

    def record_method_applicability(
        self, mission_id: str, *, reports: Sequence[Any] | None = None
    ) -> Event | None:
        """Persist why each method was refused, at the revision it was assessed against.

        G1.  :meth:`method_applicability` fed the Planner prompt and nothing else, so
        the four axes — unknown precondition, conflict, parameter mismatch, missing
        capability, missing authority — existed only inside one rendered message.  A
        reader after the fact (the Host's acceptance runner, an operator, this suite)
        had no way to ask "why was ``code.fix-by-patch`` not chosen here", which is the
        question the axes were separated for in the first place.

        ``reports`` is passed in by the caller that also renders the prompt, so the
        record and the prompt are the *same* assessment rather than two runs of it
        against a world that may have moved between them.

        Returns ``None`` when nothing was refused: an event saying "no method was
        refused" and the absence of an event are the same fact, and writing the first
        one per round would bury the rounds that have something to say.
        """

        entries = tuple(reports) if reports is not None else self.method_applicability(mission_id)
        if not entries:
            return None
        network = self.network(mission_id)
        semantics = self.semantics()
        rendered = applicability_reports(entries, limit=MAX_RECORDED_REFUSALS)
        refused: list[dict[str, Any]] = []
        applicable: list[dict[str, Any]] = []
        for item in rendered:
            cited = tuple(item.get("unknown_preconditions", ())) + tuple(
                item.get("conflicting_preconditions", ())
            )
            seen: list[str] = []
            for key in cited:
                for record in semantics.list_observations(mission_id, proposition_key=str(key)):
                    observation = str(getattr(record, "observation_id", ""))
                    if observation and observation not in seen:
                        seen.append(observation)
            # The observations that *bear on* the cited propositions, which is not the
            # same as observations that settle them: a proposition is unknown here
            # precisely because what was observed did not settle it.  Naming them is
            # what lets a reader tell "nobody looked" from "somebody looked and the
            # answer did not decide it".
            row = {**item, "observation_ids": seen}
            if str(item.get("verdict") or "") == "APPLICABLE":
                applicable.append(row)
            else:
                refused.append(row)
        revision = int(network.plan_revision)
        library_round = self.store.count_events(mission_id, "PlanningMethodProposed")
        return append_hierarchical_event(
            self.store,
            METHOD_APPLICABILITY_ASSESSED,
            mission_id,
            key=self._applicability_record_key(mission_id, revision, library_round),
            payload={
                "plan_revision": revision,
                "library_round": int(library_round),
                "refused_methods": refused,
                "applicable_methods": applicable,
                "refusal_count": len(refused),
                "truncated": len(entries) > len(rendered),
            },
        )

    def _applicability_record_key(
        self, mission_id: str, plan_revision: int, library_round: int
    ) -> str:
        """Idempotency key for one applicability assessment.

        A method proposed by the Planner changes the library without moving the plan,
        so the key moves with the number of proposals.
        """

        if int(library_round) < 1:
            return f"{mission_id}:{int(plan_revision)}"
        return f"{mission_id}:{int(plan_revision)}:library:{int(library_round)}"

    def plan_revision_committed_at(self, mission_id: str, plan_revision: int) -> int | None:
        """When this plan revision was committed, in observation milliseconds.

        ``None`` when no such revision has been committed — third-round review P2-7.
        It used to answer ``0``, which the evidence cap reads as "look at everything
        since the beginning of time": the degradation back to a Mission-lifetime cap
        was silent, and silent is the one thing a cap must not be.  The caller decides
        what to do with "there is no such revision"; this method only says so.

        Read with a typed query rather than by scanning every event of the Mission.
        This runs once per evidence round per Mission, so the old ``list_events``
        sweep was an O(events) read on a hot path that lengthens with the run.
        """

        rows = self.store.connection.execute(
            "SELECT created_at, payload_json FROM events WHERE mission_id = ? AND type = ?"
            " ORDER BY seq",
            (str(mission_id), PLAN_REVISION_COMMITTED),
        ).fetchall()
        stamps = [
            int(float(row[0]) * 1000)
            for row in rows
            if int((json.loads(row[1]) or {}).get("plan_revision", -1)) == int(plan_revision)
        ]
        return max(stamps) if stamps else None

    def propositions_looked_at(self, mission_id: str, *, plan_revision: int) -> frozenset[str]:
        """The propositions this Mission has already read **under this revision**.

        An observation does not always settle the atom that motivated it — a
        non-authoritative negative on an OPEN predicate is still UNKNOWN (§6.6) — so
        ``pending_asks`` keeps offering it, and the first real-model evidence round
        recorded the same proposition several hundred times in a few seconds until
        ``EvidenceEntry`` refused the snapshot.  A second identical read of an
        unchanged world produces the same answer at the cost of one more row, so
        within one revision each proposition is read once.

        Review P1-4: part 2c capped it over the Mission's whole **lifetime**, which
        made evidence unrefreshable — a precondition repaired while the plan ran (the
        smoke's own ``code.test-is-failing``) was never looked at again, and
        ``issue_start_witnesses``' promise of I19's "recompute, do not reuse the old
        TRUE" was recomputing an expression over a frozen snapshot.  The rule, written
        down: **committing a plan revision re-opens the look.**  A revision is the
        moment the world has demonstrably changed — work retired, a method adopted, a
        duty opened — and it is bounded, because a revision costs a Planner round of
        its own.  So an observation recorded *before* the current revision was
        committed no longer counts as having looked.
        """

        since = self.plan_revision_committed_at(mission_id, plan_revision)
        if since is None:
            # Review P2-7: a revision this Mission never committed is no barrier, and
            # saying so out loud is the difference between "no barrier" and a silent
            # fall back to the Mission-lifetime cap this rule replaced.  Every read
            # counts, which is the conservative answer: nothing is looked at twice on
            # the strength of a revision that does not exist.
            return frozenset(
                str(record.proposition_key)
                for record in self.semantics().list_observations(mission_id)
            )
        return frozenset(
            str(record.proposition_key)
            for record in self.semantics().list_observations(mission_id)
            if int(record.recorded_at_ms) >= since
        )

    def run_evidence_round(self, mission_id: str, *, now_ms: int | None = None) -> Any:
        """One evidence round: re-read what the world may have changed, then look at the
        UNKNOWN preconditions (阶段 D)."""

        reread, read = self._reread_recorded(mission_id, now_ms=now_ms)
        # a proposition read again just now is not asked a second time in the same round
        looked = self._unknown_precondition_round(mission_id, now_ms=now_ms, skip=read)
        return EvidenceRoundResult(
            outcomes=(*reread, *looked.outcomes), unobservable=looked.unobservable
        )

    def _reread_recorded(
        self, mission_id: str, *, now_ms: int | None
    ) -> tuple[tuple[Any, ...], frozenset[str]]:
        """Read the recorded propositions again when the world has moved.

        A desktop Mission's world is its accepted artifacts and its reference material: a
        step is accepted, a source is replaced, and a proposition recorded earlier may no
        longer hold — while the start gate only reads what is recorded.  So once per
        *world mark* (the set of acceptances plus the state of the sources table) every
        recorded proposition an installed observer can read is asked again, from the
        question stored on its row; only a changed truth is written (which raises the
        scope epoch, see ``insert_observation``).  One ``EvidenceReread`` event per mark
        says what was read and what changed.  An unchanged world is not read again: a
        seed domain's observer may be expensive, and writing an unchanged reading would
        stale every planning round in flight."""

        index = getattr(self._world(), "observer_index", None)
        if index is None:
            return (), frozenset()
        semantics = self.semantics()
        mark = content_hash_of(
            {
                "acceptances": sorted(
                    str(item.acceptance_id) for item in semantics.list_acceptances(mission_id)
                ),
                "sources": [
                    list(row)
                    for row in self.store.connection.execute(
                        "SELECT path, revision, version_hash, superseded_by, revoked FROM sources"
                        " WHERE mission_id=? ORDER BY path, revision, version_hash",
                        (mission_id,),
                    )
                ],
            }
        )
        done = f"EvidenceReread:{mission_id}:{mark}"
        if (
            self.store.connection.execute(
                "SELECT 1 FROM events WHERE idempotency_key=?", (done,)
            ).fetchone()
            is not None
        ):
            return (), frozenset()
        questions = semantics.observation_questions(mission_id)
        moment = int(self.store.now * 1000) if now_ms is None else int(now_ms)
        written: list[Any] = []
        read: list[str] = []
        for question in questions:
            reference = VersionedRef.from_json(question["predicate_ref"])
            if index.observer_for(str(reference.id)) is None:
                continue
            outcome = observe_predicate(index, reference, question["arguments"], now_ms=moment)
            read.append(question["proposition_key"])
            if outcome.record is None:
                continue  # could not look: nothing is written, the recorded reading stands
            before, after = truth_change(
                semantics.list_observations(
                    mission_id, proposition_key=question["proposition_key"]
                ),
                outcome.record,
            )
            if after is before:
                continue
            written.append(
                record_observation(semantics, mission_id, outcome, scope_id=question["scope_id"])
            )
        if not questions:
            return (
                (),
                frozenset(),
            )  # nothing was ever recorded: nothing to read again, and nothing to say
        append_hierarchical_event(
            self.store,
            "EvidenceReread",
            mission_id,
            key=f"{mission_id}:{mark}",
            payload={
                "mark": mark,
                "read": read,
                "changed": [str(item.record.proposition_key) for item in written],
            },
        )
        return tuple(written), frozenset(read)

    def _unknown_precondition_round(
        self, mission_id: str, *, now_ms: int | None = None, skip: Collection[str] = ()
    ) -> Any:
        """Look at the UNKNOWN preconditions of every still-open goal, once.

        P2.3c part 2c.  Part 2b built the round (``planning.htn.evidence_round``) and
        left it for a deployment to call by hand, so in the real loop an UNKNOWN
        precondition stayed UNKNOWN forever: the Planner was handed a package whose
        methods all read ``NEEDS_EVIDENCE`` and no evidence was ever gathered.  ADR-07
        is "look, do not guess", and nothing was looking.

        What it does **not** do is dispatch an agent.  Every read goes through the
        deployment's :class:`~..planning.htn.observation_pipeline.ObserverIndex`,
        which is the one path that enforces §6.6 C28 (only a listed observer, only a
        read-only type) on the way in; an observer that cannot answer produces
        ``OBSERVER_UNAVAILABLE`` and **no record**, so a proposition never becomes
        FALSE because nobody looked.

        Which propositions are asked is the catalogue's decision, not this method's:
        an atom is asked only when ``evidence_requests`` found a registered read-only
        task type that declares it observes that predicate.  A deployment that
        installed no observer index gets an empty round rather than an error — it has
        simply not wired the evidence lane, which the readiness reports already say.
        """

        world = self._world()
        index = getattr(world, "observer_index", None)
        if index is None:
            return EvidenceRoundResult()
        network = self.network(mission_id)
        snapshot = world.snapshot()
        looked_at = self.propositions_looked_at(
            mission_id, plan_revision=int(network.plan_revision)
        )
        moment = int(self.store.now * 1000) if now_ms is None else int(now_ms)
        asks: dict[str, EvidenceAsk] = {}
        for spec in sorted(network.occurrences, key=lambda item: str(item.occurrence_id)):
            if spec.form is not TaskForm.COMPOUND:
                continue
            if network.adopted_instance_for(spec.occurrence_id) is not None:
                continue
            goal = network.binding_for_occurrence(spec.occurrence_id)
            parameters = dict(goal.typed_parameters)
            for reference in world.registry.method_refs():
                if not world.registry.retrievable(reference, mission_id=MissionRef(mission_id)):
                    continue
                contract = world.registry.definition(reference)
                if contract is None:
                    continue
                if str(contract.goal_type_ref.id) != str(goal.goal_signature.signature_id):
                    continue
                conditions = contract.applicable_when
                unknowns = unknown_predicates(
                    conditions,
                    parameters=parameters,
                    predicates=world.predicates,
                    snapshot=snapshot,
                    now_ms=moment,
                )
                if not unknowns:
                    continue
                requests = evidence_requests(
                    unknowns,
                    for_occurrence=spec.occurrence_id,
                    obligation_id=spec.obligation_id,
                    catalog=world.catalog,
                    semantic_scope=goal.semantic_scope,
                    contract_revision=int(goal.contract_revision),
                )
                candidates = pending_asks(
                    conditions,
                    parameters=parameters,
                    registry=world.predicates,
                    snapshot=snapshot,
                    now_ms=moment,
                )
                for ask in asks_for_requests(requests, candidates):
                    if ask.proposition_key in looked_at or ask.proposition_key in skip:
                        continue
                    asks.setdefault(ask.proposition_key, ask)
        if not asks:
            return EvidenceRoundResult()
        return run_round(
            index,
            self.semantics(),
            mission_id,
            tuple(asks[key] for key in sorted(asks)),
            now_ms=moment,
        )

    def _publish_source_steps(
        self, mission_id: str, method: Any, share: Collection[str] | None = None
    ) -> list[str]:
        """Publish targets whose ``file:`` criterion is not linked to exactly one step.

        The Host puts ``file:X`` in front of every ``action:file_publish.publish:X``
        (``c-user-<n>`` names the Mission's n-th criterion).

        ``share``（片 B）：这份做法的目标负责的要求编号。给了就只查其中的 ``file:`` 要求——
        要发布的文件归别的目标或步骤时，这份做法既不该、也不能（覆盖检查会判越界）链接它。
        """

        mission = self.store.get_mission(mission_id)
        if mission is None:
            return []
        # 按需导入：测试替身（agent_orchestrator.deployment.root）
        from ..deployment.root import current_statements

        criteria = [str(item).strip() for item in current_statements(self.store, mission)]
        steps: dict[str, set[str]] = {}
        for link in getattr(method.composition, "criterion_links", ()) or ():
            if link.child_step is not None:
                steps.setdefault(str(link.parent_criterion_id), set()).add(str(link.child_step))
        unclear = []
        for criterion in criteria:
            parsed = parse_action_criterion(criterion)
            if parsed is None:
                continue
            source = f"file:{parsed[2]}"
            if source not in criteria:
                continue
            source_id = f"c-user-{criteria.index(source) + 1}"
            if share is not None and source_id not in share:
                continue
            linked = sorted(steps.get(source_id, ()))
            if len(linked) != 1:
                unclear.append(
                    f"{parsed[2]} 链接到 {len(linked)} 个步骤"
                    + (f"（{'、'.join(linked)}）" if linked else "")
                )
        return unclear

    def _admission_policy(self, mission_id: str) -> Any:
        """The policy a proposed method is decided against on this deployment.

        A world that knows how to build its own policy is asked for it; anything else
        gets one assembled from the four declaration stores plus the live capability
        table, so a deployment cannot end up admitting a method against capabilities
        nobody has.
        """

        world = self._world()
        builder = getattr(world, "policy", None)
        if callable(builder):
            policy = builder(mission_id=mission_id)
        else:
            policy = AdmissionPolicy(
                policy_ref="deployment-policy",
                policy_version=1,
                mission_id=MissionRef(mission_id),
                predicates=world.predicates,
                task_types=world.catalog,
                schemas=world.schemas,
                capabilities=world.capabilities(),
            )
        # A method the Planner proposes is capped at the method-width bound.

        current = int(getattr(policy, "max_steps", MAX_PROPOSED_METHOD_STEPS))
        if current > MAX_PROPOSED_METHOD_STEPS:
            policy = replace(policy, max_steps=MAX_PROPOSED_METHOD_STEPS)
        return policy

    def solver_preview_lane(
        self,
        mission_id: str,
        proposal: PlanProposal,
        *,
        preview: Any,
        admission: Any,
        principal: PlanPrincipal,
        command_id: str,
        source: Mapping[str, Any],
    ) -> Any:
        """Prepare H7's real compiler/Commit lane; solve outside any write transaction."""

        if not isinstance(preview, plan_preview.CandidatePreview) or not isinstance(
            admission, PlanningCommitAdmission
        ):
            raise ContractError("solver commit requires the typed preview and H1-H admission")
        self.require_hierarchical(mission_id)
        network = self.network(mission_id)
        if models.sha256_hex(
            plan_preview._source_snapshot_payload(network)
        ) != preview.source_snapshot_hash or int(proposal.expected_plan_revision) != int(
            network.plan_revision
        ):
            raise ContractError(
                "REQUEST_BINDING_STALE: solver preview no longer matches the active Plan"
            )
        command = self.build_command(
            mission_id,
            proposal,
            preview.compilation,
            principal=principal,
            command_id=command_id,
            source={
                **dict(source),
                "preview_compilation_hash": preview.compilation_hash,
                "preview_source_snapshot_hash": preview.source_snapshot_hash,
            },
        )
        return SolverPlanCommitLane(self.commit, command, principal, admission)

    def commit_preview_plan_proposal(
        self,
        mission_id: str,
        proposal: PlanProposal,
        *,
        preview: plan_preview.CandidatePreview,
        admission: Any | None = None,
        principal: PlanPrincipal,
        command_id: str,
        source: Mapping[str, Any] | None = None,
        owner: str | None = None,
        proposal_text: str = "",
    ) -> PlanRoundOutcome:
        """Commit exactly the compilation produced by the H1-H candidate preview.

        A planning decision has already frozen a typed source snapshot and a preview
        compilation; recompiling here could commit a different candidate than the one
        admitted.  This entry therefore only accepts a typed :class:`CandidatePreview`
        and the admission it was previewed under, rechecks the frozen network
        identity, and sends that compilation directly to ``CommitService``.
        """

        if not isinstance(preview, plan_preview.CandidatePreview):
            raise ContractError("SOURCE_UNAVAILABLE: final commit requires a typed preview")
        if not isinstance(admission, PlanningCommitAdmission):
            raise ContractError("SOURCE_UNAVAILABLE: final commit requires H1-H admission")
        mission = self.require_hierarchical(mission_id)
        del mission
        compilation = preview.compilation
        network = self.network(mission_id)
        current_hash = models.sha256_hex(plan_preview._source_snapshot_payload(network))
        if current_hash != preview.source_snapshot_hash:
            raise ContractError(
                "REQUEST_BINDING_STALE: preview network changed before final commit"
            )
        # ``compilation.network`` is the *result* snapshot produced by the pure
        # compiler after applying the candidate delta.  It is expected to differ
        # from the current source network; the source identity was already checked
        # above through ``preview.source_snapshot_hash``.  Comparing the result to
        # the source would reject every valid refinement immediately before commit.
        if int(proposal.expected_plan_revision) != int(network.plan_revision):
            raise ContractError(
                "REQUEST_BINDING_STALE: proposal revision changed before final commit"
            )

        command = self.build_command(
            mission_id,
            proposal,
            compilation,
            principal=principal,
            command_id=(
                command_id
                if isinstance(admission, PlanningCommitAdmission)
                and admission.taskgraph_candidate is not None
                else f"{command_id}:preview"
            ),
            source={
                **dict(source or {}),
                "preview_compilation_hash": preview.compilation_hash,
                "preview_source_snapshot_hash": preview.source_snapshot_hash,
            },
        )
        try:
            receipt = self.commit.commit_planning_revision(
                command,
                principal,
                admission=admission,
            )
        except PlanCommitRejected as refused:
            refusal = PlanRefusal(
                attempt=1,
                reason=refused.reason,
                detail=refused.detail,
                recompilable=False,
            )
            self._record_refusal(mission_id, proposal, (refusal,))
            return PlanRoundOutcome(proposal_id=proposal.proposal_id, refusals=(refusal,))
        return PlanRoundOutcome(proposal_id=proposal.proposal_id, receipt=receipt)

    @staticmethod
    def preview_plan_proposal(proposal: PlanProposal, *, inputs: Any) -> Any:
        """Run the pure candidate preview without entering dispatch or commit."""

        return preview_candidate(proposal, inputs=inputs)

    def _lease_blocks_cancel(self, attempt: Any, owner: str | None) -> bool:
        """A live lease held by somebody else must not be stolen (P2.3s)."""

        expires = getattr(attempt, "lease_expires_at", None)
        holder = str(getattr(attempt, "lease_owner", "") or "")
        if expires is None or holder == "":
            return False
        try:
            if float(expires) <= float(self.store.now):
                return False
        except (TypeError, ValueError):
            return False
        if owner is None:
            return False
        return holder != str(owner)

    def build_command(
        self,
        mission_id: str,
        proposal: PlanProposal,
        compilation: RefinementCompilation,
        *,
        principal: PlanPrincipal,
        command_id: str,
        source: Mapping[str, Any] | None = None,
    ) -> CommitPlanCommand:
        """The command the Commit service checks.  Authority is bound here, not read.

        P2.3j: a delta that retires an instance replaces that instance's slots, and
        the commit's running-work check refuses ``retain_if_bindings_unchanged`` for
        a replacement (it cannot decide the case).  The policy the command carries is
        therefore the *system's* reading of what the delta does — ``request_stop_then
        _reconcile`` when something is retired — and not the proposal's own claim,
        which for a plain refinement keeps the command byte-for-byte as before.

        Verification P1-2: the policy is a label, not an action; the TaskGraph commit
        revokes the retired work's execution rights in its own transaction.
        """

        policy: dict[str, Any] = {}

        policy["structure_budget"] = GraphStructureBudget.from_json(
            read_installed_graph_policy(self.store, mission_id).to_json()["graph_structure_budget"]
        )
        if compilation.delta.retired_instance_ids or compilation.superseded_occurrences:
            policy["running_work_policy"] = RunningWorkPolicy.REQUEST_STOP_THEN_RECONCILE
        if compilation.superseded_occurrences:
            policy["superseded_occurrences"] = compilation.superseded_occurrences
        return CommitPlanCommand(
            command_id=command_id,
            mission_id=mission_id,
            delta=compilation.delta,
            network=compilation.network,
            task_bindings=compilation.task_bindings,
            **policy,
            issued_by=principal.principal_id,
            scope_id=principal.scope_id,
            budget_requirement=compilation.budget_requirement,
            seed_methods=tuple(
                getattr(self.require_planning_world(), "seed_methods", ())
            ),  # see seed_method_keys
            source={
                **dict(source or {}),
                "proposal_id": proposal.proposal_id,
                "rationale": proposal.rationale,
            },
        )

    def attempt_inputs(self, mission_id: str, task_id: str) -> list[UpstreamInput]:
        """What one dispatch of ``task_id`` starts from, in the new mode.

        Only the resolved :class:`InputManifest` — §24.1 decision 4's "no longer
        collect every ancestor's files".  An ORDER-only predecessor contributes
        nothing however many artifacts it accepted, which is the property T015 /
        T066 exist to hold.  2026-10-11 第三批: the manifest carries the delivery
        bindings too, so this is a straight materialisation of it; a version conflict
        the resolution reported is handed to the write-conflict repair request rather
        than stopping the task as an artifact conflict (2026-10-09 第 4 条).
        """

        network = self.network(mission_id)
        spec = next((item for item in network.occurrences if str(item.task_id) == task_id), None)
        if spec is None:
            raise missing_bindings(mission_id, [task_id])
        result = self.input_result(mission_id, network, spec)
        if result is None:
            return []
        clashes = []
        for problem in result.problems:
            if problem.kind not in (
                ResolutionProblemKind.TARGET_PATH_CONFLICT,
                ResolutionProblemKind.DELIVERY_VERSION_CONFLICT,
            ):
                continue
            artifacts = [self.store.get_artifact(artifact_id) for artifact_id in problem.candidates]
            paths = sorted({artifact.path for artifact in artifacts if artifact is not None})
            steps = list(problem.producers) or [
                artifact.task_id for artifact in artifacts if artifact is not None
            ]
            clashes.append(
                {
                    "path": paths[0] if paths else "",
                    "artifacts": list(problem.candidates),
                    "steps": list(dict.fromkeys(steps)),
                    "consumer": task_id,
                }
            )
        if clashes:
            raise WriteConflictPending(clashes)
        if result.manifest is None or not result.manifest.is_frozen:
            # A producer that has not finished leaves a *symbolic* binding.  That is
            # "not resolved yet", which is the DATA gate's business (WAITING_DATA) and
            # not a materialisation failure — so nothing is placed and nothing raises.
            return []
        # 阶段 D（10-03）：开工前先查这一步直接上游牵涉的写入冲突（规则一：没有先后的两步把同一文件写成
        # 两样）。独立核验 opt.185 M1：这道检查原先在被删的叠加函数里，不能随它一起没了。
        producers = tuple(
            dict.fromkeys(str(item.producer_task_ref) for item in result.manifest.bindings)
        )
        clashes = self.producer_write_conflicts(mission_id, network, touching=producers)
        if clashes:
            raise WriteConflictPending(clashes)
        return manifest_upstream_inputs(
            result.manifest, self.target_rules_for(task_id), network=network
        )

    def write_conflicts(
        self, mission_id: str, *, touching: Sequence[str] | None = None
    ) -> list[dict[str, Any]]:
        """Files the plan lets two versions of reach one place with nothing saying which (阶段 D；
        2026-10-09 四项修复第 4 条扩成两条规则).

        Rule one: two steps with no order between them each delivered a different content at one
        path.  Which one a later step starts from is not something the plan says, and picking one
        ("first come") would be the Harness deciding it.  Reported as ``{path, steps, artifacts}``.
        The files are the ones each step's *acceptance* covers (2026-10-11 第三批: the same set the
        manifest delivers), read off the acceptances that feed a DATA edge.

        Rule two: several versions of one path reach one consumer and the frozen manifests prove
        no relay that makes one of them the latest; or two of its *port* files land on one path.
        That is the delivery resolution's own refusal (:func:`resolve_deliveries`), read back from
        :meth:`attempt_inputs` so the repair request and the refusal to start never disagree.  A
        relay (one step delivers the next version of a file it demonstrably received) is not a
        conflict; identical content is not one either.  ``touching`` keeps only the conflicts one
        of those producer tasks is a party to (rule one) or feeds (rule two).
        """
        network = self.network(mission_id)
        found = self.producer_write_conflicts(mission_id, network, touching=touching)
        consumers: dict[str, set[str]] = {}
        for item in network.data_requirements:
            consumers.setdefault(
                str(network.occurrence(item.consumer_occurrence).task_id), set()
            ).add(str(network.occurrence(item.producer_occurrence).task_id))

        def note(conflicts: Sequence[Mapping[str, Any]]) -> None:
            for item in conflicts:
                if not any(
                    f["path"] == item["path"] and set(f["artifacts"]) == set(item["artifacts"])
                    for f in found
                ):
                    found.append(dict(item))

        for consumer, producers in consumers.items():
            if touching is not None and not producers & set(touching):
                continue  # 只读这些上游喂的下游，不解析别的
            consumer_task = self.store.get_task(consumer)
            if consumer_task is not None and consumer_task.status is TaskStatus.COMPLETED:
                # 2026-10-11（opt.176 核验建议 1）：做完的下游拿到的输入早已冻结在它的清单里，再解析
                # 一遍只是开销（每轮修复触发都对全部下游完整解析，步骤多时核心用例集从 601 秒涨到 670 秒）。
                # 没做完的（含停下的）照旧报：那是规划器与事后取证都要看的事实。
                continue
            try:
                self.attempt_inputs(mission_id, consumer)
            except WriteConflictPending as error:
                note(error.conflicts)
            except ArtifactConflict:
                continue  # 那一步自己的别的物化问题，由它自己的派发报，不在这里替它停
        return found

    def producer_write_conflicts(
        self,
        mission_id: str,
        network: TaskNetworkSnapshot,
        *,
        touching: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Rule one of :meth:`write_conflicts`, on its own so dispatch can ask it before a step
        starts without re-entering the per-consumer resolution (rule two)."""

        semantics = self.semantics()
        occurrences: dict[str, list[Any]] = {}
        for spec in network.occurrences:
            if spec.form is TaskForm.PRIMITIVE:
                occurrences.setdefault(str(spec.task_id), []).append(spec.occurrence_id)
        producers_by_acceptance: dict[str, str] = {}
        for row in semantics.list_acceptance_outputs(mission_id):
            producers_by_acceptance.setdefault(
                str(row["acceptance_id"]), str(row["producer_task_ref"])
            )
        holders: dict[str, list[tuple[str, Any]]] = {}
        for acceptance_id, task_id in sorted(producers_by_acceptance.items()):
            if task_id not in occurrences:
                continue
            for ref in semantics.get_acceptance(acceptance_id).artifact_refs:
                artifact = self.store.get_artifact(ref.id)
                if (
                    artifact is None
                    or artifact.content_hash != ref.content_hash
                    or is_operation_candidate_path(artifact.path)
                    or artifact.path.startswith(".")
                ):
                    continue
                holders.setdefault(artifact.path, []).append((task_id, artifact))
        ordered = None
        found: list[dict[str, Any]] = []
        for path in sorted(holders):
            entries = holders[path]
            for seat, (left, left_file) in enumerate(entries):
                for right, right_file in entries[seat + 1 :]:
                    if left == right or left_file.content_hash == right_file.content_hash:
                        continue
                    if touching is not None and not {left, right} & set(touching):
                        continue
                    ordered = ordered or ordering_of(network)
                    if any(ordered(a, b) for a in occurrences[left] for b in occurrences[right]):
                        continue
                    found.append(
                        {
                            "path": path,
                            "steps": [left, right],
                            "artifacts": [left_file.id, right_file.id],
                        }
                    )
        return found

    def delivery_sources(self, mission_id: str, manifest: InputManifest) -> DeliverySources:
        """What the DATA-bound producers of ``manifest``'s consumer hand on, read once.

        The one place the delivery rule is spelled out (2026-10-11 第三批):

        * a writing producer hands on every file its *acceptance* covers
          (``Acceptance.artifact_refs`` — the per-acceptance set, not the task-level
          one, so a re-acceptance changes it in step with the licence);
        * a read-only producer hands on only its copies of original-workspace files
          (it changes nothing; its new ``tests/`` stay off the consumer's baseline);
        * operation candidates and dot-files are not part of the delivered work
          (the same two exclusions :meth:`write_conflicts` applies);
        * a continuation producer (every input port also an output port) also hands
          on what it received — read from its own frozen manifest, one level, since
          that manifest already holds what *it* was handed;
        * ``received`` maps each acceptance to the exact ``(producer, path, hash)`` set
          its Attempt was frozen with — the only proof of a relay the resolution accepts.

        A source that cannot be read is named in ``unavailable`` rather than skipped.
        """

        mission = self.store.get_mission(mission_id)
        if mission is None:
            raise ContractError("delivery sources: the Mission is unavailable")
        seed = set((mission.final_report or {}).get("workspace_seed", {}))
        semantics = self.semantics()
        files: list[DeliveredFile] = []
        received: dict[str, frozenset[tuple[str, str, str]]] = {}
        unavailable: list[tuple[str, str]] = []
        direct: dict[str, tuple[str, int]] = {}
        for binding in manifest.bindings:
            direct.setdefault(
                binding.acceptance_id,
                (str(binding.producer_task_ref), int(binding.support_revision)),
            )

        def frozen_inputs_of(acceptance: Any) -> tuple[DeliveredFile, ...] | None:
            """The files the producer's accepted Attempt started from, as its manifest froze them."""
            try:
                frozen = decode_frozen_manifest(
                    semantics.get_input_manifest(acceptance.input_manifest_hash)
                )
            except (StoreError, ContractError) as error:
                unavailable.append(
                    (str(acceptance.acceptance_id), f"frozen inputs unreadable: {error}")
                )
                return None
            rules = self.target_rules_for(str(acceptance.task_id))
            entries: list[DeliveredFile] = []
            for port in frozen.bindings:
                path = rules.target_for(port).path
                if is_operation_candidate_path(path):
                    continue
                entries.append(
                    DeliveredFile(
                        port.producer_task_ref,
                        port.acceptance_id,
                        int(port.support_revision),
                        port.artifact_id,
                        path,
                        port.content_hash,
                    )
                )
            for item in frozen.deliveries:
                entries.append(
                    DeliveredFile(
                        item.producer_task_ref,
                        item.acceptance_id,
                        int(item.support_revision),
                        item.artifact_id,
                        item.path,
                        item.content_hash,
                    )
                )
            return tuple(entries)

        for acceptance_id, (producer, support) in sorted(direct.items()):
            try:
                acceptance = semantics.get_acceptance(acceptance_id)
            except StoreError as error:
                unavailable.append((acceptance_id, str(error)))
                continue
            if acceptance.mission_id != mission_id or str(acceptance.task_id) != producer:
                unavailable.append(
                    (acceptance_id, "the acceptance belongs to another Mission or task")
                )
                continue
            semantic = semantics.task_semantics_of(mission_id, producer)
            read_only = semantic is not None and read_only_leaf(semantic)
            for ref in acceptance.artifact_refs:
                artifact = self.store.get_artifact(ref.id)
                if (
                    artifact is None
                    or artifact.mission_id != mission_id
                    or artifact.task_id != producer
                    or artifact.content_hash != ref.content_hash
                ):
                    unavailable.append(
                        (acceptance_id, f"accepted artifact {ref.id} is missing or changed")
                    )
                    continue
                if is_operation_candidate_path(artifact.path) or artifact.path.startswith("."):
                    continue
                if read_only and artifact.path not in seed:
                    continue
                files.append(
                    DeliveredFile(
                        TaskRef(producer),
                        acceptance_id,
                        support,
                        artifact.id,
                        artifact.path,
                        artifact.content_hash,
                    )
                )
            frozen = frozen_inputs_of(acceptance)
            if frozen is None:
                continue
            received[acceptance_id] = frozenset(item.version_key for item in frozen)
            if not _is_continuation(semantic):
                continue
            for item in frozen:
                files.append(replace(item, carried_from=TaskRef(producer)))
                if item.acceptance_id in received:
                    continue
                try:
                    origin = semantics.get_acceptance(item.acceptance_id)
                except StoreError as error:
                    unavailable.append((item.acceptance_id, str(error)))
                    continue
                inner = frozen_inputs_of(origin)
                if inner is not None:
                    received[item.acceptance_id] = frozenset(entry.version_key for entry in inner)
        return DeliverySources(
            files=tuple(files), received=received, unavailable=tuple(unavailable)
        )

    # ------------------------------------------------------------------------ plumbing
    def require_planning_world(self) -> PlanningWorld:
        """The deployment's declarations, or a visible refusal.

        Public because the event handler needs the same answer when it builds the
        hierarchical Planner's package: a deployment without a ``PlanningWorld`` must
        fail here rather than quietly hand the model the legacy DAG package (§18.5).
        """

        return self._world()

    def _world(self) -> PlanningWorld:
        if self.planning is None:
            raise ContractError(
                "the hierarchical assembly needs a PlanningWorld (task types, schemas, method "
                "registry, predicates); a deployment without one cannot compile a refinement "
                "and must not fall back to the legacy planner (§18.5)"
            )
        return self.planning

    def _record_refusal(
        self, mission_id: str, proposal: PlanProposal, refusals: Sequence[PlanRefusal]
    ) -> Event:
        last = refusals[-1]
        return self._append(
            PLAN_COMMIT_REFUSED,
            mission_id,
            key=f"{mission_id}:{proposal.proposal_id}:{len(refusals)}",
            payload={
                "proposal_id": proposal.proposal_id,
                "attempts": len(refusals),
                "reason": last.reason,
                "detail": last.detail,
                "refusals": [item.to_json() for item in refusals],
                # P2.3c part 2c: what the proposal actually named.  A
                # ``READ_SET_UNRESOLVED`` that says "this store cannot re-check
                # observation X" leaves the reader unable to tell an id the proposer
                # invented from one the store lost — and that is the only question
                # worth asking about that refusal.  Kind and id only: the revisions and
                # hashes are the proposer's claims and belong to the proposal, not to
                # the diagnosis.
                "read_set_named": [
                    {"kind": str(item.kind), "id": str(item.id)} for item in proposal.read_set
                ],
                # C19, stated in the record: nothing was replayed on the proposer's
                # behalf, so a reader knows the proposal has to be re-authored.
                "rebased": False,
            },
        )

    def _append(
        self,
        event_type: str,
        mission_id: str,
        *,
        key: str,
        payload: Mapping[str, Any],
        task_id: str | None = None,
    ) -> Event:
        return append_hierarchical_event(
            self.store, event_type, mission_id, key=key, payload=payload, task_id=task_id
        )


def _root_criteria(
    criteria: Sequence[Any],
    record: Any,
    *,
    effective_grades: Mapping[str, str] | None = None,
) -> tuple[ResolutionCriterion, ...]:
    """The root resolution's criteria, restated from the review record (review F4).

    The *set* of criteria is the root's content projection (Assurance §7.2: the effect
    criteria are judged by their own outcome reviews and converge in the closeout) —
    that is what the root review judged — and each verdict is the record's own.  ``UNKNOWN`` where the reviewer said
    nothing: it is the enum's word for "not judged", and it is the only honest thing a
    trigger that decides nothing can write.

    ``effective_grades`` (assured lane, handoff item 7) are the current re-decision
    of the bound review manifest that the prepared UseCertificate carries; the
    public ``CriterionOutcome`` projection of an assured record shows a SEMANTIC
    PASS as UNKNOWN, and the resolution restates the manifest, not the projection.
    """

    reviewed = {str(item.criterion_id): item.verdict for item in record.criteria}
    if effective_grades is not None:
        reviewed = {
            **reviewed,
            **{str(name): CriterionVerdict(value) for name, value in effective_grades.items()},
        }
    return tuple(
        ResolutionCriterion(
            criterion_id=item.criterion_id,
            verdict=reviewed.get(str(item.criterion_id), CriterionVerdict.UNKNOWN),
            evidence_refs=tuple(
                EvidenceRef.from_json(ref.to_json())
                for outcome in record.criteria
                if outcome.criterion_id == item.criterion_id
                for ref in outcome.evidence_refs
                if str(ref.kind) in {str(kind) for kind in EvidenceRefKind}
            ),
        )
        for item in criteria
    )


def _same_conclusion(held: ValidityWitness, offered: ValidityWitness) -> bool:
    """Whether two licences over one key say the same thing (review P2-1).

    Only the *verdict* axes, deliberately: the id already pins consumer, purpose,
    scope, epoch, support revision and subject, so what is left to differ is what the
    licence concluded.  ``as_of_ms`` is not on the list — re-reading the same world a
    second later is the same conclusion, and treating it as a contradiction would make
    every honest re-issue an anomaly.
    """

    return (
        held.truth is offered.truth
        and held.decision is offered.decision
        and held.freshness is offered.freshness
        and held.availability is offered.availability
    )


def append_hierarchical_event(
    store: Store,
    event_type: str,
    mission_id: str,
    *,
    key: str,
    payload: Mapping[str, Any],
    task_id: str | None = None,
) -> Event:
    """Append one of this module's event types, keyed for idempotency.

    A module function and not only a method because :data:`ASSEMBLY_MISSING` has to be
    recordable by a caller that has *no* assembly — that is what the event says.
    """

    idempotency_key = f"{event_type}:{key}"
    return store.append_event(
        Event(
            id=ids.event_id(idempotency_key),
            type=event_type,
            trace_id=ids.trace_id(mission_id),
            mission_id=mission_id,
            task_id=task_id,
            attempt_id=None,
            actor_type="system",
            actor_id="orchestrator",
            payload=dict(payload),
            idempotency_key=idempotency_key,
            created_at=store.now,
        )
    )


def record_assembly_missing(store: Store, mission: Mission, *, at: str) -> Event:
    """Refuse-and-record: this Mission runs hierarchically and the gates are not installed.

    Review finding F1.  ``commit_plan_revision`` materialises occurrence rows through
    the Commit Service while every dispatch gate — ``allocate_v2``'s admissions, the
    TG §8.3 re-check, the root ``GoalResolution`` trigger — lives on this assembly and
    is reached only through ``Orchestrator._hierarchical``.  Nothing couples the two,
    so a deployment that writes hierarchical plans without calling
    ``install_hierarchical`` used to hand those rows to the legacy ``allocate()``:
    dispatch on the ``TaskStatus.READY`` string, a DATA consumer running before its
    producer was accepted, and "every live Task is COMPLETED" standing in for a root
    resolution.  That is the silent half-mode §18.5 rule 1 forbids — half the Mission
    committed under the new rules and half of it scheduled under the old ones.

    The answer is the same one ``require_planning_world`` already gives on the planning
    side: refuse, and say so.  The Mission stays where it is, visibly not moving, with
    one event naming the deployment defect — which is a Mission an operator can fix,
    rather than one that quietly ran under rules nobody chose for it.
    """

    return append_hierarchical_event(
        store,
        ASSEMBLY_MISSING,
        mission.id,
        key=mission.id,
        payload={
            "semantics": semantics_of(mission),
            "at": at,
            "detail": (
                "this Mission runs under hierarchical semantics and no HierarchicalDispatch "
                "is installed on this Orchestrator; the readiness gate, the TG §8.3 dispatch "
                "re-check and the root GoalResolution trigger all live on that assembly, so "
                "nothing is dispatched and nothing is judged (§18.5 rule 1: a Mission does "
                "not run half in each mode).  Call Orchestrator.install_hierarchical()."
            ),
        },
    )


def shared_goal_index(
    network: TaskNetworkSnapshot,
    *,
    catalog: Any,
    exclude_occurrence_ids: Sequence[OccurrenceId] = (),
) -> tuple[SharedGoalEntry, ...]:
    """The occurrences of this network a later slot may name instead of re-doing.

    G2.  Every occurrence that has a semantic binding is listed; nothing here decides
    that two goals *are* one — the Planner names the step it means (TaskGraph 补全第三
    批) and :func:`~..planning.htn.grounding.named_share_refusal` checks the order.  An
    occurrence whose task type this deployment cannot resolve is skipped rather than
    listed under a guess.

    P2.3n: ``exclude_occurrence_ids`` are occurrences that will leave with a
    ``retire_method`` in the same proposal — offering them as share targets would
    ground the replacement against slots the merge then removes.
    """

    skipped = {OccurrenceId(str(item)) for item in exclude_occurrence_ids}
    by_signature = {
        (str(spec.goal_signature.signature_id), int(spec.goal_signature.version)): spec
        for spec in catalog.task_types()
    }
    entries: list[SharedGoalEntry] = []
    for occurrence in network.occurrences:
        if occurrence.occurrence_id in skipped:
            continue
        try:
            binding = network.binding_for_occurrence(occurrence.occurrence_id)
        except (KeyError, ContractError):
            continue
        spec = by_signature.get(
            (str(binding.goal_signature.signature_id), int(binding.goal_signature.version))
        )
        if spec is None:
            continue
        entries.append(
            SharedGoalEntry(
                occurrence_id=occurrence.occurrence_id,
                task_id=binding.task_id,
                obligation_id=binding.obligation_id,
                signature=SharingSignature.of(
                    spec,
                    authority_scope=binding.semantic_scope,
                    semantic_scope=binding.semantic_scope,
                ),
            )
        )
    return tuple(entries)


__all__ = (
    "ASSEMBLY_MISSING",
    "MISSION_STALLED",
    "ROOT_REVIEW_CUT",
    "ROOT_REVIEW_SUPERSEDED",
    "WITNESS_KEY_TAKEN",
    "COMPOUND_DISPLAY_STATUS",
    "COMPOUND_PHASE_CHANGED",
    "DISPATCH_INTERCEPTED",
    "PLAN_COMMIT_REFUSED",
    "PLAN_INTEGRITY_FAILED",
    "CompoundPhase",
    "DispatchInterception",
    "HierarchicalDispatch",
    "NetworkView",
    "PlanIntegrityError",
    "PlanRefusal",
    "PlanRoundOutcome",
    "PlanningWorld",
    "METHOD_APPLICABILITY_ASSESSED",
    "REPAIR_DECISION_DISPATCHED",
    "append_hierarchical_event",
    "shared_goal_index",
    "is_hierarchical",
    "missing_bindings",
    "next_compound_phase",
    "record_assembly_missing",
    "root_not_identified",
)


def criterion_statement(statement: str) -> str:
    """A criterion's text as the Planner reads it when it writes a method.

    2026-09-29 第十三局：写做法的模型不知道发布由系统做，给写文件的步骤都写了"在发布目录中
    给出落点路径"、又自设了发布步骤，审阅员照这句把写模块那步判不通过。
    ``file:``/``action:`` 要求的原文后面附一句谁负责。
    """
    if statement.startswith("action:"):
        return (
            statement + "（操作要求：内容全部通过后由系统执行，不属于任何步骤；不要为它单独设步骤，"
            "也不要在任何步骤的 evidence_requirement 里要求发布结果、发布目录或落点路径）"
        )
    if statement.startswith("file:"):
        return (
            statement + "（在任务工作区写出这个文件即满足；发布由系统完成，evidence_requirement "
            "不要写发布目录或落点路径）"
        )
    return statement


def _is_continuation(semantic: Any) -> bool:
    """Every input port is also an output port (e.g. ``desktop.continue-delivery``)."""
    if semantic is None or not semantic.input_ports:
        return False
    outputs = {(port.port_key, port.schema_ref) for port in semantic.output_ports}
    return all((port.port_key, port.schema_ref) in outputs for port in semantic.input_ports)
