#!/usr/bin/env python3
"""Read-only repository inspection; writes only to an ignored local evidence directory.
No import of SDK, no fetch/pull, no checkout, no database, no automatic equivalence.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, os, subprocess, sys
from pathlib import Path

RUNTIME_TOPS = ('src/', 'tests/', 'scripts/', 'schemas/')
ROOT_FILES = {'pyproject.toml','uv.lock','pytest.ini','mypy.ini','ruff.toml','.ruff.toml','setup.cfg','setup.py','conftest.py'}

def digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def canonical(x: object) -> bytes:
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()

def git(root: Path, *args: str) -> bytes:
    proc = subprocess.run(['git', '-C', str(root), *args], capture_output=True, timeout=60,
                          env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    if proc.returncode:
        raise RuntimeError(f'git {args[0]} failed (code {proc.returncode}); no state was changed')
    return proc.stdout

def file_state(root: Path, rel: str) -> dict:
    p = root / rel
    if p.is_symlink():
        return {'path':rel,'kind':'symlink','sha256':digest(os.readlink(p).encode())}
    if not p.exists(): return {'path':rel,'kind':'deleted','sha256':None}
    if not p.is_file(): return {'path':rel,'kind':'non_file','sha256':None}
    if not p.resolve().is_relative_to(root.resolve()):
        raise RuntimeError(f'path escapes repository: {rel}')
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return {'path':rel,'kind':'file','sha256':h.hexdigest(),'size':p.stat().st_size}

def dirty_paths(raw: bytes) -> list[dict]:
    chunks=raw.split(b'\0'); rows=[]; i=0
    while i < len(chunks):
        b=chunks[i];i+=1
        if not b: continue
        s=b.decode('utf-8','surrogateescape'); status=s[:2]; path=s[3:]
        row={'status':status,'path':path}
        if 'R' in status or 'C' in status:
            if i>=len(chunks) or not chunks[i]: raise RuntimeError('incomplete rename metadata')
            row['old_path']=chunks[i].decode('utf-8','surrogateescape');i+=1
        rows.append(row)
    return rows

def inventory(root: Path) -> dict:
    root=root.resolve()
    head=git(root,'rev-parse','HEAD').decode().strip()
    branch=git(root,'rev-parse','--abbrev-ref','HEAD').decode().strip()
    status=git(root,'status','--porcelain=v1','-z','--untracked-files=all')
    dirty=dirty_paths(status)
    names=set(x.decode('utf-8','surrogateescape') for x in
              git(root,'ls-files','-z','--cached','--others','--exclude-standard').split(b'\0') if x)
    controlled=sorted(x for x in names if x.startswith(RUNTIME_TOPS) or x in ROOT_FILES)
    states=[file_state(root,x) for x in controlled]
    dirty_states=[{**x,'worktree':file_state(root,x['path'])} for x in dirty]
    index_hash=digest(git(root,'ls-files','--stage','-z'))
    body={'head':head,'branch':branch,'index_digest':index_hash,
          'controlled_files':states,'dirty_files':dirty_states}
    return {**body,'root':str(root),'fingerprint':digest(canonical(body)),
            'capture_kind':'LOCAL_FILE_READ','raw_diff_saved':False}

def symbols(path: Path) -> dict:
    raw=path.read_bytes(); tree=ast.parse(raw, filename=str(path)); result={}
    def walk(body: list, prefix: str='') -> None:
        for n in body:
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                name=prefix+n.name
                signature=ast.unparse(n.args) if hasattr(n,'args') else None
                result[name]={'line':n.lineno,'end_line':n.end_lineno,'signature':signature,'kind':type(n).__name__}
                # Local nested function matching is deliberately not automatic.
                if isinstance(n,ast.ClassDef):walk(n.body,name+'.')
    walk(tree.body)
    return result

def inspect_requirement(root: Path, r: dict, equivalences: dict) -> dict:
    eq=equivalences.get(r['id']); path=r['path']; required=r.get('symbols',[])
    if eq:
        for k in ['path','symbols','file_sha256','reviewed_by','contract_evidence','focused_nodeids']:
            if k not in eq or not eq[k]: raise RuntimeError(f'incomplete reviewed equivalence {r["id"]}/{k}')
        path=eq['path'];required=eq['symbols']
    state=file_state(root,path)
    out={**r,'actual_path':path,'file_sha256':state['sha256'],'actual_symbols':[],
         'evidence_basis':'LOCAL_AST_AND_BYTES','behavior_verified':False}
    if state['kind']!='file':
        out['observed_status']='PLANNED_ABSENT' if r['category']=='TASKGRAPH_NEW_TARGET' else 'MISSING'
        return out
    if eq and state['sha256']!=eq['file_sha256']:
        out['observed_status']='EQUIVALENCE_HASH_STALE';return out
    try: known=symbols(root/path)
    except (SyntaxError,UnicodeError) as e:
        out['observed_status']='SOURCE_PARSE_ERROR';out['diagnostic_type']=type(e).__name__;return out
    missing=[]
    for name in required:
        # Unqualified names from the original plan can have one unambiguous class owner.
        matches=[n for n in known if n==name or ('.' not in name and n.rsplit('.',1)[-1]==name)]
        if len(matches)!=1: missing.append({'requested':name,'matches':matches})
        else: out['actual_symbols'].append({'name':matches[0],**known[matches[0]]})
    out['missing_or_ambiguous_symbols']=missing
    out['observed_status']='SYMBOL_MISSING_OR_AMBIGUOUS' if missing else 'PRESENT_UNVERIFIED_BEHAVIOR'
    out['equivalence_status']='REVIEWED_EXACT_HASH' if eq else 'DECLARED_PATH'
    return out

def freeze_sources(root: Path, captured: dict, dest: Path) -> dict:
    if dest.exists(): raise RuntimeError('snapshot destination already exists; no overwrite')
    if sum(r.get('size',0) for r in captured['controlled_files']) > 512*1024*1024:
        raise RuntimeError('snapshot exceeds 512 MiB bound; explicitly review before expanding')
    dest.mkdir(parents=True)
    copied=[]
    for item in captured['controlled_files']:
        if item['kind']=='deleted': continue
        if item['kind']!='file': raise RuntimeError('controlled source is symlink/non-file: '+item['path'])
        src=root/item['path'];raw=src.read_bytes()
        if digest(raw)!=item['sha256']: raise RuntimeError('source changed during freeze')
        target=dest/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(raw)
        copied.append({'path':item['path'],'sha256':item['sha256']})
    return {'path':str(dest),'files':copied,'sdk_fingerprint':captured['fingerprint'],
            'kind':'ISOLATED_SOURCE_SNAPSHOT_NOT_A_WORKTREE'}

def ensure_evidence_root(host: Path, out: Path) -> None:
    base=host.resolve()/'.local-test-evidence'
    if not out.resolve().is_relative_to(base):raise RuntimeError('output must be under Host/.local-test-evidence')
    p=subprocess.run(['git','-C',str(host),'check-ignore','-q',str(out)],capture_output=True,
                     env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    if p.returncode!=0:raise RuntimeError('.local-test-evidence is not ignored; stop, do not auto-edit Git config')

def project_python(sdk: Path) -> None:
    if Path(sys.prefix).resolve()!=(sdk.resolve()/'.venv').resolve():
        raise RuntimeError('use candidate .venv Python or uv run --frozen --no-sync in candidate; system Python refused')

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--sdk-main',type=Path,required=True)
    ap.add_argument('--host',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--requirements',type=Path,required=True);ap.add_argument('--equivalences',type=Path,required=True)
    ap.add_argument('--expected-head',default='102ad3dfa2db38d575ea929d39ec5ed1561a71da')
    a=ap.parse_args();a.candidate=a.candidate.expanduser().resolve();a.host=a.host.expanduser().resolve()
    project_python(a.candidate);ensure_evidence_root(a.host,a.out)
    if a.out.exists():raise RuntimeError('new evidence run directory required; will not overwrite')
    a.out.mkdir(parents=True)
    repositories={k:inventory(p) for k,p in [('candidate',a.candidate),('sdk_main',a.sdk_main),('host',a.host)]}
    candidate=repositories['candidate']
    eq=json.loads(a.equivalences.read_text())['mappings']; eq={x['id']:x for x in eq}
    req=json.loads(a.requirements.read_text())['requirements']
    rows=[inspect_requirement(a.candidate,r,eq) for r in req]
    identity_ok=candidate['head']==a.expected_head
    frozen=freeze_sources(a.candidate,candidate,a.out/'snapshot/sdk') if identity_ok else None
    local_paths = [
        'plans/taskSys2/升级planV1/v1.4/simpleharness-llm-native-htn-execution-plan-v2.zh-CN.md',
        'plans/taskSys2/升级planV1/v1.4/LLM-native-HTN计划V2-裁定补遗-2026-09-18.zh-CN.md',
        'plans/taskSys2/升级planV1/v1.4/执行workplan-HTN-H1-NanoJev-2026-09-19.zh-CN.md',
        'plans/taskSys2/升级planV1/v1.4/任务书-H1-2026-09-19/h1h-impl.md',
        'plans/taskSys2/升级planV1/v1.4/任务书-H1-2026-09-19/h1h-verify.md',
        'ARCHITECTURE/index.md',
        '.local-test-evidence/2026-09-20/h1/h1-admission-sources-terra.md',
        '.local-test-evidence/2026-09-20/h1/auth-producer-sol-final.md',
        '.local-test-evidence/2026-09-20/h1/h1-gate-closure-sol.md',
    ]
    local_artifacts=[{**file_state(a.host,p),'expected_path_not_relocated':True,
                      'raw_content_exported':False} for p in local_paths]
    # Only exact declared paths; missing architecture/doc locations need an explicit reviewed mapping.
    final={k:inventory(p) for k,p in [('candidate',a.candidate),('sdk_main',a.sdk_main),('host',a.host)]}
    unchanged=all(final[k]['fingerprint']==repositories[k]['fingerprint'] for k in repositories)
    required_ok=all(r['observed_status']=='PRESENT_UNVERIFIED_BEHAVIOR' for r in rows if r['category']!='TASKGRAPH_NEW_TARGET')
    report={'spec':'TG-READY-1.0','repositories':repositories,'requirements':rows,
            'expected_candidate_head':a.expected_head,'head_matches_handoff':identity_ok,
            'candidate_unchanged_during_capture':unchanged,'snapshot':frozen,
            'local_contract_and_evidence_artifacts':local_artifacts,
            'project_python':{'executable':sys.executable,'prefix':sys.prefix,'version':sys.version},
            'source_symbols_complete':required_ok,'source_map_complete':False,
            'source_map_review_status':'PENDING_BEHAVIOR_AND_EQUIVALENCE_REVIEW',
            'production_enablement_allowed':False}
    (a.out/'source-map.local.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('Captured local identity and AST. No business code or database changed. source_map_complete remains false.')
    return 0 if identity_ok and unchanged else 3

if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError) as e:
        print('BLOCKED: '+str(e),file=sys.stderr);raise SystemExit(3)
