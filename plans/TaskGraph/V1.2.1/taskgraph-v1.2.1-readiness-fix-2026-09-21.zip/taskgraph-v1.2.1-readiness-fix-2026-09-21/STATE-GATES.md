# V1.2.1 状态门禁与证据分层

本地状态依据用户 TG-READY-1.2-HANDOFF：候选102ad3d、fingerprint d9c331ff016b76cb4868c7bee4dc98ba8ecc13343018db70ebadb4c2a383a6dd。PlanAgent未读取原始本地证据，不能签本地PASS。本次工具验证另见VALIDATION.md。

| Gate | 当前 | 打开条件 / 证据 |
|---|---|---|
| REFERENCE_KIT_PASS | PASS（用户报告原参考范围） | 原kit/hash；不覆盖SDK/macOS新包 |
| V12_DELIVERY_INTEGRITY | PASS_USER_REPORTED | 原V1.2 ZIP完整；不等于工具无bug |
| V121_DELIVERY_MACOS_TESTS | PENDING_LOCAL | 新ZIP准确hash、原包工具macOS未修改字节实测；不能引用evidence旧补丁副本 |
| SOURCE_CAPTURE | PASS_WITH_SOURCE_MAP_INCOMPLETE（用户报告） | 已捕获d9c3...；后续变更重新采集，旧证据不覆写 |
| SOURCE_MAP_COMPLETE | BLOCKED | 必须复用/H1前置31项分类与合同；P02/P09/P19明确；11计划新增允许PLANNED_ABSENT，不要求预先实现 |
| RUNNER_TRIGGER_SUPPORT | BLOCKED | 真实候选runner已报告不支持；派生修复通过是DERIVED_PASS，不是candidate PASS |
| H1_SCHEMA_READY | PENDING_LOCAL_RECHECK | 同版本完整实际H1迁移和父表/FK，不能拼测试父表 |
| C_PROOF_TESTING_ALLOWED | CONDITIONAL_NOT_YET_CLEARED | 原H1工作流、静态源码身份/调用路径可读、真实H1schema与runner正常、fixture/conftest离线安全审查；只C01–C10 micro-tests，无TG业务 |
| COMMIT_SEAM_EQUIVALENT | BLOCKED_NOT_PROVEN | C01–C10源码+hash+实际行为+独立review；缺证明不等于NON_EQUIVALENT |
| H1_H_READY | BLOCKED | 三producer、唯一Commit、原36case+H1H12mutation及独立review；micro-tests不能代替全部 |
| TASKGRAPH_TG_A_READY | PENDING_LOCAL_PREFLIGHT | 仅当前prep权限：项目环境、ignored路径、来源冻结 |
| TASKGRAPH_TG_A_VALIDATED | BLOCKED | 真实注册迁移+新/升级/回滚/FK/checksum/populated legacy/触发器实测；离线descriptor通过不自动等同 |
| TASKGRAPH_TG_B_ALLOWED | NOT_ALLOWED | SOURCE_MAP_COMPLETE + H1_H_READY + TASKGRAPH_TG_A_VALIDATED + 独立review，并明确允许进入 |
| TASKGRAPH_CORE_READY | BLOCKED | 真实SDK对应42case core子集/12TG mutation/stateful/legacy/fullH1；Host和模型单列 |
| TASKGRAPH_HOST_READY | BLOCKED | 实际Host源码route映射/集成/协议失败和恢复；不要求提前写才能source capture |
| TASKGRAPH_REAL_MODEL_READY | BLOCKED | 原获准GPT-5.6、固定身份/预算及全场景收据；当前不运行 |
| PRODUCTION_ENABLEMENT_ALLOWED | false | 全部实现/验证与H1-I/完整H1、安装制品核对、最终操作人批准 |

## 两个门禁澄清

1. **C-proofs许可不要求C已经通过。**它需要安全的实际测试前置，用来发现/证明合同；失败回原H1工作流，成功才支撑等价审查。禁止完整suite凑数量不禁止受控的必要micro-test。
2. **TG-A注册不是本次prep。**后续维护者批准的窄迁移注册可在TG-B前进行，前置是完整H1schema、runner验证、离线迁移/旧数据证明和独立review，不能反过来依赖TG-B已实现。当前仍不注册。

## 身份和范围

PASS必须绑定：base候选HEAD/fingerprint、实际被测试source_variant_fingerprint（如有）、project Python/lock、输入DDL、源码/测试hash、命令、退出码、原证据相对路径/hash。基于相同HEAD不同dirty字节的收据不能直接复用。

`COLLECTED_NOT_RUN`、`NOT_RUN`、`STATIC_ONLY`、`NOT_PROVEN`不映射成PASS。参数化case需要全部适用item和逐case断言；其中一个参数通过不能代替整组。

`CAPTURED/PRESENT_UNVERIFIED_BEHAVIOR/PLANNED_ABSENT`均不是“可生产执行”。授权、operation、plan-shape仍fail-closed；不改业务wire/NanoJev/模型路由。
