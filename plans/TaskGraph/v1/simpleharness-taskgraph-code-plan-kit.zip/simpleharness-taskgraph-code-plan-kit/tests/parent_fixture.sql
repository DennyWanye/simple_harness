-- TEST ONLY: parent-key contract fixture derived from pinned SDK columns.
-- NOT a production schema, migration or replacement for the real SDK migrations.
CREATE TABLE missions(mission_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL) STRICT;
CREATE TABLE events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT NOT NULL UNIQUE,mission_id TEXT NOT NULL,type TEXT NOT NULL,payload_json TEXT NOT NULL) STRICT;
CREATE TABLE tasks(task_id TEXT PRIMARY KEY,mission_id TEXT NOT NULL REFERENCES missions(mission_id)) STRICT;
CREATE TABLE attempts(attempt_id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(task_id),mission_id TEXT NOT NULL REFERENCES missions(mission_id)) STRICT;
CREATE TABLE dispatch_intents(intent_id TEXT PRIMARY KEY,subject_id TEXT UNIQUE NOT NULL,mission_id TEXT NOT NULL,creation_key TEXT UNIQUE NOT NULL,input_id TEXT NOT NULL,input_hash TEXT NOT NULL) STRICT;
CREATE TABLE task_semantics(task_id TEXT NOT NULL,binding_revision INTEGER NOT NULL,mission_id TEXT NOT NULL,obligation_id TEXT NOT NULL,form TEXT NOT NULL,input_binding_revision INTEGER NOT NULL,dispatch_generation INTEGER NOT NULL,content_hash TEXT NOT NULL,binding_json TEXT NOT NULL,PRIMARY KEY(task_id,binding_revision)) STRICT;
CREATE TABLE method_instances(mission_id TEXT NOT NULL,instance_id TEXT NOT NULL,goal_occurrence_id TEXT NOT NULL,state TEXT NOT NULL,draft_json TEXT NOT NULL,PRIMARY KEY(mission_id,instance_id)) STRICT;
CREATE TABLE method_child_occurrences(instance_id TEXT NOT NULL,slot_key TEXT NOT NULL,mission_id TEXT NOT NULL,occurrence_id TEXT NOT NULL,goal_occurrence_id TEXT NOT NULL,obligation_id TEXT NOT NULL,reuse_policy TEXT NOT NULL,requiredness TEXT NOT NULL,binding_json TEXT NOT NULL,PRIMARY KEY(instance_id,slot_key)) STRICT;
CREATE TABLE plan_revisions(mission_id TEXT NOT NULL REFERENCES missions(mission_id),revision INTEGER NOT NULL,state TEXT NOT NULL,snapshot_hash TEXT NOT NULL,PRIMARY KEY(mission_id,revision)) STRICT;
CREATE UNIQUE INDEX original_active_idx ON plan_revisions(mission_id) WHERE state='ACTIVE';
CREATE TABLE plan_memberships(mission_id TEXT NOT NULL,revision INTEGER NOT NULL,occurrence_id TEXT NOT NULL,task_id TEXT NOT NULL,obligation_id TEXT NOT NULL,form TEXT NOT NULL,member_json TEXT NOT NULL,PRIMARY KEY(mission_id,revision,occurrence_id),FOREIGN KEY(mission_id,revision) REFERENCES plan_revisions(mission_id,revision)) STRICT;
CREATE TABLE obligations(mission_id TEXT NOT NULL,obligation_id TEXT NOT NULL,PRIMARY KEY(mission_id,obligation_id)) STRICT;
CREATE TABLE requirements_revisions(mission_id TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(mission_id,revision)) STRICT;
CREATE TABLE input_manifests(manifest_hash TEXT PRIMARY KEY,origin_mission_id TEXT NOT NULL,manifest_json TEXT NOT NULL) STRICT;
CREATE TABLE input_manifest_bindings(mission_id TEXT NOT NULL,task_id TEXT NOT NULL,manifest_hash TEXT NOT NULL,input_binding_revision INTEGER NOT NULL,attempt_id TEXT,request_id TEXT,PRIMARY KEY(mission_id,task_id,manifest_hash)) STRICT;
CREATE TABLE planning_requests(request_id TEXT PRIMARY KEY,mission_id TEXT NOT NULL) STRICT;
CREATE TABLE planning_decisions(decision_id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES planning_requests(request_id)) STRICT;
CREATE TABLE planning_admission_checks(check_id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES planning_requests(request_id),phase TEXT NOT NULL) STRICT;

CREATE TABLE order_constraints(mission_id TEXT NOT NULL,plan_revision INTEGER NOT NULL,before_occurrence TEXT NOT NULL,after_occurrence TEXT NOT NULL,release_condition TEXT NOT NULL,PRIMARY KEY(mission_id,plan_revision,before_occurrence,after_occurrence)) STRICT;
CREATE TABLE data_requirements(mission_id TEXT NOT NULL,plan_revision INTEGER NOT NULL,requirement_id TEXT NOT NULL,producer_occurrence TEXT NOT NULL,output_port TEXT NOT NULL,consumer_occurrence TEXT NOT NULL,input_port TEXT NOT NULL,PRIMARY KEY(mission_id,plan_revision,requirement_id)) STRICT;
