# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Commit-time H1-H producer rechecks.

The planner response is assembled from several producer snapshots.  Admission is
therefore not a write authority by itself: immediately before the existing
PlanRevision transaction writes, this mixin rereads every producer on the same
Store transaction and refuses a stale or incomplete snapshot.  Legacy callers do
not use this entry point.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, NoReturn

from ..contracts.models import sha256_hex
from ..governance.planning_authorization import (
    PlanningAuthorizationSnapshot,
    planning_policy_for_mission,
    StorePlanningAuthorityReader,
    build_planning_authorization,
    check_planning_authorization,
)
from ..governance.planning_authorization import (
    SourceUnavailable as AuthoritySourceUnavailable,
)
from ..planning.plan_preview import _source_snapshot_payload
from ..runtime.planning_operations import (
    OperationSnapshot,
    RuntimeWorkSnapshot,
    StoreOperationReader,
    build_operation_snapshot,
    operation_gate,
    read_running_work,
)
from ..runtime.planning_operations import (
    SourceUnavailable as OperationSourceUnavailable,
)
from ..storage.planning_admission_store import PlanningAdmissionStore
from .plan_commits import CommitPlanCommand, PlanCommitRejected, PlanPrincipal


@dataclass(frozen=True, slots=True)
class PlanningCommitAdmission:
    """The immutable producer values captured by H1-H preview/admission."""

    request_id: str
    decision_hash: str
    decision_key: str
    authority: PlanningAuthorizationSnapshot
    operations: OperationSnapshot
    runtime_work: RuntimeWorkSnapshot
    preview_request_id: str
    preview_decision_hash: str
    preview_compilation_hash: str
    preview_read_set_hash: str


def _authority_identity(snapshot: PlanningAuthorizationSnapshot) -> dict[str, Any]:
    value = snapshot.to_json()
    value.pop("checked_at_ms", None)
    return value


def _raise(reason: str, detail: str) -> NoReturn:
    raise PlanCommitRejected(reason, detail)


def _check_planning_commit(
    *,
    store: Any,
    command: CommitPlanCommand,
    principal: PlanPrincipal,
    admission: PlanningCommitAdmission,
) -> None:
    """Run all H1-H producer checks inside ``commit_plan_revision``'s transaction."""

    if admission.preview_request_id != admission.request_id:
        _raise("PREVIEW_IDENTITY_STALE", "preview request identity differs from admission")
    if admission.preview_decision_hash != admission.decision_hash:
        _raise("PREVIEW_IDENTITY_STALE", "preview decision identity differs from admission")
    expected_compilation_hash = sha256_hex(
        {
            "delta": command.delta.to_json(),
            "network": _source_snapshot_payload(command.network),
        }
    )
    if expected_compilation_hash != admission.preview_compilation_hash:
        _raise("PREVIEW_IDENTITY_STALE", "preview compilation identity changed")
    if sha256_hex(command.read_set.to_json()) != admission.preview_read_set_hash:
        _raise("PREVIEW_IDENTITY_STALE", "preview read-set identity changed")

    now_ms = int(store.now * 1000)
    try:
        authority = build_planning_authorization(
            admission.request_id,
            read=StorePlanningAuthorityReader(PlanningAdmissionStore(store), store),
            caller=principal,
            policy=planning_policy_for_mission(store, command.mission_id),
            now_ms=now_ms,
        )
    except Exception as error:  # pragma: no cover - producer wrapper is defensive
        _raise("SOURCE_UNAVAILABLE", f"planning authority read failed: {type(error).__name__}")
    if isinstance(authority, AuthoritySourceUnavailable):
        _raise(
            authority.reason_code
            if authority.reason_code in {"REQUEST_BINDING_STALE", "AUTHORIZATION_REQUIRED"}
            else "SOURCE_UNAVAILABLE",
            f"{authority.source}: {authority.detail}",
        )
    if not isinstance(authority, PlanningAuthorizationSnapshot):
        _raise("SOURCE_UNAVAILABLE", "planning authority snapshot is unreadable")
    if not isinstance(admission.authority, PlanningAuthorizationSnapshot):
        _raise("SOURCE_UNAVAILABLE", "preview authority snapshot is unreadable")
    if _authority_identity(authority) != _authority_identity(admission.authority):
        _raise("REQUEST_BINDING_STALE", "planning grant changed since preview")
    refusal = check_planning_authorization(
        authority, decision_key=admission.decision_key, now_ms=now_ms
    )
    if refusal is not None:
        _raise(refusal, "planning grant is inactive or expired at commit")

    try:
        operations = build_operation_snapshot(
            command.mission_id,
            reader=StoreOperationReader(store),
            now_ms=now_ms,
        )
    except OperationSourceUnavailable as error:
        _raise(
            "OPERATION_SNAPSHOT_STALE"
            if error.reason == "operation_mapping_incomplete"
            else "SOURCE_UNAVAILABLE",
            str(error),
        )
    if operations.read_digest != admission.operations.read_digest:
        _raise("OPERATION_SNAPSHOT_STALE", "operation bindings/links/actions changed since preview")
    try:
        operation_gate(operations)
    except OperationSourceUnavailable as error:
        _raise("OPERATION_UNRESOLVED", str(error))

    try:
        runtime = read_running_work(
            command.mission_id,
            admission.runtime_work.retiring_instance_ids,
            reader=StoreOperationReader(
                store,
                ignore_intent_ids=(
                    str((command.source or {}).get("intent_id"))
                    if (command.source or {}).get("intent_id") is not None
                    else "",
                ),
            ),
        )
    except OperationSourceUnavailable as error:
        _raise("SOURCE_UNAVAILABLE", str(error))
    if runtime.snapshot_digest != admission.runtime_work.snapshot_digest:
        _raise("RUNTIME_WORK_STALE", "running work changed since preview")
    if runtime.requires_convergence:
        _raise("RUNNING_WORK_UNRESOLVED", "running work requires convergence before commit")


class PlanningAdmissionCommitsMixin:
    """New-protocol commit entry; inherited by ``CommitService`` only."""

    def commit_planning_revision(
        self,
        command: CommitPlanCommand,
        principal: PlanPrincipal,
        *,
        admission: PlanningCommitAdmission,
    ) -> Any:
        if not isinstance(admission, PlanningCommitAdmission):
            raise PlanCommitRejected("SOURCE_UNAVAILABLE", "missing H1-H commit admission")

        def guard() -> None:
            _check_planning_commit(
                store=self._store,  # type: ignore[attr-defined]
                command=command,
                principal=principal,
                admission=admission,
            )

        return self.commit_plan_revision(  # type: ignore[attr-defined]
            command, principal, precommit_guard=guard
        )


__all__ = ("PlanningAdmissionCommitsMixin", "PlanningCommitAdmission")
