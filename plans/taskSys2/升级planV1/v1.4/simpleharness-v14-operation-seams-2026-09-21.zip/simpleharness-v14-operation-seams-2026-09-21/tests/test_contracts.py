import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from reference.rules import (hash_domains, strict_json, check_transition,
                             stop_gate_is_active,covers_current_handoffs)
from jsonschema import Draft202012Validator

H='a'*64
REF={'kind':'artifact','id':'x','revision':1,'content_hash':H}
ACC={**REF,'kind':'acceptance','id':'a'}
SCHEMA=json.loads((ROOT/'contracts.schema.json').read_text())

def validate(kind,value):
    schema={'$schema':SCHEMA['$schema'],'$defs':SCHEMA['$defs'],
            '$ref':'#/$defs/'+kind}
    Draft202012Validator(schema).validate(value)

class Contracts(unittest.TestCase):
    def test_all_schemas_well_formed(self):
        Draft202012Validator.check_schema(SCHEMA)
        for v in SCHEMA['$defs'].values(): Draft202012Validator.check_schema(v)
    def test_user_submit_needs_no_fabricated_receipt(self):
        cmd={'schema_version':1,'mission_id':'m','idempotency_key':'u1',
             'intent_source':{'kind':'USER_COMMAND'},'candidate_artifact_ref':REF,
             'prepared_acceptance_refs':[ACC],'supersedes_intent_id':None}
        validate('submit_command',cmd)
        cmd['intent_source']['origin_receipt_id']='fake'
        self.assertTrue(list(Draft202012Validator(SCHEMA['$defs']['submit_command']).iter_errors(cmd)))
    def test_automation_requires_explicit_source(self):
        cmd={'schema_version':1,'mission_id':'m','idempotency_key':'u1',
             'intent_source':{'kind':'AUTHORIZED_SLOT'},'candidate_artifact_ref':REF,
             'prepared_acceptance_refs':[ACC],'supersedes_intent_id':None}
        self.assertTrue(list(Draft202012Validator(SCHEMA['$defs']['submit_command']).iter_errors(cmd)))
        cmd['intent_source'].update(origin_receipt_id='real-source',slot_key='one')
        validate('submit_command',cmd)
    def test_no_model_authority_field(self):
        cmd={'schema_version':1,'mission_id':'m','idempotency_key':'u1',
             'intent_source':{'kind':'USER_COMMAND'},'candidate_artifact_ref':REF,
             'prepared_acceptance_refs':[ACC],'supersedes_intent_id':None,'approved':True}
        self.assertTrue(list(Draft202012Validator(SCHEMA['$defs']['submit_command']).iter_errors(cmd)))
    def test_parameters_schema(self):
        p={'schema_version':1,'intent_id':'i','connector_id':'c','connector_version':'1',
           'operation_name':'op','connector_profile_hash':H,'normalized_target_ref':'t',
           'expected_target_version':None,'parameter_schema_ref':{'id':'s','version':1,'content_hash':H},
           'effective_params':{'body':'x'},'params_hash':H,'candidate_artifact_ref':REF,
           'accepted_input_refs':[ACC]}
        validate('parameters',p)
        p['candidate_artifact_ref']={**REF,'revision':True}
        self.assertTrue(list(Draft202012Validator(SCHEMA['$defs']['parameters']).iter_errors(p)))
    def test_hashes_do_not_substitute(self):
        # Inject a fixture hasher. This is NOT the actual SDK connectors.params_hash.
        ph=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
        p={'x':1}
        a=hash_domains(b'{"params":{"x":1}}',b'{"effective_params":{"x":1}}',p,ph)
        b=hash_domains(b'{ "params": {"x":1} }',b'{"effective_params":{"x":1}}',p,ph)
        self.assertNotEqual(a.candidate_file_hash,b.candidate_file_hash)
        self.assertEqual(a.params_hash,b.params_hash)
        c=hash_domains(b'{"params":{"x":1}}',b'{"v":1,"effective_params":{"x":1}}',p,ph)
        self.assertNotEqual(a.parameters_content_hash,c.parameters_content_hash)
        self.assertEqual(a.params_hash,c.params_hash)
    def test_strict_duplicate_and_nan(self):
        for raw in (b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":Infinity}'):
            with self.assertRaises(ValueError): strict_json(raw)
        self.assertEqual(strict_json(b'{"x":1}'),{'x':1})
    def test_continuation_timeout_stays_fenced(self):
        check_transition('WAITING','MANUAL_REQUIRED')
        self.assertTrue(stop_gate_is_active('MANUAL_REQUIRED'))
        self.assertTrue(stop_gate_is_active('STALE_FENCED'))
        self.assertTrue(stop_gate_is_active('PAUSED'))
    def test_continuation_terminal_not_reopened(self):
        with self.assertRaises(ValueError):check_transition('APPLIED','WAITING')
        self.assertFalse(stop_gate_is_active('APPLIED'))
        with self.assertRaises(ValueError):stop_gate_is_active('invented')
    def test_negative_proof_coverage_not_future_handoff(self):
        self.assertTrue(covers_current_handoffs(('h1',),('h1',)))
        self.assertFalse(covers_current_handoffs(('h1','h2'),('h1',)))
        self.assertFalse(covers_current_handoffs((),()))
        self.assertFalse(covers_current_handoffs(('h1',),('h1','h1')))

class SchemaSQL(unittest.TestCase):
    def setUp(self):
        # Parent-key fixture only. Not a real SDK schema/migration test.
        self.c=sqlite3.connect(':memory:',isolation_level=None)
        self.c.execute('PRAGMA foreign_keys=ON')
        for table,key in [('missions','mission_id'),('commit_receipts','commit_id'),
                          ('tasks','task_id'),('results','result_id'),('attempts','attempt_id'),
                          ('artifacts','artifact_id'),('review_packages','package_id'),
                          ('planning_decisions','decision_id'),('planning_requests','request_id')]:
            self.c.execute(f'CREATE TABLE {table}({key} TEXT PRIMARY KEY) STRICT')
        for t in ('requirements_revisions','plan_revisions'):
            self.c.execute(f'CREATE TABLE {t}(mission_id TEXT,revision INTEGER,PRIMARY KEY(mission_id,revision)) STRICT')
        self.c.execute('BEGIN IMMEDIATE')
        # This addition has no triggers; parse complete statements rather than splitting.
        buf=''
        for ch in (ROOT/'sql/operation_seams.sql').read_text():
            buf+=ch
            if ch==';' and sqlite3.complete_statement(buf):
                self.c.execute(buf);buf=''
        self.c.execute('COMMIT')
    def tearDown(self): self.c.close()
    def test_three_tables_and_foreign_keys(self):
        tables={r[0] for r in self.c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({'operation_payload_objects','operation_intent_bindings','planning_repair_continuations'}<=tables)
        self.assertEqual(list(self.c.execute('PRAGMA foreign_key_check')),[])
    def test_receipt_can_be_written_in_same_transaction(self):
        self.c.execute("INSERT INTO missions VALUES ('m')")
        self.c.execute('BEGIN IMMEDIATE')
        self.c.execute("INSERT INTO operation_payload_objects VALUES(?,?,?,?,?,?,?,?,?,?)",('p','m','PARAMETERS',1,H,2,'application/json','cas:p','r',1))
        self.c.execute("INSERT INTO commit_receipts VALUES ('r')")
        self.c.execute('COMMIT')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM operation_payload_objects').fetchone()[0],1)
    def test_missing_source_receipt_rejected_at_commit(self):
        self.c.execute("INSERT INTO missions VALUES ('m')")
        self.c.execute('BEGIN IMMEDIATE')
        self.c.execute("INSERT INTO operation_payload_objects VALUES(?,?,?,?,?,?,?,?,?,?)",('p','m','PARAMETERS',1,H,2,'application/json','cas:p','missing',1))
        with self.assertRaises(sqlite3.IntegrityError):self.c.execute('COMMIT')
        self.c.execute('ROLLBACK')
        self.assertEqual(self.c.execute('SELECT COUNT(*) FROM operation_payload_objects').fetchone()[0],0)
    def test_no_shadow_effect_columns(self):
        for t in ('operation_payload_objects','operation_intent_bindings','planning_repair_continuations'):
            cols={r[1] for r in self.c.execute(f'PRAGMA table_info({t})')}
            self.assertFalse({'effect_outcome','balance','settled_cost','reconciled'}&cols)

if __name__=='__main__':unittest.main()
