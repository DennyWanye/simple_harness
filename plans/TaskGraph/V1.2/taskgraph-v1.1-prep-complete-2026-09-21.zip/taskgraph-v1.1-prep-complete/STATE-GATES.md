# TaskGraph V1.1：当前状态门禁

**TG-READY-1.1，2026-09-21。候选 HEAD 为用户报告 `102ad3dfa2db38d575ea929d39ec5ed1561a71da`；本轮未采集本地 dirty fingerprint。**

| Gate | 当前状态 | 必需证据；不能以什么代替 |
|---|---|---|
| `REFERENCE_KIT_PASS` | PASS（参考范围） | 原包87 reference、8 Schema及其hash；不能推导SDK |
| `SOURCE_MAP_COMPLETE` | BLOCKED | 三仓真实HEAD/index/dirty hashes、24接缝/等价合同审查；AST存在不能替代 |
| `H1_H_READY` | BLOCKED | 三producer、唯一Commit C01–C10、36case真实覆盖与运行、H1H的12mutation、独立审阅；不是TaskGraph的12mutation |
| `TASKGRAPH_TG_A_READY` | PENDING_LOCAL_PREFLIGHT | 项目环境、ignored路径、真实来源冻结、runner/SQL预检；仅允许prep |
| `TASKGRAPH_TG_A_VALIDATED` | BLOCKED | 完整SDK的真实runner/new/upgrade/rollback/FK/checksum/populated legacy/trigger收据；process-local描述符probe只是其中一步 |
| `TASKGRAPH_CORE_READY` | BLOCKED | 实际TaskGraph核心场景、12mutation、stateful、legacy/full H1；Host与真实模型子项单独 |
| `TASKGRAPH_HOST_READY` | BLOCKED | 实际Host route/组件/权限/协议/恢复证据，绑定Host与SDK字节 |
| `TASKGRAPH_REAL_MODEL_READY` | BLOCKED | 获准GPT-5.6和冻结budget/scenario真实结果，不能stub |
| `PRODUCTION_ENABLEMENT_ALLOWED` | BLOCKED | 所有依赖、同一candidate fingerprint、独立最终核验、明确操作人授权；工具永不自行签发 |

当前许可：`TG_A_PREP=true`、`TG_B=false`、`TG_C_D_E_RUNTIME=false`、`PRODUCTION=false`。

## 记录格式

每项本地通过记录必须包含：gate、status、candidate HEAD、candidate fingerprint、SDK/Host相关文件与lock hash、命令/cwd、实际 nodeid、结果范围、证据相对路径/SHA256、reviewer。只有文件名/文字“PASS”而没有实际凭据不算。

`h1h/closure.json` 当前所有36case NOT_RUN、实际 fingerprint=null；它是状态模板，不是已获得的closure。实际结果写到 ignored run 的副本，不能覆盖本包模板然后把交付hash当测试证据。

`commit_planning_revision` 可在C01–C10审查通过后登记为合同等价实现；名称不同本身不是永久blocker。未核实前仍BLOCKED。probe、collection、工具单测和参考SQL都不打开本表门禁。

## 后续顺序

`LOCAL_CAPTURE → 合同与schema核对 → H1H闭合/独立核验 + TG-A真实迁移验证 → TG-B单独获准 → TG-C/D/E → 全验收/Host/真实模型/明确生产批准`。

H1-I与完整H1继续保留；H1H focused通过不能称H1完成。42个TaskGraph case的Host、模型子项必须在对应门禁完成后执行，不能把核心通过写成全42通过。
