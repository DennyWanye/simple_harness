#!/usr/bin/env python3
"""Bind planned tests to locally collected exact pytest nodeids. Does not run tests."""
from __future__ import annotations
import argparse,json
from pathlib import Path

def map_cases(mapping:dict,collection:dict)->dict:
    if collection.get('collection_errors'):raise ValueError('collection has errors')
    if not collection.get('candidate_fingerprint'):raise ValueError('collection lacks candidate fingerprint')
    available=set(collection['nodeids']); rows=[]
    for original in mapping['cases']:
        row=dict(original);target=row['target_nodeid']
        eq=row.get('nodeid_equivalence')
        if eq:
            for key in ('reviewed_by','source_sha256','candidate_fingerprint','assertion_coverage','nodeids'):
                if not eq.get(key):raise ValueError('incomplete test equivalence review')
            if eq['candidate_fingerprint']!=collection['candidate_fingerprint']:
                raise ValueError('test equivalence belongs to another candidate')
            wanted=eq['nodeids']
            actual=sorted(n for n in wanted if n in available)
            complete=len(actual)==len(wanted)
        else:
            actual=sorted(n for n in available if n==target or n.startswith(target+'['))
            complete=bool(actual)
        row['actual_nodeids']=actual
        row['collection_coverage_complete']=complete
        row['nodeid_status']='COLLECTED_NOT_EXECUTED' if complete else 'PARTIALLY_COLLECTED' if actual else 'NOT_COLLECTED' 
        row['status']='PENDING_SDK_EXECUTION'
        rows.append(row)
    return {**mapping,'candidate_fingerprint':collection['candidate_fingerprint'],
            'actual_sdk_pass_count':0,'cases':rows,'reference_results_used':False}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mapping',type=Path,required=True);p.add_argument('--collection',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    result=map_cases(json.loads(a.mapping.read_text()),json.loads(a.collection.read_text()))
    with a.out.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print('Collection mapping written; no PASS inferred.')
    return 0
if __name__=='__main__':raise SystemExit(main())
