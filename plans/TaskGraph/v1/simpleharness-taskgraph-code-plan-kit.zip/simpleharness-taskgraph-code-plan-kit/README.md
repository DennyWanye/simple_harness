# TaskGraph 代码级实施包 · TG-EXEC-2.0

**入口：`PLAN.zh-CN.md`。**这是 SimpleHarness TaskGraph 的实施规格和验证辅助，不是已经合入的生产补丁。

沿用 H1H-ADM-1.0、LLM-native HTN、原60项要求/P1–P9，不新增第二套任务、预算或Operation权威。H1 decode-only和NanoJev Shadow限制保持。用户本地脏worktree没有在本环境读取，远端参考SHA不是升级目标。

## 文件

| 文件 | 用途 |
|---|---|
| PLAN.zh-CN.md | 主规格；附全部SQL、查询、Store步骤、42组验收与8份Schema |
| sql/001_taskgraph_extension.sql | 九张新增表及真实PK/FK/CHECK/索引/触发器；通过原runner注册下一未占用迁移 |
| sql/002_access_patterns.sql | 15组命名读取、CAS、fence、claim/ack/retry查询模板；不是迁移 |
| schemas/*.schema.json | 完整新增内部/只读通信定义；嵌套旧合同仍由原codec验证 |
| implementation/seams.json | 24项真实输入的producer、权威、join、缺失行为、关联测试 |
| implementation/STORE-RECIPES.zh-CN.md | Source装配、历史pins、Attempt关联、收敛/通知状态转换 |
| sdk-test-cases.json / mutations.json | 42组真实SDK待执行验收和12个定点变异，不是已通过记录 |
| reference/rules.py | 可执行局部算法参考；不是替换原SDK的拷贝代码 |
| tests/parent_fixture.sql | **仅测试**原表关键列/PK契约，严禁用于生产迁移 |
| scripts/probe_checkout.py | 本地只读源码预检；不pull/reset/clean，不读生产DB |
| scripts/validate_kit.py | 资料包、Schema、SQL夹具、编号与哈希检查 |
| evidence/ | 原60项要求和前次mapping原样保留 |
| VALIDATION.md / validation-results.json | 本轮真实运行范围与尚未运行范围 |

## 本包运行

Python >=3.11。结构Schema测试使用 `jsonschema`；本次实际环境为4.26.0。依赖文件仅服务本包，不要求给SDK生产运行时新增依赖。

```bash
python -m unittest discover -s tests -v
python scripts/validate_kit.py
```

本地候选预检（实际存在该路径的用户机器）：

```bash
python scripts/probe_checkout.py \
  --sdk /Users/denny/projects/simple-harness-sdk-h1h-impl \
  --out ./checkout-probe.json
```

source-map不吻合时报告真实符号差异；不得自动拉代码、改数据库或让模型编造producer。H1H补遗生产接线必须通过才启用TaskGraph实际任务。完整SDK、独立核验、真实模型/Host门禁仍按主规格执行。

**测试tokens：**绝大多数负向/并发/恢复场景用固定Provider回复+真实Store/Compiler/Commit完成；仅最后集成候选使用获准GPT-5.6。默认报告摘要+证据hash，不循环读取整个计划和所有模型轨迹。
