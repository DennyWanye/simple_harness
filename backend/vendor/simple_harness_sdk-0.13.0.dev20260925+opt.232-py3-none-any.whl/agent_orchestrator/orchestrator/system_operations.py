# SPDX-License-Identifier: Apache-2.0
"""System-prepared operation intents: the ``AUTHORIZED_SLOT`` source.

2026-09-29（plans/2026-09-28-system-operations）：发布这类参数早已被用户在确认页定死的操作，
由系统按已批准效果准备申请单，模型只做内容。真机第四、五局里模型写申请单反复出错，把整个
任务 12 次尝试耗光。

- 要做什么：只从已批准效果覆盖的那条 ``action:`` 要求里读（一件事只记一处）。
- 发布哪个文件：当前已接受的内容产出里路径等于目标（其次文件名相同）的唯一产物。申请单里
  的候选引用仍是那份审过的真实文件本身，只有申请单 JSON 由系统生成，所以原有的来源、参数
  绑定、审阅与核对检查全部照旧成立，发布的一定是审过的字节。
- 谁提交：确认页批准该规格的那个人（自动模式下由主机按用户的模式代为确认，如实记来源）。
- 应用注册的连接器（第 2 片，2026-10-20）：参数是建任务时写在要求上的那一份；参数引用了产物
  （``{"$artifact": 路径}``）就以那份产物为候选，没有引用就以该义务下最下游已接受步骤的产出为
  锚点产物——它不是操作的内容，只把申请单钉在审过的那一步上。L1 操作照样由系统准备，按等级
  规则不要人批，直接执行。
"""

from __future__ import annotations

import json
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, cast

from ..contracts import MissionStopReason
from ..contracts.htn import TaskForm
from ..contracts.models import ContractError
from ..contracts.operation_intents import (
    CompletionSlotV2,
    OperationIntentSourceKind,
    OperationIntentSourceV2,
    SubmitOperationIntentV2,
)
from ..contracts.semantic_base import TypedRef, TypedRefKind, content_hash_of
from ..governance.permissions import Principal
from ..planning.htn.grounding import derive_id
from ..runtime.action_params import PUBLISH, artifact_paths
from ..runtime.action_schema import parse_action_criterion
from ..runtime.operation_reconciliation import nonapplication_outcome, stored_negative_proof
from ..storage import planning_human_store
from ..storage.htn_store import HtnStore
from ..storage.operation_completion_store import OperationCompletionStore
from ..storage.operation_intent_store import OperationIntentStore
from .action_commits import business_action_id
from .planning_repair_requests import REQUESTED, record_request

if TYPE_CHECKING:
    from ..contracts.resolution import Acceptance

SYSTEM_REASON = "用户在确认页批准的操作：发布 {source} 到 {target}"
GENERIC_REASON = "用户在建任务时写明、确认页批准的操作：{operation}（目标 {target}）"


def effect_operation(effect: Any, requirements: Any) -> tuple[str, str, str]:
    """The one ``action:<connector>.<operation>:<target>`` an approved effect covers."""

    statements = {item.criterion_id: item.statement for item in requirements.criteria}
    found = [
        parsed
        for criterion in effect.criterion_ids
        if (parsed := parse_action_criterion(statements.get(criterion, ""))) is not None
    ]
    if len(found) != 1:
        raise ContractError(f"effect {effect.effect_key!r} covers {len(found)} operations, not one")
    return found[0]


def effect_params(effect: Any, requirements: Any) -> dict[str, Any]:
    """The parameters written on the one ``action:`` requirement an effect covers."""

    statements = {item.criterion_id: item for item in requirements.criteria}
    for criterion in effect.criterion_ids:
        item = statements.get(criterion)
        if item is not None and parse_action_criterion(str(item.statement)) is not None:
            return dict(item.action_params or {})
    return {}


def is_publish(operation: tuple[str, str, str]) -> bool:
    return (operation[0], operation[1]) == PUBLISH


def source_matches(path: str, target: str) -> bool:
    return path == target or path.rsplit("/", 1)[-1] == target.rsplit("/", 1)[-1]


def system_candidate_bytes(
    operation: tuple[str, str, str], source_path: str, params: dict[str, Any] | None = None
) -> bytes:
    """The application form JSON the system writes: for a publish the file to send, for any
    other operation the parameters frozen on its requirement."""

    connector, name, target = operation
    candidate = (
        {
            "connector": connector,
            "operation": name,
            "target": target,
            "params": {"artifact_path": source_path},
            "reason": SYSTEM_REASON.format(source=source_path, target=target),
        }
        if is_publish(operation)
        else {
            "connector": connector,
            "operation": name,
            "target": target,
            "params": dict(params or {}),
            "reason": GENERIC_REASON.format(operation=f"{connector}.{name}", target=target),
        }
    )
    return json.dumps(candidate, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def authorized_slot_operation(
    store: Any,
    command: SubmitOperationIntentV2,
    principal: Principal,
    effect: Any,
    requirements: Any,
) -> tuple[str, str, str]:
    """Check the slot authority and return the operation it names (read-only)."""

    source = command.intent_source
    receipt = store.get_receipt(str(source.origin_receipt_id))
    authority = (receipt or {}).get("authority") or {}
    if (
        receipt is None
        or receipt.get("kind") != "operation_completion_spec_approved"
        or receipt.get("mission_id") != command.mission_id
        or receipt.get("spec_hash") != command.completion_slot.spec_hash
        or source.slot_key != command.completion_slot.effect_key
        or authority.get("issuer_id") != principal.principal_id
    ):
        raise ContractError("AUTHORIZED_SLOT authority differs from the approved Spec")
    return effect_operation(effect, requirements)


#: 审阅没做成或判断不了时，系统替代重交的次数上限；规划器为同一发布补步骤的次数上限。
SYSTEM_RESUBMIT_CAP = 2
SOURCE_REPAIR_CAP = 2
_RETRY_VERDICTS = frozenset({"REVIEW_FAILED", "INCONCLUSIVE"})
_REFUSED_VERDICTS = frozenset({"REWORK", "REJECTED"})


def _leaves(store: Any, htn: HtnStore, mission_id: str) -> list[Any] | None:
    """Tasks of the active plan's primitive leaves (each with ``upstream`` task ids from the
    plan's own ORDER/DATA edges), or None while any leaf has no accepted result.

    审阅 2026-09-29：分层任务的 ``Task.dependency_ids`` 故意留空，上下游只能从计划网络读。
    """

    active = htn.active_plan_revision(mission_id)
    if active is None:
        return None
    members = htn.list_plan_memberships(mission_id, active.revision)
    task_of = {str(member.occurrence_id): str(member.task_id) for member in members}
    before: dict[str, set[str]] = {}
    for order in htn.list_order_constraints(mission_id, active.revision):
        before.setdefault(str(order.after), set()).add(str(order.before))
    for data in htn.list_data_requirements(mission_id, active.revision):
        before.setdefault(str(data.consumer_occurrence), set()).add(str(data.producer_occurrence))

    def upstream(occurrence: str) -> frozenset[str]:
        seen: set[str] = set()
        stack = list(before.get(occurrence, ()))
        while stack:
            item = stack.pop()
            if item not in seen:
                seen.add(item)
                stack.extend(before.get(item, ()))
        return frozenset(task_of[item] for item in seen if item in task_of)

    tasks = []
    for member in members:
        if member.form is not TaskForm.PRIMITIVE:
            continue
        task = store.get_task(str(member.task_id))
        if task is None or not task.accepted_result_id:
            return None
        tasks.append(SimpleNamespace(task=task, upstream=upstream(str(member.occurrence_id))))
    return tasks or None


def _current_acceptances(htn: HtnStore, mission_id: str) -> dict[tuple[str, str], Any]:
    current: dict[tuple[str, str], Any] = {}
    for acceptance in htn.list_acceptances(mission_id):
        if str(acceptance.validity) == "CURRENT":
            for ref in acceptance.artifact_refs:
                current.setdefault((ref.id, ref.content_hash), acceptance)
    return current


def _anchor(store: Any, htn: HtnStore, mission_id: str, leaves: list[Any]) -> list[Any]:
    """没有引用产物的操作的锚点：最下游的已接受步骤（不在任何别的步骤上游）里按任务号排第一个、
    它被接受的结果里按路径排第一份的已核产物。只做锚点，不是操作内容；找不到就是空。"""

    upstream = set().union(*(leaf.upstream for leaf in leaves))
    current = _current_acceptances(htn, mission_id)
    for leaf in sorted(
        (leaf for leaf in leaves if str(leaf.task.id) not in upstream),
        key=lambda leaf: str(leaf.task.id),
    ):
        result = store.get_result(leaf.task.accepted_result_id)
        artifacts = [
            artifact
            for artifact_id in (() if result is None else result.artifacts)
            if (artifact := store.get_artifact(artifact_id)) is not None
            and artifact.verification_status == "VERIFIED"
        ]
        for artifact in sorted(artifacts, key=lambda item: str(item.path)):
            acceptance = current.get((artifact.id, artifact.content_hash))
            if acceptance is not None:
                return [(artifact, acceptance, leaf)]
    return []


def _sources(
    store: Any,
    htn: HtnStore,
    mission_id: str,
    leaves: list[Any],
    target: str,
    *,
    exact: bool = False,
) -> list[tuple[Any, Any, Any]]:
    """(artifact, acceptance, task) — only the current plan's leaves, only the result each
    leaf finally had accepted (审阅 2026-09-29：旧步骤、旧版本的接受记录一直算"当前"，
    续写同一文件的正常计划会被判成多个匹配而卡住)。"""

    # 计划里声明写出这个文件的步骤（任务行 outputs 含它）恰好一个时，
    # 只在它和它下游的步骤里、按路径完全相同找（下游续写步骤可以改它，取最下游的一版）；
    # 没有声明或声明不唯一时照旧按路径/文件名在全部步骤里找。
    declared = [leaf for leaf in leaves if target in tuple(leaf.task.outputs)]
    exact_only = exact or len(declared) == 1
    if len(declared) == 1:
        producer = str(declared[0].task.id)
        leaves = [
            leaf for leaf in leaves if str(leaf.task.id) == producer or producer in leaf.upstream
        ]
    current = _current_acceptances(htn, mission_id)
    acceptance: Acceptance | None
    matches: list[tuple[Any, Any, Any]] = []
    by_name: list[tuple[Any, Any, Any]] = []
    for leaf in leaves:
        task = leaf.task
        result = store.get_result(task.accepted_result_id)
        for artifact_id in () if result is None else result.artifacts:
            artifact = store.get_artifact(artifact_id)
            if artifact is None or artifact.verification_status != "VERIFIED":
                continue
            acceptance = current.get((artifact.id, artifact.content_hash))
            if acceptance is None:
                continue
            if artifact.path == target:
                matches.append((artifact, acceptance, leaf))
            elif not exact_only and source_matches(artifact.path, target):
                by_name.append((artifact, acceptance, leaf))
    found = matches or by_name
    if len(found) > 1:
        # 续写链上多个版本：取最下游的那一版（其余版本都在它的上游）。
        downstream = [
            item
            for item in found
            if {str(other[2].task.id) for other in found if other is not item} <= item[2].upstream
        ]
        if len(downstream) == 1:
            return downstream
    return found


def _stop(orch: Any, mission_id: str, detail: dict[str, Any]) -> bool:

    orch._commit_fail_mission(
        mission_id,
        stop_reason=MissionStopReason.MISSION_CRITERIA_UNMET,
        detail={"reason": "system_operation_blocked", **detail},
    )
    orch._note(f"mission {mission_id} stopped: system operation blocked ({detail})")
    return True


def _ask_planner_once(
    orch: Any, mission: Any, *, key: str, event_type: str, detail: dict[str, Any], stop: Any
) -> bool:
    """问规划器一次（同一个 ``key`` 只问一次）；它提交过决定而事情仍没解决，就调 ``stop`` 停。

    "回应过"只认规划器真正提交的决定（格式错被退回不算，审阅 2026-09-29）；它提交的决定是
    去问用户、问题还没答时不算回应完——等人答。"""

    store = orch.store
    events = tuple(store.iter_events(mission.id))
    asked = next(
        (e for e in events if e.type == REQUESTED and e.payload.get("source_key") == key), None
    )
    if asked is not None:
        # "不改""等待"被接受时状态是"无状态变化"，同样是回应（核验 2026-10-03：只认"已提交"时
        # 规划器回"不改"任务就永远挂着）；先提做法等中间一步不算。
        answered = any(
            e.type == "PlanningDecisionEvaluated"
            and e.seq > asked.seq
            and (
                e.payload.get("status") == "COMMITTED"
                or (
                    e.payload.get("status") == "NO_STATE_CHANGE"
                    and e.payload.get("decision_type") in ("NO_CHANGE", "WAIT")
                )
            )
            for e in events
        )
        if answered and not planning_human_store.PlanningHumanStore(store).pending(mission.id):
            return stop("；规划器已回应但仍未解决")
        return False
    dispatch = orch._new_mode(mission)
    if dispatch is None:
        return stop("")
    root = next(iter(dispatch.network(mission.id).root_occurrence_ids), None)
    root_task = (
        None if root is None else dispatch.network(mission.id).binding_for_occurrence(root).task_id
    )
    return record_request(
        dispatch,
        mission.id,
        event_type=event_type,
        trigger_refs=tuple(str(x) for x in (root_task,) if x) or (mission.id,),
        source_key=key,
        detail=detail,
    )


def _ask_planner_for_source(
    orch: Any,
    mission: Any,
    htn: HtnStore,
    effect_key: str,
    target: str,
    matches: list[str],
    *,
    operation: str = "",
    reference: str | None = None,
) -> bool:
    """找不到要发布的文件、操作引用的产物（或判断不了用哪一版），或没有可做锚点的已接受产出：
    请规划器补/改步骤；它回应过仍不行就停。"""

    active = htn.active_plan_revision(mission.id)
    if active is None:  # 5E 显式判空：这类提问只在有现行计划时生成（_leaves）
        raise ContractError("a system operation source question needs the active plan")
    prefix = f"system-operation-source:{effect_key}:"
    wanted = reference or target
    if operation and reference is None:
        reason = (
            f"已批准的操作 {operation}（目标 {target}）还没有任何已接受的步骤产出可以作为依据，"
            "需要一个写出说明或准备材料的步骤"
        )
    else:
        reason = (
            (f"已批准的操作 {operation} 引用的产物 " if operation else "已批准的发布 ")
            + f"{wanted} 找不到"
            + ("唯一的" if matches else "")
            + "来源文件："
            + (
                "、".join(matches) + " 都匹配，需指定其中一个步骤的产出"
                if matches
                else f"当前计划里没有任何步骤产出 {wanted}，需要补一个写出它的步骤"
            )
        )

    def stop(why: str) -> bool:
        return _stop(
            orch,
            mission.id,
            {"effect_key": effect_key, "target": target, "explanation": reason + why},
        )

    key = prefix + str(active.revision)
    mine = [
        e
        for e in orch.store.iter_events(mission.id)
        if e.type == REQUESTED and str(e.payload.get("source_key", "")).startswith(prefix)
    ]
    if all(e.payload.get("source_key") != key for e in mine) and len(mine) >= SOURCE_REPAIR_CAP:
        return stop(f"；已请规划器补过 {len(mine)} 次")
    return _ask_planner_once(
        orch,
        mission,
        key=key,
        event_type="VerifierAcceptanceRejected",
        stop=stop,
        detail={
            "reason": "system_operation_source_unresolved",
            "effect_key": effect_key,
            "target": target,
            "matches": matches,
            "explanation": reason,
        },
    )


def _ask_planner_after_rejection(orch: Any, mission: Any, rejected: dict[str, Any]) -> bool:
    """阶段 B 裁决第 2 类：人拒绝了发布卡——把拒绝理由原文交给规划器（改内容、问人或不改由它判断）。

    上限（秩序，不是判断）：每次拒绝只问一次；规划器回应了而内容没换出新版本就停；同一效果被人
    拒绝累计 ``SOURCE_REPAIR_CAP`` 次直接停。被拒过的同一份内容系统不会再自动重交。"""

    count = len(rejected["rejections"])
    latest = rejected["rejections"][-1]

    def stop(why: str) -> bool:
        orch._commit_fail_mission(
            mission.id,
            stop_reason=MissionStopReason.APPROVAL_REJECTED,
            detail={
                "reason": "operation_rejected",
                "effect_key": rejected["effect_key"],
                "target": rejected["target"],
                "rejections": rejected["rejections"],
                "explanation": f"发布 {rejected['target']} 被人拒绝" + why,
            },
        )
        return True

    if count >= SOURCE_REPAIR_CAP:
        return stop(f"；已被拒绝 {count} 次")
    return _ask_planner_once(
        orch,
        mission,
        key=f"operation-rejected:{rejected['effect_key']}:{latest['request_id']}",
        event_type="OperationNotApplied",
        stop=lambda why: stop(why.replace("仍未解决", "内容未变")),
        detail={
            "reason": "operation_rejected_by_person",
            "effect_key": rejected["effect_key"],
            "target": rejected["target"],
            "rejection_reason": latest["reason"],
            "rejected_by": latest["rejected_by"],
            "rejections": count,
            "remaining": SOURCE_REPAIR_CAP - count,
        },
    )


def pending_system_operations(orch: Any, mission_id: str) -> list[dict[str, Any]]:
    """What the system would do now for each approved effect (read-only).

    Each entry has ``command`` (submit it), ``stop`` (stop the Mission, with why),
    ``ask`` (ask the planner for a source step) or ``skip`` (nothing to do yet).
    """

    store = orch.store
    mission = store.get_mission(mission_id)
    if mission is None or str(mission.status) != "ACTIVE":
        return []
    htn = HtnStore(store)
    requirements = htn.latest_requirements_revision(mission_id)
    if requirements is None:
        return []
    row = OperationCompletionStore(store).get_spec_exact(
        mission_id, requirements.revision, requirements.content_hash()
    )
    spec = None if row is None else row.get("document")
    if spec is None or not spec.effects:
        return []
    leaves = _leaves(store, htn, mission_id)
    if leaves is None:
        return []  # 内容还没全部通过
    # row 为空时 spec 也为空，上面已返回
    receipt = store.get_receipt(str(cast("dict[str, Any]", row)["approval_receipt_id"]))
    authority = (receipt or {}).get("authority") or {}
    if not authority.get("issuer_id") or not authority.get("tenant_id"):
        return []
    principal = Principal(authority["issuer_id"])
    intents = OperationIntentStore(store).for_mission(mission_id)
    superseded = {item["supersedes_intent_id"] for item in intents if item["supersedes_intent_id"]}
    spec_hash = spec.content_hash()
    plans: list[dict[str, Any]] = []
    for effect in spec.effects:
        try:
            operation = effect_operation(effect, requirements)
        except ContractError as error:
            plans.append({"effect_key": effect.effect_key, "skip": str(error)})
            continue
        reference: str | None = None
        if is_publish(operation):
            found = _sources(store, htn, mission_id, leaves, operation[2])
        else:
            references = artifact_paths(effect_params(effect, requirements))
            reference = references[0] if references else None
            found = (
                _sources(store, htn, mission_id, leaves, reference, exact=True)
                if reference is not None
                else _anchor(store, htn, mission_id, leaves)
            )
        if len(found) != 1:
            plans.append(
                {
                    "effect_key": effect.effect_key,
                    "target": operation[2],
                    "ask": True,
                    "matches": sorted(artifact.path for artifact, _, _ in found),
                    **(
                        {}
                        if is_publish(operation)
                        else {"operation": f"{operation[0]}.{operation[1]}", "reference": reference}
                    ),
                }
            )
            continue
        artifact, acceptance, _ = found[0]
        mine = []
        for item in intents:
            completion = json.loads(item["binding_json"]).get("completion", {})
            if (
                completion.get("effect_key") == effect.effect_key
                and completion.get("spec_hash") == spec_hash
            ):
                mine.append(item)
        earlier = _earlier_operation_fact(store, mission_id, operation, mine)
        if earlier is not None:
            # 这个操作在本任务里已经交出去过（按更早一版要求）：不再准备第二份申请单。
            if earlier["state"] == "SUCCEEDED" and earlier["content_hash"] != artifact.content_hash:
                plans.append(
                    {
                        "effect_key": effect.effect_key,
                        "published_earlier": {
                            "effect_key": effect.effect_key,
                            "target": operation[2],
                            "action_key": earlier["action_key"],
                            "published_content_hash": earlier["content_hash"],
                            "current_content_hash": artifact.content_hash,
                            "current_requirements_revision": int(requirements.revision),
                        },
                    }
                )
            else:
                # 同一份内容已经发布（或结果还没核清）：原事实由结果审查按现行要求重审 / 对账接手
                plans.append({"effect_key": effect.effect_key, "skip": "earlier_operation_fact"})
            continue
        heads = [item for item in mine if item["intent_id"] not in superseded]
        supersedes = None
        if heads:
            head = heads[-1]
            status = orch.commit.operation_intent_status(
                head["intent_id"], tenant_id=authority["tenant_id"], principal=principal
            )
            if status.get("materialization") is not None:
                # 已进入执行链，由批准卡片和执行流程接手——除非这一版的动作已经证实没生效、
                # 且不是人拒绝的（阶段 B 裁决第 1 类）：按原内容重交一张新卡，有上限。
                action = _materialized_action(store, head["intent_id"])
                if action is not None and action["state"] == "REJECTED":
                    # 阶段 B 裁决第 2 类：人拒绝了这张卡。内容换出了新版本（字节变了）就替代重交，
                    # 再出一张卡；没换就交规划器（同一份内容不再拿去问已经说"不"的人）。
                    if (
                        _artifact_hash(store, head["candidate_artifact_id"])
                        != artifact.content_hash
                    ):
                        plans.append(
                            _resubmit_plan(
                                effect,
                                operation,
                                head["intent_id"],
                                mission_id,
                                spec_hash,
                                row,
                                acceptance,
                                artifact,
                                len(mine),
                                authority,
                            )
                        )
                    else:
                        plans.append(
                            {
                                "effect_key": effect.effect_key,
                                "rejected": {
                                    "effect_key": effect.effect_key,
                                    "target": operation[2],
                                    "rejections": _person_rejections(store, mine),
                                },
                            }
                        )
                    continue
                if action is None or not _proven_not_applied(store, action):
                    continue
                if len(mine) > SYSTEM_RESUBMIT_CAP:
                    attempts = [
                        nonapplication_outcome(store, item)
                        for item in (
                            _materialized_action(store, intent["intent_id"]) for intent in mine
                        )
                        if item is not None and item["state"] == "FAILED"
                    ]
                    plans.append(
                        {
                            "effect_key": effect.effect_key,
                            "stop_failed": {
                                "reason": "publish_not_applied",
                                "effect_key": effect.effect_key,
                                "target": operation[2],
                                "attempts": attempts,
                            },
                        }
                    )
                    continue
                supersedes = head["intent_id"]
                plans.append(
                    _resubmit_plan(
                        effect,
                        operation,
                        supersedes,
                        mission_id,
                        spec_hash,
                        row,
                        acceptance,
                        artifact,
                        len(mine),
                        authority,
                    )
                )
                continue
            state = str(status.get("state"))
            if head["candidate_artifact_id"] == artifact.id:
                if state in _REFUSED_VERDICTS:
                    plans.append(
                        {
                            "effect_key": effect.effect_key,
                            "stop": {
                                "effect_key": effect.effect_key,
                                "target": operation[2],
                                "verdict": state,
                                "explanation": f"审阅员不认可系统准备的发布申请（{state}），需要人来判断",
                            },
                        }
                    )
                    continue
                if state not in _RETRY_VERDICTS:
                    continue  # 审阅中或已通过待物化：等
                if len(mine) > SYSTEM_RESUBMIT_CAP:
                    plans.append(
                        {
                            "effect_key": effect.effect_key,
                            "stop": {
                                "effect_key": effect.effect_key,
                                "target": operation[2],
                                "verdict": state,
                                "explanation": f"发布申请的审阅已 {len(mine)} 次没能完成",
                            },
                        }
                    )
                    continue
            supersedes = head["intent_id"]  # 内容换了新版本，或审阅没做成：替代重交
        plans.append(
            _resubmit_plan(
                effect,
                operation,
                supersedes,
                mission_id,
                spec_hash,
                row,
                acceptance,
                artifact,
                len(mine),
                authority,
            )
        )
    return plans


def _earlier_operation_fact(
    store: Any, mission_id: str, operation: tuple[str, str, str], mine: list[Any]
) -> dict[str, Any] | None:
    """这个操作（同一任务、同一连接器、同一操作、同一目标）在台账里最新的一版，如果它已经交出去过、
    而现行完成映射下还没有任何一份申请单进入执行链——也就是它是按更早一版要求做的（用户后来改了
    要求）。台账本来就不许同一目标在一个任务里再发生一次；这里只是提前读到这件事实，不去准备一份
    注定被拒的申请单。"""

    if any(store.get_receipt("materialize:" + item["intent_id"]) is not None for item in mine):
        return None
    versions = [
        v
        for v in store.list_action_versions(business_action_id(mission_id, *operation))
        if v["state"] != "REFUSED"
    ]
    if not versions or versions[-1]["state"] not in {"SUCCEEDED", "HANDED_OFF", "UNKNOWN"}:
        return None
    latest = versions[-1]
    return {
        "state": str(latest["state"]),
        "action_key": str(latest["action_key"]),
        "content_hash": str(
            (latest.get("params") or {}).get("content_hash") or latest.get("artifact_hash")
        ),
    }


def _ask_planner_about_earlier_publish(orch: Any, mission: Any, facts: dict[str, Any]) -> bool:
    """用户改要求后要发布的内容变了，而这个目标在本任务里已经发布过一次（台账不许再发）：把两份内容
    的事实交给规划器一次（问用户、改回原内容、不改由它判断）；它回应过仍没解决就具名停下。"""

    explanation = (
        f"本任务已发布过 {facts['target']}（内容哈希 {facts['published_content_hash'][:12]}）；"
        f"按第 {facts['current_requirements_revision']} 版要求现在要发布的内容不同"
        f"（{facts['current_content_hash'][:12]}），同一目标在一个任务里不能再发布一次"
    )
    return _ask_planner_once(
        orch,
        mission,
        key=f"operation-published-earlier:{facts['effect_key']}:r{facts['current_requirements_revision']}",
        event_type="OperationNotApplied",
        stop=lambda why: _stop(
            orch,
            mission.id,
            {
                "reason": "published_under_earlier_requirements",
                **facts,
                "explanation": explanation + why,
            },
        ),
        detail={
            "reason": "published_under_earlier_requirements",
            **facts,
            "explanation": explanation,
        },
    )


def _materialized_action(store: Any, intent_id: str) -> Any:
    receipt = store.get_receipt("materialize:" + intent_id)
    return None if receipt is None else store.get_action(str(receipt.get("action_key") or ""))


def _artifact_hash(store: Any, artifact_id: Any) -> str | None:
    artifact = store.get_artifact(str(artifact_id or ""))
    return None if artifact is None else str(artifact.content_hash)


def _person_rejections(store: Any, intents: list[Any]) -> list[dict[str, Any]]:
    """Each card of this effect a person rejected, oldest first: who and their words."""
    found = []
    for intent in intents:
        action = _materialized_action(store, intent["intent_id"])
        if action is None or action["state"] != "REJECTED":
            continue
        for request in store.list_approvals(str(action["mission_id"]), "REJECTED"):
            if request.get("kind") == "action" and str(request.get("subject_key")) == str(
                action["action_key"]
            ):
                found.append(
                    (
                        float(request.get("closed_at") or 0),
                        {
                            "request_id": request["request_id"],
                            "action_key": action["action_key"],
                            "rejected_by": request.get("rejected_by"),
                            "reason": request.get("reason") or "",
                        },
                    )
                )
    return [item for _, item in sorted(found, key=lambda pair: (pair[0], pair[1]["request_id"]))]


def _proven_not_applied(store: Any, action: Any) -> bool:
    """FAILED after leaving our hands, with a stored proof it never happened."""

    return (
        action["state"] == "FAILED"
        and int(action.get("handoffs") or 0) >= 1
        and stored_negative_proof(store, action)
    )


def _resubmit_plan(
    effect: Any,
    operation: Any,
    supersedes: Any,
    mission_id: str,
    spec_hash: str,
    row: Any,
    acceptance: Any,
    artifact: Any,
    ordinal: int,
    authority: Any,
) -> dict[str, Any]:
    return {
        "effect_key": effect.effect_key,
        "target": operation[2],
        "supersedes": supersedes,
        "command": SubmitOperationIntentV2(
            schema_version=2,
            mission_id=mission_id,
            idempotency_key=derive_id(
                "system-operation",
                mission_id,
                spec_hash,
                effect.effect_key,
                str(acceptance.acceptance_id),
                artifact.id,
                str(ordinal),
            ),
            intent_source=OperationIntentSourceV2(
                OperationIntentSourceKind.AUTHORIZED_SLOT,
                origin_receipt_id=str(row["approval_receipt_id"]),
                slot_key=effect.effect_key,
            ),
            candidate_artifact_ref=TypedRef(
                TypedRefKind.ARTIFACT, artifact.id, artifact.version, artifact.content_hash
            ),
            prepared_acceptance_refs=(
                TypedRef(
                    TypedRefKind.ACCEPTANCE,
                    str(acceptance.acceptance_id),
                    1,
                    content_hash_of(acceptance.to_json()),
                ),
            ),
            supersedes_intent_id=supersedes,
            completion_slot=CompletionSlotV2(spec_hash, effect.effect_key),
        ),
        "tenant_id": authority["tenant_id"],
        "principal_id": authority["issuer_id"],
    }


def prepare_system_operations(orch: Any, mission_id: str) -> bool:
    """Act on every ready system operation; a refused submission is noted, never raised."""

    progressed = False
    for plan in pending_system_operations(orch, mission_id):
        if "stop" in plan:
            return _stop(orch, mission_id, plan["stop"])
        if "stop_failed" in plan:
            # 阶段 B 裁决第 1 类：同一效果按原内容重交到上限仍没生效——具名停，列出每次的结局

            orch._commit_fail_mission(
                mission_id,
                stop_reason=MissionStopReason.ACTION_FAILED,
                detail=dict(plan["stop_failed"]),
            )
            return True
        if "rejected" in plan:
            if _ask_planner_after_rejection(
                orch, orch.store.get_mission(mission_id), plan["rejected"]
            ):
                return True
            continue
        if "published_earlier" in plan:
            if _ask_planner_about_earlier_publish(
                orch, orch.store.get_mission(mission_id), plan["published_earlier"]
            ):
                return True
            continue
        if plan.get("ask"):
            mission = orch.store.get_mission(mission_id)
            if _ask_planner_for_source(
                orch,
                mission,
                HtnStore(orch.store),
                plan["effect_key"],
                plan["target"],
                plan["matches"],
                operation=plan.get("operation", ""),
                reference=plan.get("reference"),
            ):
                return True
            continue
        command = plan.get("command")
        if command is None:
            continue
        try:
            # 提交前先装配操作运行时，否则每轮都被"operation runtime is unavailable"拒掉、
            # 任务空转（2026-09-29 真机）。只在真要提交时装：没有操作效果的任务所在环境可能
            # 根本没注册连接器。
            # 按需导入：循环依赖（system_operations ↔ operation_runtime）
            from .operation_runtime import ensure_operation_runtime

            ensure_operation_runtime(orch)
            orch.commit.submit_operation_intent(
                command, tenant_id=plan["tenant_id"], principal=Principal(plan["principal_id"])
            )
            progressed = True
        except (ContractError, ValueError) as error:  # OperationCompletionError / sources errors
            orch._note(f"system operation {plan['effect_key']} not submitted: {error}")
            if getattr(error, "code", None) == "OP_CAPABILITY_UNSUPPORTED":
                # 阶段 B 裁决第 4 类: the deployment changed after confirmation and its
                # profile can no longer reach the confirmed milestone. Deterministic: no
                # retry; the Mission stops by name with the fact recorded.

                orch._commit_fail_mission(
                    mission_id,
                    stop_reason=MissionStopReason.ACTION_FAILED,
                    detail={
                        "reason": "operation_capability_unsupported",
                        "effect_key": plan["effect_key"],
                        "error": str(error)[:300],
                    },
                )
                return True
    return progressed
