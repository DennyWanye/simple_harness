"""Owned read-through contract for the optional public Harness audit facade."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Protocol, cast

from .contracts import ServiceError, ServiceErrorCode, _text

AUDIT_RESPONSE_MAX_BYTES = 256 * 1024


@dataclass(frozen=True, slots=True)
class RunAuditRequest:
    external_run_id: str
    limit: int = 256

    def __post_init__(self) -> None:
        _text(self.external_run_id, "external_run_id")
        if type(self.limit) is not int or not 1 <= self.limit <= 256:
            raise ValueError("audit limit must be in1..256")


class _AuditSnapshot(Protocol):
    run_id: str
    operations: tuple[object, ...]

    def to_json(self) -> dict[str, object]: ...


def validate_run_audit(snapshot: object, *, run_id: str, limit: int) -> object:
    import simple_harness as h

    expected = getattr(h, "RunOperationAuditSnapshotV1", None)
    if expected is None or type(snapshot) is not expected:
        raise ServiceError(ServiceErrorCode.UNAVAILABLE, "audit_reader_unavailable")
    value = cast(_AuditSnapshot, snapshot)
    # Keep the SDK's exact DTO/hash/truncation semantics; never reconstruct a
    # purported canonical snapshot from a diagnostic log or arbitrary dictionary.
    if value.run_id != run_id or len(value.operations) > limit:
        raise ServiceError(ServiceErrorCode.FORBIDDEN, "audit_response_binding_mismatch")
    if (
        len(json.dumps(value.to_json(), ensure_ascii=False, allow_nan=False).encode())
        > AUDIT_RESPONSE_MAX_BYTES
    ):
        raise ServiceError(ServiceErrorCode.PAYLOAD_TOO_LARGE, "audit_response_limit")
    return snapshot
