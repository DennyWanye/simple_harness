"""Offline schema generator; not a runtime SDK implementation."""
import json
from pathlib import Path
R=Path(__file__).resolve().parent
S={"type":"string","minLength":1}
H={"type":"string","pattern":"^[0-9a-f]{64}$"}
I={"type":"integer","minimum":0}
N={"anyOf":[S,{"type":"null"}]}
def obj(p): return {"type":"object","properties":p,"required":list(p),"additionalProperties":False}
def arr(t,n=0): return {"type":"array","items":t,"minItems":n,"maxItems":128}
def ref(k=None):
 p={"kind":{"enum":k or ["task","method","requirements","artifact","source","observation","review","acceptance","resolution","operation","tool_receipt","knowledge"]},"id":S,"revision":I,"content_hash":H,"produced_by":{"enum":["system","tool","model","human"]}}
 x=obj(p); x['required'].remove('produced_by'); return x
V=obj({"id":S,"version":{"type":"integer","minimum":1},"content_hash":H})
NS=obj({"service_id":S,"account_scope":S,"environment":S})
cond={"oneOf":[{"const":"NONE"},obj({"kind":{"enum":["ETAG","TRANSACTION","FENCE"]},"value":S})]}
idem={"oneOf":[{"const":"UNKNOWN"},obj({"namespace":S,"retention_basis_ref":ref(),"minimum_retention_ms":{"type":"integer","minimum":1}})]}
proofs=["SERVER_CANCELLED_BEFORE_APPLY","SERVER_DEADLINE_FENCED","EXECUTOR_NO_SEND_FINAL"]
d={}
d['parameters']=obj({"schema_version":{"const":1},"intent_id":S,"connector_id":S,"connector_version":S,"operation_name":S,"connector_profile_hash":H,"normalized_target_ref":S,"expected_target_version":N,"parameter_schema_ref":V,"effective_params":{"type":"object"},"params_hash":H,"candidate_artifact_ref":ref(['artifact']),"accepted_input_refs":arr(ref(['acceptance']),1)})
d['effect_contract']=obj({"schema_version":{"const":1},"connector_profile_hash":H,"namespace":NS,"operation_name":S,"required_milestone":S,"milestone_criterion_ids":arr(S,1),"required_target_condition":cond,"receipt_adapter":obj({"id":S,"version":S}),"retry_policy_ref":V,"reconciliation_policy":{"enum":["RECONCILE_ONLY","EXISTING_APPROVED_POLICY"]},"idempotency_contract":idem,"accepted_nonapplication_proofs":arr({"enum":proofs})})
d['frozen_proposal']=obj({"schema_version":{"const":1},"intent_id":S,"candidate_artifact_ref":ref(['artifact']),"parameters_ref":ref(['artifact']),"effect_contract_ref":ref(['artifact']),"prepared_acceptance_refs":arr(ref(['acceptance']),1),"producer_task_ref":ref(['task']),"producer_occurrence_id":S,"obligation_id":S,"requirements_ref":ref(['requirements']),"plan_ref":obj({"revision":I,"snapshot_hash":H}),"request_hash":H})
d['submit_command']=obj({"schema_version":{"const":1},"mission_id":S,"idempotency_key":S,"intent_source":{"oneOf":[obj({"kind":{"const":"USER_COMMAND"}}),obj({"kind":{"const":"AUTHORIZED_SLOT"},"origin_receipt_id":S,"slot_key":S})]},"candidate_artifact_ref":ref(['artifact']),"prepared_acceptance_refs":arr(ref(['acceptance']),1),"supersedes_intent_id":N})
# Proofs always quote durable source receipts; no generic no_late_apply=true flag.
pcommon={"proof_id":S,"basis_receipt_refs":arr(ref(['tool_receipt']),1)}
pr=[obj({"kind":{"const":"SERVER_CANCELLED_BEFORE_APPLY"},**pcommon,"cancellation_receipt_ref":ref(['tool_receipt']),"server_final_status":S}),obj({"kind":{"const":"SERVER_DEADLINE_FENCED"},**pcommon,"fence_protocol_version":S,"server_deadline_ms":I,"fence_receipt_ref":ref(['tool_receipt']),"nonapplication_query_ref":ref(['tool_receipt'])}),obj({"kind":{"const":"EXECUTOR_NO_SEND_FINAL"},**pcommon,"execution_epoch":I,"send_boundary_receipt_ref":ref(['tool_receipt']),"dispatch_closed_receipt_ref":ref(['tool_receipt'])}),obj({"kind":{"const":"NONE"},"reason_code":S})]
d['reconciliation_observation']=obj({"schema_version":{"const":1},"action_key":S,"action_version":{"type":"integer","minimum":1},"operation_id":S,"operation_occurrence_id":S,"request_hash":H,"params_hash":H,"idempotency_key":S,"connector_profile_hash":H,"namespace":NS,"normalized_target_ref":S,"covered_handoff_ids":arr(S,1),"queried_at_ms":I,"observation_receipt_ref":ref(['tool_receipt']),"observation_origin":{"enum":["REMOTE_QUERY","LOCAL_EXECUTOR"]},"query_scope":obj({"namespace":NS,"request_identity":S,"consistency_kind":{"enum":["AUTHORITATIVE","BEST_EFFORT","UNKNOWN"]},"high_watermark":N}),"outcome":{"enum":["APPLIED","NOT_APPLIED_FINAL","PENDING","PARTIAL","UNKNOWN"]},"proof":{"oneOf":pr}})
profile_idem={"oneOf":[{"const":"UNKNOWN"},obj({"kind":{"const":"ATOMIC_KEY"},"namespace":S,"retention_basis_ref":ref(),"minimum_retention_ms":{"type":"integer","minimum":1},"conflict_protocol_id":S})]}
d['connector_profile']=obj({"schema_version":{"const":1},"connector_id":S,"adapter_version":S,"adapter_code_digest":H,"namespace":NS,"operation_name":S,"parameter_schema_ref":V,"outcome_contract_version":S,"supported_milestones":arr(S,1),"receipt_adapter":obj({"id":S,"version":S}),"conditional_write":{"oneOf":[{"const":"NONE"},obj({"kind":{"enum":["ETAG","TRANSACTION","FENCE"]},"protocol_id":S})]},"idempotency":profile_idem,"nonapplication_proofs":arr({"enum":proofs}),"authority_source_ref":ref()})
schema={"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"urn:simpleharness:v14:operation-seams:1","description":"Select a $defs schema by payload purpose; all semantic evidence checks remain required.","$defs":d}
(R/'contracts.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
