"""Explicit verification dispatch. Unknown domains never inherit document semantics."""

from __future__ import annotations

from typing import Any

from ..contracts import ContractError
from ..governance.domains import (
    APPWORLD_DOMAIN,
    CODE_DOMAIN,
    DRONE_SIM_DOMAIN,
    DomainProfileV1,
)
from .deterministic_checks import LayerResult, rule_check


class CodeHandler:
    name = "code"

    def rules(self, *args: Any, **kwargs: Any) -> LayerResult:
        return rule_check(*args, **kwargs)


class AppWorldHandler(CodeHandler):
    name = "appworld"

    def rules(self, *args: Any, **kwargs: Any) -> LayerResult:
        # This gate checks submitted reports and references only. Official task
        # success is scored from the saved world after ALL agent activity stops.
        kwargs["local_code_execution"] = False
        result = rule_check(*args, **kwargs)
        return LayerResult(
            result.layer,
            result.status,
            result.summary,
            {
                **dict(result.detail),
                "handler": self.name,
                "benchmark_success": "external_evaluation_pending",
            },
        )


class DroneSimHandler(AppWorldHandler):
    name = "drone-sim"


_HANDLERS = {
    CODE_DOMAIN: CodeHandler(),
    APPWORLD_DOMAIN: AppWorldHandler(),
    DRONE_SIM_DOMAIN: DroneSimHandler(),
}


def handler_for(domain: DomainProfileV1 | None) -> CodeHandler:
    domain_id = CODE_DOMAIN if domain is None else domain.id
    try:
        return _HANDLERS[domain_id]
    except KeyError as error:
        raise ContractError(f"No verification handler for domain {domain_id}") from error
