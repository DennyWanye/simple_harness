这些文件仅保留已交付总需求与专项映射；不修改原编号，不表示其验收已经通过。新代码实际覆盖由本包 sdk-test-cases.json 与 implementation/seams.json 追踪。
