# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Official ReAct RuntimeDriver."""

from __future__ import annotations

import time
import hashlib
from collections.abc import Mapping
from dataclasses import replace
from typing import cast

from simple_harness.contracts import RequestId, RunId, canonical_json, thaw_json
from simple_harness.contracts.messages import Message, MessageRole
from simple_harness.execution.dispatch import ProviderInvocationUnknownError
from simple_harness.execution.budget import (
    BudgetPolicy,
    FrozenPriceEstimator,
    budget_policy_fingerprint,
)
from simple_harness.execution.recovery import RecoveryKind, WaitBlockerSpec
from simple_harness.execution.uow import RunState
from simple_harness.providers import ProviderToolSpec
from simple_harness.runtime.kernel import DriverInvocation, DriverResult
from simple_harness.runtime.workflow_spawn import WorkflowSpawnFailed
from simple_harness.tools.errors import UnknownToolError
from simple_harness.tools.executor import ToolAuthorizationPending

from ..termination import TerminationBudgetExceeded, TerminationLimits
from .react_loop import (
    AgentLoopCollaborator,
    EffectBatchExecutor,
    ReActLoop,
    ReActRunInput,
    ToolEffectUnknownError,
)


class ReActDriver:
    def __init__(
        self,
        *,
        collaborator: AgentLoopCollaborator | None = None,
        effects: EffectBatchExecutor | None = None,
        clock=time.time,
        policy_fingerprint: str | None = None,
        provider_budget_fingerprint: str | None = None,
    ) -> None:
        self._clock = clock
        self._loop = ReActLoop(
            collaborator=collaborator or AgentLoopCollaborator(),
            effects=effects or EffectBatchExecutor(),
            clock=clock,
            policy_fingerprint=policy_fingerprint,
        )
        self.policy_fingerprint = policy_fingerprint
        self.provider_budget_fingerprint = provider_budget_fingerprint

    async def start(
        self, invocation: DriverInvocation, *, context, cancel
    ) -> DriverResult:
        if context is not invocation.services.context:
            raise ValueError("Runtime context service mismatch")
        if self.provider_budget_fingerprint is not None and (
            getattr(invocation.services.provider, "budget_policy_fingerprint", None)
            != self.provider_budget_fingerprint
        ):
            raise ValueError("Provider budget policy differs from ReAct composition")
        ready = invocation.workflow_spawn_ready_activation
        if ready is not None:
            coordinator = invocation.services.workflow_spawn
            if coordinator is None:
                raise RuntimeError(
                    "workflow spawn ready activation lacks its SDK coordinator"
                )
            outcome = await coordinator.continue_ready(ready)
            if isinstance(outcome, WorkflowSpawnFailed):
                return await self.start(
                    replace(
                        invocation, workflow_spawn_ready_activation=None
                    ),
                    context=context,
                    cancel=cancel,
                )
            return DriverResult(
                RunState.WAITING,
                {
                    "workflow_spawn_child_run_id": outcome.child_start_ref.child_run_id,
                    "workflow_spawn_wait_receipt_id": (
                        outcome.suspension.parent_wait_receipt_id
                    ),
                },
                workflow_spawn_control=outcome,
            )
        if invocation.continuations:
            stored = invocation.services.react_checkpoint.read_react_checkpoint(
                invocation.run.run_id
            )
            payload = None if stored is None else thaw_json(stored.checkpoint)
            if isinstance(payload, dict) and payload.get("phase") == "child_wait":
                if len(invocation.continuations) != 1:
                    raise RuntimeError(
                        "workflow child wait requires exactly one continuation"
                    )
                invocation.services.react_checkpoint.ack_spawn_child_continuation_and_continue_batch(
                    run_id=invocation.run.run_id,
                    continuation_claim=invocation.continuations[0],
                    execution_lease=invocation.execution_lease,
                    run_fence=invocation.run_fence,
                    now=self._clock(),
                )
        input_value = cast(Mapping[str, object], invocation.start.input)
        initial = _messages(input_value.get("messages"))
        tools = _tools(
            input_value.get("capability_snapshot"), invocation.services.tools
        )
        try:
            result = await self._loop.run(
                ReActRunInput(
                    RunId(invocation.run.run_id),
                    RequestId(invocation.run.request_id),
                    tools=tools,
                    temperature=(
                        None
                        if input_value.get("temperature") is None
                        else float(input_value["temperature"])
                    ),
                    max_output_tokens=(
                        None
                        if input_value.get("max_output_tokens") is None
                        else int(input_value["max_output_tokens"])
                    ),
                ),
                services=invocation.services,
                execution_lease=invocation.execution_lease,
                run_fence=invocation.run_fence,
                cancel=cancel,
                initial_messages=initial,
            )
        except UnknownToolError:
            return DriverResult(
                RunState.WAITING,
                {
                    "raw_failures": [
                        {
                            "error_code": "tool_not_exposed",
                            "source_kind": "tool_parse",
                            "retriable": True,
                            "replan": True,
                            "message": "Tool is not exposed; use capability_search.",
                        }
                    ]
                },
            )
        except ProviderInvocationUnknownError as error:
            invocation_record = error.invocation
            return DriverResult(
                RunState.WAITING,
                {"raw_failures": [{"error_code": "provider_outcome_unknown"}]},
                wait_blocker=(
                    None
                    if invocation_record is None
                    else WaitBlockerSpec(
                        RecoveryKind.PROVIDER,
                        invocation_record.invocation_id,
                        invocation_record.handoff_attempt,
                        invocation_record.version,
                    )
                ),
            )
        except TerminationBudgetExceeded as error:
            return DriverResult(
                RunState.FAILED,
                {"raw_failures": [{"error_code": str(error.code)}]},
            )
        except ToolAuthorizationPending as pending:
            return DriverResult(
                RunState.WAITING,
                {
                    "authorization_decision_id": pending.decision_id,
                    "authorization_prompt": pending.request.prompt,
                },
                authorization_wait=pending,
            )
        except ToolEffectUnknownError as error:
            return DriverResult(
                RunState.WAITING,
                {"raw_failures": [{"error_code": "tool_outcome_unknown"}]},
                wait_blocker=WaitBlockerSpec(
                    RecoveryKind.TOOL,
                    error.effect.effect_id.value,
                    error.effect.handoff_attempt,
                    error.effect.version,
                ),
            )
        return DriverResult(
            RunState.COMPLETED,
            {"message": result.response.message.content},
        )


def _messages(value: object) -> tuple[Message, ...]:
    if not isinstance(value, (list, tuple)):
        raise TypeError("ReAct input messages are required")
    messages: list[Message] = []
    for item in value:
        if not isinstance(item, Mapping):
            raise TypeError("ReAct input message must be an object")
        messages.append(Message(MessageRole(str(item["role"])), str(item["content"])))
    return tuple(messages)


def _tools(value: object, executor) -> tuple[ProviderToolSpec, ...]:
    if value is None:
        return ()
    if not isinstance(value, Mapping):
        raise TypeError("capability_snapshot must be an object")
    names = value.get("tools", ())
    if not isinstance(names, (list, tuple)) or not all(
        isinstance(name, str) for name in names
    ):
        raise TypeError("capability_snapshot.tools must contain strings")
    return executor.provider_tool_specs(tuple(names))


def build_react_driver(
    *,
    limits: TerminationLimits,
    budget_policy: BudgetPolicy,
    estimator: FrozenPriceEstimator | None,
    effects: EffectBatchExecutor | None = None,
    clock=time.time,
) -> ReActDriver:
    """Public hard-policy builder; every authority must be explicit and frozen."""

    if not isinstance(limits, TerminationLimits):
        raise TypeError("limits must use TerminationLimits")
    if not isinstance(budget_policy, BudgetPolicy):
        raise TypeError("budget_policy must use BudgetPolicy")
    if estimator is not None and not isinstance(estimator, FrozenPriceEstimator):
        raise TypeError("estimator must use FrozenPriceEstimator or None")
    provider_fingerprint = budget_policy_fingerprint(budget_policy, estimator)
    policy_payload = {
        "limits": {
            "max_consecutive_same_tool": limits.max_consecutive_same_tool,
            "max_cost_micros": limits.max_cost_micros,
            "max_tool_calls": limits.max_tool_calls,
            "max_turns": limits.max_turns,
            "max_wall_seconds": limits.max_wall_seconds,
        },
        "protocol": "react-hard-policy-v1",
        "provider_budget_fingerprint": provider_fingerprint,
    }
    policy_fingerprint = hashlib.sha256(
        canonical_json(policy_payload).encode("utf-8")
    ).hexdigest()
    return ReActDriver(
        collaborator=AgentLoopCollaborator(limits=limits),
        effects=effects,
        clock=clock,
        policy_fingerprint=policy_fingerprint,
        provider_budget_fingerprint=provider_fingerprint,
    )


__all__ = ("ReActDriver", "build_react_driver")
