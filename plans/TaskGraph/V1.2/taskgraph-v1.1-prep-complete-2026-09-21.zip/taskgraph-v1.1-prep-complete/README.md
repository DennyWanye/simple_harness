# TaskGraph V1.1 完整 prep 补交包

从 `V1.1-PREP-CLOSURE-2026-09-21.md` 开始。它只收紧 TG-A-prep 的交付/合同核对，不开启生产、不改变原九表和 HTN 协议。

**完整解压到新的 ignored evidence 目录，不覆盖现有 V1.1/dirty worktree，不把工具安装进 .venv。**

```bash
SDK=/Users/denny/projects/simple-harness-sdk-h1h-impl
"$SDK/.venv/bin/python" tools/verify_delivery.py --root .
```

接着按主文档执行 source capture、真实 runner 隔离预检、H1-H registry/collection 映射。所有执行用项目解释器。

`h1h/closure.json`、`commit-seam-review.json`、`assertion-review.json` 都是未完成状态，不是批准书。独立审阅的本地副本存 ignored evidence，不改写本包原模板。

`inputs/` 封存了原 TaskGraph 与 H1H 资料，含参考报告；不是 SDK PASS，不提交整个目录到 Git。
