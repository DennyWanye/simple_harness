# TaskGraph V1.2.1 readiness patch

入口：`V1.2.1-READINESS-AMENDMENT-2026-09-21.md`。

这是用户目录V1.2原包的补丁交付，不改TG-EXEC-2.0或H1 wire。优先使用新入口和STATE-GATES.md；`V1.1-PREP-CLOSURE...`、`HANDOFF-PLANAGENT-OPTIMIZED...`和旧runbook为历史背景，其命令/禁止范围与新入口冲突时以新入口为准。原inputs归档字节不变。

当前TG-B/C/D/E及生产仍禁止。新增`H1H-CONTRACT-PROOF-ONLY`必须满足新入口§6条件，属于原H1工作流，不是完整suite或TG运行。

先解压新ignored目录，项目`.venv/bin/python tools/verify_delivery.py --root .`；再项目Python运行`-m unittest discover -s tests -v`，原始输出放包外ignored证据。工具不装进site-packages；不覆盖原V1.2目录/dirty worktree，不自动提交Git。

- `tools/prepare_runner_patch.py`只写新隔离源码副本。
- `h1h/commit-proof-plan.json`是拟议测试要求，actual nodeid均未知。
- `metadata/workagent-v12-handoff.json`是用户报告，不是本环境采集。
- `VALIDATION.md`只报告本包工具和参考规则，不是SDK PASS。
