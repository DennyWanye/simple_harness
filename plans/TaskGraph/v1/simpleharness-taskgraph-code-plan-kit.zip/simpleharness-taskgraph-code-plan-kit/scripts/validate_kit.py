#!/usr/bin/env python3
"""Validate this documentation/reference kit, never the user's SimpleHarness checkout."""
from __future__ import annotations
import ast,hashlib,json,re,sqlite3,sys
from pathlib import Path
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def main():
    schemas=list((ROOT/'schemas').glob('*.schema.json'))
    assert len(schemas)==8
    examples=read('schemas/examples.json')
    for p in schemas:
        s=json.loads(p.read_text());Draft202012Validator.check_schema(s)
        Draft202012Validator(s).validate(examples[p.name.removesuffix('.schema.json')])
    cases=read('sdk-test-cases.json')['cases'];ids={c['id'] for c in cases}
    assert len(cases)==len(ids)==42
    assert all(c['status']=='PENDING_SDK_EXECUTION' for c in cases)
    seams=read('implementation/seams.json')['seams'];assert len(seams)==24
    assert all(s['focused_case'] in ids and s['producer'] and s['authority'] and s['join_key'] for s in seams)
    muts=read('mutations.json')['mutations'];assert len(muts)==12
    assert all(m['required_case'] in ids and m['status']=='PENDING_SDK_EXECUTION' for m in muts)
    req=read('evidence/original-60-requirements.json');assert len(req)==60 and len({r['id'] for r in req})==60
    for p in ROOT.rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
    for p in ROOT.rglob('*.md'):
        if 'evidence' in p.parts: continue
        text=p.read_text();assert sum(l.startswith('```') for l in text.splitlines())%2==0,p
        for block in re.findall(r'```python\n(.*?)\n```',text,re.S):ast.parse(block,filename=str(p))
    c=sqlite3.connect(':memory:');c.execute('PRAGMA foreign_keys=ON')
    c.executescript((ROOT/'tests/parent_fixture.sql').read_text())
    c.executescript((ROOT/'sql/001_taskgraph_extension.sql').read_text())
    assert not c.execute('PRAGMA foreign_key_check').fetchall()
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close()
    source=read('sources.json');assert source
    digest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.json'}
    (ROOT/'SHA256SUMS.json').write_text(json.dumps(digest,ensure_ascii=False,indent=2)+'\n')
    print('PASS: 8 schemas; 42 PENDING SDK cases; 24 producer seams; 12 PENDING mutations; 60 preserved requirements; syntax; SQL parent-contract fixture.')
    print('NOT RUN: actual SDK migration, project integration, Host, GPT-5.6 or full H1 gates.')
if __name__=='__main__':main()
