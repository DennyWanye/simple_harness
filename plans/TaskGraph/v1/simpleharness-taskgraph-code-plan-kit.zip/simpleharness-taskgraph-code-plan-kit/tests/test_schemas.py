import copy,json,unittest,re
from jsonschema import Draft202012Validator
from helpers import ROOT,connect,initialise

class Schemas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.examples=json.loads((ROOT/'schemas/examples.json').read_text())
        cls.validators={}
        for f in (ROOT/'schemas').glob('*.schema.json'):
            schema=json.loads(f.read_text()); Draft202012Validator.check_schema(schema)
            cls.validators[f.name.removesuffix('.schema.json')]=Draft202012Validator(schema)
    def test_eight_complete_schemas(self):self.assertEqual(8,len(self.validators))
    def test_valid_examples(self):
        for name,v in self.validators.items():
            with self.subTest(name=name):v.validate(self.examples[name])
    def test_unknown_top_field_refused(self):
        for name,v in self.validators.items():
            x=copy.deepcopy(self.examples[name]);x['invented']='bad'
            with self.subTest(name=name):self.assertFalse(v.is_valid(x))
    def test_each_required_field_enforced(self):
        for name,v in self.validators.items():
            for field in v.schema['required']:
                x=copy.deepcopy(self.examples[name]);x.pop(field)
                with self.subTest(name=name,field=field):self.assertFalse(v.is_valid(x))
    def test_preview_cannot_omit_any_source(self):
        v=self.validators['preview-binding-v1'];x=self.examples['preview-binding-v1']
        for i in range(len(x['source_reads'])):
            y=copy.deepcopy(x);y['source_reads'].pop(i)
            self.assertFalse(v.is_valid(y))
    def test_preview_duplicate_source_refused(self):
        x=copy.deepcopy(self.examples['preview-binding-v1']);x['source_reads'].append(x['source_reads'][0]);self.assertFalse(self.validators['preview-binding-v1'].is_valid(x))
    def test_preview_not_checked_source_refused(self):
        x=copy.deepcopy(self.examples['preview-binding-v1']);x['source_reads'][0]['coverage']='NOT_CHECKED';self.assertFalse(self.validators['preview-binding-v1'].is_valid(x))
    def test_public_false_completeness_refused(self):
        x=copy.deepcopy(self.examples['taskgraph-view-v1']);x['complete']=False;self.assertFalse(self.validators['taskgraph-view-v1'].is_valid(x))
    def test_unimplemented_pagination_refused(self):
        x=copy.deepcopy(self.examples['taskgraph-view-v1']);x['next_cursor']='pretend';self.assertFalse(self.validators['taskgraph-view-v1'].is_valid(x))
    def test_integer_bool_rejected(self):
        x=copy.deepcopy(self.examples['taskgraph-view-v1']);x['read_token']['plan_revision']=True;self.assertFalse(self.validators['taskgraph-view-v1'].is_valid(x))
    def test_json_hash_format(self):
        x=copy.deepcopy(self.examples['network-document-v1']);x['codec_manifest_hash']='bad';self.assertFalse(self.validators['network-document-v1'].is_valid(x))
    def test_all_named_sql_compiles_on_contract_fixture(self):
        c=connect();initialise(c)
        raw=(ROOT/'sql/002_access_patterns.sql').read_text()
        sql='\n'.join(line for line in raw.splitlines() if not line.lstrip().startswith('--'))
        statements=[x.strip() for x in sql.split(';') if x.strip()]
        self.assertGreaterEqual(len(statements),15)
        for statement in statements:
            params={n:0 for n in re.findall(r':([A-Za-z_][A-Za-z_0-9]*)',statement)}
            c.execute('EXPLAIN '+statement,params).fetchall()
        c.close()
