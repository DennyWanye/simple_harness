"""Loss-aware Realtime metadata projection, explicitly detached from Harness Runs."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from .contracts import CloseDisposition, RealtimeErrorCode
from .observability import RealtimeDiagnosticSnapshot, RealtimeDiagnosticStage


@dataclass(frozen=True, slots=True)
class RealtimeOperationAuditEvent:
    correlation: str
    stage: RealtimeDiagnosticStage
    stable_code: RealtimeErrorCode | None
    close_class: CloseDisposition | None
    generation: int | None
    frame_count: int
    byte_count: int
    duration_ms: int


@dataclass(frozen=True, slots=True)
class RealtimeOperationAuditSnapshot:
    events: tuple[RealtimeOperationAuditEvent, ...]
    emitted_count: int
    retention_dropped_count: int
    projection_omitted_count: int
    sink_drop_count: int
    sink_failure_count: int
    pending_count: int
    sdk_run_id: None = None
    durable: bool = False
    coverage_gaps: tuple[str, ...] = (
        "bounded_diagnostics_only",
        "realtime_no_verified_harness_binding",
    )

    def to_json(self) -> dict[str, object]:
        return asdict(self)


def realtime_operation_audit(
    snapshot: RealtimeDiagnosticSnapshot, *, limit: int = 256
) -> RealtimeOperationAuditSnapshot:
    if type(snapshot) is not RealtimeDiagnosticSnapshot:
        raise TypeError("canonical diagnostics snapshot required")
    if type(limit) is not int or not 1 <= limit <= 256:
        raise ValueError("audit limit must be in1..256")
    return RealtimeOperationAuditSnapshot(
        tuple(
            RealtimeOperationAuditEvent(
                event.correlation,
                event.stage,
                event.stable_code,
                event.close_class,
                event.generation,
                event.frame_count,
                event.byte_count,
                event.duration_ms,
            )
            for event in snapshot.events[-limit:]
        ),
        snapshot.emitted_count,
        snapshot.dropped_count,
        max(0, len(snapshot.events) - limit),
        snapshot.sink_drop_count,
        snapshot.sink_failure_count,
        snapshot.pending_count,
    )
