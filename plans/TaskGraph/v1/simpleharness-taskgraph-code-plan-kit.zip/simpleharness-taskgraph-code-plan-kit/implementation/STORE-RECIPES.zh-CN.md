# Store / producer 逐步实现合同（TG-EXEC-2.0）

本文件是主计划的规范部分。下列步骤必须落到真实SDK Store/Commit，不是允许用测试helper替代。参数只来自固定API调用者、冻结请求、原codec和完整source reader。

## 1. 来源失败分类与具体装配

所有输入分三种：读成功（可以为空）、来源缺失/不完整/解码失败、来源完整但不满足业务要求。第三种返回具体拒绝/等待，不能一律叫系统错误。`CompleteRead`只能由真实reader生成，不提供全True的默认构造器。

### 1.1 已有装配对象的具体使用

- `HierarchicalDispatch.planning` 必须是已安装的 `DeploymentPlanningWorld` 或经验证的同合同实现。声明读取使用其 `catalog/schemas/registry/predicates`；能力读取调用 `capabilities()`，实际由 `world.py::capability_records` 和安装的 `records` 生产。**不新建一个默认 CapabilitySnapshot()。**当前实现对一些可达/兼容轴有缺省值，这只能证明部署声明；真实Tool/Provider执行授权和连通性仍在原handoff门检查。需要额外健康证据的policy没有真实reader时返回unavailable，不把声明升格为健康证明。
- schema兼容读取 `HierarchicalDispatch.resolution_policy.schema_registry`；规则为空可以是“只接受同一schema”的明确policy，不是读异常fallback。
- 目标物化规则来自 `HierarchicalDispatch.target_rules` 与工作区/Operator实际绑定。为None时，非物化的纯图读可以执行；请求落文件的执行必须 `TARGET_RULES_UNAVAILABLE`。不得根据运行Python的OS猜用户指定的远程target规则。
- 证据通过原 `witnesses / start_witness_index / input_witness_index / scope_epochs` 读取。判断授权或current必须用真实consumer/purpose，不复用Planner的PLAN witness作为Worker的START许可。
- 预算读取原 `BudgetLedger.account`（纯读）；`reserve`只在原派发写事务执行，不能出现在snapshot producer。
- `settlement_facts`先读原 `occurrence_outcomes`，再用H1H的running-work/operation证明核对。所有相关Attempt至少处于真实terminal并没有未决provider/tool账目（按cleanup合同），没有 `PENDING/PARTIAL/UNKNOWN` effect，才可产生 `SettledTerminalOccurrence`。

### 1.2 不同用途的输入类型

`StructuralReadContext`字段：caller、policy、NetworkRecord、解码后的TaskNetworkSnapshot、codec_manifest、through_seq。只读取结构历史不需要live planning grant。

`ExecutionReadContext`字段：structure、current_task_bindings、current_method_registrations、witnesses/starts/licences、scope_epochs、accepted_outputs、source_input_policies、target_rules（读取用途可为显式NOT_APPLICABLE联合分支）、active_demands、independent_obligations、running_work、operation_snapshot、execution_policy、budget_snapshots、deployment_capabilities。每个集合都带source receipt和完整性；这些不是随意dict默认值。

`PlanMutationReadContext`字段：execution、PlanningRequestRecord、PlanningDecisionRecord、PlanningAuthorizationSnapshot、AdapterContext、source-candidate限制。其Planning request grant只是改图授权，不能当execute grant。

生成过程：在原Store一次一致读事务读取同库数据，外部execution facts仅通过原可靠导入。结束事务后运行纯compiler。以canonical source digest记录输入；currentness重新检查时重读**相关集合及成员**而不是只查旧成员id。

没有拿到原call结果是 `SourceUnavailable/OutcomeUnknown`，不能把它转换成 `not_running`。

## 2. kernel启用与政策写入

新增 `orchestrator/taskgraph_policy.py::enable_taskgraph_contract(mission_id, command_id, caller)`，由认证Host装配调用，不注册给模型。

1. 调用原facade租户/读取guard；查同command的原commit_receipts。有回执时核对相同意图，再按当前读权返回。
2. 验证当前Mission非legacy、planning-decision-v1、未终结，H1H-ADM依赖就绪并通过实际部署验收，不以环境变量声称通过。
3. 读取实际planning委派、冻结GraphStructureBudget、候选策略、schema/target/deployment政策引用，生成policy JSON。policy内容只来自已安装版本化配置。
4. 已有ACTIVE图时先确认不在派发、真实工作已收敛，执行显式CAPTURED_BASELINE流程；不允许自动在in-flight图上启用。
5. 原Store单写事务复核全部条件，写 `taskgraph_policy_bindings` + 原版本化event + 现有command receipt。`enabling_receipt_hash`为该确定性receipt内容hash，不含动态重放时间。
6. 同Mission已有不同policy不UPDATE旧行。后续政策升级需独立版本裁定；本版本只有一次明确opt-in。

## 3. `read_revision` 与 `insert_revision_record`

### 3.1 编码规则

`NetworkDocumentV1.objects`的kind到原codec映射是主计划§4.1的固定表。对每个原对象：
1. 原 `to_json()` -> 项目既有canonical JSON UTF-8 bytes -> SHA-256。
2. 保存完整canonical JSON字符串和hash，禁止用Python repr/按字段猜摘要。
3. kind+identity重复直接拒绝；顶层集合排序，原对象内部有序数组不重排。
4. roots/required obligations/adopted ids从compiled network显式拷贝并检查引用，不从Task列表推断。
5. `codec_manifest_hash`绑定使用的codec版本及源码hash清单；清单存版本化repo文件，升级不能覆盖旧清单。

### 3.2 `read_revision(mission_id,revision)`

1. 同事务读取原 `plan_revisions` 与Q14；不存在record但有legacy图时返回HISTORICAL_STRUCTURE_UNAVAILABLE，不能补写。
2. 验证NetworkDocument完整Schema、canonical hash、mission/revision与row一致；验证parent chain。
3. 用原codec逐个解码objects；去原不可变表读取时只能用doc中精确revision/hash（不能查today registration状态来重写历史）。
4. Q02、Q03取得pins；比对数量、所有identity、hash以及完整集合digest。`LEFT JOIN`读取并检测缺失，或JOIN后与原pin总数严格相等；不能丢失一行后返回“完整”。
5. pins和objects是一一映射：多余/缺少都错误；ORDER/DATA端点完整检查Q08。
6. 从document显式adopted集合构造TaskNetworkSnapshot；物理`method_instances.state`仅用于当前overlay或新Commit准入，不用于重构历史。
7. 对执行读运行完整projection验证；对历史读返回合法结构及非执行标记。错误返回GraphIntegrityError，不返回排序完成的健康前缀。

### 3.3 写入顺序（必须在外层Commit同一事务）

1. 原Commit先完成受控预算/Task/Method/plan_memberships/ORDER/DATA写入，生成原PlanCommitReceipt。
2. H1H-ADM写**本次实际成功**的APPLIED check；没有提前为未来结果造PASS。
3. 生成NetworkDocument hash及TaskGraphRevisionRecorded事件。
4. 写revision_record（COMMIT/SEED_COMMIT需要APPLIED check；CAPTURED_BASELINE只允许NULL，并由真实baseline授权receipt解释）。
5. 遍历结果网络所有occurrence，写member pin。必须核对原Task binding身份、mission、obligation、form与hash。不是只写新节点。
6. 遍历结果网络所有MethodInstance，写method pin及本revision adopted状态；不是只存当前全局state。
7. 从本revision **adopted** Method 的真实ChildBinding生成demand_refs；child的occurrence/goal_occurrence两个身份严格核对，拒绝无生产者的共享引用。独立Obligation不用伪造一个consumer slot，单独从原账本查。
8. 完整比较所有成员/方法/需求集合，追加followup，收敛job置APPLIED；最外层提交。

任何阶段失败，原预算与Task写入一并rollback。现有函数内部savepoint不能提交外层。

## 4. 派发绑定：一份manifest不等于一次Attempt

`insert_attempt_inputs`只由原实际创建Attempt/DispatchIntent入口调用。字段来源：

| 字段 | 精确生产来源 |
|---|---|
| attempt_id/task_id/mission_id | 原已创建但未提交的Attempt row |
| occurrence_id/source_revision | 当前ACTIVE plan_member，明确参与该次执行 |
| binding_revision/contract_hash | 本次正在核验的TaskSemanticBinding，不从旧preview猜 |
| input_binding_revision/dispatch_generation | 同一binding中的原控制字段 |
| manifest_hash | 原resolver成功生成的完整冻结InputManifest |
| intent_id/creation_key/input_id/frozen_input_hash | 同一次原DispatchIntent内容 |
| admission_check_id | **source_revision对应revision_record**的APPLIED check；CAPTURED_BASELINE明确NULL |
| origin_hash | canonical上述身份、manifest及intent，不含created_at |

首次检查 `taskgraph_attempt_inputs` 已存在：比较上述全语义字段；相同返回原行，不重复reserve；不同StoreConflict。创建两个合法Attempt使用相同manifest时，保留两条attempt关联，而不是覆盖原input_manifest_bindings中的attempt_id。

派发事务仍要执行原execution authorization/预算/资源/源witness/fence检查。原Plan的APPLIED check只是出处，**不能授权当前执行**。

## 5. 收敛状态机与并发

候选合法但旧work未收敛时创建job：`job_id=derive_id('tg-converge', mission_id, decision_id)`，candidate_hash和impact_hash来自纯preview。job/targets/event/followup在同一原Store事务；一decision同candidate返回原job，异candidate冲突。

| 原状态 | 合法新状态 | 必需条件 |
|---|---|---|
| FENCED | WAITING | 已按原取消/核对入口提交稳定命令，仍有在途事实 |
| FENCED | READY | 从真实完整runtime/operation读取证明已收敛 |
| WAITING | WAITING | 事实仍未决；有界更新，不调用Planner重想同决定 |
| WAITING | READY | 所有target核对完成且没有共享误取消 |
| READY | WAITING | 新观察表明仍有在途影响，不能硬Commit |
| READY | APPLIED | 同一候选经当前完整source检查后实际PlanCommit成功；同事务转换 |
| FENCED/WAITING/READY | ABANDONED | 当前获准操作者放弃候选；原工作已收敛或另有显式责任移交及安全恢复授权 |

APPLIED/ABANDONED终态不能回退。READY仍然是fence，不因TTL到期、队列空或lease过期自动解除。

`advance_convergence`在事务外调用已有取消/核对，稳定子命令key由job_id+原Attempt/Operation+action种类决定。接收外部回执后短事务读当前job版本，核对identity再CAS。planner的旧request不因job状态更新或临时fence被自动改写；若真正Plan/要求/权限变化，按H1拒绝旧决定，先安全处理已有job，不能自动换base重编。

## 6. 通知投递流程与SQL

`append_followup`输入完整FollowupV1，系统生成message_id/hash/dedupekey；dedupekey取原event_id+kind+subject_key。原事件相同而payload不同是冲突。只允许三个kind。

`claim_followup`在短事务Q09选取并CAS；租约默认30秒，可由固定部署配置调整。过期仅使**通知**可再次投递，不判Worker已停。

`pump_taskgraph_followups`映射固定handler：REEVALUATE调用原eventloop的目标Mission重新检查入口；CONVERGE调用advance_convergence；REQUEST_COMPOSITION调用现有composition/rootReview producer。handler返回已经持久存在的command/intent/receipt引用；Store按对应读取器验证引用再Q10 ACK，把canonical引用写consumer_receipt_json。

若handler暂时失败，Q12前四次失败分别退避1/2/4/8秒，第5次BLOCKED；不删除消息，不无限调用模型。BLOCKED恢复必须真实source故障修复+明确操作者命令后Q13重置，不自动loop。每一consumer错误有具名code，raw exception/secret不写日志。

“消费者已经创建下游意图，但ACK前崩溃”的恢复：下一次同message重复调用，原稳定下游key返回同意图/receipt，再ACK。不能看异常就mint新的下游command。

## 7. Snapshot / diff / recovery具体结果

历史：`view_mode=HISTORICAL_STRUCTURE`，`planning_frontier=[]`,`execution_frontier=[]`，节点phase=HISTORY_ONLY、readiness=NOT_SELECTED、reason=HISTORICAL_VIEW_NON_EXECUTABLE。这不是声称历史任务当时不可执行，而是此API结果不提供执行许可。

当前：CURRENT，原TaskView/current witness/operation/预算用于readiness，全部数据带同一read_token。读取失败返回TaskGraphError，不把坏数据写成Task UNKNOWN。UI保留最后合法画面并标stale。

`diff`集合键按kind+identity比较完整对象hash，输出added/removed/changed和from/to hashes；不将运行状态变化混入结构diff。不读取最新Task JSON来补历史。

replay只在新的离线目标库：从首个真实seed/captured记录解码所有对象，根据版本化reducer重新建立pins/adoption/demands和既有图投影；若目标需parent rows，使用记录中冻结原对象和显式baseline清单恢复。无法重建外部Task/账本证据时生成纯图验证库，不伪造完整可运行SDK库；正式恢复必须使用项目已有完整备份恢复流程。图replay报告分`GRAPH_PROJECTION_VERIFIED`与`RUNTIME_RESUME_NOT_AUTHORIZED`，不能因图hash相同自动恢复执行。

## 8. 数字、时间、大小与默认值

旧SQLite时间REAL维持原Store秒单位；新增lease/源witness时间名带`_ms`的为UTC毫秒。`int(store.now*1000)`只在明确读clock边界执行，preview用冻结now_ms。ordinal/revision是非负整数，bool不接受；JSON公开整数上限2^53-1，超限明确错误，不截断。

NetworkDocument最大bytes绑定GraphStructureBudget和新增固定 `max_network_document_bytes=16*1024*1024`；preview source_reads固定12类，不可缺类或重复类；公共view最大nodes/edges受Schema和部署预算较小者限制。`CompleteRead`空集合允许，但需完整reader成功并带digest；NOT_APPLICABLE与UNAVAILABLE不能用同一个None表达。

任何新模块只导入本文授权的版本化codec/状态，不通过`getattr(obj,'state',True)`、`.get(...,{})`给关键来源造默认成功。
