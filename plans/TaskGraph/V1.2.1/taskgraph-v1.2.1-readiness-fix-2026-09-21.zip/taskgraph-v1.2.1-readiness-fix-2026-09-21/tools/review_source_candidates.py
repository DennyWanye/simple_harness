#!/usr/bin/env python3
"""List exact AST candidates for unresolved source requirements. Never approve equivalence."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from capture_sources import digest, symbols
from h1h_manifest import verified_snapshot, write_new
from collection_identity import executed_fingerprint


def report_candidates(root: Path, requirements: list[dict], ids: set[str]) -> list[dict]:
    root = root.resolve(strict=True)
    result = []
    for item in requirements:
        if item['id'] not in ids:
            continue
        path = (root / item['path']).resolve()
        if not path.is_relative_to(root):
            raise ValueError('declared source path escapes snapshot')
        row = {'id': item['id'], 'declared_path': item['path'], 'declared_symbols': item['symbols'],
               'category': item['category'], 'file_sha256': None, 'qualified_candidates': {},
               'equivalence': 'NOT_PROVEN', 'reviewed_by': None, 'behavior_receipts': []}
        if not path.is_file():
            row['status'] = 'MISSING'
        else:
            row['file_sha256'] = digest(path.read_bytes())
            known = symbols(path)
            # Return ALL qualified symbols; do not promote suffix/name matches.
            row['qualified_candidates'] = known
            row['status'] = 'SOURCE_AVAILABLE_REVIEW_REQUIRED'
        result.append(row)
    if {r['id'] for r in result} != ids:
        raise ValueError('requested source requirement missing from manifest')
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-map', type=Path, required=True)
    parser.add_argument('--requirements', type=Path, required=True)
    parser.add_argument('--ids', nargs='+', default=['P02','P09','P19'])
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source, root = verified_snapshot(args.source_map)
    items = json.loads(args.requirements.read_text(encoding='utf-8'))['requirements']
    report = {'schema_version':1, 'kind':'SOURCE_CANDIDATES_NOT_EQUIVALENCE',
              'candidate_fingerprint':source['repositories']['candidate']['fingerprint'],
              'executed_source_fingerprint':executed_fingerprint(source),
              'requirements':report_candidates(root,items,set(args.ids)),
              'source_map_complete':False, 'production_enablement_allowed':False}
    write_new(args.out,report,args.source_map.resolve().parent)
    print(json.dumps({'status':'REVIEW_REQUIRED','source_map_complete':False,'production_enablement_allowed':False}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, KeyError, SyntaxError) as error:
        print(json.dumps({'status':'BLOCKED','error':str(error),'production_enablement_allowed':False}))
        raise SystemExit(3)
