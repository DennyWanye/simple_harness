#!/usr/bin/env python3
"""Create a NEW ignored source copy with the narrow runner proposal. Never edit a worktree.

Only the exact Store._apply_migration migration.ddl.split(';') call is rewritten;
unknown shapes are blocked. This script does not run a migration or add its descriptor.
"""
from __future__ import annotations
import argparse
import ast
import copy
import difflib
import json
from pathlib import Path

from capture_sources import canonical, digest
from h1h_manifest import verified_snapshot, write_new

STORE_REL = 'src/agent_orchestrator/storage/store.py'
HELPER_REL = 'src/agent_orchestrator/storage/sql_statements.py'


def _byte_offset(raw: bytes, line: int, col: int) -> int:
    return sum(len(p) for p in raw.splitlines(keepends=True)[:line - 1]) + col


def patched_store(raw: bytes) -> bytes:
    text = raw.decode('utf-8')
    tree = ast.parse(text)
    classes = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Store']
    if len(classes) != 1:
        raise ValueError('expected exactly one top-level Store')
    methods = [n for n in classes[0].body if isinstance(n, ast.FunctionDef) and n.name == '_apply_migration']
    if len(methods) != 1:
        raise ValueError('expected exactly one Store._apply_migration')
    matches = [n for n in ast.walk(methods[0]) if isinstance(n, ast.Call)
               and ast.unparse(n.func) == 'migration.ddl.split'
               and len(n.args) == 1 and isinstance(n.args[0], ast.Constant)
               and n.args[0].value == ';' and not n.keywords]
    if len(matches) != 1:
        raise ValueError('runner shape not exact/unique; independent adaptation required')
    if any(isinstance(n, ast.Name) and n.id == 'iter_sql_statements' for n in ast.walk(tree)):
        raise ValueError('helper name already used; no automatic overwrite')
    imports = [n for n in tree.body if isinstance(n, ast.ImportFrom) and n.level == 1
               and n.module is None and any(a.name == 'schema' for a in n.names)]
    if len(imports) != 1:
        raise ValueError('expected existing from . import schema import anchor')
    node = matches[0]
    start = _byte_offset(raw, node.lineno, node.col_offset)
    end = _byte_offset(raw, node.end_lineno, node.end_col_offset)
    import_end = sum(len(p) for p in raw.splitlines(keepends=True)[:imports[0].end_lineno])
    if import_end > start:
        raise ValueError('unusual source ordering; manual review required')
    new = raw[:start] + b'iter_sql_statements(migration.ddl, allow_unterminated_final=True)' + raw[end:]
    new = new[:import_end] + b'from .sql_statements import iter_sql_statements\n' + new[import_end:]
    ast.parse(new.decode('utf-8'))
    return new


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-map', type=Path, required=True)
    p.add_argument('--out-dir', type=Path, required=True)
    a = p.parse_args()
    sm, root = verified_snapshot(a.source_map)
    evidence = a.source_map.resolve(strict=True).parent
    out = a.out_dir.resolve()
    if not out.is_relative_to(evidence) or out.exists():
        raise ValueError('new isolated output inside the captured evidence run required')
    if sm.get('snapshot', {}).get('source_variant_fingerprint'):
        raise ValueError('do not patch an already derived snapshot')
    captured = {r['path']: r['sha256'] for r in sm['snapshot']['files']}
    if STORE_REL not in captured or HELPER_REL in captured or (root / HELPER_REL).exists():
        raise ValueError('store missing or helper already exists; inspect actual equivalent before patching')
    raw = (root / STORE_REL).read_bytes()
    revised = patched_store(raw)
    helper = (Path(__file__).resolve().parents[1] / 'reference/sql_statement_iterator.py').read_bytes()
    out.mkdir(parents=True)
    frozen = out / 'snapshot/sdk'
    for entry in sm['snapshot']['files']:
        src = (root / entry['path']).resolve(strict=True)
        if not src.is_relative_to(root) or digest(src.read_bytes()) != entry['sha256']:
            raise ValueError('frozen source changed while preparing derivative')
        dst = frozen / entry['path']
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open('xb') as stream:
            stream.write(revised if entry['path'] == STORE_REL else src.read_bytes())
    helper_path = frozen / HELPER_REL
    with helper_path.open('xb') as stream:
        stream.write(helper)
    files = [{'path': r, 'sha256': digest((frozen / r).read_bytes())} for r in sorted([*captured, HELPER_REL])]
    origin = sm['repositories']['candidate']['fingerprint']
    variant = digest(canonical({'kind': 'RUNNER_PATCH_PROPOSAL', 'base': origin, 'files': files}))
    new_sm = copy.deepcopy(sm)
    new_sm['snapshot'] = {**sm['snapshot'], 'path': str(frozen), 'files': files,
                          'kind': 'ISOLATED_DERIVED_SOURCE_NOT_CANDIDATE',
                          'source_variant_fingerprint': variant, 'base_candidate_fingerprint': origin}
    new_sm['source_map_complete'] = False
    new_sm['source_map_review_status'] = 'DERIVED_PATCH_NOT_REVIEWED'
    new_sm['source_symbols_complete'] = False
    for row in new_sm.get('requirements', []):
        rel = row.get('actual_path') or row.get('path')
        if rel in (STORE_REL, HELPER_REL):
            row['file_sha256'] = digest((frozen / rel).read_bytes())
            row['behavior_verified'] = False
            row['equivalence_status'] = 'RECHECK_REQUIRED_SOURCE_CHANGED'
    new_sm['derived_patch'] = {'id': 'TG-A-RUNNER-01', 'status': 'PROPOSED_NOT_APPLIED_TO_CANDIDATE',
                             'base_source_map_sha256': digest(a.source_map.read_bytes()),
                             'changed_paths': [STORE_REL, HELPER_REL]}
    write_new(out / 'source-map.derived.json', new_sm, evidence)
    diff = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), revised.decode().splitlines(keepends=True),
                                      fromfile='a/' + STORE_REL, tofile='b/' + STORE_REL))
    with (out / 'runner-proposal.diff').open('x', encoding='utf-8') as stream:
        stream.write(diff)
    write_new(out / 'patch-report.json', {
        'kind': 'ISOLATED_RUNNER_PATCH_ONLY', 'candidate_fingerprint': origin,
        'executed_source_fingerprint': variant, 'changed_paths': [STORE_REL, HELPER_REL],
        'schema_registration_modified': False, 'ddl_modified': False, 'candidate_modified': False,
        'tests_run': False, 'source_map_complete': False, 'production_enablement_allowed': False,
    }, evidence)
    verified_snapshot(a.source_map)  # original capture must still be unchanged
    print(json.dumps({'status': 'ISOLATED_PATCH_PREPARED_NOT_TESTED', 'source_variant_fingerprint': variant,
                      'production_enablement_allowed': False}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, KeyError, SyntaxError) as error:
        print(json.dumps({'status': 'BLOCKED', 'error': str(error), 'production_enablement_allowed': False}))
        raise SystemExit(3)
