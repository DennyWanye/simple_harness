# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0
# ruff: noqa: E501

"""Deterministic verification layers (§14.1 layers 1, 2 and 4).

* ``format_check``  — the Result Envelope parsed against §26.4 (already done by the
  collector; recorded here as a layer so the policy is auditable).
* ``rule_check``    — artifacts referenced by the envelope exist in the verification
  copy with the recorded hash; claims cite evidence; ``file:`` criteria hold.
* ``code_test``     — pytest in the verification copy (child process, timeout).

Each layer returns a ``LayerResult`` with PASS / FAIL / ERROR; NOT_REQUIRED is
produced by the router for layers the Task policy did not ask for.
"""

from __future__ import annotations

import logging
import re
import shutil
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from ..artifacts.workspace import EXEC_COPY_MARK, Workspace, sha256_file
from ..contracts import Artifact, ResultEnvelope, Task
from ..contracts.models import sha256_hex
from ..governance.domains import DomainProfileV1
from ..memory.verified_knowledge import KnowledgeIndex
from ..runtime.tool_gateway import run_pytest

logger = logging.getLogger(__name__)


PASS = "PASS"
FAIL = "FAIL"
ERROR = "ERROR"
NOT_REQUIRED = "NOT_REQUIRED"


@dataclass(frozen=True, slots=True)
class LayerResult:
    layer: str
    status: str
    summary: str
    detail: Mapping[str, Any]

    def to_json(self) -> dict[str, Any]:
        return {
            "layer": self.layer,
            "status": self.status,
            "summary": self.summary,
            "detail": dict(self.detail),
        }


def format_check(envelope: ResultEnvelope, *, client_result_id: str | None) -> LayerResult:
    return LayerResult(
        "format_check",
        PASS,
        "Result Envelope conforms to §26.4",
        {
            "result_id": envelope.id,
            "client_result_id": client_result_id,
            "outcome": str(envelope.outcome),
        },
    )


def check_used_knowledge(used_knowledge: Sequence[str], index: KnowledgeIndex) -> list[str]:
    """D4-4: every cited knowledge id must be VERIFIED knowledge of *this* Mission and
    not SUPERSEDED (the message names the current version)."""

    return index.check(used_knowledge)


def rule_check(
    envelope: ResultEnvelope,
    task: Task,
    *,
    artifacts: Sequence[Artifact],
    verification_copy: Workspace,
    tampered: Sequence[str] = (),
    knowledge: KnowledgeIndex | None = None,
    extra_problems: Sequence[str] = (),
    local_code_execution: bool = True,
    domain: DomainProfileV1 | None = None,
) -> LayerResult:
    problems: list[str] = [
        f"protected seed file rewritten by the Worker: {path}" for path in tampered
    ]
    problems.extend(extra_problems)  # step 7 (D7-2''): action candidates, checked by the caller
    if knowledge is not None:
        problems.extend(check_used_knowledge(envelope.used_knowledge, knowledge))
    by_path = {artifact.path: artifact for artifact in artifacts}
    if envelope.outcome.value != "candidate":
        problems.append(f"outcome is {envelope.outcome}, not a candidate")
    if not envelope.artifacts:
        problems.append("no artifacts were submitted")
    for reference in envelope.artifacts:
        artifact = by_path.get(reference)
        if artifact is None:
            problems.append(f"artifact {reference!r} is not a recorded workspace file")
            continue
        try:
            actual = sha256_file(verification_copy.resolve(reference))
        except Exception as error:  # noqa: BLE001
            logger.debug("rule_check_sha256_file_failed", exc_info=True)
            problems.append(
                f"artifact {reference!r} is unreadable in the verification copy: {error}"
            )
            continue
        if actual != artifact.content_hash:
            problems.append(f"artifact {reference!r} hash differs from the recorded artifact")
    if not envelope.claims:
        problems.append("no claims were submitted")
    if envelope.claims and not envelope.evidence:
        problems.append("claims cite no evidence")
    for criterion in task.success_criteria:
        if criterion.startswith("file:"):
            relative = criterion.removeprefix("file:")
            try:
                if not verification_copy.resolve(relative).is_file():
                    problems.append(f"success criterion {criterion!r} not met: file missing")
            except Exception as error:  # noqa: BLE001
                logger.debug("rule_check_is_file_failed", exc_info=True)
                problems.append(f"success criterion {criterion!r} unreadable: {error}")
        elif criterion.startswith("pytest:") and not local_code_execution:
            # review round 1 P1-1: a Task committed while execution was on keeps its
            # criterion; with it off nothing may treat that criterion as met
            problems.append(
                f"success criterion {criterion!r} cannot be judged: local_code_execution is "
                "off in this deployment (model-written tests are not run on this machine)"
            )
    status = FAIL if problems else PASS
    return LayerResult(
        "rule_check",
        status,
        "; ".join(problems)
        if problems
        else "artifacts, hashes, claims and file criteria consistent",
        {"problems": problems, "checked_artifacts": list(envelope.artifacts)},
    )


async def code_test(
    task: Task,
    *,
    verification_copy: Workspace,
    timeout: float,
    mission_criteria: Sequence[str] = (),
    executor: Any = None,
    result_id: str | None = None,
    artifacts: Sequence[Artifact] = (),
    on_base: bool = False,
) -> LayerResult:
    """Run every ``pytest:`` criterion (Task and Mission) in the verification copy.

    没有 ``pytest:`` 条件（连不带路径的也没有）时照例顺手跑一次（目标记为 None）。任务有底（``on_base``）
    时不跑整棵树：验收副本里有使用方仓库原有的全部测试和根目录的 pytest 配置、``conftest.py``，其中本来
    就红、要联网、缺依赖的与这一步无关，不能让一个只要求 ``file:`` 的步骤因此反复失败。所以本次登记的
    产物里的每个测试文件各跑一次（照常加载底里的配置与夹具；收集不到测试的不算失败）；一个有测试的都没有时，在验收副本旁边
    一个空目录里跑（不加载底里的任何配置，退出码 5），照旧算「不适用、视为满足」。
    """

    manifest = {
        path: sha256_file(verification_copy.resolve(path))
        for path in verification_copy.list_files()
    }
    artifact_hashes = {artifact.path: artifact.content_hash for artifact in artifacts}
    bound = bool(result_id) and all(
        manifest.get(path) == value for path, value in artifact_hashes.items()
    )
    scope = {
        "schema": "pytest-observation-v2",
        "mission_id": task.mission_id,
        "task_id": task.id,
        "attempt_id": verification_copy.attempt_id,
        "result_id": result_id,
        "artifact_hashes": artifact_hashes,
        "workspace_hash": sha256_hex(manifest),
        "checker": "pytest",
        "criteria": list(task.success_criteria),
    }
    targets: list[str | None] = []
    # 2026-09-25 主流程优化条目 3: a bare ``pytest:`` criterion (no path) is still a
    # criterion *asking* for tests, so it is a requested whole-tree run and must
    # collect at least one test.  Only the courtesy run nobody asked for may be vacuous.
    requested_whole_tree = False
    for criterion in (*task.success_criteria, *mission_criteria):
        if criterion.startswith("pytest:"):
            target = criterion.removeprefix("pytest:").strip() or None
            if target is None:
                requested_whole_tree = True
            if target not in targets:
                targets.append(target)
    runs: list[dict[str, Any]] = []
    failed = False
    courtesy_no_tests: list[str] = []
    if not targets and on_base:
        runs, courtesy_no_tests = await _courtesy_on_base(
            verification_copy, artifacts, timeout=timeout, executor=executor
        )
        failed = any(not row["passed"] for row in runs)
    if not targets and not on_base:
        targets.append(None)
    for target in targets:
        if target is not None:
            try:
                verification_copy.resolve(target)
            except Exception as error:  # noqa: BLE001
                logger.debug("code_test_resolve_failed", exc_info=True)
                runs.append({"target": target, "error": str(error)})
                failed = True
                continue
        run = await run_pytest(
            str(verification_copy.root),
            path=target,
            timeout=timeout,
            executor=executor,
            report_all=True,
        )
        # Assurance 1.1 default-ON (2026-09-23): the courtesy whole-tree run that no
        # ``pytest:`` criterion asked for, on a workspace pytest collects nothing from
        # (exit 5), attests nothing and fails nothing.  Any run a criterion asked for —
        # a named target or a bare ``pytest:`` — that collects nothing is a criterion
        # nobody checked, and stays FAIL.
        no_tests_collected = (
            target is None
            and not requested_whole_tree
            and run.returncode == 5
            and not run.timed_out
            and (run.receipt is None or run.receipt.status == "ok")
        )
        row: dict[str, Any] = {
            "target": target,
            **run.to_json(),
            "passed": run.passed or no_tests_collected,
        }
        if no_tests_collected:
            row["no_tests_collected"] = True
        runs.append(row)
        failed = failed or not row["passed"]
    summary = (
        (
            "not applicable, counts as satisfied: no pytest target was named and the "
            "workspace has no tests (exit 5)"
            if any(r.get("no_tests_collected") for r in runs)
            else "all pytest targets passed"
        )
        if not failed
        else "pytest failed: "
        + "; ".join(
            (r.get("stdout") or r.get("error") or "")[-300:].strip().splitlines()[-1]
            if (r.get("stdout") or r.get("error"))
            else "no output"
            for r in runs
            if not r.get("passed")
        )
    )
    # Tests can modify their own workspace. Such a run never attests the original
    # source snapshot, even if pytest returned zero. Newly-created cache files do
    # not invalidate it; every original input must still have the same bytes.
    unchanged = all(
        verification_copy.resolve(path).is_file()
        and sha256_file(verification_copy.resolve(path)) == digest
        for path, digest in manifest.items()
    )
    detail: dict[str, Any] = {"runs": runs}
    if courtesy_no_tests:
        detail["courtesy_no_tests"] = courtesy_no_tests
    if failed:
        detail["failure_nodes"] = _code_test_failure_nodes(runs)
    if bound and unchanged:
        detail["observation_scope"] = scope
    return LayerResult("code_test", FAIL if failed else PASS, summary, detail)


def _vacuous(run: Any) -> bool:
    return (
        run.returncode == 5
        and not run.timed_out
        and (run.receipt is None or run.receipt.status == "ok")
    )


async def _courtesy_on_base(
    copy: Workspace, artifacts: Sequence[Artifact], *, timeout: float, executor: Any
) -> tuple[list[dict[str, Any]], list[str]]:
    """任务有底、一条 ``pytest:`` 都没写时的顺手运行（见 :func:`code_test`）。

    本次登记的每个测试文件各跑一次（启动脚本只认一个目标）。行的目标仍记 None，与没有底时的
    顺手运行同一口径：它不替哪条 ``pytest:<路径>`` 作证，路径另记在 ``courtesy_target``。收集不到
    测试的文件（没有测试函数、被使用方配置反选掉，退出码 5）不算失败，记进第二个返回值。一个
    有测试的都没有时，在验收副本外的空目录里跑一次：不加载底里的 pytest 配置与 ``conftest.py``，
    退出码 5，照旧「不适用、视为满足」。
    """

    runs: list[dict[str, Any]] = []
    no_tests: list[str] = []
    for path in sorted({a.path for a in artifacts if _is_test_file(a.path)}):
        run = await run_pytest(
            str(copy.root), path=path, timeout=timeout, executor=executor, report_all=True
        )
        if _vacuous(run):
            no_tests.append(path)
            continue
        runs.append(
            {
                "target": None,
                "courtesy_target": path,
                **run.to_json(),
                "passed": run.passed,
                "courtesy": True,
            }
        )
    if runs:
        return runs, no_tests
    # 空目录放在验收副本外面：pytest 的根目录与配置查找都止于工作目录，碰不到底里的东西
    isolated = (
        copy.root.parent / f"{copy.root.name}{EXEC_COPY_MARK}no-tests-{uuid.uuid4().hex[:12]}"
    )
    isolated.mkdir()
    run = await run_pytest(
        str(isolated), path=None, timeout=timeout, executor=executor, report_all=True
    )
    if run.receipt is None or run.receipt.status == "ok":
        # 出错的运行留着工作目录，交给执行器的清理（目录名带执行副本标记）
        shutil.rmtree(isolated, ignore_errors=True)
    row = {"target": None, **run.to_json(), "passed": run.passed or _vacuous(run), "courtesy": True}
    if _vacuous(run):
        row["no_tests_collected"] = True
    return [row], no_tests


def _is_test_file(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    return name.endswith(".py") and (name.startswith("test_") or name.endswith("_test.py"))


def _code_test_failure_nodes(runs: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Stable pytest identity: exception class + node id, not the timing line."""

    exc = re.compile(r"^E\s+(\w+(?:Error|Exception|Warning)): ", re.M)
    node = re.compile(r"^(?:ERROR|FAILED) (\S+)", re.M)
    timing = re.compile(r"\bin\s+\d+(?:\.\d+)?s\b")
    workspace = re.compile(r"(?:/[\w.-]+)*/workspaces/[\w.:-]+/")
    out: list[dict[str, Any]] = []
    for run in runs:
        if run.get("passed"):
            continue
        text = str(run.get("stdout") or run.get("error") or "")
        text = workspace.sub("<ws>/", text)
        text = timing.sub("in Xs", text)
        out.append({"exc": exc.findall(text), "node": node.findall(text)})
    return out


__all__ = (
    "ERROR",
    "FAIL",
    "NOT_REQUIRED",
    "PASS",
    "LayerResult",
    "check_used_knowledge",
    "code_test",
    "format_check",
    "rule_check",
)
