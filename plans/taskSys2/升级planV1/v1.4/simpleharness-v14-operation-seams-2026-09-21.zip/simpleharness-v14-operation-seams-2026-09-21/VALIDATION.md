# 本包验证范围

环境：本轮容器 Python；不是用户的候选 .venv/macOS。

实际执行：`PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v`。
结果：**14 passed / 0 failed / 0 errors / 0 skipped**。

覆盖：六个Schema的结构检查和部分正反样本；三个hash的域区分；严格JSON重复key/非有限数拒绝；内部continuation转换和保持fence；handoff覆盖集合；增量三表在明确标识的parent-key fixture上的FK、同事务来源receipt写入与回滚。

附加执行：全部Python文件AST解析；Markdown围栏闭合；交付文件SHA-256；ZIP解压后的文件hash一致。

**未执行**：真实SDK完整schema migration、真实accept_result/facade/Review生产链、Connector proof adapter、D3真实进程重启、16项SDK验收、Host UI、应用模型、实施子代理、H1-I/完整H1/V1.4。

schema正确不等于证据真实。reference/rules.py不是授权producer、不是重发许可器。测试中params_hasher明确是fixture，不证明实际SDK params_hash兼容；该兼容由D2-01真实SDK用例证明。

目标测试文件/nodeid在主文档§11是实施目标，不是本轮已经收集的SDK项。之前3891 PASS/5 SKIP等历史结果不作为本候选证明。
