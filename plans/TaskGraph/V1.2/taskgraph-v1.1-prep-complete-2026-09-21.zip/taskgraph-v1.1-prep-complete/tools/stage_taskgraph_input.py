#!/usr/bin/env python3
"""Locate exact input ZIP by filename AND digest, then safely unpack to ignored evidence.
No replacement by a newer similarly named plan, no repository writes.
"""
from __future__ import annotations
import argparse,hashlib,json,shutil,stat,zipfile
from pathlib import Path

def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--search-root',type=Path,required=True);p.add_argument('--input-manifest',type=Path,required=True)
    p.add_argument('--source-map',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();name='simpleharness-taskgraph-code-plan-kit.zip'
    manifest=json.loads(a.input_manifest.read_text());expected=next(f['sha256'] for f in manifest['files'] if f['name']==name)
    candidates=list(a.search_root.rglob(name))
    if len(candidates)>50:raise RuntimeError('too many candidate paths; narrow search-root')
    matches=[]
    for f in candidates:
        if f.is_symlink() or not f.is_file():continue
        if hashlib.sha256(f.read_bytes()).hexdigest()==expected:matches.append(f.resolve())
    if not matches:raise RuntimeError('exact supplied archive not found; no replacement was selected')
    archive=sorted(matches)[0]
    if not a.out.resolve().is_relative_to(a.source_map.resolve().parent):raise RuntimeError('output not under ignored evidence run')
    if a.out.exists():raise RuntimeError('destination exists; no overwrite')
    with zipfile.ZipFile(archive) as z:
        if sum(x.file_size for x in z.infolist())>64*1024*1024:raise RuntimeError('uncompressed bound exceeded')
        for item in z.infolist():
            dest=(a.out/item.filename).resolve()
            if not dest.is_relative_to(a.out.resolve()):raise RuntimeError('archive traversal')
            if stat.S_ISLNK(item.external_attr>>16):raise RuntimeError('archive symlink')
        a.out.mkdir(parents=True)
        z.extractall(a.out)
    receipt={'kind':'EXACT_INPUT_STAGED','archive_name':name,'sha256':expected,
             'source_path_local_only':str(archive),'identical_aliases_local_only':[str(x) for x in matches],
             'kit_root':str(a.out/'simpleharness-taskgraph-code-plan-kit')}
    (a.out/'staging-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print('Exact original kit staged locally; no SDK status changed.')
    return 0
if __name__=='__main__':raise SystemExit(main())
