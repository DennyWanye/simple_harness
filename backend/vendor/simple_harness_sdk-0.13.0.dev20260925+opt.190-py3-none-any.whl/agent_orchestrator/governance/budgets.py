# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0
# ruff: noqa: E501  (SQL statement literals)

"""Budget accounts, Reserve / Settle and usage import (§18, ORCH-BUILD §12.2).

Two layers, never mixed:

* **Allocation layer** (this module): ``budget_accounts`` for Mission → Task →
  Attempt, ``budget_reservations`` per dispatch subject.  Reserve before an
  Attempt starts (§18.3), Settle with the real usage afterwards, release what was
  not used.  Child limits never exceed the parent (§18.2) and a child allocation
  never *adds* funds.
* **Fact layer** (the SDK ``provider_invocations`` ledger): the only source of
  actual token figures.  ``import_usage`` copies each ``usage_ref`` at most once
  (``imported_usage`` PK).  Orchestration accounts tokens only; it records no money.

An UNKNOWN provider call keeps its reservation occupied: ``settle`` refuses to
run until the caller says every usage ref is final.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from simple_harness.contracts import canonical_json

from ..contracts import Budget
from ..storage.store import Store, StoreError


class BudgetError(StoreError):
    pass


class BudgetExhausted(BudgetError):
    """Reserve refused: the requested allocation does not fit the remaining budget."""

    def __init__(self, account_id: str, dimension: str, requested: int, remaining: int) -> None:
        super().__init__(
            f"budget exhausted on {account_id}: {dimension} requested {requested}, remaining {remaining}"
        )
        self.account_id = account_id
        self.dimension = dimension
        self.requested = requested
        self.remaining = remaining


@dataclass(frozen=True, slots=True)
class UsageFact:
    """One SDK provider invocation as imported from the fact layer."""

    usage_ref: str
    input_tokens: int
    output_tokens: int
    unknown: bool = False  # the call's token usage could not be read

    @property
    def tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass(frozen=True, slots=True)
class AccountSnapshot:
    account_id: str
    scope: str
    parent_id: str | None
    limits: Budget
    reserved_tokens: int
    settled_tokens: int
    attempts_created: int
    version: int
    reserved_tool_calls: int = 0
    settled_tool_calls: int = 0
    reserved_attempts: int = 0
    # 推后第 3 批 H08：真起过的执行者会话数（只增不退）与检索类工具的预留 / 结清
    agents_started: int = 0
    reserved_search_calls: int = 0
    settled_search_calls: int = 0

    def remaining_agents(self) -> int | None:
        if self.limits.max_agents is None:
            return None
        return self.limits.max_agents - self.agents_started

    def remaining_search_calls(self) -> int | None:
        if self.limits.max_search_calls is None:
            return None
        return self.limits.max_search_calls - self.reserved_search_calls - self.settled_search_calls

    def remaining_tool_calls(self) -> int | None:
        if self.limits.max_tool_calls is None:
            return None
        return self.limits.max_tool_calls - self.reserved_tool_calls - self.settled_tool_calls

    def remaining_tokens(self) -> int | None:
        if self.limits.max_tokens is None:
            return None
        return self.limits.max_tokens - self.reserved_tokens - self.settled_tokens

    def remaining_attempts(self) -> int | None:
        if self.limits.max_attempts is None:
            return None
        return self.limits.max_attempts - self.attempts_created - self.reserved_attempts

    def to_json(self) -> dict[str, Any]:
        return {
            "account_id": self.account_id,
            "scope": self.scope,
            "parent_id": self.parent_id,
            "limits": self.limits.to_json(),
            "reserved_tokens": self.reserved_tokens,
            "settled_tokens": self.settled_tokens,
            "attempts_created": self.attempts_created,
            "reserved_attempts": self.reserved_attempts,
            "reserved_tool_calls": self.reserved_tool_calls,
            "settled_tool_calls": self.settled_tool_calls,
            "remaining_tool_calls": self.remaining_tool_calls(),
            "agents_started": self.agents_started,
            "remaining_agents": self.remaining_agents(),
            "reserved_search_calls": self.reserved_search_calls,
            "settled_search_calls": self.settled_search_calls,
            "remaining_search_calls": self.remaining_search_calls(),
            "remaining_tokens": self.remaining_tokens(),
            "remaining_attempts": self.remaining_attempts(),
            "version": self.version,
        }


class BudgetLedger:
    """All methods must run inside a ``Store.transaction()`` opened by the Commit Service."""

    def __init__(self, store: Store) -> None:
        self._store = store

    # ---------------------------------------------------------------- accounts
    def open_account(
        self, *, account_id: str, scope: str, parent_id: str | None, mission_id: str, limits: Budget
    ) -> AccountSnapshot:
        if parent_id is not None:
            parent = self.account(parent_id)
            if not limits.fits_within(parent.limits):
                raise BudgetError(
                    f"{scope} budget {limits.to_json()} exceeds parent {parent.limits.to_json()} (§18.2)"
                )
        self._store.connection.execute(
            "INSERT INTO budget_accounts(account_id,scope,parent_id,mission_id,limits_json,version,updated_at)"
            " VALUES (?,?,?,?,?,1,?) ON CONFLICT(account_id) DO NOTHING",
            (
                account_id,
                scope,
                parent_id,
                mission_id,
                canonical_json(limits.to_json()),
                self._store.now,
            ),
        )
        return self.account(account_id)

    def set_limits(self, account_id: str, limits: Budget) -> None:
        """Replace an account's limits (the monthly Global quota follows the deployment's
        configuration).  What is reserved and settled stays on the books."""

        cursor = self._store.connection.execute(
            "UPDATE budget_accounts SET limits_json = ?, version = version + 1, updated_at = ?"
            " WHERE account_id = ?",
            (canonical_json(limits.to_json()), self._store.now, account_id),
        )
        if cursor.rowcount != 1:
            raise BudgetError(f"unknown budget account {account_id}")

    def account(self, account_id: str) -> AccountSnapshot:
        row = self._store.connection.execute(
            "SELECT * FROM budget_accounts WHERE account_id = ?", (account_id,)
        ).fetchone()
        if row is None:
            raise BudgetError(f"unknown budget account {account_id}")

        return AccountSnapshot(
            account_id=row["account_id"],
            scope=row["scope"],
            parent_id=row["parent_id"],
            limits=Budget.from_json(json.loads(row["limits_json"])),
            reserved_tokens=row["reserved_tokens"],
            settled_tokens=row["settled_tokens"],
            attempts_created=row["attempts_created"],
            version=row["version"],
            reserved_tool_calls=int(row["reserved_tool_calls"] or 0),
            settled_tool_calls=int(row["settled_tool_calls"] or 0),
            # Pre-system-tail libraries cannot contain reserved attempt pools.
            reserved_attempts=int(row["reserved_attempts"])
            if "reserved_attempts" in row.keys()
            else 0,
            agents_started=int(row["agents_started"]),
            reserved_search_calls=int(row["reserved_search_calls"]),
            settled_search_calls=int(row["settled_search_calls"]),
        )

    def _chain(self, account_id: str) -> list[AccountSnapshot]:
        chain = []
        current: str | None = account_id
        while current is not None:
            snapshot = self.account(current)
            chain.append(snapshot)
            current = snapshot.parent_id
        return chain

    def _apply(self, account_id: str, **deltas: int) -> None:
        assignments = ", ".join(f"{column} = {column} + ?" for column in deltas)
        cursor = self._store.connection.execute(
            f"UPDATE budget_accounts SET {assignments}, version = version + 1, updated_at = ?"
            " WHERE account_id = ?",
            (*deltas.values(), self._store.now, account_id),
        )
        if cursor.rowcount != 1:
            raise BudgetError(f"unknown budget account {account_id}")

    # ---------------------------------------------------------------- reserve
    def reserve(
        self,
        *,
        account_id: str,
        subject_id: str,
        tokens: int,
        counts_attempt: bool,
        tool_calls: int = 0,
        mission_id: str | None = None,
        search_calls: int = 0,
    ) -> str:
        """Reserve ``tokens`` (/ ``tool_calls`` / ``search_calls``) on ``account_id`` and every ancestor.

        ``counts_attempt`` marks an executor Attempt: it also starts one executor session,
        checked against ``max_agents`` and never given back (推后第 3 批 H08).

        Idempotent per ``subject_id``: a second call returns the existing reservation.
        Fails closed on the first dimension that does not fit (§18.3: 避免并发 Agent 同时超支).
        """

        existing = self._store.connection.execute(
            "SELECT reservation_id FROM budget_reservations WHERE subject_id = ?", (subject_id,)
        ).fetchone()
        if existing is not None:
            return str(existing[0])
        chain = self._chain(account_id)
        for snapshot in chain:
            remaining_tokens = snapshot.remaining_tokens()
            if remaining_tokens is not None and tokens > remaining_tokens:
                raise BudgetExhausted(snapshot.account_id, "tokens", tokens, remaining_tokens)
            if counts_attempt:
                remaining_attempts = snapshot.remaining_attempts()
                if remaining_attempts is not None and remaining_attempts < 1:
                    raise BudgetExhausted(snapshot.account_id, "attempts", 1, remaining_attempts)
            remaining_calls = snapshot.remaining_tool_calls()
            if remaining_calls is not None and tool_calls > remaining_calls:
                raise BudgetExhausted(
                    snapshot.account_id, "tool_calls", tool_calls, remaining_calls
                )
            if counts_attempt:
                remaining_agents = snapshot.remaining_agents()
                if remaining_agents is not None and remaining_agents < 1:
                    raise BudgetExhausted(snapshot.account_id, "agents", 1, remaining_agents)
            remaining_search = snapshot.remaining_search_calls()
            if remaining_search is not None and search_calls > remaining_search:
                raise BudgetExhausted(
                    snapshot.account_id, "search_calls", search_calls, remaining_search
                )
        for snapshot in chain:
            self._apply(
                snapshot.account_id,
                reserved_tokens=tokens,
                reserved_tool_calls=tool_calls,
                attempts_created=1 if counts_attempt else 0,
                agents_started=1 if counts_attempt else 0,
                reserved_search_calls=search_calls,
            )
        reservation_id = f"reservation-{subject_id}"
        if (
            mission_id is None
        ):  # review P0-1: the caller names the Mission; the chain may end at Global
            mission_id = next(
                (s.account_id.removeprefix("budget:") for s in chain if s.scope == "mission"),
                chain[-1].account_id.removeprefix("budget:"),
            )
        self._store.connection.execute(
            "INSERT INTO budget_reservations(reservation_id,account_id,mission_id,subject_id,state,"
            "reserved_tokens,reserved_tool_calls,reserved_search_calls,created_at,updated_at)"
            " VALUES (?,?,?,?,?,?,?,?,?,?)",
            (
                reservation_id,
                account_id,
                mission_id,
                subject_id,
                "RESERVED",
                tokens,
                tool_calls,
                search_calls,
                self._store.now,
                self._store.now,
            ),
        )
        return reservation_id

    def release_attempt(self, account_id: str) -> None:
        """Give back one attempt on ``account_id`` and every ancestor (2026-09-28：非模型原因
        的失败不扣次数)。只退次数；token 与工具次数照常结清。"""

        if not self._store.connection.in_transaction:
            raise BudgetError("attempt release requires a Commit transaction")
        chain = self._chain(account_id)
        if any(snapshot.attempts_created < 1 for snapshot in chain):
            raise BudgetError(f"no attempt to release on {account_id}")
        for snapshot in chain:
            self._apply(snapshot.account_id, attempts_created=-1)

    def reservation(self, subject_id: str) -> dict[str, Any] | None:
        row = self._store.connection.execute(
            "SELECT * FROM budget_reservations WHERE subject_id = ?", (subject_id,)
        ).fetchone()
        return None if row is None else dict(row)

    def grow(self, *, subject_id: str, tokens: int) -> None:
        """Raise an existing token envelope; all checks precede writes."""
        if not self._store.connection.in_transaction:
            raise BudgetError("reservation grow requires a Commit transaction")
        if type(tokens) is not int or tokens < 0:
            raise BudgetError("reservation allowance must be a nonnegative integer")
        reservation = self.reservation(subject_id)
        if reservation is None or reservation["state"] != "RESERVED":
            raise BudgetError("reservation grow requires a live original subject")
        delta = max(0, tokens - reservation["reserved_tokens"])
        if not delta:
            return
        chain = self._chain(reservation["account_id"])
        for snapshot in chain:
            remaining = snapshot.remaining_tokens()
            if remaining is not None and delta > remaining:
                raise BudgetExhausted(snapshot.account_id, "tokens", delta, remaining)
        for snapshot in chain:
            self._apply(snapshot.account_id, reserved_tokens=delta)
        self._store.connection.execute(
            "UPDATE budget_reservations SET reserved_tokens=reserved_tokens+?,updated_at=?"
            " WHERE subject_id=?",
            (delta, self._store.now, subject_id),
        )

    # ------------------------------------------------------------ usage facts
    def import_usage(self, *, subject_id: str, mission_id: str, facts: Sequence[UsageFact]) -> int:
        """Copy usage facts from the SDK ledger; each ``usage_ref`` lands at most once.

        An ``unknown=1`` row is the exception: a later known fact for the same
        ``usage_ref`` overwrites it (P2.3l P1-1).  A known row stays append-only.
        """

        imported = 0
        for fact in facts:
            cursor = self._store.connection.execute(
                "INSERT INTO imported_usage(usage_ref,subject_id,mission_id,input_tokens,output_tokens,"
                "unknown,imported_at) VALUES (?,?,?,?,?,?,?)"
                " ON CONFLICT(usage_ref) DO UPDATE SET"
                " input_tokens=excluded.input_tokens, output_tokens=excluded.output_tokens,"
                " unknown=excluded.unknown, imported_at=excluded.imported_at"
                " WHERE imported_usage.unknown=1 AND excluded.unknown=0",
                (
                    fact.usage_ref,
                    subject_id,
                    mission_id,
                    fact.input_tokens,
                    fact.output_tokens,
                    1 if fact.unknown else 0,
                    self._store.now,
                ),
            )
            imported += cursor.rowcount
        return imported

    def usage_for(self, subject_id: str) -> int:
        """Tokens over the subject's imported usage."""

        row = self._store.connection.execute(
            "SELECT COALESCE(SUM(input_tokens + output_tokens), 0)"
            " FROM imported_usage WHERE subject_id = ?",
            (subject_id,),
        ).fetchone()
        return int(row[0])

    def known_usage_for(self, subject_id: str) -> int:
        """Like :meth:`usage_for`, but unknown rows do not count as a 0-token charge."""

        row = self._store.connection.execute(
            "SELECT COALESCE(SUM(input_tokens + output_tokens), 0)"
            " FROM imported_usage WHERE subject_id = ? AND unknown = 0",
            (subject_id,),
        ).fetchone()
        return int(row[0])

    def imported_unknown_count(self, subject_id: str) -> int:
        row = self._store.connection.execute(
            "SELECT COUNT(*) FROM imported_usage WHERE subject_id = ? AND unknown = 1",
            (subject_id,),
        ).fetchone()
        return int(row[0])

    def has_unknown_usage(self, subject_id: str) -> bool:
        row = self._store.connection.execute(
            "SELECT COUNT(*) FROM imported_usage WHERE subject_id = ? AND unknown = 1",
            (subject_id,),
        ).fetchone()
        held = self._store.connection.execute(
            "SELECT 1 FROM provider_token_grants WHERE subject_id=?"
            " AND state IN ('RESERVED','HANDED_OFF','UNKNOWN') LIMIT 1",
            (subject_id,),
        ).fetchone()
        return int(row[0]) > 0 or held is not None

    # ----------------------------------------------------------------- settle
    def settle(self, *, subject_id: str, tool_calls: int = 0) -> dict[str, Any]:
        """Replace the reservation by the imported facts on the whole account chain
        (``tool_calls`` is the gateway's count for the subject — a fact, never a guess)."""

        reservation = self.reservation(subject_id)
        if reservation is None:
            raise BudgetError(f"no reservation for {subject_id}")
        if reservation["state"] == "SETTLED":
            return reservation
        if self.has_unknown_usage(subject_id):
            # ORCH §12.2: an UNKNOWN charge keeps the reservation occupied until reconciled.
            raise BudgetError(f"{subject_id} has an unknown provider charge; reservation held")
        tokens = self.usage_for(subject_id)
        searches = self._store.count_search_calls(subject_id)  # H08: the tool-call table's fact
        for snapshot in self._chain(reservation["account_id"]):
            self._apply(
                snapshot.account_id,
                reserved_tokens=-int(reservation["reserved_tokens"]),
                reserved_tool_calls=-int(reservation.get("reserved_tool_calls") or 0),
                settled_tokens=tokens,
                settled_tool_calls=int(tool_calls),
                reserved_search_calls=-int(reservation.get("reserved_search_calls") or 0),
                settled_search_calls=searches,
            )
        self._store.connection.execute(
            "UPDATE budget_reservations SET state = 'SETTLED', settled_tokens = ?,"
            " settled_tool_calls = ?, settled_search_calls = ?, updated_at = ? WHERE subject_id = ?",
            (tokens, int(tool_calls), searches, self._store.now, subject_id),
        )
        settled = self.reservation(subject_id)
        assert settled is not None
        return settled

    def settle_at_upper_bound(self, *, subject_id: str) -> dict[str, Any]:
        """Count a reservation an UNKNOWN charge holds at its upper bound (user, 2026-09-26).

        Only for a subject that will never run again (closeout of a judged
        Mission).  The charge stays unknown in the usage facts — the truth — but the
        account is charged the larger of the reservation and the known facts, so the
        Mission can close: overcount, never undercount, never freeze.
        """

        reservation = self.reservation(subject_id)
        if reservation is None:
            raise BudgetError(f"no reservation for {subject_id}")
        if reservation["state"] == "SETTLED":
            return reservation
        known_tokens = self.known_usage_for(subject_id)
        tokens = max(int(reservation["reserved_tokens"]), int(known_tokens))
        searches = self._store.count_search_calls(subject_id)  # H08: executed calls are known facts
        for snapshot in self._chain(reservation["account_id"]):
            self._apply(
                snapshot.account_id,
                reserved_tokens=-int(reservation["reserved_tokens"]),
                reserved_tool_calls=-int(reservation.get("reserved_tool_calls") or 0),
                settled_tokens=tokens,
                settled_tool_calls=0,
                reserved_search_calls=-int(reservation.get("reserved_search_calls") or 0),
                settled_search_calls=searches,
            )
        self._store.connection.execute(
            "UPDATE budget_reservations SET state = 'SETTLED', settled_tokens = ?,"
            " settled_tool_calls = 0, settled_search_calls = ?, updated_at = ? WHERE subject_id = ?",
            (tokens, searches, self._store.now, subject_id),
        )
        settled = self.reservation(subject_id)
        assert settled is not None
        return settled

    def costs_report(self, mission_id: str) -> dict[str, Any]:
        rows = self._store.connection.execute(
            "SELECT * FROM budget_accounts WHERE mission_id = ? ORDER BY account_id", (mission_id,)
        ).fetchall()
        usage = self._store.connection.execute(
            "SELECT subject_id, usage_ref, input_tokens, output_tokens, unknown"
            " FROM imported_usage WHERE mission_id = ? ORDER BY imported_at, usage_ref",
            (mission_id,),
        ).fetchall()
        reservations = self._store.connection.execute(
            "SELECT * FROM budget_reservations WHERE mission_id = ? ORDER BY created_at",
            (mission_id,),
        ).fetchall()
        # 按月配额（2026-10-06 车道 P）：这个任务挂在它建立当月的全局总账下，报告就读那一个，
        # 不是库里随便第一个全局账户
        global_row = self._store.connection.execute(
            "SELECT g.account_id FROM budget_accounts m JOIN budget_accounts g ON g.account_id = m.parent_id"
            " WHERE m.mission_id = ? AND m.scope = 'mission' AND g.scope = 'global' LIMIT 1",
            (mission_id,),
        ).fetchone()
        report: dict[str, Any] = {
            "accounts": [self.account(row["account_id"]).to_json() for row in rows],
            "usage": [dict(row) for row in usage],
            "reservations": [dict(row) for row in reservations],
            "global": None if global_row is None else self.account(global_row[0]).to_json(),
            # L3-3: reservations an UNKNOWN provider charge keeps occupied (never auto-released)
            "held_reservations": [
                dict(row)
                for row in reservations
                if row["state"] != "SETTLED" and self.has_unknown_usage(row["subject_id"])
            ],
        }
        report["usage_fully_known"] = self._usage_fully_known(mission_id, usage)
        report["budget_conserved"] = self._budget_conserved(rows)
        return report

    def _usage_fully_known(self, mission_id: str, usage: Sequence[Any]) -> bool:
        if any(int(row["unknown"] or 0) == 1 for row in usage):
            return False
        if not self._store.has_table("provider_token_grants"):
            return True
        held = self._store.connection.execute(
            "SELECT 1 FROM provider_token_grants"
            " WHERE mission_id=? AND state IN ('RESERVED','HANDED_OFF','UNKNOWN') LIMIT 1",
            (mission_id,),
        ).fetchone()
        return held is None

    def _budget_conserved(self, account_rows: Sequence[Any]) -> bool:
        for row in account_rows:
            snapshot = self.account(row["account_id"])
            if snapshot.scope != "mission":
                continue
            remaining = snapshot.remaining_tokens()
            pool = snapshot.limits.max_tokens
            if remaining is None or pool is None:
                continue
            if remaining + snapshot.reserved_tokens + snapshot.settled_tokens != pool:
                return False
        return True

    def usage_flags(self, mission_id: str) -> dict[str, bool]:
        rows = self._store.connection.execute(
            "SELECT * FROM budget_accounts WHERE mission_id = ? ORDER BY account_id", (mission_id,)
        ).fetchall()
        usage = self._store.connection.execute(
            "SELECT subject_id, usage_ref, input_tokens, output_tokens, unknown"
            " FROM imported_usage WHERE mission_id = ? ORDER BY imported_at, usage_ref",
            (mission_id,),
        ).fetchall()
        return {
            "usage_fully_known": self._usage_fully_known(mission_id, usage),
            "budget_conserved": self._budget_conserved(rows),
        }


def budget_from_mapping(value: Mapping[str, Any] | Budget | None) -> Budget:
    if value is None:
        return Budget()
    if isinstance(value, Budget):
        return value
    return Budget.from_json(value)


__all__ = (
    "AccountSnapshot",
    "BudgetError",
    "BudgetExhausted",
    "BudgetLedger",
    "UsageFact",
    "budget_from_mapping",
)
