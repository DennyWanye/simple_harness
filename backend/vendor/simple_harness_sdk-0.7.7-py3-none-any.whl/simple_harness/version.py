# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Single SDK version authority used by metadata and runtime reports."""

__version__ = "0.7.7"

__all__ = ("__version__",)
