#!/usr/bin/env python3
"""Create a reviewable relative-path evidence index; never commits it to Git."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path

def redact_source_map(source:dict,relative_evidence:str,sha256:str)->dict:
    if relative_evidence.startswith('/') or '..' in Path(relative_evidence).parts:
        raise ValueError('evidence index must be a safe repository-relative path')
    repos={}
    for role,repo in source['repositories'].items():
        repos[role]={k:repo[k] for k in ('head','branch','index_digest','fingerprint','dirty_files')}
    rows=[]
    for r in source['requirements']:
        rows.append({k:r.get(k) for k in ('id','category','actual_path','file_sha256','actual_symbols','observed_status','equivalence_status','behavior_verified')})
    return {'spec':'TG-READY-1.0','kind':'REVIEWABLE_SUMMARY_NOT_A_PASS',
            'repositories':repos,'sources':rows,
            'evidence_index':{'relative_path':relative_evidence,'sha256':sha256},
            'source_map_complete':False,'independent_review':'PENDING','production_enablement_allowed':False}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-map',type=Path,required=True)
    p.add_argument('--host',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    raw=a.source_map.read_bytes();relative=str(a.source_map.resolve().relative_to(a.host.resolve()))
    output=redact_source_map(json.loads(raw),relative,hashlib.sha256(raw).hexdigest())
    with a.out.open('x') as f:json.dump(output,f,ensure_ascii=False,indent=2)
    print('Review index written; manual review required before saving a summary to Git.')
    return 0
if __name__=='__main__':raise SystemExit(main())
