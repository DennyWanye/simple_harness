import unittest
from itertools import permutations
from reference.rules import (Rejected,checked_int,topological,Occurrence,Slot,Method,Order,Data,Accepted,project,node_id,resolve_inputs,order_is_released,impact,must_preserve_shared,accepts_parent,check_dispatch_origin,same_command_receipt,digest)

class Rules(unittest.TestCase):
    def setUp(self):
        self.occ=(Occurrence('r','compound'),Occurrence('a','primitive'),Occurrence('b','primitive'))
        self.method=Method('m','r',(Slot('a','a',True),Slot('b','b',True)))
        self.out=Accepted('a','out','result1','acc1','art1','h1','v1','schema1',True,True)
        self.data=(Data('d','a','out','b','in'),)
    def rejects(self,code,fn,*args,**kwargs):
        with self.assertRaises(Rejected) as cm:fn(*args,**kwargs)
        self.assertEqual(code,cm.exception.code)
    def test_bool_not_integer(self): self.rejects('PARAMETER_INVALID',checked_int,True)
    def test_int_lower_bound(self): self.rejects('PARAMETER_INVALID',checked_int,-1)
    def test_unknown_graph_node_refused(self): self.rejects('STRUCTURE_INVALID',topological,['a'],[('a','missing')])
    def test_duplicate_graph_node_refused(self): self.rejects('STRUCTURE_INVALID',topological,['a','a'],[])
    def test_cycle_not_partial_order(self): self.rejects('ORDER_CYCLE',topological,['a','b','c'],[('a','b'),('b','a')])
    def test_node_order_does_not_change_sort(self):
        for p in permutations(['a','b','c']):self.assertEqual(('a','b','c'),topological(p,[('a','c')]))
    def test_compound_gates_not_billable(self):
        p=project(self.occ,(self.method,),('m',),('r',))
        self.assertEqual(('a','b'),p.billable_occurrences)
        self.assertIn(node_id('r','entry'),p.nodes)
        self.assertNotIn((node_id('a','node'),node_id('b','node')),p.edges)
    def test_unexpanded_compound_not_worker(self): self.assertEqual((),project((self.occ[0],),(),(),('r',)).billable_occurrences)
    def test_alternatives_are_not_and(self):
        mb=Method('mb','r',(Slot('b','b',True),))
        ma=Method('ma','r',(Slot('a','a',True),))
        self.assertEqual(('a',),project(self.occ,(ma,mb),('ma',),('r',)).billable_occurrences)
    def test_two_adoptions_refused(self):
        self.rejects('OR_NOT_RESOLVED',project,self.occ,(self.method,Method('m2','r',(Slot('a','a',True),))),('m','m2'),('r',))
    def test_duplicate_slot_refused(self):
        self.rejects('STRUCTURE_INVALID',project,self.occ,(Method('m','r',(Slot('x','a',True),Slot('x','b',True))),),('m',),('r',))
    def test_refinement_cycle_separate(self):
        self.rejects('REFINEMENT_CYCLE',project,self.occ,(Method('m','r',(Slot('self','r',True),)),),('m',),('r',))
    def test_optional_only_cannot_satisfy(self):
        self.rejects('COVERAGE_GAP',project,self.occ,(Method('m','r',(Slot('a','a',False),)),),('m',),('r',))
    def test_order_targets_must_exist(self):
        self.rejects('STRUCTURE_INVALID',project,self.occ,(self.method,),('m',),('r',),(Order('x','a'),))
    def test_data_makes_dependency(self):
        p=project(self.occ,(self.method,),('m',),('r',),data=self.data)
        self.assertIn((node_id('a','node'),node_id('b','node')),p.edges)
    def test_data_order_combined_cycle_refused(self):
        self.rejects('ORDER_CYCLE',project,self.occ,(self.method,),('m',),('r',),(Order('b','a'),),self.data)
    def resolve(self,**kw):
        d=dict(consumer='b',required_ports=frozenset({'in'}),requirements=self.data,outputs=(self.out,),pins={'d':'v1'},schemas={'in':'schema1'},complete_sources=True);d.update(kw)
        return resolve_inputs(**d)
    def test_exact_input_resolved(self):self.assertEqual((self.out,),self.resolve())
    def test_no_latest_on_frozen_input(self):
        newer=Accepted('a','out','r2','acc2','art2','h2','v2','schema1',True,True)
        self.assertEqual((self.out,),self.resolve(outputs=(self.out,newer)))
    def test_missing_source_not_empty(self): self.rejects('SOURCE_UNAVAILABLE',self.resolve,complete_sources=False)
    def test_required_port_empty_refused(self): self.rejects('DATA_UNBOUND',self.resolve,requirements=())
    def test_legitimate_no_input(self):self.assertEqual((),self.resolve(required_ports=frozenset(),requirements=()))
    def test_duplicate_candidates_refused(self):self.rejects('DATA_UNBOUND',self.resolve,outputs=(self.out,self.out))
    def test_stale_or_nondisclosable_refused(self):
        for a in (Accepted('a','out','r','ac','ar','h','v1','schema1',False,True),Accepted('a','out','r','ac','ar','h','v1','schema1',True,False)):
            self.rejects('STALE_BINDING',self.resolve,outputs=(a,))
    def test_schema_converter_not_implied(self):self.rejects('DATA_UNBOUND',self.resolve,schemas={'in':'other'})
    def test_order_only_does_not_provide_data(self):self.rejects('DATA_UNBOUND',self.resolve,requirements=())
    def test_cancelled_not_settled(self):self.assertFalse(order_is_released('CANCELLED','settled_terminal',settled=False))
    def test_failed_never_accepted(self):self.assertFalse(order_is_released('FAILED','accepted',settled=True))
    def test_unknown_never_releases(self):
        for r in ('accepted','settled_terminal'):self.assertFalse(order_is_released('UNKNOWN',r,settled=True))
    def test_settled_failure_releases_cleanup(self):self.assertTrue(order_is_released('FAILED','settled_terminal',settled=True))
    def test_data_invalidation_local(self):
        retained,recheck=impact(frozenset({'a'}),self.data,{},frozenset({'a','b','z'}),complete=True)
        self.assertEqual(frozenset({'z'}),retained);self.assertEqual(frozenset({'a','b'}),recheck)
    def test_incomplete_coverage_conservative(self):
        self.assertEqual((frozenset(),frozenset({'a','b','z'})),impact(frozenset({'a'}),self.data,{},frozenset({'a','b','z'}),complete=False))
    def test_shared_consumer_preserved(self):self.assertTrue(must_preserve_shared('c',{'c':('other',)},independent_demand=False,unresolved_effect=False))
    def test_independent_obligation_preserved(self):self.assertTrue(must_preserve_shared('c',{},independent_demand=True,unresolved_effect=False))
    def test_unknown_operation_preserved(self):self.assertTrue(must_preserve_shared('c',{},independent_demand=False,unresolved_effect=True))
    def test_children_pass_not_enough(self):self.assertFalse(accepts_parent(frozenset({'a'}),frozenset({'a'}),adopted_method=True,composition_accepted=False,requirements_covered=True,validity_current=True))
    def test_all_parent_conditions(self):self.assertTrue(accepts_parent(frozenset({'a'}),frozenset({'a'}),adopted_method=True,composition_accepted=True,requirements_covered=True,validity_current=True))
    def test_no_vacuous_root_completion(self):self.assertFalse(accepts_parent(frozenset(),frozenset(),adopted_method=True,composition_accepted=True,requirements_covered=True,validity_current=True))
    def test_unrelated_revision_not_fence(self):
        e=dict(mission='m',task='t',occurrence='o',contract_hash='h',input_binding_revision=1,dispatch_generation=1,plan_revision=1)
        check_dispatch_origin(expected=e,current=dict(e,plan_revision=2),fence_active=False,valid_inputs=True,has_demand=True)
    def test_changed_generation_refused(self):
        e=dict(mission='m',task='t',occurrence='o',contract_hash='h',input_binding_revision=1,dispatch_generation=1)
        self.rejects('STALE_BINDING',check_dispatch_origin,expected=e,current=dict(e,dispatch_generation=2),fence_active=False,valid_inputs=True,has_demand=True)
    def test_command_duplicate_or_conflict(self):
        self.assertEqual('REPLAY',same_command_receipt('h','h'));self.rejects('COMMAND_PAYLOAD_CONFLICT',same_command_receipt,'h','other')
    def test_canonical_object_order(self):self.assertEqual(digest({'a':1,'b':2}),digest({'b':2,'a':1}))
