# 实际验证范围

日期：2026-09-21。环境：Linux，Python 3.13.5，SQLite 3.46.1。

## 本轮真实运行

- 新内部document strict codec、引用/范围规则、milestone精确匹配与根覆盖等参考测试：与SQL测试合计 **41 tests / 0 failures / 0 errors / 0 skipped**。
- 四张扩展表、八个不可变trigger在明确标识的最小parent-key fixture中执行，foreign key/重复要求版本/延迟receipt关联/事务与DDL rollback参考检查通过。
- Python源码AST、12组SDK待执行编号与状态、Markdown fence配对通过。
- 旧补遗正文和ZIP的SHA-256与用户handoff一致。

这些不是生产SDK的证明。参考测试中的`applicable_acceptance_ids`和`verified_outcomes`是明确fixture，用来测试覆盖算法；并未验证真实Validity、官方Review或connector receipt真实性。SQL parent fixture也不是完整SDK schema。

## 未运行

- 用户六份dirty源码的内容读取与hash复验。
- 真实SDK迁移、12组SDK集成场景、真实并发/进程强退、独立Review/授权/connector接口。
- Host源码UI、应用模型/子代理、H1-I/full H1/V1.4最终验收。
- jsonschema检查：本包未依赖该第三方库，使用标准库strict codec；不能把旧包缺依赖的测试记录改成PASS。

当前交付是完成合同的增量规格和局部参考实现，不是SDK补丁。原始参考测试日志留在本轮工作目录，不捆绑成SDK执行证据。
