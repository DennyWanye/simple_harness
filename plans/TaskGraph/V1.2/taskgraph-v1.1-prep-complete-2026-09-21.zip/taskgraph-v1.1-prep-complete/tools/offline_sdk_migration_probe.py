#!/usr/bin/env python3
"""Exercise the actual candidate Store migration runner on disposable full-schema DBs.
Never opens a supplied production DB. No source edits, no runtime flag, no model calls.
An unregistered TG descriptor is appended only in this disposable Python process.
"""
from __future__ import annotations
import argparse, contextlib, gc, hashlib, importlib, json, sqlite3, sys
from pathlib import Path
from capture_sources import digest, project_python, canonical

REQUIRED_H1_TABLES={'planning_lane_grants','planning_request_authority_bindings',
                    'planning_operation_action_links','planning_admission_checks'}

def schema_rows(db:Path):
    with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as c:
        return [list(r) for r in c.execute('SELECT version,name,checksum FROM orch_schema_migrations ORDER BY version')]

def table_columns(db:Path)->dict:
    with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as c:
        names=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        return {name:[r[1] for r in c.execute('PRAGMA table_info('+quote(name)+')')] for name in names}

def quote(s:str)->str:return '"'+s.replace('"','""')+'"'

def logical_fingerprint(db:Path, names:list[str]|None=None)->dict:
    with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as c:
        master=[list(r) for r in c.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")]
        if names is None:names=[r[1] for r in master if r[0]=='table']
        records={}
        for name in names:
            rows=[]
            for row in c.execute('SELECT * FROM '+quote(name)):
                rows.append(canonical([{'bytes':v.hex()} if isinstance(v,bytes) else v for v in row]).decode())
            records[name]=digest(canonical(sorted(rows)))
        return {'schema_sha256':digest(canonical(master)),'tables':records}

def backup(source:Path,target:Path)->None:
    if target.exists():raise RuntimeError('backup target exists')
    with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as a,sqlite3.connect(target) as b:a.backup(b)

@contextlib.contextmanager
def migrations(schema, items):
    original=schema.MIGRATIONS
    schema.MIGRATIONS=items
    try:yield
    finally:schema.MIGRATIONS=original

def open_close(Store,db:Path)->None:
    store=Store.open(db)
    try:
        # Exercise public Store; actual driver handles schema and migrations.
        if not store.has_table('orch_schema_migrations'):raise AssertionError('missing migration table')
    finally:store.close()

def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-map',type=Path,required=True)
    p.add_argument('--kit',type=Path,required=True)
    p.add_argument('--parent-contract',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    sm=json.loads(a.source_map.read_text());candidate=Path(sm['repositories']['candidate']['root'])
    project_python(candidate)
    if not sm.get('candidate_unchanged_during_capture') or not sm.get('head_matches_handoff'):
        raise RuntimeError('capture identity unresolved')
    snapshot=sm.get('snapshot')
    if not snapshot:raise RuntimeError('no isolated source snapshot')
    root=Path(snapshot['path']).resolve();evidence=a.source_map.resolve().parent
    if not root.is_relative_to(evidence) or not a.out.resolve().is_relative_to(evidence):
        raise RuntimeError('snapshot/output must remain inside captured evidence run')
    if a.out.exists():raise RuntimeError('new migration-probe directory required')
    for f in snapshot['files']:
        if digest((root/f['path']).read_bytes())!=f['sha256']:raise RuntimeError('frozen source hash mismatch')
    a.out.mkdir(parents=True)
    report={'spec':'TG-READY-1.0','kind':'OFFLINE_FULL_SDK_SCHEMA_PROBE',
            'candidate_head':sm['repositories']['candidate']['head'],
            'candidate_fingerprint':sm['repositories']['candidate']['fingerprint'],
            'source_snapshot':str(root),'status':'PENDING','checks':{},
            'production_enablement_allowed':False,'registered_sdk_migration_pass':False,
            'legacy_populated_data_preservation':'PENDING_REAL_SDK_FIXTURE',
            'sdk_cases_C06_C07':'PENDING_SDK_EXECUTION'}
    path=a.out/'migration-report.json'
    def save():path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    sys.path.insert(0,str(root/'src'))
    try:
        storage=importlib.import_module('agent_orchestrator.storage.store')
        schema=importlib.import_module('agent_orchestrator.storage.schema')
        shared_contracts=importlib.import_module("simple_harness.contracts")
        for module in (storage,schema,shared_contracts):
            if not Path(module.__file__).resolve().is_relative_to(root):
                raise RuntimeError('import came from installed wheel, not frozen candidate')
        Store=storage.Store
        original=tuple(schema.MIGRATIONS)
        versions=[m.version for m in original]
        if not versions or versions!=sorted(set(versions)):raise RuntimeError('migration order/identity invalid')
        report['migration_descriptors']=[{'version':m.version,'name':m.name,'checksum':m.checksum} for m in original]
        report['runner_source']=str(Path(storage.__file__).relative_to(root))
        report['descriptor_chain_hash']=digest(canonical(report['migration_descriptors']))
        base=a.out/'base-full-schema.sqlite3'
        open_close(Store,base)
        report['checks']['base_fresh']='PASS'
        base_fp=logical_fingerprint(base)
        parent=json.loads(a.parent_contract.read_text());cols=table_columns(base)
        missing={t:sorted(set(cs)-set(cols.get(t,[]))) for t,cs in parent['tables'].items() if t not in cols or set(cs)-set(cols[t])}
        report['missing_parent_tables_or_columns']=missing
        ddl_path=a.kit/'sql/001_taskgraph_extension.sql';ddl=ddl_path.read_text()
        if digest(ddl_path.read_bytes())!=parent['ddl_sha256']:raise RuntimeError('TG DDL differs from reviewed input')
        report['extension_ddl_sha256']=parent['ddl_sha256']
        # Characterize trigger handling independently of unavailable business producers.
        smoke= a.out/'runner-trigger-probe.sqlite3';backup(base,smoke)
        smoke_ddl="CREATE TABLE tg_ready_probe(x INTEGER); CREATE TRIGGER tg_ready_probe_tr BEFORE INSERT ON tg_ready_probe BEGIN SELECT CASE WHEN NEW.x<0 THEN RAISE(ABORT,'negative value; expected') END; END;"
        smoke_m=schema.Migration(max(versions)+1,'tg_readiness_trigger_probe_ONLY',smoke_ddl)
        try:
            with migrations(schema,(*original,smoke_m)):open_close(Store,smoke)
            with sqlite3.connect(smoke) as c:
                c.execute('INSERT INTO tg_ready_probe VALUES(1)')
                try:c.execute('INSERT INTO tg_ready_probe VALUES(-1)')
                except sqlite3.IntegrityError:pass
                else:raise AssertionError('trigger did not enforce guard')
            report['checks']['actual_runner_trigger_support']='PASS'
        except Exception as e:
            gc.collect();report['checks']['actual_runner_trigger_support']='BLOCKED'
            report['runner_trigger_error']={'code':'MIGRATION_RUNNER_TRIGGER_UNSUPPORTED','type':type(e).__name__,'message':str(e)}
        if missing or report['checks']['actual_runner_trigger_support']!='PASS':
            report['status']='BLOCKED';report['next_action']='Resolve real parent schema and runner contract. Do not add dummy parent tables or patch the runner inside this probe.'
            save();return 3
        extension_matches=[m for m in original if m.checksum==parent['ddl_sha256']]
        has_tg=any(t.startswith('taskgraph_') for t in cols)
        if extension_matches or has_tg:
            report['status']='BLOCKED';report['next_action']='Extension already registered/present: use pre-extension real fixture and registered-runner pytest lane C06; do not append duplicate DDL.'
            save();return 3
        number=max(versions)+1
        report['proposed_migration_number']=number
        report['registration_kind']='PROCESS_LOCAL_APPEND_ONLY_NOT_SOURCE_REGISTRATION'
        target=(*original,schema.Migration(number,'taskgraph_execution_v2',ddl))
        fresh=a.out/'fresh-target.sqlite3'
        with migrations(schema,target):open_close(Store,fresh)
        report['checks']['full_schema_fresh_with_extension']='PASS'
        upgrade=a.out/'upgrade-copy.sqlite3';backup(base,upgrade)
        with migrations(schema,target):open_close(Store,upgrade)
        up_fp=logical_fingerprint(upgrade,list(base_fp['tables']))
        if up_fp['tables']!=base_fp['tables']|{'orch_schema_migrations':up_fp['tables']['orch_schema_migrations']}:
            raise AssertionError('pre-existing table contents changed')
        if logical_fingerprint(fresh)['schema_sha256']!=logical_fingerprint(upgrade)['schema_sha256']:
            raise AssertionError('fresh and upgrade sqlite schema differ')
        with migrations(schema,target):open_close(Store,upgrade)
        if schema_rows(upgrade)!=[[m.version,m.name,m.checksum] for m in target]:raise AssertionError('descriptor/checksum mismatch')
        report['checks']['upgrade_and_idempotent_reopen']='PASS'
        with sqlite3.connect(upgrade) as c:
            c.execute('PRAGMA foreign_keys=ON')
            if list(c.execute('PRAGMA foreign_key_check')):raise AssertionError('foreign key check failed')
            if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise AssertionError('integrity check failed')
            try:
                c.execute('INSERT INTO taskgraph_policy_bindings VALUES(?,?,?,?,?,?,?)',
                          ('NONEXISTENT-MISSION','taskgraph-exec-v2','a'*64,'{}','probe-command','b'*64,0.0))
            except sqlite3.IntegrityError: c.rollback()
            else:raise AssertionError('foreign Mission accepted by FK')
        report['checks']['foreign_key_and_integrity']='PASS'
        rollback=a.out/'rollback-copy.sqlite3';backup(base,rollback)
        broken=(*original,schema.Migration(number,'taskgraph_execution_v2_fault_only',ddl+'\nINSERT INTO __TG_EXPECTED_MISSING_TABLE VALUES(1);'))
        try:
            with migrations(schema,broken):open_close(Store,rollback)
        except sqlite3.Error:pass
        else:raise AssertionError('fault was not raised')
        gc.collect()
        if logical_fingerprint(rollback)!=base_fp:raise AssertionError('migration failure left partial schema/data')
        report['checks']['transaction_rollback']='PASS'
        corrupt=a.out/'checksum-copy.sqlite3';backup(base,corrupt)
        with sqlite3.connect(corrupt) as c:
            c.execute('UPDATE orch_schema_migrations SET checksum=? WHERE version=?',('f'*64,min(versions)))
        before=logical_fingerprint(corrupt)
        try:
            with migrations(schema,target):open_close(Store,corrupt)
        except storage.SchemaIncompatible:pass
        else:raise AssertionError('checksum conflict accepted')
        gc.collect()
        if logical_fingerprint(corrupt)!=before:raise AssertionError('checksum refusal changed DB')
        report['checks']['checksum_refusal_without_changes']='PASS'
        if logical_fingerprint(base)!=base_fp:raise AssertionError('base fixture was modified')
        report['checks']['baseline_source_preserved']='PASS'
        report['status']='OFFLINE_DESCRIPTOR_PROBE_PASS'
        report['next_action']='Still require reviewed source registration, populated legacy fixture, real SDK C06/C07 and H1-H independent gates. This probe never grants TG-B/production.'
        save();return 0
    except Exception as e:
        report['status']='BLOCKED';report['error']={'type':type(e).__name__,'message':str(e)};save()
        print('BLOCKED: see local migration-report.json',file=sys.stderr);return 3
if __name__=='__main__':raise SystemExit(main())
