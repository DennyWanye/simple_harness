# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0
"""Narrow FIRST/system tail hooks for the existing Commit transactions.

The caller freezes actual routed-profile amounts, calculates the actual next
Attempt ID, and retains all existing dispatch/lease/Task acceptance gates. These
hooks perform no routing, allowance estimation, submission, acceptance or await.
They must share the caller's transaction with the corresponding real writes.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from ..contracts import TERMINAL_ATTEMPT, TERMINAL_MISSION, TERMINAL_TASK, ids
from ..governance.budgets import BudgetError
from ..governance.tail_budget import TailAllocation, TailBudgetLedger, TailReserve
from .tail_revision import task_tail_revision


class ProtectedTailCommitsMixin:
    if TYPE_CHECKING:
        from ..governance.budgets import BudgetLedger
        from ..storage.store import Store

        _store: Store
        _ledger: BudgetLedger

    @staticmethod
    def critic_tail_id(attempt_id: str) -> str:
        return "first-critic:" + attempt_id

    @staticmethod
    def _protected_critic_subject(attempt_id: str, subject_id: str, store: Any = None) -> None:
        if isinstance(subject_id, str) and (
            re.fullmatch(re.escape(attempt_id) + r":critic:[1-9][0-9]*", subject_id) is not None
            or (store is not None and _assurance_critic_attempt(store, subject_id) == attempt_id)
        ):
            return
        raise BudgetError("Critic subject must belong to its actual Attempt and positive ordinal")

    def protected_tail_revision(self, task_id: str) -> str:
        task = self._store.get_task(task_id)
        if task is None:
            raise BudgetError("protected tail Task does not exist")
        # Semantic contract/policy/domain/constraints; ordinary lease/status
        # updates do not invalidate the protected original Task budget.
        return task_tail_revision(self._store, task)

    def _protected_tail_task(self, task_id: str, semantic_revision: str):
        if not self._store.connection.in_transaction:
            raise BudgetError("protected tail hook requires its caller's Commit transaction")
        task = self._store.get_task(task_id)
        if task is None:
            raise BudgetError("protected tail Task does not exist")
        mission = self._store.get_mission(task.mission_id)
        if mission is None or mission.status in TERMINAL_MISSION or task.status in TERMINAL_TASK:
            raise BudgetError("protected tail Task or Mission is terminal")
        if self.protected_tail_revision(task_id) != semantic_revision:
            raise BudgetError("protected tail semantic revision changed")
        return task

    def _protected_attempt(self, task_id: str, attempt_id: str, *, allow_next: bool):
        attempt = self._store.get_attempt(attempt_id)
        if attempt is None:
            next_id = ids.attempt_id(task_id, len(self._store.list_attempts(task_id)) + 1)
            if not allow_next or attempt_id != next_id:
                raise BudgetError("protected tail requires the actual Attempt identity")
        elif attempt.task_id != task_id or attempt.status in TERMINAL_ATTEMPT:
            raise BudgetError("protected tail Attempt is foreign or terminal")
        return attempt

    def protected_tail_hold(self, hold_id: str) -> dict[str, Any] | None:
        row = self._store.connection.execute(
            "SELECT * FROM budget_tail_holds WHERE hold_id=?", (hold_id,)
        ).fetchone()
        return None if row is None else dict(row)

    def reserve_critic_tail(
        self,
        *,
        attempt_id: str,
        task_id: str,
        reserve: TailReserve,
        semantic_revision: str,
    ) -> dict[str, Any]:
        """Before Worker reserve, alongside its actual Attempt creation.

        ``reserve`` is the caller's actual routed Critic allowance (tokens). A
        Critic is a service, so it consumes no Attempt count.
        """
        task = self._protected_tail_task(task_id, semantic_revision)
        self._protected_attempt(task_id, attempt_id, allow_next=True)
        if reserve.attempts or reserve.tokens <= 0:
            raise BudgetError("Critic tail requires positive tokens and no Attempt allocation")
        return TailBudgetLedger(self._ledger).reserve_tail(
            self.critic_tail_id(attempt_id),
            f"budget:{task_id}",
            reserve,
            mission_id=task.mission_id,
            task_revision=semantic_revision,
            purpose="critic",
        )

    def consume_critic_tail(
        self,
        *,
        attempt_id: str,
        task_id: str,
        subject_id: str,
        account_id: str,
        reservation: Any,
        semantic_revision: str,
    ) -> dict[str, Any]:
        """After existing-intent replay check, before writing the actual Critic intent.

        Routing may select a different frozen profile for the real call. Its
        exact allowance must fit this original hold; this hook never expands it
        or rewrites prior rates. A retry uses its real new subject identity.
        """
        self._protected_tail_task(task_id, semantic_revision)
        self._protected_attempt(task_id, attempt_id, allow_next=False)
        if account_id != f"budget:{task_id}":
            raise BudgetError("Critic tail account differs from its original Task")
        self._protected_critic_subject(attempt_id, subject_id, self._store)
        hold_id = self.critic_tail_id(attempt_id)
        hold = self.protected_tail_hold(hold_id)
        if hold is None or hold["account_id"] != account_id:
            raise BudgetError("Critic has no original same-Task tail hold")
        return TailBudgetLedger(self._ledger).transfer_tail(
            hold_id,
            subject_id,
            [
                TailAllocation(
                    subject_id,
                    account_id,
                    "critic",
                    tokens=reservation.tokens,
                    tool_calls=reservation.tool_calls,
                    counts_attempt=False,
                )
            ],
            task_revision=semantic_revision,
        )

    def release_terminal_tail_holds(
        self,
        *,
        mission_id: str,
        task_id: str | None = None,
        attempt_id: str | None = None,
    ) -> list[str]:
        """Release only unused FIRST Critic holds whose actual subject stopped.

        This is safe after Mission/Task cancellation and actual Attempt terminal
        transitions. It does not settle or release any transferred reservation;
        those real subjects retain their UNKNOWN/settlement obligations.
        """
        if not self._store.connection.in_transaction:
            raise BudgetError("terminal tail release requires its Commit transaction")
        mission = self._store.get_mission(mission_id)
        if mission is None:
            raise BudgetError("terminal tail Mission does not exist")
        if task_id is not None:
            task = self._store.get_task(task_id)
            if task is None or task.mission_id != mission_id:
                raise BudgetError("terminal tail Task differs from Mission")
        if attempt_id is not None:
            attempt = self._store.get_attempt(attempt_id)
            if (
                attempt is None
                or attempt.mission_id != mission_id
                or (task_id is not None and attempt.task_id != task_id)
            ):
                raise BudgetError("terminal tail Attempt differs from Task/Mission")
        released = []
        for row in self._store.connection.execute(
            "SELECT * FROM budget_tail_holds WHERE mission_id=? AND state='HELD' ORDER BY hold_id",
            (mission_id,),
        ).fetchall():
            origin_id = row["account_id"].removeprefix("budget:")
            if task_id is not None and origin_id != task_id:
                continue
            origin = self._store.get_task(origin_id)
            if origin is None or origin.mission_id != mission_id:
                raise BudgetError("terminal tail has no original Task")
            parent = None
            if row["hold_id"].startswith("first-critic:") and row["purpose"] == "critic":
                parent_id = row["hold_id"].removeprefix("first-critic:")
                parent = self._store.get_attempt(parent_id)
                if parent is None or parent.task_id != origin_id:
                    raise BudgetError("terminal Critic tail has no actual parent Attempt")
                if attempt_id is not None and parent.id != attempt_id:
                    continue
            else:
                continue  # not a FIRST Critic hold
            stopped = (
                mission.status in TERMINAL_MISSION
                or origin.status in TERMINAL_TASK
                or (parent is not None and parent.status in TERMINAL_ATTEMPT)
            )
            if not stopped:
                continue
            # A hold must never be a real usage subject. Preserve even malformed
            # data for diagnosis rather than writing a fabricated zero settlement.
            has_fact = self._store.connection.execute(
                "SELECT 1 FROM imported_usage WHERE subject_id=? LIMIT 1",
                (row["subject_id"],),
            ).fetchone()
            has_grant = self._store.connection.execute(
                "SELECT 1 FROM provider_token_grants WHERE subject_id=? LIMIT 1",
                (row["subject_id"],),
            ).fetchone()
            if has_fact is not None or has_grant is not None:
                raise BudgetError("terminal tail contains actual usage; cannot release as unused")
            TailBudgetLedger(self._ledger).release_tail(
                row["hold_id"],
                task_revision=row["task_revision"],
                reason="protected_subject_terminal",
            )
            released.append(row["hold_id"])
        return released


__all__ = ("ProtectedTailCommitsMixin",)


_ASSURANCE_CRITIC_SUBJECT = re.compile(
    r"(?P<mission>[^:]+):assurance:(?P<key>assurance-content:[0-9a-f]{64}):[12]"
)


def _assurance_critic_attempt(store: Any, subject_id: str) -> str | None:
    """The Attempt an Assurance TASK_CONTENT review intent actually belongs to.

    The Assurance transport names its Critic intent ``<mission>:assurance:<review
    key>:<ordinal>`` (no Attempt in the name). Ownership is proven from the durable
    review binding written earlier in the same transaction: its TASK_CONTENT
    subject is an exact Result, and that Result's Attempt is the owner. Host real
    model run 12 (2026-09-23): without this the protected first-Critic tail refused
    every assured review and the loop re-raised forever.
    """
    import json

    match = _ASSURANCE_CRITIC_SUBJECT.fullmatch(subject_id)
    if match is None:
        return None
    connection = store.connection
    if connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='assurance_review_bindings'"
    ).fetchone() is None:
        return None
    row = connection.execute(
        "SELECT binding_json FROM assurance_review_bindings WHERE review_key=? AND mission_id=?",
        (match["key"], match["mission"]),
    ).fetchone()
    if row is None:
        return None
    subject = json.loads(row[0]).get("subject") or {}
    if subject.get("purpose") != "TASK_CONTENT":
        return None
    result = store.get_result(((subject.get("target") or {}).get("pin") or {}).get("id"))
    if result is None or result.envelope.mission_id != match["mission"]:
        return None
    return result.envelope.attempt_id
