"""Pure reference fragments, not SDK producers or evidence validators."""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass
from typing import Callable, Mapping

@dataclass(frozen=True)
class HashDomains:
    candidate_file_hash: str
    parameters_content_hash: str
    params_hash: str

def hash_domains(candidate_bytes: bytes, parameters_bytes: bytes,
                 effective_params: Mapping[str, object],
                 legacy_params_hasher: Callable[[Mapping[str, object]], str]) -> HashDomains:
    """Production must inject existing connectors.params_hash, never this file's own clone."""
    return HashDomains(hashlib.sha256(candidate_bytes).hexdigest(),
                       hashlib.sha256(parameters_bytes).hexdigest(),
                       legacy_params_hasher(effective_params))

def strict_json(raw: bytes) -> object:
    if len(raw) > 262144:
        raise ValueError('OP_PAYLOAD_TOO_LARGE')
    def pairs(items):
        d = {}
        for k,v in items:
            if k in d:
                raise ValueError('DUPLICATE_KEY')
            d[k]=v
        return d
    def bad_constant(value):
        raise ValueError('NONFINITE_JSON')
    out=json.loads(raw.decode('utf-8'),object_pairs_hook=pairs,parse_constant=bad_constant)
    def walk(x, depth=0):
        if depth>16: raise ValueError('JSON_TOO_DEEP')
        if isinstance(x,dict):
            for v in x.values(): walk(v,depth+1)
        elif isinstance(x,list):
            for v in x: walk(v,depth+1)
    walk(out)
    return out

TRANSITIONS = {
    'WAITING': {'READY','PAUSED','MANUAL_REQUIRED','STALE_FENCED'},
    'READY': {'WAITING','APPLIED','PAUSED','MANUAL_REQUIRED','STALE_FENCED'},
    'PAUSED': {'WAITING','READY','MANUAL_REQUIRED','STALE_FENCED','CLOSED'},
    'MANUAL_REQUIRED': {'STALE_FENCED','CLOSED'},
    'STALE_FENCED': {'CLOSED'},
    'APPLIED': set(), 'CLOSED': set(),
}

def check_transition(old: str, new: str) -> None:
    if old not in TRANSITIONS or new not in TRANSITIONS[old]:
        raise ValueError('CONTINUATION_TRANSITION_INVALID')

def stop_gate_is_active(state: str) -> bool:
    if state not in TRANSITIONS: raise ValueError('CONTINUATION_STATE_UNKNOWN')
    return state not in {'APPLIED','CLOSED'}

def covers_current_handoffs(current: tuple[str,...], proved: tuple[str,...]) -> bool:
    """Coverage ONLY. True is not proof of nonapplication or retry permission."""
    if not current or len(set(current))!=len(current) or len(set(proved))!=len(proved):
        return False
    return set(current)==set(proved)
