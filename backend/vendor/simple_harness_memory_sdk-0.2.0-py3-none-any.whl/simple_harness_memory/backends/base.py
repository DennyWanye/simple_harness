"""BaseMemoryBackend — 后端共享逻辑。"""
from __future__ import annotations

import json
import time
from abc import abstractmethod
from contextlib import asynccontextmanager
from typing import Optional

import structlog

from simple_harness_memory.cognitive.decay import bump_salience, decay_salience, should_forget
from simple_harness_memory.cognitive.twin_builder import build_twin_from_facts, detect_fact_conflicts
from simple_harness_memory.core.errors import MemoryLimitError
from simple_harness_memory.core.models import SINGLE_VALUED_KEYS, Fact, FactConflict, Hit, Message
from simple_harness_memory.core.port import MemoryBackend
from simple_harness_memory.core.twin import DigitalTwin
from simple_harness_memory.embedders.base import EMBEDDING_FORMAT_VERSION, Embedder, encode_vector
from simple_harness_memory.embedders.mock import HashEmbedder
from simple_harness_memory.features.facts import FactExtractor, RuleBasedFactExtractor
from simple_harness_memory.features.reranker import IdentityReranker, Reranker
from simple_harness_memory.features.retriever import Retriever
from simple_harness_memory.features.summarizer import RuleBasedSummarizer, Summarizer


logger = structlog.get_logger("simple_harness_memory.backends.base")


class BaseMemoryBackend(MemoryBackend):
    def __init__(self, *, embedder=None, fact_extractor=None, reranker=None, summarizer=None, auto_extract_facts=False, max_content_chars=100_000, max_fact_value_chars=10_000, max_payload_bytes=1_000_000, max_db_bytes=None):
        self._embedder = embedder or HashEmbedder()
        self._fact_extractor = fact_extractor or RuleBasedFactExtractor()
        self._reranker = reranker or IdentityReranker()
        self._summarizer = summarizer or RuleBasedSummarizer()
        self._retriever = Retriever(self._embedder, self._reranker)
        self._auto_extract_facts = auto_extract_facts
        self._max_content_chars = max_content_chars
        self._max_fact_value_chars = max_fact_value_chars
        self._max_payload_bytes = max_payload_bytes
        self._max_db_bytes = max_db_bytes

    async def _commit(self) -> None:
        """Commit pending writes (no-op for in-memory backends)."""
        return None

    @asynccontextmanager
    async def _transaction(self):
        """Transaction context (no-op for in-memory backends)."""
        yield

    def _check_content(self, content: str) -> None:
        if len(content) > self._max_content_chars:
            raise MemoryLimitError(
                f"content length {len(content)} exceeds max_content_chars={self._max_content_chars}"
            )

    async def _check_db_size(self) -> None:
        return None

    @abstractmethod
    async def _append_message_impl(self, session_id, role, content, embedding, salience, decay_rate, created_at, is_summary, summary_of, source_event_id, embedder_kind, embedding_dim, embedding_format_version) -> int: ...

    @abstractmethod
    async def _get_message_impl(self, message_id) -> Optional[Message]: ...

    @abstractmethod
    async def _get_recent_messages_impl(self, session_id, limit) -> list[Message]: ...

    @abstractmethod
    async def _messages_all(self) -> list[Message]: ...

    @abstractmethod
    async def _facts_all(self) -> list[Fact]: ...

    @abstractmethod
    async def _insert_fact(self, fact) -> int: ...

    @abstractmethod
    async def _supersede_fact(self, fact_id, superseded_by) -> None: ...

    @abstractmethod
    async def _forget_fact_by_id(self, fact_id, forgotten_at) -> bool: ...

    @abstractmethod
    async def _update_message_salience(self, message_id, salience, last_recalled) -> None: ...

    @abstractmethod
    async def _set_fact_decay(self, fact_id, *, forgotten_at=None, last_decay_at=None) -> None: ...

    @abstractmethod
    async def _load_twin(self, subject) -> DigitalTwin: ...

    @abstractmethod
    async def _save_twin(self, twin) -> None: ...

    @abstractmethod
    async def _record_workspace_impl(self, session_id, action_type, payload) -> None: ...

    @abstractmethod
    async def _delete_messages_by_ids_impl(self, ids) -> None: ...

    @abstractmethod
    async def _delete_facts_by_ids_impl(self, ids) -> None: ...

    @abstractmethod
    async def _delete_workspace_by_session_impl(self, session_id) -> None: ...

    @abstractmethod
    async def _clear_all_impl(self) -> None: ...

    @abstractmethod
    async def _clear_dangling_supersede_impl(self, deleted_fact_ids) -> None: ...

    @abstractmethod
    async def _update_embedding_impl(self, message_id, embedding, embedder_kind, embedding_dim, embedding_format_version) -> None: ...

    async def append_message(self, session_id, role, content, *, salience=0.0, decay_rate=0.02, source_event_id=None):
        try:
            self._check_content(content)
            await self._check_db_size()
            now = time.time()
            embedding = encode_vector(await self._embedder.embed(content))
            async with self._transaction():
                msg_id = await self._append_message_impl(
                    session_id, role, content, embedding, salience, decay_rate, now, False, None, source_event_id,
                    self._embedder.kind, self._embedder.dim, EMBEDDING_FORMAT_VERSION,
                )
                if self._auto_extract_facts and role == "user":
                    await self.extract_facts(msg_id, content, role)
            logger.info(
                "memory.append_message",
                session_id=session_id,
                role=role,
                content_len=len(content),
                message_id=msg_id,
                auto_extract_facts=self._auto_extract_facts,
            )
            return msg_id
        except Exception:
            logger.exception(
                "memory.append_message_failed",
                session_id=session_id,
                role=role,
                content_len=len(content),
            )
            raise

    async def get_recent_messages(self, session_id, limit=20):
        return await self._get_recent_messages_impl(session_id, limit)

    async def get_message(self, message_id):
        return await self._get_message_impl(message_id)

    async def extract_facts(self, message_id, content, role):
        try:
            await self._check_db_size()
            facts = await self._fact_extractor.extract(
                content, role=role, message_id=message_id, created_at=time.time()
            )
            stored = []
            for fact in facts:
                fact.source_msg_id = message_id
                if len(fact.value) > self._max_fact_value_chars or len(fact.evidence) > self._max_fact_value_chars:
                    raise MemoryLimitError(
                        f"fact value/evidence exceeds max_fact_value_chars={self._max_fact_value_chars}"
                    )
                new_id = await self._insert_fact(fact)
                fact.id = new_id
                stored.append(fact)
                if fact.key in SINGLE_VALUED_KEYS:
                    for old in await self._facts_all():
                        if (
                            old.subject == fact.subject
                            and old.key == fact.key
                            and old.is_active
                            and old.id != new_id
                        ):
                            await self._supersede_fact(old.id, new_id)
                            logger.info(
                                "memory.fact_superseded",
                                subject=fact.subject,
                                old_id=old.id,
                                new_id=new_id,
                            )
            logger.info(
                "memory.extract_facts",
                message_id=message_id,
                role=role,
                fact_count=len(stored),
            )
            await self._commit()
            return stored
        except Exception:
            logger.exception("memory.extract_facts_failed", message_id=message_id, role=role)
            raise

    async def get_facts(self, subject="user", category=None, active_only=True):
        facts = [f for f in await self._facts_all() if f.subject == subject]
        if category:
            facts = [f for f in facts if f.category == category]
        if active_only:
            facts = [f for f in facts if f.is_active]
        return facts

    async def forget_fact(self, fact_id, reason=""):
        result = await self._forget_fact_by_id(fact_id, time.time())
        await self._commit()
        return result

    async def get_digital_twin(self, subject="user"):
        base = await self._load_twin(subject)
        facts = await self._facts_all()
        twin = build_twin_from_facts(facts, base, subject)
        logger.debug(
            "memory.digital_twin_built",
            subject=subject,
            fact_count=len(facts),
            entity_count=len(getattr(getattr(twin, "relationships", None), "entities", {})),
        )
        return twin

    async def update_digital_twin(self, twin):
        await self._check_db_size()
        twin.last_updated = time.time()
        twin.recalculate_completeness()
        await self._save_twin(twin)
        await self._commit()

    async def suggest_questions(self, subject="user"):
        twin = await self.get_digital_twin(subject)
        q_map = {"name": "你叫什么名字？", "occupation": "你是做什么工作的？", "location": "你在哪个城市？", "language": "你常用的语言是什么？"}
        return [q_map[f] for f in twin.missing_profile_fields() if f in q_map]

    async def detect_inconsistencies(self, subject="user"):
        facts = await self._facts_all()
        return detect_fact_conflicts([f for f in facts if f.subject == subject])

    async def recall(self, query, session_id=None, limit=10):
        try:
            messages = await self._messages_all()
            facts = await self._facts_all()
            twin = await self.get_digital_twin("user")
            hits = await self._retriever.recall(
                query, messages=messages, facts=facts, twin=twin, session_id=session_id, limit=limit
            )
            logger.info(
                "memory.recall",
                query_len=len(query),
                session_id=session_id,
                limit=limit,
                hit_count=len(hits),
                message_count=len(messages),
                fact_count=len(facts),
            )
            return hits
        except Exception:
            logger.exception("memory.recall_failed", query_len=len(query), session_id=session_id, limit=limit)
            raise

    async def recall_and_reinforce(self, query, session_id=None, limit=10):
        hits = await self.recall(query, session_id=session_id, limit=limit)
        now = time.time()
        for hit in hits:
            bumped = bump_salience(hit.salience)
            await self._update_message_salience(hit.message_id, bumped, now)
            hit.salience = bumped
        await self._commit()
        return hits

    async def vector_search(self, query, limit=20):
        messages = await self._messages_all()
        return await self._retriever.vector_search(query, messages=messages, limit=limit)

    async def daily_decay(self):
        try:
            now = time.time()
            decayed = 0
            forgotten = 0
            for m in await self._messages_all():
                ref = m.last_recalled or m.created_at
                days = (now - ref) / 86400.0
                new_salience = decay_salience(m.salience, m.decay_rate, days)
                if abs(new_salience - m.salience) > 1e-9:
                    await self._update_message_salience(m.id, new_salience, None)
                    decayed += 1
            for f in await self._facts_all():
                if not f.is_active or f.pinned:
                    continue
                ref = f.last_decay_at or f.created_at
                days = (now - ref) / 86400.0
                if should_forget(f.decay_rate, days):
                    await self._set_fact_decay(f.id, forgotten_at=now)
                    forgotten += 1
                else:
                    await self._set_fact_decay(f.id, last_decay_at=now)
                    decayed += 1
            logger.info("memory.daily_decay", decayed=decayed, forgotten=forgotten)
            await self._commit()
            return {"decayed": decayed, "forgotten": forgotten}
        except Exception:
            logger.exception("memory.daily_decay_failed")
            raise

    async def summarize_old_sessions(self, older_than_days=7, max_sessions=5):
        try:
            now = time.time()
            cutoff = now - older_than_days * 86400.0
            by_session: dict[str, list[Message]] = {}
            for m in await self._messages_all():
                if m.is_summary or m.created_at >= cutoff:
                    continue
                by_session.setdefault(m.session_id, []).append(m)
            ordered = sorted(by_session, key=lambda s: min(m.created_at for m in by_session[s]))
            count = 0
            for session_id in ordered[:max_sessions]:
                msgs = sorted(by_session[session_id], key=lambda m: m.created_at)
                summary = await self._summarizer.summarize(msgs)
                if not summary:
                    continue
                await self._append_message_impl(
                    session_id, "system", summary, None, 0.0, 0.02, now, True,
                    json.dumps([m.id for m in msgs]), None, None, None, None,
                )
                count += 1
            logger.info(
                "memory.summarize_sessions",
                candidate_sessions=len(ordered),
                summarized_sessions=count,
            )
            await self._commit()
            return {"summarized_sessions": count}
        except Exception:
            logger.exception("memory.summarize_sessions_failed")
            raise

    async def record_workspace_action(self, session_id, action_type, payload):
        await self._check_db_size()
        if len(json.dumps(payload, ensure_ascii=False)) > self._max_payload_bytes:
            raise MemoryLimitError(f"payload exceeds max_payload_bytes={self._max_payload_bytes}")
        await self._record_workspace_impl(session_id, action_type, payload)
        await self._commit()

    async def delete_session(self, session_id: str) -> int:
        messages = [m for m in await self._messages_all() if m.session_id == session_id]
        message_ids = [m.id for m in messages if m.id is not None]
        facts = [f for f in await self._facts_all() if f.source_msg_id in message_ids]
        fact_ids = [f.id for f in facts if f.id is not None]
        # 先 re-point dangling supersede（后继 fact 仍在表里），再物理删除
        await self._clear_dangling_supersede_impl(fact_ids)
        await self._delete_messages_by_ids_impl(message_ids)
        await self._delete_facts_by_ids_impl(fact_ids)
        await self._delete_workspace_by_session_impl(session_id)
        await self._commit()
        await self._rebuild_twin()
        return len(message_ids)

    async def delete_all(self) -> None:
        await self._clear_all_impl()
        await self._commit()

    async def delete_old_sessions(self, older_than_days: float = 30.0) -> int:
        cutoff = time.time() - older_than_days * 86400.0
        latest: dict[str, float] = {}
        for m in await self._messages_all():
            if m.created_at > latest.get(m.session_id, 0.0):
                latest[m.session_id] = m.created_at
        deleted = 0
        for session_id, last in latest.items():
            if last < cutoff:
                deleted += await self.delete_session(session_id)
        return deleted

    async def _rebuild_twin(self, subject: str = "user") -> None:
        active_facts = [f for f in await self._facts_all() if f.is_active]
        twin = build_twin_from_facts(active_facts, base=None, subject=subject)
        await self._save_twin(twin)
        await self._commit()

    async def reindex(self, embedder=None) -> int:
        new_embedder = embedder or self._embedder
        messages = await self._messages_all()
        texts = [m.content for m in messages]
        for i in range(0, len(messages), 100):
            chunk = messages[i:i + 100]
            vectors = await new_embedder.embed_batch(texts[i:i + 100])
            for m, vec in zip(chunk, vectors):
                await self._update_embedding_impl(
                    m.id, encode_vector(vec), new_embedder.kind, new_embedder.dim, EMBEDDING_FORMAT_VERSION
                )
        await self._commit()
        self._embedder = new_embedder
        self._retriever = Retriever(new_embedder, self._reranker)
        return len(messages)
