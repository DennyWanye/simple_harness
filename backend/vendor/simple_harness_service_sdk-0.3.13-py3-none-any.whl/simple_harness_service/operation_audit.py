"""Safe Service request observations; never a business execution ledger."""

from __future__ import annotations

import math
import queue
import re
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Protocol, cast

from simple_harness import CommandErrorCode

from .contracts import CommandKind, CommandState, ServiceErrorCode
from .tool_operation_audit import RealtimeToolOperationObservation


class ServiceOperation(StrEnum):
    START = "start"
    CONTINUE = "continue"
    GET = "get"
    CANCEL = "cancel"


class ServiceOperationPhase(StrEnum):
    STARTED = "started"
    DISPATCHED = "dispatched"
    RETURNED = "returned"
    REJECTED = "rejected"
    UNKNOWN = "unknown"


class ServiceAdmissionObservation(StrEnum):
    NOT_DISPATCHED = "not_dispatched"
    UNKNOWN = "unknown"
    RECEIPT_OBSERVED = "receipt_observed"


class ServiceObservationCode(StrEnum):
    COMMAND_ERROR = "command_error"
    SERVICE_ERROR = "service_error"
    INVALID_REQUEST = "invalid_request"
    UNEXPECTED_ERROR = "unexpected_error"
    CANCELLED = "cancelled"
    RECEIPT_LINKAGE_UNAVAILABLE = "receipt_linkage_unavailable"


def _ref(value: str | None, kind: str, *, optional: bool = False) -> None:
    if value is None and optional:
        return
    if not isinstance(value, str) or re.fullmatch(rf"svc_{kind}_[0-9a-f]{{64}}", value) is None:
        raise ValueError("invalid projected audit reference")


def _integer(value: int) -> None:
    if type(value) is not int or value < 0:
        raise ValueError("invalid audit integer")


@dataclass(frozen=True, slots=True)
class ServiceCommandReceiptRef:
    command_id: str
    run_id: str
    accept_seq: int
    version: int
    kind: CommandKind
    state: CommandState

    def __post_init__(self) -> None:
        _ref(self.command_id, "command")
        _ref(self.run_id, "run")
        _integer(self.accept_seq)
        _integer(self.version)
        object.__setattr__(self, "kind", CommandKind(self.kind))
        object.__setattr__(self, "state", CommandState(self.state))


@dataclass(frozen=True, slots=True)
class ServiceOperationObservation:
    attempt_id: str
    owner_ref: str
    command_ref: str | None
    run_ref: str | None
    operation: ServiceOperation
    phase: ServiceOperationPhase
    admission: ServiceAdmissionObservation
    elapsed_ms: int
    receipt: ServiceCommandReceiptRef | None = None
    code: ServiceObservationCode | None = None
    schema_version: int = 1
    command_error_code: CommandErrorCode | None = None
    service_error_code: ServiceErrorCode | None = None

    def __post_init__(self) -> None:
        if re.fullmatch(r"svc_attempt_[0-9a-f]{32}", self.attempt_id) is None:
            raise ValueError("invalid audit attempt")
        _ref(self.owner_ref, "audit-owner")
        _ref(self.command_ref, "command", optional=True)
        _ref(self.run_ref, "run", optional=True)
        _integer(self.elapsed_ms)
        if type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError("invalid audit schema")
        object.__setattr__(self, "operation", ServiceOperation(self.operation))
        object.__setattr__(self, "phase", ServiceOperationPhase(self.phase))
        object.__setattr__(self, "admission", ServiceAdmissionObservation(self.admission))
        if self.code is not None:
            object.__setattr__(self, "code", ServiceObservationCode(self.code))
        if self.command_error_code is not None:
            object.__setattr__(
                self, "command_error_code", CommandErrorCode(self.command_error_code)
            )
        if self.service_error_code is not None:
            object.__setattr__(
                self, "service_error_code", ServiceErrorCode(self.service_error_code)
            )
        if self.receipt is not None:
            if (
                type(self.receipt) is not ServiceCommandReceiptRef
                or self.receipt.command_id != self.command_ref
                or self.receipt.run_id != self.run_ref
                or self.admission is not ServiceAdmissionObservation.RECEIPT_OBSERVED
            ):
                raise ValueError("invalid receipt observation linkage")
        elif self.admission is ServiceAdmissionObservation.RECEIPT_OBSERVED:
            raise ValueError("receipt observation requires actual receipt")

    def to_json(self) -> dict[str, object]:
        return asdict(self)


class ServiceOperationSink(Protocol):
    """Metadata consumer; delivered on a bounded queue, never executes commands."""

    def emit(
        self, observation: ServiceOperationObservation | RealtimeToolOperationObservation
    ) -> None: ...


@dataclass(frozen=True, slots=True)
class ServiceOperationSnapshot:
    observations: tuple[ServiceOperationObservation | RealtimeToolOperationObservation, ...]
    emitted_count: int
    dropped_count: int
    sink_failure_count: int
    sink_drop_count: int
    pending_count: int
    worker_count: int
    durable: bool = False
    coverage_gaps: tuple[str, ...] = (
        "process_lifetime_only",
        "pre_service_transport_unobserved",
        "client_ack_unobserved",
        "business_execution_owned_by_harness",
    )

    def to_json(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RealtimeToolOperationSnapshot(ServiceOperationSnapshot):
    producer_failure_count: int = 0
    sink_configured: bool = False


_STOP = object()


class ServiceOperationRecorder:
    """Bounded trusted-host metadata recorder. Snapshot is not a remote user API."""

    _observation_type: type[ServiceOperationObservation] | type[RealtimeToolOperationObservation] = (
        ServiceOperationObservation
    )

    def __init__(
        self,
        sink: ServiceOperationSink | None = None,
        *,
        max_events: int = 256,
        max_pending_events: int = 256,
    ) -> None:
        for value in (max_events, max_pending_events):
            if type(value) is not int or not 1 <= value <= 4096:
                raise ValueError("recorder bounds must be in 1..4096")
        self._sink = sink
        self._events: deque[ServiceOperationObservation | RealtimeToolOperationObservation] = deque(maxlen=max_events)
        self._emitted = self._failures = self._sink_drops = 0
        self._pending = self._queued = 0
        self._capacity = max_pending_events
        self._closed = False
        self._changed = threading.Condition()
        # One reserved sentinel slot makes close non-blocking even at capacity.
        self._queue: queue.Queue[object] = queue.Queue(maxsize=max_pending_events + 1)
        self._thread: threading.Thread | None = None
        if sink is not None:
            self._thread = threading.Thread(
                target=self._drain, name="simple-harness-service-observations", daemon=True
            )
            self._thread.start()

    def emit(self, observation: ServiceOperationObservation | RealtimeToolOperationObservation) -> None:
        if type(observation) is not self._observation_type:
            raise TypeError("canonical observation required")
        with self._changed:
            self._events.append(observation)
            self._emitted += 1
            if self._sink is not None:
                if self._closed or self._queued >= self._capacity:
                    self._sink_drops += 1
                else:
                    self._queue.put_nowait(observation)
                    self._queued += 1
                    self._pending += 1

    def snapshot(self) -> ServiceOperationSnapshot:
        with self._changed:
            return ServiceOperationSnapshot(
                tuple(self._events),
                self._emitted,
                self._emitted - len(self._events),
                self._failures,
                self._sink_drops,
                self._pending,
                int(self._thread is not None and self._thread.is_alive()),
            )

    def flush(self, timeout_seconds: float = 0.0) -> bool:
        deadline = self._deadline(timeout_seconds)
        with self._changed:
            while self._pending:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._changed.wait(remaining)
            return True

    def close(self, timeout_seconds: float = 0.0) -> bool:
        deadline = self._deadline(timeout_seconds)
        with self._changed:
            if not self._closed:
                self._closed = True
                if self._thread is not None:
                    self._queue.put_nowait(_STOP)
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(max(0.0, deadline - time.monotonic()))
        return self._thread is None or not self._thread.is_alive()

    @staticmethod
    def _deadline(timeout: float) -> float:
        if (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout)
            or timeout < 0
        ):
            raise ValueError("timeout must be finite and non-negative")
        return time.monotonic() + timeout

    def _drain(self) -> None:
        assert self._sink is not None
        for value in iter(self._queue.get, _STOP):
            with self._changed:
                self._queued -= 1
            try:
                self._sink.emit(cast(ServiceOperationObservation | RealtimeToolOperationObservation, value))
            except Exception:
                with self._changed:
                    self._failures += 1
            finally:
                with self._changed:
                    self._pending -= 1
                    self._changed.notify_all()
                self._queue.task_done()
        self._queue.task_done()


class RealtimeToolOperationRecorder(ServiceOperationRecorder):
    """Same bounded sink delivery, separate tool family; no durable ACK is inferred."""

    _observation_type = RealtimeToolOperationObservation

    def __init__(self, sink: ServiceOperationSink | None = None, *,
                 max_events: int = 256, max_pending_events: int = 256) -> None:
        super().__init__(sink, max_events=max_events, max_pending_events=max_pending_events)
        self._producer_failures = 0

    def producer_failed(self) -> None:
        with self._changed:
            self._producer_failures += 1

    def snapshot(self) -> RealtimeToolOperationSnapshot:
        with self._changed:
            gaps = ["process_lifetime_only", "realtime_no_verified_harness_binding",
                    "tool_execution_owned_by_caller", "followup_linkage_session_order",
                    "durable_sink_unavailable" if self._sink is None else "sink_persistence_unverified"]
            if self._producer_failures:
                gaps.append("producer_observation_failed")
            if self._emitted > len(self._events) or self._sink_drops or self._failures:
                gaps.append("observation_loss")
            return RealtimeToolOperationSnapshot(
                observations=tuple(self._events), emitted_count=self._emitted,
                dropped_count=self._emitted - len(self._events),
                sink_failure_count=self._failures, sink_drop_count=self._sink_drops,
                pending_count=self._pending,
                worker_count=int(self._thread is not None and self._thread.is_alive()),
                producer_failure_count=self._producer_failures,
                sink_configured=self._sink is not None, coverage_gaps=tuple(gaps),
            )
