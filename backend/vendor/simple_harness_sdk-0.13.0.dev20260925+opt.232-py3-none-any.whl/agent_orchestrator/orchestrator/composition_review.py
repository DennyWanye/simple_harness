# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""P2.3l / N7: a non-root compound in ``composition_review`` forms a GoalResolution.

A compound whose gating children are accepted parks in ``composition_review``.  The
root has a ``MISSION_FINAL`` coordinator; an inner compound had none, so ORDER
successors (M3's ``revert``) stayed ``WAITING_ORDER`` forever.

This assembly is the missing trigger.  It does **not** ask a model and it does
**not** invent PASS (AER I05):

* the package is a ``ReviewPurpose.COMPOSITION`` anchor over the children's
  CURRENT Acceptances;
* the record transcribes each parent criterion from the linked child's official
  review — missing or non-PASS becomes ``UNKNOWN``;
* ``composition_obligation_passed`` is the record's own verdict;
* ``commit_goal_resolution`` (``is_mission_root=False``) is the only writer.

Why not reuse the root-reviewer service intent: §6.3 / ``leaf_acceptance`` already
say a compound is satisfied out of its children's acceptances, never by a review
of its own.  Those children already had independent TASK_CONTENT reviews.  A
second model call would charge a review against a 0-token compound budget, and M3's assess compound has no root requirements to judge.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from ..assurance.codec import AssuranceError
from ..contracts.evidence_state import (
    Validity,
)
from ..contracts.htn import (
    MethodInstanceId,
    OccurrenceId,
    ReadItem,
    ReadItemKind,
    ScopeEpochRead,
    SemanticReadSet,
    TaskForm,
)
from ..contracts.models import ContractError
from ..contracts.resolution import (
    Criterion,
    CriterionVerdict,
    GoalResolution,
    GoalResolutionId,
    RequirementsRevision,
    ResolutionCriterion,
    ReviewBinding,
    ReviewPackage,
    ReviewPackageId,
    ReviewPurpose,
    ReviewVerdict,
    WorkspaceAccess,
)
from ..contracts.semantic_base import (
    TypedRef,
    TypedRefKind,
    content_hash_of,
)
from ..graph.task_network import GATING_REQUIREDNESS
from ..storage.assurance_store import AssuranceStore
from ..storage.htn_store import HtnStore
from ..storage.store import StoreError
from ..verification.acceptance_rules import CompoundFacts, ExecutionPosture, IndependenceFacts
from .assurance_purpose_reviews import assurance_review_runtime
from .completion_support import current_child_supports, read_completion_support
from .hierarchical_dispatch import CompoundPhase, HierarchicalDispatch, next_compound_phase
from .resolution_commits import (
    CommitGoalResolutionCommand,
    GoalResolutionReceipt,
    ResolutionCommitRejected,
    ResolutionPrincipal,
)
from .review_adjudication import adjudication_of
from .scoped_composition_review import read_compound_projection

COMPOSITION_REVIEW_POLICY = "hierarchical-composition-review-v1"
COMPOSITION_REVIEWER = "composition-reviewer"
COMPOSITION_UNCOVERED = "composition_criterion_uncovered"
REVIEWER_ACCESS = WorkspaceAccess.READ_ONLY


def assured_composition_action(record: Any, ruling: Mapping[str, Any] | None) -> str:
    """What an official COMPOSITION record calls for: resolve / ask / repair.

    ACCEPT resolves; INCONCLUSIVE with no ruling asks the person; a ruling of
    "pass" resolves, of "fail" repairs; REWORK / REJECTED repair.
    """
    if record.verdict is ReviewVerdict.ACCEPT:
        return "resolve"
    if record.verdict is ReviewVerdict.INCONCLUSIVE:
        if ruling is None:
            return "ask"
        return "resolve" if ruling.get("decision") == "pass" else "repair"
    return "repair"


@dataclass(frozen=True, slots=True)
class CompositionAcceptanceAssembly:
    """Form a non-root ``GoalResolution`` from children's CURRENT Acceptances."""

    store: Any
    commit: Any
    dispatch: HierarchicalDispatch
    scope_id: str = "mission"
    issued_by: str = "orchestrator"
    #: 保证通道下正式组合审阅记录的两个出口，由编排循环提供——
    #: 复审后仍判不下来 → ``ask_person(record, task_id, occurrence_id)``；
    #: 打回 / 拒绝（或人裁决打回）→ ``on_rejected(record, package, task_id, occurrence_id)``。
    ask_person: Any = None
    on_rejected: Any = None
    #: 片 B：某个中间目标这一轮出不了结论、且原因是报错（审阅开不起来、提交被拒）时，
    #: ``on_deferred(occurrence, task_id, goal_type, error)``——如实记下来，不再静默吞掉。
    on_deferred: Any = None

    @property
    def semantics(self) -> HtnStore:
        return HtnStore(self.store)

    def resolve_ready(self, mission_id: str) -> tuple[GoalResolutionReceipt, ...]:
        """Resolve every non-root compound that is waiting on composition review.

        Idempotent: an occurrence that already has an adopted GoalResolution is
        skipped.  A refusal is noted by raising into the caller; this method
        swallows ``ResolutionCommitRejected`` so one stuck compound does not
        block its siblings.
        """

        view = self.dispatch.read(mission_id)
        formed: list[GoalResolutionReceipt] = []
        for spec in view.network.occurrences:
            if spec.form is not TaskForm.COMPOUND:
                continue
            if spec.occurrence_id in view.network.root_occurrence_ids:
                continue
            if spec.occurrence_id in view.resolved:
                continue
            children = {
                binding.occurrence_id: view.outcomes[binding.occurrence_id]
                for binding in view.network.adopted_children(spec.occurrence_id)
                if binding.occurrence_id in view.outcomes
            }
            phase = next_compound_phase(
                spec,
                view.network,
                view.reports[spec.occurrence_id],
                child_outcomes=children,
                resolved=False,
            )
            if phase is not CompoundPhase.COMPOSITION_REVIEW:
                continue
            try:
                receipt = self.resolve_one(mission_id, spec.occurrence_id)
            except (ContractError, ResolutionCommitRejected, StoreError) as error:
                # One stuck compound does not block its siblings — but it is said, not hidden.
                if self.on_deferred is not None:
                    binding = view.network.binding_for_occurrence(spec.occurrence_id)
                    self.on_deferred(
                        str(spec.occurrence_id),
                        str(spec.task_id),
                        str(binding.goal_signature.signature_id),
                        error,
                    )
                continue
            if receipt is not None:
                formed.append(receipt)
        if formed:
            self.dispatch.advance_compound_phases(mission_id)
        return tuple(formed)

    def resolve_one(
        self, mission_id: str, occurrence_id: OccurrenceId
    ) -> GoalResolutionReceipt | None:
        """Build the COMPOSITION anchors and commit, or return None if not ready."""

        view = self.dispatch.read(mission_id)
        spec = view.network.occurrence(occurrence_id)
        adopted = view.network.adopted_instance_for(occurrence_id)
        if adopted is None:
            return None
        instance_id = str(adopted.instance_id)
        gating = [
            binding
            for binding in view.network.adopted_children(occurrence_id)
            if binding.requiredness in GATING_REQUIREDNESS
        ]
        accepted = self._accepted_children(mission_id, view.network.adopted_children(occurrence_id))
        if any(str(binding.occurrence_id) not in accepted for binding in gating):
            return None
        binding = view.network.binding_for_occurrence(occurrence_id)
        now_ms = int(self.store.now * 1000)
        producers = self._producers(mission_id, accepted)
        # The goal's criteria and success expression are its frozen completion scope's.

        projection = read_compound_projection(
            self.store, mission_id, str(occurrence_id), str(spec.task_id)
        )
        revision = projection.requirements
        manifest = self._manifest_hash(mission_id, str(spec.task_id))

        AssuranceStore(self.store).require_assured(mission_id)
        package = self._package(
            mission_id,
            spec,
            binding,
            revision,
            accepted,
            producers,
            manifest_hash=manifest,
            method_instance_id=instance_id,
            criteria=projection.criteria,
            expression=projection.expression,
        )
        # BW03: the composition is judged by an independent review on the round
        # transport; the official COMPOSITION record is consumed below.

        mission = self.store.get_mission(mission_id)
        try:
            assurance_review_runtime(self.commit).ensure_composition(
                mission, package=package, occurrence_id=str(occurrence_id), accepted=accepted
            )
        except AssuranceError as error:
            raise ContractError(f"Assurance COMPOSITION review unavailable: {error}") from error
        # 消费正式记录：不读它的话，中间目标永远收不了尾。

        record = self.semantics.official_review_record(str(package.package_id))
        if record is None:
            return None
        ruling = (
            adjudication_of(self.store, str(record.record_id))
            if record.verdict is ReviewVerdict.INCONCLUSIVE
            else None
        )
        action = assured_composition_action(record, ruling)
        if action == "ask":
            if self.ask_person is not None:
                self.ask_person(record, str(spec.task_id), str(occurrence_id))
            return None
        if action == "repair":
            if self.on_rejected is not None:
                self.on_rejected(record, package, str(spec.task_id), str(occurrence_id))
            return None
        return self._commit_assured_composition(
            mission_id,
            spec,
            binding,
            revision,
            package,
            record,
            accepted,
            producers,
            instance_id=instance_id,
            manifest=manifest,
            now_ms=now_ms,
        )

    def _commit_assured_composition(
        self,
        mission_id,
        spec,
        binding,
        revision,
        package,
        record,
        accepted,
        producers,
        *,
        instance_id,
        manifest,
        now_ms,
    ):  # type: ignore[no-untyped-def]
        """Form the compound's GoalResolution from its official COMPOSITION record.

        The licence is the record's current use certificate (prepared here outside
        the write lock, committed by ``commit_goal_resolution`` under it); every
        criterion verdict is restated from the certificate's current effective grades,
        never asserted here (review F4, as for the root).
        """
        validity = getattr(self.commit, "_assurance_validity", None)
        if validity is None:
            raise ContractError("USE_CERTIFICATE_REQUIRED")
        resolution_id = f"res-{spec.occurrence_id}-{content_hash_of(str(package.package_id))[:16]}"
        candidate = validity.prepare_composition_use(record, resolution_id=resolution_id)
        grades = candidate.effective_grades
        resolution = GoalResolution(
            resolution_id=GoalResolutionId(resolution_id),
            mission_id=mission_id,
            obligation_id=str(spec.obligation_id),
            goal_task_id=str(spec.task_id),
            requirements_version=int(revision.revision),
            contract_revision=int(binding.contract_revision),
            method_instance_id=instance_id,
            input_manifest_hash=manifest,
            artifact_refs=(),
            child_resolution_ids=tuple(
                ref.id for ref in package.candidate_refs if ref.kind is TypedRefKind.RESOLUTION
            ),
            criteria=tuple(
                ResolutionCriterion(
                    criterion_id=item.criterion_id,
                    verdict=CriterionVerdict(grades.get(str(item.criterion_id), "UNKNOWN")),
                )
                for item in package.criteria
            ),
            review_receipt_id=str(record.record_id),
            verdict=ReviewVerdict.ACCEPT,
            validity=Validity.CURRENT,
        )
        command = CommitGoalResolutionCommand(
            command_id=f"compose:{spec.occurrence_id}:{str(package.package_id)}",
            mission_id=mission_id,
            resolution=resolution,
            package=package,
            record=record,
            requirements=revision,
            witness_id=candidate.certificate_id,
            independence=IndependenceFacts(
                producer_agent_ids=producers,
                reviewer_can_write_candidate=False,
            ),
            posture=ExecutionPosture(),
            read_set=self._read_set(mission_id, binding, revision),
            decided_at_ms=now_ms,
            purpose=ReviewPurpose.COMPOSITION,
            compound=CompoundFacts(
                selected_method_legal=True,
                contributing_occurrence_ids=tuple(sorted(accepted)),
                composition_obligation_passed=True,  # the official record, or the person, said so
            ),
            is_mission_root=False,
            semantic_review_required=True,
            issued_by=self.issued_by,
            scope_id=self.scope_id,
            source={"occurrence_id": str(spec.occurrence_id), "policy": COMPOSITION_REVIEW_POLICY},
        )
        principal = ResolutionPrincipal(
            principal_id=self.issued_by,
            scope_id=self.scope_id,
        )
        return self.commit.commit_goal_resolution(command, principal)

    def _accepted_children(
        self, mission_id: str, gating: Sequence[Any]
    ) -> dict[str, tuple[str, ...]]:

        return current_child_supports(self.store, mission_id, gating)

    def _producers(
        self, mission_id: str, accepted: Mapping[str, tuple[str, ...]]
    ) -> tuple[str, ...]:

        agents: list[str] = []
        for ids in accepted.values():
            for source_id in ids:
                support = read_completion_support(self.store, mission_id, source_id)
                agents.extend(support.package.producer_agent_ids)
        return tuple(dict.fromkeys(item for item in agents if item))

    def _manifest_hash(self, mission_id: str, task_id: str) -> str:
        document: dict[str, Any] = {"consumer_task_ref": str(task_id), "bindings": []}
        return self.semantics.insert_input_manifest(mission_id, str(task_id), document)

    def _package(
        self,
        mission_id: str,
        spec: Any,
        binding: Any,
        revision: RequirementsRevision,
        accepted: Mapping[str, tuple[str, ...]],
        producers: Sequence[str],
        *,
        manifest_hash: str,
        method_instance_id: str,
        criteria: tuple[Criterion, ...],
        expression: Any,
    ) -> ReviewPackage:
        # ``accepted`` 装的是子步骤的支撑（验收或复用的目标结论），引用由支撑读取给出。

        supports = tuple(
            read_completion_support(self.store, mission_id, source_id)
            for source_ids in accepted.values()
            for source_id in source_ids
        )
        child_refs = tuple(
            item.ref for item in supports if item.ref.kind is TypedRefKind.ACCEPTANCE
        )
        resolution_refs = tuple(
            item.ref for item in supports if item.ref.kind is TypedRefKind.RESOLUTION
        )
        identity: dict[str, Any] = {
            "occ": str(spec.occurrence_id),
            "rev": revision.revision,
            "method_instance_id": method_instance_id,
            "manifest_hash": manifest_hash,
            "supports": [ref.to_json() for ref in (*child_refs, *resolution_refs)],
        }
        digest = content_hash_of(identity)[:32]
        package = ReviewPackage(
            package_id=ReviewPackageId(f"pkg-compose-{digest}"),
            purpose=ReviewPurpose.COMPOSITION,
            binding=ReviewBinding(
                mission_id=mission_id,
                obligation_id=str(spec.obligation_id),
                subject_ref=TypedRef(
                    kind=TypedRefKind.TASK,
                    id=str(spec.task_id),
                    revision=int(binding.contract_revision),
                    content_hash=binding.contract_hash,
                ),
                requirements_revision=int(revision.revision),
                input_manifest_hash=manifest_hash,
                policy_ref=TypedRef(
                    kind=TypedRefKind.SOURCE,
                    id=COMPOSITION_REVIEW_POLICY,
                    revision=1,
                    content_hash=content_hash_of(COMPOSITION_REVIEW_POLICY),
                ),
            ),
            criteria=criteria,
            success_expression=expression,
            child_acceptance_refs=child_refs,
            candidate_refs=resolution_refs,
            producer_agent_ids=tuple(producers),
            reviewer_workspace_access=REVIEWER_ACCESS,
            requirements_content_hash=revision.content_hash(),
            method_instance_id=MethodInstanceId(method_instance_id),
        )
        return package

    def _read_set(
        self, mission_id: str, binding: Any, revision: RequirementsRevision
    ) -> SemanticReadSet:
        epoch = self.semantics.epoch(mission_id, self.scope_id)
        return SemanticReadSet(
            requirements_revision=int(revision.revision),
            scope_epochs=(ScopeEpochRead(scope_id=self.scope_id, validity_epoch=epoch),),
            goal_revisions=(
                ReadItem(
                    kind=ReadItemKind.TASK,
                    id=str(binding.task_id),
                    semantic_revision=int(binding.contract_revision),
                    content_hash=binding.contract_hash,
                ),
            ),
        )
