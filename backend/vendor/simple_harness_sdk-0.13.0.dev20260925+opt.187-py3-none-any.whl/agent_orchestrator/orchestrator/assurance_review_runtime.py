# SPDX-License-Identifier: Apache-2.0
"""Original Critic runner using durable Assurance transport and REVIEW effects.

This adapter never parses a model response into a successful verification layer.
Only the original official importer can produce the record consumed here. The
layer remains a historical verdict; acceptance needs independent current proof.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Mapping
from typing import Any

from simple_harness.agents import AgentConfig, AgentLimits

from ..assurance.codec import AssuranceError, decode, fingerprint
from ..assurance.refs import AssuranceRef, Pin
from ..assurance.review_input import REVIEW_INSTRUCTIONS, REVIEW_INSTRUCTIONS_VERSION
from ..assurance.reviews import REVIEW_CODEC_VERSION
from ..contracts import TERMINAL_ATTEMPT, TERMINAL_MISSION, TERMINAL_TASK, ContractError

# One review turn: the initial request plus a bounded number of tool rounds.
# The per-call cap on the gateway binding is MAX_EVIDENCE_TOOL_CALLS; the turn's
# own tool cap matches it. Host real model run 13 (2026-09-23): a real reviewer
# listed the catalogue and read the candidate plus five evidence items (3+2+5 = 10
# tool calls) before concluding, and the old cap of 8 ended every such turn with
# react_max_tool_calls_exceeded → TURN_FAILED.
from ..runtime.tool_gateway import ASSURANCE_REVIEWER_TOOLS, TOOL_ANSWER_MARGIN
from ..storage.assurance_reads import AssuranceReader
from ..storage.htn_store import HtnStore
from ..verification.critics import CriticVerdict
from ..verification.reviewer_evidence_tools import MAX_EVIDENCE_TOOL_CALLS
from .assurance_content_review import ensure_task_content_review
from .assurance_review_collect import collect_assurance_review
from .assurance_review_consumer import AssuranceReviewConsumer
from .assurance_review_import import carried_review_alive, read_official_review_binding_locked
from .assurance_review_policies import register_review_policies
from .failure_classes import INTERRUPTED_REVIEW, REVIEW_INTERRUPTED_CODE

#: 2026-10-09 库存题：最终审阅员每轮查 2 次左右，10 次模型调用先用完（只查了 20 次，工具上限 32），
#: 循环被截断、没有任何提示，两次都没给结论，任务判失败。模型调用上限放在工具上限之上：先到的总是
#: 带"只剩 N 次"提示和"马上作答"拒绝话的工具上限；多出的两次留给被拒的那一轮和作答的那一轮。
REVIEW_MODEL_CALLS = MAX_EVIDENCE_TOOL_CALLS + 2


class ReviewCallInterrupted(ContractError):
    """审阅调用被打断（没回来，或两次都被打断而用完）：不是审阅员的结论，也不是它的错。
    审阅层按出错收口，带结构化码；步骤按"被打断"原地重做、不扣次数。"""

    code = REVIEW_INTERRUPTED_CODE


#: The reviewing model is in its provider-failure cooldown: a review cannot be opened now.
REVIEW_ROUTE_UNAVAILABLE = "REVIEW_ROUTE_UNAVAILABLE"
#: 2026-09-29 第六局：最终审阅员每轮并发查 5 次左右，查满 32 次时循环直接截断，两次都没给
#: 结论。循环上限比查看工具上限多留一轮的余量（与执行者共用 ``TOOL_ANSWER_MARGIN``）：工具先拒绝
#: 并提示"马上作答"，模型还能作答。
REVIEW_TOOL_CALLS = MAX_EVIDENCE_TOOL_CALLS + TOOL_ANSWER_MARGIN


class AssuranceReviewRuntime:
    def __init__(
        self,
        orchestrator: Any,
        consumer: AssuranceReviewConsumer,
        *,
        check_policy_projector: Callable[[str], None] | None = None,
    ) -> None:
        if consumer.commit is not orchestrator.commit or consumer.store is not orchestrator.store:
            raise AssuranceError("ASSURANCE_STORE_MISMATCH")
        self.orchestrator = orchestrator
        self.consumer = consumer
        self.store = consumer.store
        # Deployment port: projects the frozen Scope's check policy under the
        # Host's caller right before the first review preparation needs it.
        self._check_policy_projector = check_policy_projector
        from ..verification.reviewer_evidence_tools import ReviewerEvidenceTools

        self.evidence_tools = ReviewerEvidenceTools(self)

    def install(self) -> AssuranceReviewConsumer:
        """Bind original runner/handoff; caller still installs all four consumers.

        Startup may call this before execution pools are opened. The actual pool,
        root and complete tick are required again on each later runtime entry.
        """
        from .assurance_review_handoff import AssuranceReviewHandoff
        from .assurance_settlement import AssuranceSettlement

        orch = self.orchestrator
        if orch._assurance_reviews not in (None, self):
            raise AssuranceError("ASSURANCE_REVIEW_RUNTIME_ALREADY_BOUND")
        if (
            orch.commit._assurance_review_handoff is not None
            and orch._assurance_reviews is not self
        ):
            raise AssuranceError("ASSURANCE_REVIEW_RUNTIME_ALREADY_BOUND")
        orch._assurance_reviews = self
        if orch.commit._assurance_review_handoff is None:
            orch.commit._assurance_review_handoff = AssuranceReviewHandoff(self)
        if orch.commit._assurance_settlement is None:
            orch.commit._assurance_settlement = AssuranceSettlement(orch)
        gateway = getattr(getattr(orch, "assembled", None), "gateway", None)
        if gateway is not None and hasattr(gateway, "assurance_evidence_reader"):
            self.evidence_tools.install(gateway)
        return self.consumer

    def task_record(
        self, mission_id: str, attempt_id: str, requirements_revision: int | None = None
    ):
        """Exact official source for this Result under one requirements revision (``None``:
        the one it was produced under); no latest-Review fallback (TaskGraph 补全第四批)."""
        from .completion_inputs import frozen_requirements_revision

        result = self.store.find_result_for_attempt(attempt_id)
        if result is None or result.envelope.mission_id != mission_id:
            raise AssuranceError("REVIEW_RESULT_SOURCE_MISSING")
        revision = (
            frozen_requirements_revision(self.store, result)
            if requirements_revision is None
            else int(requirements_revision)
        )
        rows = self.store.connection.execute(
            "SELECT package_id FROM assurance_review_bindings WHERE mission_id=? "
            "AND subject_hash=? AND requirements_revision=? "
            "AND json_extract(binding_json,'$.subject.purpose')='TASK_CONTENT'",
            (mission_id, fingerprint(result.envelope.to_json()), revision),
        ).fetchall()
        if len(rows) > 1:
            raise AssuranceError("REVIEW_RESULT_SOURCE_AMBIGUOUS")
        if not rows:
            return None
        record = HtnStore(self.store).official_review_record(rows[0][0])
        if record is not None:
            read_official_review_binding_locked(
                self.orchestrator.commit, self.consumer.tenant_id, record
            )
        return record

    def provenance(
        self, mission_id: str, attempt_id: str, requirements_revision: int | None = None
    ) -> dict[str, str]:
        with self.store.read_view():
            record = self.task_record(mission_id, attempt_id, requirements_revision)
            if record is None:
                return {}
            rows = self.store.connection.execute(
                "SELECT i.dispatch_intent_id FROM assurance_review_invocations i "
                "JOIN assurance_review_record_bindings r "
                "ON r.mission_id=i.mission_id AND r.review_key=i.review_key "
                "AND json_extract(r.binding_json,'$.invocation_ordinal')=i.ordinal "
                "WHERE r.record_id=?",
                (str(record.record_id),),
            ).fetchall()
            if len(rows) != 1:
                raise AssuranceError("REVIEW_RESULT_SOURCE_AMBIGUOUS")
            intent = self.store.get_intent(rows[0][0])
            if intent is None or intent.config.get("attempt_id") != attempt_id:
                raise AssuranceError("REVIEW_RESULT_SOURCE_MISMATCH")
            return {"critic_intent_id": intent.intent_id, "verifier_version": REVIEW_CODEC_VERSION}

    def _verdict(self, record: Any) -> CriticVerdict:
        reader = AssuranceReader(
            self.store, tenant_id=self.consumer.tenant_id, mission_id=record.binding.mission_id
        )
        read_official_review_binding_locked(
            self.orchestrator.commit, self.consumer.tenant_id, record
        )
        manifest = decode(
            reader.read_exact_metadata(
                AssuranceRef(
                    "input_manifest",
                    Pin(record.evidence_manifest_hash, 0, record.evidence_manifest_hash),
                )
            ).body_json
        )
        verdict = manifest["effective_verdict"]
        if verdict not in {"ACCEPT", "REWORK", "REJECTED", "INCONCLUSIVE"}:
            raise ContractError("Assurance official verdict cannot drive this verification")
        # INCONCLUSIVE（2026-09-30）：复审后仍判不下来，不再当"没通过"让执行者重做——
        # 结论标"需要人定"，走现成的挂起 → 复核审批 → 用户点通过/不通过；证书那边认用户的裁决。
        inconclusive = verdict == "INCONCLUSIVE"
        return CriticVerdict(
            "PASS" if verdict == "ACCEPT" or inconclusive else "FAIL",
            tuple(
                {
                    "severity": item["severity"].lower(),
                    "description": item["reason"],
                    "criterion_id": item["criterion_id"],
                }
                for item in manifest["findings"]
            )
            + tuple(
                {
                    "severity": "blocker" if item["effective_grade"] == "FAIL" else "info",
                    "description": item["reason"],
                    "criterion_id": item["criterion_id"],
                }
                for item in manifest["criteria"]
                if item["effective_grade"] != "PASS"
            ),
            tuple(
                {"criterion": item["criterion_id"], "met": item["effective_grade"] == "PASS"}
                for item in manifest["criteria"]
            ),
            {
                "official_review_record_id": str(record.record_id),
                "evidence_manifest_hash": record.evidence_manifest_hash,
                "effective_verdict": verdict,
            },
            needs_human=inconclusive,
        )

    def _licensed(self, record: Any) -> CriticVerdict:
        """Historical verdict; the licence is prepared later by the acceptance path.

        The verdict itself is not a licence. The router still records layers
        (inventoried sources) after this returns, so the current ACCEPT use is
        computed by ``CommitService.accept_result`` immediately before its UoW.
        A deployment without a validity evaluator is refused here rather than
        producing an unlicensed PASS.
        """
        with self.store.read_view():
            verdict = self._verdict(record)
        if not verdict.passed:
            return verdict
        if getattr(self.orchestrator.commit, "_assurance_validity", None) is None:
            raise AssuranceError("ASSURANCE_VALIDITY_UNBOUND")
        return verdict

    # ------------------------------------------------ the other five purposes
    def _purpose_config(self, mission: Any, name: str) -> tuple[Any, dict[str, Any], Any]:
        orch = self.orchestrator
        if mission.tenant_id != self.consumer.tenant_id:
            raise AssuranceError("ASSURANCE_TENANT_MISMATCH")
        from ..runtime.model_router import RoutingUnavailable

        try:
            decision = orch._route_service("critic", mission.id)
        except RoutingUnavailable as unavailable:
            # 2026-10-03: the reviewing model is cooling down after provider failures. The
            # review cannot be opened *now*; every opener already treats this the same way
            # as any other "review unavailable" (retry later), never as a loop error.
            raise AssuranceError(REVIEW_ROUTE_UNAVAILABLE, unavailable.profile_id) from unavailable
        config = {
            **orch._service_config(decision),
            "prompt_version": REVIEW_INSTRUCTIONS_VERSION,
            "agent_config": AgentConfig(
                name=name,
                instructions=REVIEW_INSTRUCTIONS,
                model_profile_ref=decision.profile_id,
                # §4: the two read-only evidence tools, plus the blackboard readers (K01).
                tool_names=ASSURANCE_REVIEWER_TOOLS,
                limits=AgentLimits(
                    max_model_calls_per_turn=REVIEW_MODEL_CALLS,
                    max_tool_calls_per_turn=REVIEW_TOOL_CALLS,
                    turn_deadline_seconds=orch._config.turn_deadline_seconds,
                ),
            ).to_json(),
        }
        reservation = orch._reservation(orch._config.critic_reserve_tokens)
        return decision, config, reservation

    def _ensure_purpose(
        self,
        mission: Any,
        *,
        name: str,
        package: Any,
        subject: Any,
        requirements: Any,
        request_command_id: str,
        allow_in_transaction: bool = False,
    ) -> Any:
        from .assurance_purpose_reviews import prepare_purpose_review

        decision, config, reservation = self._purpose_config(mission, name)
        return prepare_purpose_review(
            self.orchestrator.commit,
            tenant_id=mission.tenant_id,
            mission_id=mission.id,
            package=package,
            subject=subject,
            requirements=requirements,
            principal_id=self.consumer.principal_id,
            authority=self.consumer.authority,
            cas=self.consumer.cas,
            config=config,
            policy_refs=register_review_policies(
                self.orchestrator, mission.id, decision.profile_id
            ),
            reservation=reservation,
            request_command_id=request_command_id,
            allow_in_transaction=allow_in_transaction,
        )

    def ensure_method_plan(
        self, mission: Any, *, task_id: str, method_ref: Pin, producer_agent_ids: tuple[str, ...]
    ) -> Any:
        """METHOD_PLAN from the original method admission (planning subject + registry)."""
        from .assurance_purpose_reviews import method_plan_package

        package, subject, requirements = method_plan_package(
            self.store,
            mission_id=mission.id,
            task_id=task_id,
            method_ref=method_ref,
            producer_agent_ids=producer_agent_ids,
        )
        return self._ensure_purpose(
            mission,
            name="assurance-method-plan-review",
            package=package,
            subject=subject,
            requirements=requirements,
            request_command_id="method-plan-review:" + str(package.package_id),
            allow_in_transaction=True,
        )

    def ensure_composition(
        self, mission: Any, *, package: Any, occurrence_id: str, accepted: Mapping[str, Any]
    ) -> Any:
        """COMPOSITION from the original composition assembly's package."""
        from .assurance_purpose_reviews import composition_subject

        subject, requirements = composition_subject(
            self.store,
            mission_id=mission.id,
            package=package,
            occurrence_id=occurrence_id,
            accepted=accepted,
        )
        return self._ensure_purpose(
            mission,
            name="assurance-composition-review",
            package=package,
            subject=subject,
            requirements=requirements,
            request_command_id="composition-review:" + str(package.package_id),
        )

    def ensure_action_proposal(
        self, mission: Any, *, draft: Any, sources: Any, payloads: Any
    ) -> Any:
        """ACTION_PROPOSAL from T0's frozen draft, inside T0's own UoW."""
        from .assurance_purpose_reviews import action_proposal_subject

        subject, requirements = action_proposal_subject(
            self.store,
            mission_id=mission.id,
            package=draft.package,
            sources=sources,
            payloads=payloads,
        )
        return self._ensure_purpose(
            mission,
            name="assurance-action-proposal-review",
            package=draft.package,
            subject=subject,
            requirements=requirements,
            request_command_id="action-proposal-review:" + str(draft.package.package_id),
            allow_in_transaction=True,
        )

    def ensure_operation_outcome(self, mission: Any, *, prepared: Any) -> Any:
        """OPERATION_OUTCOME from the original outcome readback, inside its persistence UoW."""
        from .assurance_purpose_reviews import operation_outcome_subject

        subject, requirements = operation_outcome_subject(
            self.store, mission_id=mission.id, prepared=prepared
        )
        return self._ensure_purpose(
            mission,
            name="assurance-operation-outcome-review",
            package=prepared.package,
            subject=subject,
            requirements=requirements,
            request_command_id="operation-outcome-review:" + str(prepared.package.package_id),
            allow_in_transaction=True,
        )

    def ensure_mission_final(self, mission: Any, *, package: Any, dispatch: Any) -> Any:
        """MISSION_FINAL from the root coordinator's cut package."""
        from .assurance_purpose_reviews import mission_final_subject

        if self._check_policy_projector is not None and not self.store.connection.in_transaction:
            # Same deployment port as TASK_CONTENT: the root Scope's MISSION_FINAL
            # policy is projected right before the root review needs it.
            self._check_policy_projector(mission.id)
        subject, requirements = mission_final_subject(
            self.store, mission_id=mission.id, package=package, dispatch=dispatch
        )
        return self._ensure_purpose(
            mission,
            name="assurance-mission-final-review",
            package=package,
            subject=subject,
            requirements=requirements,
            request_command_id="mission-final-review:" + str(package.package_id),
        )

    async def run_task(
        self, mission: Any, task: Any, *, attempt_id: str, requirements_revision: int | None = None
    ) -> CriticVerdict:
        """The TASK_CONTENT review of one result.  ``requirements_revision`` set: the result
        was accepted under older requirements and is kept by the current plan; the reviewer
        judges the same result under this newer revision (TaskGraph 补全第四批).  Driven by
        the plan-commit scan, not by the Attempt: no lease, its own reservation on the Task,
        alive while the Task is in the current plan."""
        carried = requirements_revision is not None
        orch = self.orchestrator
        tick = orch._assurance_tick
        if tick is None or tick.consumers.get("REVIEW") is not self.consumer:
            raise AssuranceError("ASSURANCE_REVIEW_CONSUMER_UNBOUND")
        if mission.tenant_id != self.consumer.tenant_id:
            raise AssuranceError("ASSURANCE_TENANT_MISMATCH")
        with self.store.read_view():
            record = self.task_record(mission.id, attempt_id, requirements_revision)
            if record is None:
                result = self.store.find_result_for_attempt(attempt_id)
        if record is not None:
            return self._licensed(record)
        with self.store.read_view():
            if result is None or result.envelope.task_id != task.id:
                raise AssuranceError("REVIEW_RESULT_SOURCE_MISMATCH")
            from .completion_inputs import frozen_requirements_revision

            prior = self.store.connection.execute(
                "SELECT i.dispatch_intent_id FROM assurance_review_invocations i "
                "JOIN assurance_review_bindings b USING(mission_id,review_key) "
                "WHERE b.mission_id=? AND b.subject_hash=? AND b.requirements_revision=? AND i.ordinal=1 "
                "AND json_extract(b.binding_json,'$.subject.purpose')='TASK_CONTENT'",
                (
                    mission.id,
                    fingerprint(result.envelope.to_json()),
                    frozen_requirements_revision(self.store, result)
                    if not carried
                    else int(requirements_revision),
                ),
            ).fetchone()
            invocation = None
            if prior is not None:
                from .assurance_review_transport import read_review_invocation_locked

                invocation, _ = read_review_invocation_locked(
                    orch.commit,
                    AssuranceReader(self.store, tenant_id=mission.tenant_id, mission_id=mission.id),
                    prior[0],
                )
        deadline = self.store.now + orch._critic_wait
        if invocation is None:
            decision = orch._route_service("critic", mission.id)
            if carried:
                # 重审不动原尝试的保护预算：在任务上另记一次审阅预留，不计尝试次数
                fields: dict[str, Any] = {
                    "carried_requirements_revision": int(requirements_revision)
                }
                reservation = orch._reservation(orch._config.critic_reserve_tokens)
            else:
                fields, reservation = protected_critic_budget(orch, decision, task.id, attempt_id)
            config = {
                **orch._service_config(decision),
                **fields,
                "attempt_id": attempt_id,
                "prompt_version": REVIEW_INSTRUCTIONS_VERSION,
                "agent_config": AgentConfig(
                    name="assurance-content-review",
                    instructions=REVIEW_INSTRUCTIONS,
                    model_profile_ref=decision.profile_id,
                    tool_names=ASSURANCE_REVIEWER_TOOLS,
                    limits=AgentLimits(
                        max_model_calls_per_turn=REVIEW_MODEL_CALLS,
                        max_tool_calls_per_turn=REVIEW_TOOL_CALLS,
                        turn_deadline_seconds=min(
                            orch._config.turn_deadline_seconds, deadline - self.store.now
                        ),
                    ),
                ).to_json(),
            }
            if (
                self._check_policy_projector is not None
                and not self.store.connection.in_transaction
            ):
                # The projector approves through the ordinary verb (receipted,
                # replay-safe); a projection failure surfaces below as the same
                # CHECK_POLICY_UNRESOLVED the review would raise without it.
                self._check_policy_projector(mission.id)
            invocation = ensure_task_content_review(
                orch.commit,
                tenant_id=mission.tenant_id,
                result_id=result.envelope.id,
                principal_id=self.consumer.principal_id,
                authority=self.consumer.authority,
                cas=self.consumer.cas,
                config=config,
                policy_refs=register_review_policies(orch, mission.id, decision.profile_id),
                reservation=reservation,
            )
        review_key = invocation.to_json()["review_key"]
        while self.store.now < deadline:
            if carried:
                self._require_live_in_plan(mission.id, task.id)
            else:
                self._require_live(mission.id, task.id, attempt_id)
            with self.store.read_view():
                record = self.task_record(mission.id, attempt_id, requirements_revision)
            if record is not None:
                return self._licensed(record)
            with self.store.read_view():
                row = self.store.connection.execute(
                    "SELECT dispatch_intent_id FROM assurance_review_invocations "
                    "WHERE mission_id=? AND review_key=? ORDER BY ordinal DESC LIMIT 1",
                    (mission.id, review_key),
                ).fetchone()
                intent = self.store.get_intent(row[0])
            if intent.state not in {"SETTLED", "FAILED"}:
                intent, answer = await orch._await_service_turn(
                    intent, deadline, attempt_id=None if carried else attempt_id
                )
                if answer is None:
                    # SUBMITTED and its held reservation remain collectable. A
                    # timeout does not create a format-repair ordinal.
                    await orch._cancel_turn(intent)
                    raise ReviewCallInterrupted(INTERRUPTED_REVIEW)
                if orch._critic_subject_stopped(intent):
                    await orch._collect_after_stop(intent)
                    raise ContractError("Assurance review subject stopped")
                await collect_assurance_review(orch, intent)
                orch.assembled.gateway.unbind(intent.agent_id)
            # Same durable four-consumer tick as the outer loop. It only prepares
            # effects; a repair intent goes through the original dispatcher above.
            await tick.tick()
            self._raise_final_failure(review_key)
            if not carried:
                orch._hold_lease(attempt_id)
            await asyncio.sleep(orch._poll)
        raise ContractError("Assurance review import wait window elapsed")

    def _require_live(self, mission_id: str, task_id: str, attempt_id: str) -> None:
        self.orchestrator._require_assurance_execution_root()
        mission, task = self.store.get_mission(mission_id), self.store.get_task(task_id)
        attempt = self.store.get_attempt(attempt_id)
        if (
            mission is None
            or task is None
            or attempt is None
            or mission.status in TERMINAL_MISSION
            or task.status in TERMINAL_TASK
            or attempt.status in TERMINAL_ATTEMPT
        ):
            raise ContractError("Assurance review subject stopped")

    def _require_live_in_plan(self, mission_id: str, task_id: str) -> None:
        """A re-review is alive while its Mission runs and its step is in the current plan."""
        self.orchestrator._require_assurance_execution_root()
        if not carried_review_alive(self.store, mission_id, task_id):
            raise ContractError("Assurance review subject stopped")

    def _raise_final_failure(self, review_key: str) -> None:
        failed = self.store.connection.execute(
            "SELECT json_extract(receipt_json,'$.classification') FROM commit_receipts "
            "WHERE kind='AssuranceReviewClassified' AND json_extract(receipt_json,'$.review_key')=? "
            "AND json_extract(receipt_json,'$.classification')<>'READY_FOR_CURRENT_REVIEW' "
            # TURN_FAILED is never final by itself (2026-10-09 四项修复第 1 条): the first is
            # retried once (TURN_RETRY); a second that was interrupted ends as
            # AssuranceReviewFormatExhausted (below); any other second one is imported as
            # the official "no usable reply" record and goes to the person.
            "AND json_extract(receipt_json,'$.classification')<>'TURN_FAILED' LIMIT 1",
            (review_key,),
        ).fetchone()
        if failed is not None:
            raise ContractError("Assurance review cannot be imported: " + failed[0])
        row = self.store.connection.execute(
            "SELECT kind, json_extract(receipt_json,'$.reason') FROM commit_receipts WHERE subject_id=? AND kind IN "
            "('AssuranceReviewImportRejected','AssuranceReviewFormatExhausted','AssuranceReviewLateTurn') LIMIT 1",
            (review_key,),
        ).fetchone()
        if row is not None:
            from .assurance_review_consumer import REVIEW_SOURCE_REPLACED

            if row[1] == REVIEW_SOURCE_REPLACED:
                # 说出真正的原因（2026-10-05 真机：规划器只看到"审阅准备需要人工处理"）
                raise ContractError(
                    "这次审阅作废：审阅进行期间，任务的资料换了版本或被撤销，审阅员看的不是现行资料"
                    "（这一步是拿旧版资料做的）"
                )
            if row[0] == "AssuranceReviewFormatExhausted":
                # 只有两次调用都被打断才会写这条回执：不是审阅员的错，步骤按被打断重做
                raise ReviewCallInterrupted(
                    "Assurance review stopped: both review calls were interrupted (" + row[0] + ")"
                )
            raise ContractError("Assurance review stopped: " + row[0])
        row = self.store.connection.execute(
            "SELECT wait_reason FROM assurance_pending_work WHERE consumer='REVIEW' "
            "AND work_key IN (?,?) AND wait_reason='MANUAL_REQUIRED' LIMIT 1",
            ("review-import:" + review_key + ":1", "review-import:" + review_key + ":2"),
        ).fetchone()
        if row is not None:
            raise ContractError("Assurance review preparation requires manual resolution")


def protected_critic_budget(orch: Any, decision: Any, task_id: str, attempt_id: str):
    """Retain the original first-Critic protected-tail contract and account."""
    from ..runtime.first_request_budget import FirstRequestBudget, ProviderInputCap

    worker = orch.store.get_intent_for_subject(attempt_id)
    if worker is None:
        raise ContractError("FIRST Critic has no original Worker intent")
    frozen = worker.config.get("first_critic_budget")
    if frozen is not None:
        if not isinstance(frozen, Mapping):
            raise ContractError("frozen FIRST Critic budget is malformed")
        cap = ProviderInputCap.from_json(frozen.get("provider_input_cap"))
        actual = orch._first_critic_budget(decision)
        if not isinstance(actual, FirstRequestBudget):
            raise ContractError("FIRST Critic budget unavailable")
        reservation = orch._first_critic_reservation(actual)
        if (
            actual.provider_input_cap != cap
            or frozen.get("output_ceiling") != actual.output_ceiling
            or frozen.get("minimum_tokens") != actual.minimum_tokens
        ):
            raise ContractError("FIRST Critic route or cap differs from protected tail")
        return {
            "provider_input_cap": cap.to_json(),
            "provider_output_ceiling": actual.output_ceiling,
        }, reservation
    reservation = orch._reservation(orch._config.critic_reserve_tokens)
    return {
        "first_critic_budget_unknown": worker.config.get(
            "first_critic_budget_unknown", "original_intent_has_no_first_cap"
        )
    }, reservation
