#!/usr/bin/env python3
"""Read a static H1-H registry without importing it; bind exact case IDs to collected nodeids.

No test execution, no PASS inference, no edits to the SDK runner's existing manifest.
Unsupported registry expressions are rejected, never evaluated with eval/runpy/import.
"""
from __future__ import annotations
import argparse
import ast
from collections import defaultdict
import json
from pathlib import Path
from typing import Any
from capture_sources import digest, project_python
from collection_identity import expand_selector, executed_fingerprint

ID_KEYS = ('case_id', 'id')
NODE_KEYS = ('nodeid', 'nodeids', 'test_nodeid')

class RegistryUnsupported(ValueError): pass

def literal(node: ast.AST, symbols: dict[str, ast.AST], seen: frozenset[str] = frozenset()) -> Any:
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Name) and node.id in symbols and node.id not in seen:
        return literal(symbols[node.id], symbols, seen | {node.id})
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        return [literal(x, symbols, seen) for x in node.elts]
    if isinstance(node, ast.Dict):
        out = {}
        for k, v in zip(node.keys, node.values):
            if k is None: raise RegistryUnsupported('dictionary unpacking requires a reviewed export adapter')
            key = literal(k, symbols, seen)
            if not isinstance(key, (str, int)) or isinstance(key, bool): raise RegistryUnsupported('invalid dictionary key')
            if key in out: raise RegistryUnsupported('duplicate static dictionary key')
            out[key] = literal(v, symbols, seen)
        return out
    raise RegistryUnsupported(f'nonliteral expression: {type(node).__name__}')

def nodeids(value: Any) -> list[str]:
    items = [value] if isinstance(value, str) else value
    if not isinstance(items, list) or not items: raise RegistryUnsupported('empty/nonliteral nodeids')
    if any(not isinstance(n, str) or '::' not in n or not n.split('::', 1)[0].endswith('.py') for n in items):
        raise RegistryUnsupported('not exact pytest nodeids')
    if len(set(items)) != len(items): raise RegistryUnsupported('duplicate nodeid within a case')
    return items

def one_key(value: dict, keys: tuple[str, ...]) -> str:
    matches = [k for k in keys if k in value]
    if len(matches) != 1: raise RegistryUnsupported('ambiguous/missing field: ' + ','.join(keys))
    return matches[0]

def normalize(value: Any, expected: set[str]) -> list[dict]:
    rows = []
    if isinstance(value, dict):
        for case_id, target in value.items():
            if isinstance(target, dict):
                target = target[one_key(target, NODE_KEYS)]
            rows.append({'id': case_id, 'actual_nodeids': nodeids(target)})
    elif isinstance(value, list):
        for row in value:
            if not isinstance(row, dict): raise RegistryUnsupported('sequence items must explicitly name id and nodeids')
            rows.append({'id': row[one_key(row, ID_KEYS)], 'actual_nodeids': nodeids(row[one_key(row, NODE_KEYS)])})
    else: raise RegistryUnsupported('registry must be literal dict or list of named records')
    ids = [r['id'] for r in rows]
    if any(not isinstance(i, str) for i in ids) or len(ids) != len(set(ids)): raise RegistryUnsupported('duplicate/invalid case IDs')
    if set(ids) != expected: raise RegistryUnsupported('case set is not the exact 36-case specification')
    return sorted(rows, key=lambda r: r['id'])

def constructor_registry(node: ast.AST, symbols: dict[str, ast.AST], expected: set[str], constructor: str) -> list[dict]:
    """Optional explicitly selected record constructor. Positional meaning is not guessed."""
    if not isinstance(node, (ast.Tuple, ast.List)): raise RegistryUnsupported('constructor registry must be literal list/tuple')
    values = []
    for item in node.elts:
        if not isinstance(item, ast.Call) or ast.unparse(item.func) != constructor or item.args:
            raise RegistryUnsupported('only explicit keyword constructor records supported; positional form needs reviewed export')
        if any(k.arg is None for k in item.keywords): raise RegistryUnsupported('keyword expansion refused')
        values.append({k.arg: literal(k.value, symbols) for k in item.keywords})
    return normalize(values, expected)

def extract_registry(raw: str, expected: set[str], symbol: str | None = None,
                     constructor: str | None = None) -> dict:
    tree = ast.parse(raw)
    defs: dict[str, ast.AST] = {}
    for n in tree.body:
        if isinstance(n, ast.Assign):
            for target in n.targets:
                if isinstance(target, ast.Name):
                    if target.id in defs: raise RegistryUnsupported('reassigned registry symbol: ' + target.id)
                    defs[target.id] = n.value
        elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.value is not None:
            if n.target.id in defs: raise RegistryUnsupported('reassigned registry symbol: ' + n.target.id)
            defs[n.target.id] = n.value
    considered = [symbol] if symbol else list(defs)
    matches = []; errors = {}
    for name in considered:
        if name not in defs:
            errors[name] = 'symbol not found'; continue
        n = defs[name]
        try:
            try: rows = normalize(literal(n, defs), expected)
            except RegistryUnsupported:
                if not constructor: raise
                rows = constructor_registry(n, defs, expected, constructor)
            matches.append({'registry_symbol': name, 'source_line': n.lineno, 'cases': rows})
        except (RegistryUnsupported, TypeError, KeyError, ValueError) as e: errors[name] = str(e)
    if len(matches) != 1:
        return {'status': 'BLOCKED', 'reason': 'REGISTRY_FORMAT_UNSUPPORTED_OR_AMBIGUOUS',
                'candidate_symbols': [m['registry_symbol'] for m in matches],
                'static_symbols': list(defs), 'diagnostics': errors, 'cases': []}
    return {'status': 'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED', **matches[0]}

def verified_snapshot(source_map: Path) -> tuple[dict, Path]:
    sm = json.loads(source_map.read_text(encoding='utf-8'))
    candidate = sm['repositories']['candidate']
    project_python(Path(candidate['root']))
    if not sm.get('head_matches_handoff') or not sm.get('candidate_unchanged_during_capture'):
        raise ValueError('unstable or wrong candidate snapshot')
    root = Path(sm['snapshot']['path']).resolve()
    if not root.is_relative_to(source_map.resolve().parent): raise ValueError('snapshot outside evidence root')
    for f in sm['snapshot']['files']:
        p = (root / f['path']).resolve()
        if not p.is_relative_to(root) or digest(p.read_bytes()) != f['sha256']:
            raise ValueError('snapshot source hash mismatch')
    return sm, root

def bind_collection(registry: dict, collection: dict, specification: dict) -> dict:
    if registry.get('status') != 'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED':
        raise ValueError('registry extraction not complete')
    fp = registry.get('candidate_fingerprint')
    if not fp or collection.get('candidate_fingerprint') != fp: raise ValueError('candidate fingerprint mismatch')
    if collection.get('collection_exitstatus') != 0 or collection.get('collection_errors'):
        raise ValueError('pytest collection was not successful')
    if collection.get('sdk_tests_executed') is not False: raise ValueError('expected a collection receipt, not a test result')
    variant = registry.get('executed_source_fingerprint', fp)
    if collection.get('executed_source_fingerprint', fp) != variant:
        raise ValueError('executed source fingerprint mismatch')
    by_id = {c['id']: c for c in specification['cases']}
    rows = normalize({r['id']: r['actual_nodeids'] for r in registry['cases']}, set(by_id))
    used = defaultdict(list)
    for row in rows:
        selectors = list(row['actual_nodeids'])
        actual, missing, expansions = [], [], []
        for selector in selectors:
            expanded, mode = expand_selector(selector, collection)
            if not expanded:
                missing.append(selector)
            actual.extend(expanded)
            expansions.append({'registry_selector': selector, 'mode': mode, 'nodeids': expanded})
        if len(actual) != len(set(actual)):
            raise ValueError('case contains overlapping selectors; review registry instead of silently deduplicating')
        row['registry_selectors'] = selectors
        row['actual_nodeids'] = actual
        row['parameter_expansions'] = expansions
        for n in actual:
            used[n].append(row['id'])
        row.update({'required_assertions': by_id[row['id']]['required_assertions'],
                    'missing_nodeids': missing,
                    'parameter_policy': 'ALL_ITEMS_FROM_EXACT_COLLECTOR',
                    'assertion_coverage_review': 'PENDING', 'execution_status': 'NOT_RUN',
                    'execution_receipts': []})
    missing = sorted({n for r in rows for n in r['missing_nodeids']})
    return {'schema_version': 2, 'kind': 'H1H_COVERAGE_MANIFEST_NOT_RUNNER_CONFIG',
            'candidate_fingerprint': fp, 'executed_source_fingerprint': variant,
            'registry_file_sha256': registry['runner_sha256'], 'registry_symbol': registry['registry_symbol'],
            'status': 'COLLECTED_NOT_RUN' if not missing else 'BLOCKED_MISSING_NODEIDS',
            'case_count': len(rows), 'unique_registry_selector_count': len({n for r in rows for n in r['registry_selectors']}),
            'unique_nodeid_count': len(used),
            'shared_nodeids': [{'nodeid': n, 'case_ids': ids, 'review': 'PENDING_PER_CASE_ASSERTIONS'}
                              for n, ids in sorted(used.items()) if len(ids) > 1],
            'missing_nodeids': missing, 'cases': rows, 'sdk_pass_cases': 0,
            'h1_h_ready': False, 'production_enablement_allowed': False}

def write_new(out: Path, value: dict, evidence: Path) -> None:
    if not out.resolve().is_relative_to(evidence.resolve()): raise ValueError('output outside evidence root')
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write('\n')

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    e = sub.add_parser('extract'); b = sub.add_parser('bind')
    for parser in (e, b):
        parser.add_argument('--source-map', type=Path, required=True)
        parser.add_argument('--spec', type=Path, required=True)
        parser.add_argument('--out', type=Path, required=True)
    e.add_argument('--runner-relative', default='tests/orchestrator/full_target/h1h_stage_runner.py')
    e.add_argument('--registry-symbol'); e.add_argument('--constructor')
    b.add_argument('--registry', type=Path, required=True); b.add_argument('--collection', type=Path, required=True)
    a = p.parse_args(); sm, root = verified_snapshot(a.source_map)
    spec = json.loads(a.spec.read_text(encoding='utf-8'))
    expected = {c['id'] for c in spec['cases']}
    if len(spec['cases']) != 36 or len(expected) != 36: raise ValueError('exact 36-case specification required')
    if a.command == 'extract':
        runner = (root / a.runner_relative).resolve()
        if not runner.is_relative_to(root): raise ValueError('runner path outside snapshot')
        snapshot_files = {f['path']: f['sha256'] for f in sm['snapshot']['files']}
        rel = str(runner.relative_to(root)); raw = runner.read_bytes()
        if snapshot_files.get(rel) != digest(raw): raise ValueError('runner was not part of captured snapshot')
        result = extract_registry(raw.decode('utf-8'), expected, a.registry_symbol, a.constructor)
        result.update({'kind': 'STATIC_H1H_REGISTRY_READ', 'runner_relative_path': rel,
                       'runner_sha256': digest(raw), 'candidate_fingerprint': sm['repositories']['candidate']['fingerprint'],
                       'executed_source_fingerprint': executed_fingerprint(sm),
                       'sdk_pass_cases': 0, 'h1_h_ready': False, 'production_enablement_allowed': False})
    else:
        result = bind_collection(json.loads(a.registry.read_text()), json.loads(a.collection.read_text()), spec)
        if result['candidate_fingerprint'] != sm['repositories']['candidate']['fingerprint']: raise ValueError('source map changed')
        if result['executed_source_fingerprint'] != executed_fingerprint(sm): raise ValueError('executable source changed')
        captured = {r['path']: r['sha256'] for r in sm['snapshot']['files']}
        reg = json.loads(a.registry.read_text())
        if captured.get(reg.get('runner_relative_path')) != reg.get('runner_sha256'):
            raise ValueError('registry runner hash is not the captured source')
        collection = json.loads(a.collection.read_text())
        for item in collection.get('items', []):
            if captured.get(item.get('source_path')) != item.get('source_sha256'):
                raise ValueError('collection source hash is not the captured source')
    write_new(a.out, result, a.source_map.parent)
    print(json.dumps({k: result[k] for k in ('status', 'sdk_pass_cases', 'production_enablement_allowed')}, ensure_ascii=False))
    return 3 if result['status'].startswith('BLOCKED') else 0

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (ValueError, RuntimeError, OSError, KeyError, SyntaxError) as err:
        print(json.dumps({'status': 'BLOCKED', 'error': str(err), 'sdk_pass_cases': 0}, ensure_ascii=False))
        raise SystemExit(3)
