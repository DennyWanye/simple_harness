# V14-OP-SEAMS-1.0

先读 `V1.4-D1-D2-D3-Operation补遗-2026-09-21.md`。这是当前 V1.4 的小型专项补遗；不是另一个 readiness/prep 项目，也不替换原 H1–H8。

- `contracts.schema.json`：六种新增系统payload/command/profile的严格结构；按 `$defs` 选择，语义证据检查仍须实现。
- `sql/operation_seams.sql`：三张增量sidecar表，不含新的效果/预算状态。
- `reference/rules.py`、`tests/test_contracts.py`：局部参考片段与测试，不可作为真实producer、SDK migration或外部核对证据。
- `VALIDATION.md`：本包实际验证范围。
- `SOURCES.json`：来源边界与附件字节身份。
- `DELIVERY-MANIFEST.json`：交付文件SHA-256，manifest不对自身做递归hash。

本地参考检查从本包目录执行，解释器使用候选环境：

```bash
/Users/denny/projects/simple-harness-sdk-h1h-impl/.venv/bin/python -m unittest discover -s tests -v
```

参考Schema测试需要项目测试环境已有 jsonschema；缺依赖只表示参考环境未就绪，不应自动更换项目依赖或阻塞无关已授权V1.4工作。实际SDK用例按主文档§11实施与运行。不得把本包源码直接覆盖dirty SDK。

不附会话源码快照或原始provider日志。原始本地证据写 ignored `.local-test-evidence/`，Git只保留审阅后的结论、命令、nodeid和hash索引。
