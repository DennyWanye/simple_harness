from __future__ import annotations
import json,sqlite3,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'));sys.path.insert(0,str(ROOT/'reference'))
from capture_sources import dirty_paths,symbols,inspect_requirement,inventory,freeze_sources,digest
from map_collected_nodeids import map_cases
from export_commit_index import redact_source_map
from sql_statement_iterator import iter_sql_statements,comments_only
from offline_sdk_migration_probe import logical_fingerprint,backup

class SqlBoundaryTests(unittest.TestCase):
    def test_two_on_same_line(self):
        self.assertEqual(len(list(iter_sql_statements('SELECT 1; SELECT 2;'))),2)
    def test_string_semicolon(self):
        self.assertEqual(len(list(iter_sql_statements("SELECT 'x;y'; SELECT 2;"))),2)
    def test_comment_semicolon(self):
        self.assertEqual(len(list(iter_sql_statements('-- x;y;\nSELECT 1; /*z;*/'))),1)
    def test_trigger_single_statement(self):
        ddl="CREATE TABLE x(v); CREATE TRIGGER xx BEFORE INSERT ON x BEGIN SELECT CASE WHEN NEW.v<0 THEN RAISE(ABORT,'x;y') END; SELECT 1; END;"
        parts=list(iter_sql_statements(ddl));self.assertEqual(len(parts),2)
        c=sqlite3.connect(':memory:')
        for s in parts:c.execute(s)
        with self.assertRaises(sqlite3.IntegrityError):c.execute('INSERT INTO x VALUES(-1)')
        c.close()
    def test_incomplete_refused(self):
        with self.assertRaises(ValueError):list(iter_sql_statements('SELECT 1'))
    def test_unclosed_comment_refused(self):
        with self.assertRaises(ValueError):list(iter_sql_statements('SELECT 1; /*'))
    def test_does_not_commit(self):
        c=sqlite3.connect(':memory:',isolation_level=None);c.execute('BEGIN IMMEDIATE')
        for s in iter_sql_statements('CREATE TABLE x(v); INSERT INTO x VALUES(1);'):c.execute(s)
        self.assertTrue(c.in_transaction);c.rollback()
        self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='x'").fetchone());c.close()
    def test_old_naive_split_exposes_trigger_risk(self):
        ddl="CREATE TABLE x(v); CREATE TRIGGER xx BEFORE INSERT ON x BEGIN SELECT 1; END;"
        c=sqlite3.connect(':memory:')
        with self.assertRaises(sqlite3.OperationalError):
            for part in ddl.split(';'):
                if part.strip():c.execute(part)
        c.close()

class SourceTests(unittest.TestCase):
    def test_rename_metadata(self):
        self.assertEqual(dirty_paths(b'R  new.py\0old.py\0')[0]['old_path'],'old.py')
    def test_spaces_in_path(self):
        self.assertEqual(dirty_paths(b' M a b.py\0')[0]['path'],'a b.py')
    def test_qualified_symbol(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.py';p.write_text('class C:\n    def go(self, value: int):\n        return value\n')
            self.assertEqual(symbols(p)['C.go']['line'],2)
    def test_duplicate_name_not_equivalent(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.py';p.write_text('class A:\n def go(self): pass\nclass B:\n def go(self): pass\n')
            r={'id':'x','path':'x.py','symbols':['go'],'category':'EXISTING_REUSE'}
            self.assertEqual(inspect_requirement(Path(d),r,{})['observed_status'],'SYMBOL_MISSING_OR_AMBIGUOUS')
    def test_missing_h1_is_not_new_target(self):
        with tempfile.TemporaryDirectory() as d:
            r={'id':'x','path':'absent.py','symbols':['go'],'category':'H1H_PREREQUISITE'}
            self.assertEqual(inspect_requirement(Path(d),r,{})['observed_status'],'MISSING')
    def test_future_target_explicit(self):
        with tempfile.TemporaryDirectory() as d:
            r={'id':'x','path':'absent.py','symbols':['go'],'category':'TASKGRAPH_NEW_TARGET'}
            self.assertEqual(inspect_requirement(Path(d),r,{})['observed_status'],'PLANNED_ABSENT')
    def test_stale_equivalence_refused(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.py';p.write_text('def go(): pass\n')
            r={'id':'x','path':'x.py','symbols':['go'],'category':'EXISTING_REUSE'}
            e={'x':{'id':'x','path':'x.py','symbols':['go'],'file_sha256':'0'*64,'reviewed_by':'reviewer','contract_evidence':['doc'],'focused_nodeids':['test']}}
            self.assertEqual(inspect_requirement(Path(d),r,e)['observed_status'],'EQUIVALENCE_HASH_STALE')
    def test_dirty_bytes_frozen_not_head_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'repo';root.mkdir();(root/'src').mkdir();p=root/'src/x.py';p.write_text('OLD=1\n')
            def g(*args):subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True)
            g('init');g('config','user.name','tool-test');g('config','user.email','local@example.invalid');g('add','src/x.py');g('commit','-m','fixture')
            one=inventory(root);p.write_text('NEW=2\n');two=inventory(root)
            self.assertNotEqual(one['fingerprint'],two['fingerprint'])
            dest=Path(d)/'snapshot';freeze_sources(root,two,dest)
            self.assertEqual((dest/'src/x.py').read_text(),'NEW=2\n')
            self.assertEqual(inventory(root)['fingerprint'],two['fingerprint'])

class CollectionTests(unittest.TestCase):
    def base(self):return {'cases':[{'id':'S01','target_nodeid':'x.py::test_S01','status':'PENDING_SDK_EXECUTION'}]}
    def test_collection_never_pass(self):
        out=map_cases(self.base(),{'candidate_fingerprint':'x','nodeids':['x.py::test_S01[a]'],'collection_errors':[]})
        self.assertEqual(out['cases'][0]['status'],'PENDING_SDK_EXECUTION');self.assertEqual(out['actual_sdk_pass_count'],0)
    def test_missing_nodeid_kept_missing(self):
        out=map_cases(self.base(),{'candidate_fingerprint':'x','nodeids':[],'collection_errors':[]})
        self.assertEqual(out['cases'][0]['nodeid_status'],'NOT_COLLECTED')
    def test_collection_error_not_pass(self):
        with self.assertRaises(ValueError):map_cases(self.base(),{'candidate_fingerprint':'x','nodeids':[],'collection_errors':['error']})
    def test_identity_required(self):
        with self.assertRaises(ValueError):map_cases(self.base(),{'nodeids':[],'collection_errors':[]})
    def test_equivalent_tests_need_review(self):
        data=self.base();data['cases'][0]['nodeid_equivalence']={'nodeids':['old.py::test_old']}
        with self.assertRaises(ValueError):map_cases(data,{'candidate_fingerprint':'x','nodeids':['old.py::test_old'],'collection_errors':[]})
    def test_reviewed_equivalence_partial_is_not_complete(self):
        data=self.base();data['cases'][0]['nodeid_equivalence']={'reviewed_by':'reviewer','source_sha256':'a'*64,'candidate_fingerprint':'x','assertion_coverage':['checks all required behavior'],'nodeids':['old.py::a','old.py::b']}
        result=map_cases(data,{'candidate_fingerprint':'x','nodeids':['old.py::a'],'collection_errors':[]})
        self.assertEqual(result['cases'][0]['nodeid_status'],'PARTIALLY_COLLECTED')
        self.assertFalse(result['cases'][0]['collection_coverage_complete'])


class ManifestTests(unittest.TestCase):
    def test_42_original_ids(self):
        j=json.loads((ROOT/'sdk-nodeid-map.json').read_text());self.assertEqual(len(j['cases']),42)
        self.assertEqual(len({c['id'] for c in j['cases']}),42)
    def test_12_mutations_refer_to_existing_tests(self):
        j=json.loads((ROOT/'sdk-nodeid-map.json').read_text());m=json.loads((ROOT/'mutation-nodeid-map.json').read_text())
        by={c['id']:c for c in j['cases']};self.assertEqual(len(m['mutations']),12)
        for row in m['mutations']:self.assertEqual(row['target_test_nodeid'],by[row['required_case']]['target_nodeid'])
    def test_all_actual_nodeids_initially_unknown(self):
        for f in ('sdk-nodeid-map.json','h1h-nodeid-map.json'):
            for row in json.loads((ROOT/f).read_text())['cases']:
                self.assertEqual(row['actual_nodeids'],[]);self.assertEqual(row['status'],'PENDING_SDK_EXECUTION')
    def test_gates_do_not_enable_production(self):
        g=json.loads((ROOT/'gates.current.json').read_text());self.assertFalse(g['production_enablement_allowed'])
        self.assertTrue(g['permissions']['TG_A_OFFLINE_PREPARATION']);self.assertFalse(g['permissions']['TG_B_COMPILER_WIRING'])
    def test_source_map_no_invented_sha(self):
        s=json.loads((ROOT/'source-map.seed.json').read_text());self.assertFalse(s['source_map_complete'])
        for r in s['requirements']:self.assertIsNone(r['file_sha256'])
    def test_backup_preserves_full_table_data(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.db';q=Path(d)/'b.db'
            with sqlite3.connect(p) as c:c.execute('CREATE TABLE x(v TEXT)');c.execute('INSERT INTO x VALUES(?)',('dirty;value',))
            before=logical_fingerprint(p);backup(p,q)
            self.assertEqual(logical_fingerprint(q),before);self.assertEqual(logical_fingerprint(p),before)

class ExportTests(unittest.TestCase):
    def test_no_absolute_repo_root_export(self):
        source={'repositories':{'candidate':{'root':'/private/worktree','head':'h','branch':'b','index_digest':'i','fingerprint':'f','dirty_files':[]}},'requirements':[]}
        result=redact_source_map(source,'.local-test-evidence/run/source-map.local.json','a'*64)
        self.assertNotIn('root',result['repositories']['candidate'])
        self.assertFalse(result['source_map_complete'])
    def test_absolute_evidence_refused(self):
        with self.assertRaises(ValueError):redact_source_map({},'/private/log','a'*64)

if __name__=='__main__':unittest.main()
