"""Optional collection-only plugin. Raw result path must be local ignored evidence."""
from __future__ import annotations
import json
from pathlib import Path

def pytest_addoption(parser):
    group=parser.getgroup('taskgraph-readiness')
    group.addoption('--readiness-collection-out',default=None)
    group.addoption('--readiness-source-map',default=None)

def pytest_sessionfinish(session,exitstatus):
    out=session.config.getoption('--readiness-collection-out')
    if not out:return
    if not session.config.option.collectonly:raise RuntimeError('collection plugin requires --collect-only')
    sm=session.config.getoption('--readiness-source-map')
    if not sm:raise RuntimeError('source-map required')
    source=json.loads(Path(sm).read_text())
    fingerprint=source['repositories']['candidate']['fingerprint']
    target=Path(out).resolve();evidence=Path(sm).resolve().parent
    if not target.is_relative_to(evidence):raise RuntimeError('output outside evidence run')
    result={'candidate_fingerprint':fingerprint,'nodeids':[i.nodeid for i in session.items],
            'collection_errors':[] if int(exitstatus) in (0,5) else [f'exitstatus={int(exitstatus)}'],
            'collection_exitstatus':int(exitstatus),'sdk_tests_executed':False}
    with target.open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
