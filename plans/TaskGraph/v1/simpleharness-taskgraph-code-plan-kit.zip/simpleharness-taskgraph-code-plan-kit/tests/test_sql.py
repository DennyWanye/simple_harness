import sqlite3
import tempfile
import unittest
import subprocess
import sys
from pathlib import Path
from helpers import ROOT,H,H2,H3,connect,initialise,insert,seed,add_revision,add_pins,revision_values,attempt_values,job_values,target_values,followup_values

class SQL(unittest.TestCase):
    def setUp(self):
        self.c=connect(); initialise(self.c); seed(self.c)
    def tearDown(self): self.c.close()
    def rejects(self,fn,*args,**kwargs):
        with self.assertRaises(sqlite3.IntegrityError):fn(*args,**kwargs)
    def test_foreign_keys_and_integrity(self):
        self.assertEqual([],self.c.execute('PRAGMA foreign_key_check').fetchall())
        self.assertEqual('ok',self.c.execute('PRAGMA integrity_check').fetchone()[0])
    def test_nine_additive_tables(self):
        names=[r[0] for r in self.c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'taskgraph_%'")]
        self.assertEqual(9,len(names))
    def test_policy_immutable(self):self.rejects(self.c.execute,"UPDATE taskgraph_policy_bindings SET policy_hash=?",(H2,))
    def test_revision_immutable(self):self.rejects(self.c.execute,"UPDATE taskgraph_revision_records SET network_json='{}'")
    def test_pin_immutable(self):self.rejects(self.c.execute,"DELETE FROM taskgraph_member_pins")
    def test_child_hash_chain(self):
        add_revision(self.c,'m1',2,parent=1,parent_hash=H)
        self.assertEqual(2,self.c.execute("SELECT revision FROM plan_revisions WHERE state='ACTIVE'").fetchone()[0])
    def test_wrong_parent_hash_rejected(self):
        self.c.execute('BEGIN IMMEDIATE')
        try:self.rejects(add_revision,self.c,'m1',2,parent=1,parent_hash=H3)
        finally:self.c.execute('ROLLBACK')
        self.assertEqual(1,self.c.execute("SELECT revision FROM plan_revisions WHERE state='ACTIVE'").fetchone()[0])
    def test_cross_mission_parent_rejected(self):
        insert(self.c,'missions',mission_id='m2',tenant_id='tenant2')
        insert(self.c,'taskgraph_policy_bindings',mission_id='m2',kernel_version='taskgraph-exec-v2',policy_hash=H,policy_json='{}',enabling_command_id='enable-m2',enabling_receipt_hash=H,created_at=0.0)
        insert(self.c,'plan_revisions',mission_id='m2',revision=2,state='ACTIVE',snapshot_hash=H)
        insert(self.c,'requirements_revisions',mission_id='m2',revision=1)
        insert(self.c,'events',event_id='event-m2-2',mission_id='m2',type='TaskGraphRevisionRecorded',payload_json='{}')
        self.rejects(insert,self.c,'taskgraph_revision_records',**revision_values('m2',2,'COMMIT',1,H))
    def test_second_active_rejected(self):self.rejects(insert,self.c,'plan_revisions',mission_id='m1',revision=2,state='ACTIVE',snapshot_hash=H)
    def test_pin_hash_must_match_source(self):
        add_revision(self.c,'m1',2,parent=1,parent_hash=H,pins=False)
        self.rejects(insert,self.c,'taskgraph_member_pins',mission_id='m1',revision=2,occurrence_id='occ-m1-leaf',task_id='m1-leaf',binding_revision=1,binding_hash=H2)
    def test_pin_task_mismatch_rejected(self):
        add_revision(self.c,'m1',2,parent=1,parent_hash=H,pins=False)
        self.rejects(insert,self.c,'taskgraph_member_pins',mission_id='m1',revision=2,occurrence_id='occ-m1-leaf',task_id='m1-root',binding_revision=1,binding_hash=H)
    def test_history_not_latest(self):
        insert(self.c,'task_semantics',task_id='m1-leaf',binding_revision=2,mission_id='m1',obligation_id='obl-m1',form='primitive',input_binding_revision=2,dispatch_generation=2,content_hash=H2,binding_json='{"marker":"new"}')
        old=self.c.execute('SELECT s.binding_json FROM taskgraph_member_pins p JOIN task_semantics s ON s.task_id=p.task_id AND s.binding_revision=p.binding_revision WHERE p.mission_id=? AND p.revision=? AND p.occurrence_id=?',('m1',1,'occ-m1-leaf')).fetchone()[0]
        self.assertEqual('{"marker":"original"}',old)
    def test_history_adoption_not_current_state(self):
        self.c.execute("UPDATE method_instances SET state='RETIRED'")
        self.assertEqual(1,self.c.execute('SELECT adopted FROM taskgraph_method_pins').fetchone()[0])
    def test_two_adopted_per_goal_rejected(self):
        insert(self.c,'method_instances',mission_id='m1',instance_id='mi-other',goal_occurrence_id='occ-m1-root',state='ADOPTED',draft_json='{}')
        self.rejects(insert,self.c,'taskgraph_method_pins',mission_id='m1',revision=1,instance_id='mi-other',goal_occurrence_id='occ-m1-root',adopted=1,draft_hash=H)
    def test_demand_source_slot_strict(self):
        add_revision(self.c,'m1',2,parent=1,parent_hash=H,pins=False)
        insert(self.c,'taskgraph_method_pins',mission_id='m1',revision=2,instance_id='mi-m1',goal_occurrence_id='occ-m1-root',adopted=1,draft_hash=H)
        self.rejects(insert,self.c,'taskgraph_demand_refs',mission_id='m1',revision=2,consumer_instance_id='mi-m1',slot_key='leaf',slot_occurrence_id='occ-m1-leaf',producer_occurrence_id='occ-m1-root',obligation_id='obl-m1',mode='new_work',requiredness='required',source_slot_hash=H)
    def test_attempt_actual_identity(self):
        insert(self.c,'taskgraph_attempt_inputs',**attempt_values(self.c))
        self.assertEqual(1,self.c.execute('SELECT count(*) FROM taskgraph_attempt_inputs').fetchone()[0])
    def test_repeated_attempts_same_manifest_supported(self):
        insert(self.c,'taskgraph_attempt_inputs',**attempt_values(self.c,n=1))
        insert(self.c,'taskgraph_attempt_inputs',**attempt_values(self.c,n=2))
        self.assertEqual(2,self.c.execute('SELECT count(*) FROM taskgraph_attempt_inputs').fetchone()[0])
        self.assertEqual(1,self.c.execute('SELECT count(*) FROM input_manifests').fetchone()[0])
    def test_attempt_wrong_input_hash(self):
        values=attempt_values(self.c);values['frozen_input_hash']=H2
        self.rejects(insert,self.c,'taskgraph_attempt_inputs',**values)
    def test_attempt_wrong_generation(self):
        values=attempt_values(self.c);values['dispatch_generation']=2
        self.rejects(insert,self.c,'taskgraph_attempt_inputs',**values)
    def test_attempt_wrong_plan_admission_check(self):
        insert(self.c,'planning_admission_checks',check_id='other',request_id='req-m1',phase='APPLIED')
        values=attempt_values(self.c);values['admission_check_id']='other'
        self.rejects(insert,self.c,'taskgraph_attempt_inputs',**values)
    def test_attempt_no_blank_admission_check(self):
        values=attempt_values(self.c);values['admission_check_id']=None
        self.rejects(insert,self.c,'taskgraph_attempt_inputs',**values)
    def test_baseline_explicit_source_not_fake_pass(self):
        c=connect();initialise(c);seed(c,baseline=True)
        insert(c,'taskgraph_attempt_inputs',**attempt_values(c,baseline=True));c.close()
    def test_record_wrong_event_mission(self):
        insert(self.c,'events',event_id='foreign',mission_id='other',type='TaskGraphRevisionRecorded',payload_json='{}')
        add_revision(self.c,'m1',2,parent=1,parent_hash=H,pins=False)
        # Existing revision uniqueness would also fail, so use new revision3 parent2.
        insert(self.c,'plan_revisions',mission_id='m1',revision=3,state='PREPARED',snapshot_hash=H)
        values=revision_values('m1',3,'COMMIT',2,H2);values['event_id']='foreign'
        with self.assertRaisesRegex(sqlite3.IntegrityError,'TG_REVISION_EVENT_MISMATCH'):insert(self.c,'taskgraph_revision_records',**values)
    def test_convergence_exact_target(self):
        insert(self.c,'taskgraph_convergence_jobs',**job_values())
        values=target_values();values['task_id']='m1-root'
        self.rejects(insert,self.c,'taskgraph_convergence_targets',**values)
    def test_convergence_cas_and_legal_transition(self):
        insert(self.c,'taskgraph_convergence_jobs',**job_values())
        q='UPDATE taskgraph_convergence_jobs SET state=?,row_version=row_version+1 WHERE job_id=? AND row_version=? AND state=?'
        self.assertEqual(1,self.c.execute(q,('WAITING','job-m1',1,'FENCED')).rowcount)
        self.assertEqual(0,self.c.execute(q,('WAITING','job-m1',1,'FENCED')).rowcount)
        self.assertEqual(1,self.c.execute(q,('READY','job-m1',2,'WAITING')).rowcount)
        self.assertEqual(1,self.c.execute(q,('APPLIED','job-m1',3,'READY')).rowcount)
        self.rejects(self.c.execute,q,('WAITING','job-m1',4,'APPLIED'))
    def test_convergence_cannot_apply_directly(self):
        insert(self.c,'taskgraph_convergence_jobs',**job_values())
        self.rejects(self.c.execute,"UPDATE taskgraph_convergence_jobs SET state='APPLIED',row_version=2 WHERE job_id='job-m1'")
    def test_ready_still_fenced(self):
        insert(self.c,'taskgraph_convergence_jobs',**job_values());insert(self.c,'taskgraph_convergence_targets',**target_values())
        self.c.execute("UPDATE taskgraph_convergence_jobs SET state='READY',row_version=2")
        q="SELECT count(*) FROM taskgraph_convergence_targets t JOIN taskgraph_convergence_jobs j ON t.job_id=j.job_id WHERE t.task_id=? AND j.state IN ('FENCED','WAITING','READY')"
        self.assertEqual(1,self.c.execute(q,('m1-leaf',)).fetchone()[0])
    def test_followup_cannot_ack_unclaimed(self):
        insert(self.c,'taskgraph_followups',**followup_values())
        self.rejects(self.c.execute,"UPDATE taskgraph_followups SET delivery_state='ACKED',row_version=2")
    def test_followup_claim_then_ack(self):
        insert(self.c,'taskgraph_followups',**followup_values())
        self.c.execute("UPDATE taskgraph_followups SET delivery_state='LEASED',lease_owner='worker1',lease_until_ms=1000,attempts=1,row_version=2")
        cur=self.c.execute("UPDATE taskgraph_followups SET delivery_state='ACKED',consumer_receipt_json='{}',lease_owner=NULL,lease_until_ms=NULL,row_version=3 WHERE lease_owner='worker1' AND row_version=2")
        self.assertEqual(1,cur.rowcount)
    def test_followup_wrong_event_owner(self):
        insert(self.c,'events',event_id='foreign',mission_id='m2',type='x',payload_json='{}')
        v=followup_values();v['source_event_id']='foreign';self.rejects(insert,self.c,'taskgraph_followups',**v)
    def test_write_failure_rolls_back_plan_and_event(self):
        self.c.execute('BEGIN IMMEDIATE')
        try:
            add_revision(self.c,'m1',2,parent=1,parent_hash=H)
            raise RuntimeError('fault before final commit')
        except RuntimeError:self.c.execute('ROLLBACK')
        self.assertEqual(1,self.c.execute('SELECT count(*) FROM taskgraph_revision_records').fetchone()[0])
        self.assertEqual(1,self.c.execute('SELECT count(*) FROM events').fetchone()[0])
        self.assertEqual(1,self.c.execute("SELECT revision FROM plan_revisions WHERE state='ACTIVE'").fetchone()[0])

class ProcessSQL(unittest.TestCase):
    def test_two_connections_observe_stale_cas(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.db';a=connect(path);initialise(a);seed(a);insert(a,'taskgraph_convergence_jobs',**job_values());b=connect(path)
            expected=b.execute('SELECT row_version FROM taskgraph_convergence_jobs').fetchone()[0]
            a.execute('BEGIN IMMEDIATE');a.execute("UPDATE taskgraph_convergence_jobs SET state='WAITING',row_version=2 WHERE row_version=1");a.execute('COMMIT')
            b.execute('BEGIN IMMEDIATE');n=b.execute("UPDATE taskgraph_convergence_jobs SET state='READY',row_version=row_version+1 WHERE row_version=?",(expected,)).rowcount;b.execute('COMMIT')
            self.assertEqual(0,n);a.close();b.close()
    def test_process_exit_before_commit_rolls_back(self): self.run_fault(False)
    def test_process_exit_after_commit_preserves_receipt_source(self): self.run_fault(True)
    def run_fault(self,commit):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.db';c=connect(path);initialise(c);seed(c);c.close()
            code="""import sys,os
sys.path.insert(0,sys.argv[2])
from helpers import connect,add_revision,H
c=connect(sys.argv[1]);c.execute('BEGIN IMMEDIATE')
add_revision(c,'m1',2,parent=1,parent_hash=H)
if sys.argv[3]=='yes': c.execute('COMMIT')
os._exit(31)
"""
            p=subprocess.run([sys.executable,'-c',code,str(path),str(ROOT/'tests'),'yes' if commit else 'no'],capture_output=True,timeout=10)
            self.assertEqual(31,p.returncode,p.stderr.decode())
            c=connect(path);expected=2 if commit else 1
            self.assertEqual(expected,c.execute('SELECT count(*) FROM taskgraph_revision_records').fetchone()[0])
            self.assertEqual(expected,c.execute("SELECT revision FROM plan_revisions WHERE state='ACTIVE'").fetchone()[0])
            self.assertEqual([],c.execute('PRAGMA foreign_key_check').fetchall());c.close()
