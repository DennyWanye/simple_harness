"""Stateless semantic service mapped only to public Harness APIs."""

from __future__ import annotations

import asyncio
import secrets
import time
from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Protocol, TypeVar

from simple_harness import (
    AgentIdentity,
    CancelCommandIntent,
    CommandError,
    CommandErrorCode,
    ContinueCommandIntent,
    ConversationContinuationInput,
    ConversationTurnInput,
    Message,
    MessageRole,
    RequestId,
    RunId,
    StartCommandIntent,
)
from simple_harness import (
    CommandReceipt as HarnessCommandReceipt,
)
from simple_harness import (
    CommandSnapshot as HarnessCommandSnapshot,
)

from .auth import AuthenticatedContext
from .contracts import (
    CancelRequest,
    CommandKind,
    CommandOutcome,
    CommandReceipt,
    CommandSnapshot,
    CommandState,
    ContinueRequest,
    GetRequest,
    HealthSnapshot,
    OutputState,
    RunState,
    ServiceError,
    ServiceErrorCode,
    StartRequest,
)
from .identity import IdentityProjector, Principal
from .operation_audit import (
    ServiceAdmissionObservation,
    ServiceCommandReceiptRef,
    ServiceObservationCode,
    ServiceOperation,
    ServiceOperationObservation,
    ServiceOperationPhase,
    ServiceOperationRecorder,
)
from .run_audit import RunAuditRequest, validate_run_audit

T = TypeVar("T")
R = TypeVar("R", StartRequest, ContinueRequest, GetRequest, CancelRequest)


@dataclass
class _ObservedAttempt:
    recorder: ServiceOperationRecorder
    operation: ServiceOperation
    owner_ref: str
    attempt_id: str
    started_ns: int
    command_ref: str | None = None
    run_ref: str | None = None
    dispatched: bool = False
    code: ServiceObservationCode | None = None
    command_error_code: CommandErrorCode | None = None
    service_error_code: ServiceErrorCode | None = None

    def emit(
        self,
        phase: ServiceOperationPhase,
        receipt: ServiceCommandReceiptRef | None = None,
        code: ServiceObservationCode | None = None,
    ) -> None:
        admission = (
            ServiceAdmissionObservation.UNKNOWN
            if self.dispatched
            else ServiceAdmissionObservation.NOT_DISPATCHED
        )
        if receipt is not None:
            admission = ServiceAdmissionObservation.RECEIPT_OBSERVED
            self.run_ref = receipt.run_id
        self.recorder.emit(
            ServiceOperationObservation(
                self.attempt_id,
                self.owner_ref,
                self.command_ref,
                self.run_ref,
                self.operation,
                phase,
                admission,
                max(0, (time.monotonic_ns() - self.started_ns) // 1_000_000),
                receipt,
                code,
                command_error_code=self.command_error_code,
                service_error_code=self.service_error_code,
            )
        )


_attempt: ContextVar[_ObservedAttempt | None] = ContextVar("service_observed_attempt", default=None)


class _PublicRunState(Protocol):
    value: str


class _PublicRunRecord(Protocol):
    state: _PublicRunState


class PublicRunClient(Protocol):
    async def submit_start(self, intent: StartCommandIntent) -> HarnessCommandReceipt: ...
    async def submit_continue(self, intent: ContinueCommandIntent) -> HarnessCommandReceipt: ...
    async def submit_cancel(self, intent: CancelCommandIntent) -> HarnessCommandReceipt: ...
    async def get_command(self, command_id: str) -> HarnessCommandSnapshot: ...
    def query(self, run_id: RunId) -> _PublicRunRecord | None: ...


class HarnessAdapter:
    """The sole translation point to the four public durable command methods."""

    def __init__(
        self,
        client: PublicRunClient,
        *,
        health: Callable[[], Awaitable[HealthSnapshot]],
    ) -> None:
        self._client = client
        self._health = health

    async def health(self) -> HealthSnapshot:
        return await self._health()

    async def submit_start(self, intent: StartCommandIntent) -> CommandReceipt:
        return _receipt(await self._client.submit_start(intent))

    async def submit_continue(self, intent: ContinueCommandIntent) -> CommandReceipt:
        return _receipt(await self._client.submit_continue(intent))

    async def submit_cancel(self, intent: CancelCommandIntent) -> CommandReceipt:
        return _receipt(await self._client.submit_cancel(intent))

    async def read_run_operation_audit(self, run_id: RunId, *, limit: int = 256) -> object:
        reader = getattr(self._client, "read_run_operation_audit", None)
        if not callable(reader):
            raise ServiceError(ServiceErrorCode.UNAVAILABLE, "audit_reader_unavailable")
        try:
            return await reader(run_id, limit=limit)
        except Exception:
            # The optional SDK reader may be absent for a store or Run. Never
            # export its arbitrary exception text through the service boundary.
            raise ServiceError(ServiceErrorCode.UNAVAILABLE, "audit_reader_unavailable") from None

    async def get_command(self, command_id: str) -> CommandSnapshot:
        snapshot = await self._client.get_command(command_id)
        output_text = None
        if snapshot.output is not None:
            output_text = snapshot.output.memory_text
            if output_text is None and isinstance(snapshot.output.message.content, str):
                output_text = snapshot.output.message.content
        run = self._client.query(snapshot.receipt.run_id)
        run_state = None if run is None else RunState(run.state.value)
        output_state = OutputState(snapshot.output_state.value)
        command_state = CommandState(snapshot.receipt.state.value)
        return CommandSnapshot(
            _receipt(snapshot.receipt),
            output_state,
            output_text,
            None if snapshot.error_code is None else snapshot.error_code.value,
            run_state,
            _closed_outcome(
                command_state,
                output_state,
                run_state,
                CommandKind(snapshot.receipt.kind.value),
            ),
        )


class ServiceAdapterPort(Protocol):
    async def health(self) -> HealthSnapshot: ...
    async def submit_start(self, intent: StartCommandIntent) -> CommandReceipt: ...
    async def submit_continue(self, intent: ContinueCommandIntent) -> CommandReceipt: ...
    async def submit_cancel(self, intent: CancelCommandIntent) -> CommandReceipt: ...
    async def get_command(self, command_id: str) -> CommandSnapshot: ...


class HarnessService:
    """Command facade with bounded metadata; all durable lifecycle remains in Harness."""

    def __init__(
        self,
        adapter: ServiceAdapterPort,
        projector: IdentityProjector,
        *,
        operation_recorder: ServiceOperationRecorder | None = None,
    ) -> None:
        self._adapter = adapter
        self._projector = projector
        self.operation_recorder = (
            operation_recorder if operation_recorder is not None else ServiceOperationRecorder()
        )

    async def health(self) -> HealthSnapshot:
        return await self._adapter.health()

    async def read_run_operation_audit(
        self, request: RunAuditRequest, context: AuthenticatedContext
    ) -> object:
        if type(request) is not RunAuditRequest:
            raise ServiceError(ServiceErrorCode.INVALID_REQUEST)
        run_id = self._id("run", context.principal, request.external_run_id)
        reader = getattr(self._adapter, "read_run_operation_audit", None)
        if not callable(reader):
            raise ServiceError(ServiceErrorCode.UNAVAILABLE, "audit_reader_unavailable")
        try:
            snapshot = await reader(RunId(run_id), limit=request.limit)
            return validate_run_audit(snapshot, run_id=run_id, limit=request.limit)
        except ServiceError:
            raise
        except Exception:
            raise ServiceError(ServiceErrorCode.UNAVAILABLE, "audit_reader_unavailable") from None

    async def start(self, request: StartRequest, context: AuthenticatedContext) -> CommandReceipt:
        return await self._observe(ServiceOperation.START, request, context, self._start)

    async def continue_(
        self, request: ContinueRequest, context: AuthenticatedContext
    ) -> CommandReceipt:
        return await self._observe(ServiceOperation.CONTINUE, request, context, self._continue)

    async def get(self, request: GetRequest, context: AuthenticatedContext) -> CommandSnapshot:
        return await self._observe(ServiceOperation.GET, request, context, self._get)

    async def cancel(self, request: CancelRequest, context: AuthenticatedContext) -> CommandReceipt:
        return await self._observe(ServiceOperation.CANCEL, request, context, self._cancel)

    async def _observe(
        self,
        operation: ServiceOperation,
        request: R,
        context: AuthenticatedContext,
        call: Callable[[R, AuthenticatedContext], Awaitable[T]],
    ) -> T:
        observed = _ObservedAttempt(
            self.operation_recorder,
            operation,
            self._id("audit-owner", context.principal, "owner"),
            "svc_attempt_" + secrets.token_hex(16),
            time.monotonic_ns(),
        )
        observed.emit(ServiceOperationPhase.STARTED)
        token = _attempt.set(observed)
        try:
            expected = {
                ServiceOperation.START: StartRequest,
                ServiceOperation.CONTINUE: ContinueRequest,
                ServiceOperation.GET: GetRequest,
                ServiceOperation.CANCEL: CancelRequest,
            }[operation]
            if type(request) is not expected:
                observed.code = ServiceObservationCode.INVALID_REQUEST
                raise ServiceError(ServiceErrorCode.INVALID_REQUEST)
            observed.command_ref = self._id(
                "command", context.principal, request.external_command_id
            )
            if not isinstance(request, GetRequest):
                observed.run_ref = self._id("run", context.principal, request.external_run_id)
            result = await call(request, context)
            receipt = self._observed_receipt(result, observed)
            observed.emit(
                ServiceOperationPhase.RETURNED,
                receipt,
                None if receipt else ServiceObservationCode.RECEIPT_LINKAGE_UNAVAILABLE,
            )
            return result
        except asyncio.CancelledError:
            observed.emit(
                ServiceOperationPhase.UNKNOWN
                if observed.dispatched
                else ServiceOperationPhase.REJECTED,
                code=ServiceObservationCode.CANCELLED,
            )
            raise
        except ServiceError as error:
            observed.service_error_code = error.code
            observed.emit(
                ServiceOperationPhase.REJECTED,
                code=observed.code or ServiceObservationCode.SERVICE_ERROR,
            )
            raise
        except Exception:
            observed.emit(
                ServiceOperationPhase.UNKNOWN
                if observed.dispatched
                else ServiceOperationPhase.REJECTED,
                code=ServiceObservationCode.UNEXPECTED_ERROR,
            )
            raise
        finally:
            _attempt.reset(token)

    @staticmethod
    def _observed_receipt(
        result: object, observed: _ObservedAttempt
    ) -> ServiceCommandReceiptRef | None:
        value = result.receipt if type(result) is CommandSnapshot else result
        if (
            type(value) is not CommandReceipt
            or value.command_id != observed.command_ref
            or (observed.run_ref is not None and value.run_id != observed.run_ref)
            or (
                observed.operation is not ServiceOperation.GET
                and value.kind.value != observed.operation.value
            )
        ):
            return None
        try:
            return ServiceCommandReceiptRef(
                value.command_id,
                value.run_id,
                value.accept_seq,
                value.version,
                value.kind,
                value.state,
            )
        except (TypeError, ValueError):
            return None

    async def _start(self, request: StartRequest, context: AuthenticatedContext) -> CommandReceipt:
        p = context.principal
        session_id = self._id("session", p, request.external_session_id)
        run_id = self._id("run", p, request.external_run_id)
        command_id = self._id("command", p, request.external_command_id)
        turn_id = self._id("turn", p, request.external_command_id)
        conversation = ConversationTurnInput(
            AgentIdentity(
                p.deployment_id,
                p.household_id,
                p.actor_id,
                session_id,
            ),
            Message(MessageRole.USER, request.message),
            request.message,
        )
        try:
            intent = StartCommandIntent(
                self._projector.namespace,
                self._projector.key_id,
                command_id,
                RunId(run_id),
                RequestId(self._id("request", p, request.external_command_id)),
                turn_id,
                conversation,
                request.profile_key,
            )
        except CommandError as error:
            observed = _attempt.get()
            if observed is not None:
                observed.code = ServiceObservationCode.COMMAND_ERROR
                observed.command_error_code = error.code
            raise _mapped_command_error(error) from None
        return await self._call(self._adapter.submit_start, intent)

    async def _continue(
        self, request: ContinueRequest, context: AuthenticatedContext
    ) -> CommandReceipt:
        p = context.principal
        try:
            intent = ContinueCommandIntent(
                self._projector.namespace,
                self._projector.key_id,
                self._id("command", p, request.external_command_id),
                RunId(self._id("run", p, request.external_run_id)),
                self._id("continuation", p, request.external_continuation_id),
                self._id("turn", p, request.external_command_id),
                ConversationContinuationInput(
                    Message(MessageRole.USER, request.message), request.message
                ),
            )
        except CommandError as error:
            observed = _attempt.get()
            if observed is not None:
                observed.code = ServiceObservationCode.COMMAND_ERROR
                observed.command_error_code = error.code
            raise _mapped_command_error(error) from None
        return await self._call(self._adapter.submit_continue, intent)

    async def _get(self, request: GetRequest, context: AuthenticatedContext) -> CommandSnapshot:
        return await self._call(
            self._adapter.get_command,
            self._id("command", context.principal, request.external_command_id),
        )

    async def _cancel(
        self, request: CancelRequest, context: AuthenticatedContext
    ) -> CommandReceipt:
        p = context.principal
        intent = CancelCommandIntent(
            self._projector.namespace,
            self._projector.key_id,
            self._id("command", p, request.external_command_id),
            RunId(self._id("run", p, request.external_run_id)),
        )
        return await self._call(self._adapter.submit_cancel, intent)

    def _id(self, kind: str, principal: Principal, external_id: str) -> str:
        return self._projector.project(kind, principal, external_id)

    @staticmethod
    async def _call(call: Callable[..., Awaitable[T]], *args: object) -> T:
        observed = _attempt.get()
        if observed is not None:
            observed.dispatched = True
            observed.emit(ServiceOperationPhase.DISPATCHED)
        try:
            return await call(*args)
        except CommandError as error:
            if observed is not None:
                observed.code = ServiceObservationCode.COMMAND_ERROR
                observed.command_error_code = error.code
            raise _mapped_command_error(error) from None


def _receipt(value: HarnessCommandReceipt) -> CommandReceipt:
    return CommandReceipt(
        command_id=value.command_id,
        run_id=value.run_id.value,
        accept_seq=value.accept_seq,
        state=CommandState(value.state.value),
        version=value.version,
        kind=CommandKind(value.kind.value),
    )


def _mapped_command_error(error: CommandError) -> ServiceError:
    mapping = {
        CommandErrorCode.NOT_FOUND: ServiceErrorCode.NOT_FOUND,
        CommandErrorCode.INTENT_CONFLICT: ServiceErrorCode.CONFLICT,
        CommandErrorCode.RUN_MODE_CONFLICT: ServiceErrorCode.CONFLICT,
        CommandErrorCode.NAMESPACE_KEY_CONFLICT: ServiceErrorCode.CONFLICT,
        CommandErrorCode.CANCEL_FENCE: ServiceErrorCode.CONFLICT,
        CommandErrorCode.PAYLOAD_TOO_LARGE: ServiceErrorCode.PAYLOAD_TOO_LARGE,
        CommandErrorCode.TRANSIENT_FAILURE: ServiceErrorCode.UNAVAILABLE,
        CommandErrorCode.RETRY_EXHAUSTED: ServiceErrorCode.UNAVAILABLE,
        CommandErrorCode.PERMANENT_FAILURE: ServiceErrorCode.INVALID_REQUEST,
    }
    return ServiceError(mapping[error.code], error.code.value)


def _closed_outcome(
    command_state: CommandState,
    output_state: OutputState,
    run_state: RunState | None,
    command_kind: CommandKind | None = None,
) -> CommandOutcome:
    if command_state in {
        CommandState.ACCEPTED,
        CommandState.CONTEXT_CALL_INTENT,
        CommandState.CONTEXT_READY,
    }:
        return CommandOutcome.PENDING
    if output_state is OutputState.UNKNOWN:
        return CommandOutcome.PROTOCOL_ERROR
    if output_state is OutputState.PRESENT:
        return (
            CommandOutcome.COMPLETED
            if run_state is RunState.COMPLETED
            else CommandOutcome.PROTOCOL_ERROR
        )
    if output_state is OutputState.PENDING:
        if run_state in {RunState.COMPLETED, RunState.FAILED, RunState.CANCELLED}:
            return CommandOutcome.PROTOCOL_ERROR
        return CommandOutcome.PENDING
    if (
        command_kind is CommandKind.CANCEL
        and command_state is CommandState.APPLIED
        and output_state is OutputState.ABSENT
        and run_state is None
    ):
        return CommandOutcome.CANCELLED
    if (
        command_kind in {CommandKind.START, CommandKind.CONTINUE}
        and command_state is CommandState.APPLIED
        and output_state is OutputState.ABSENT
        and run_state is None
    ):
        return CommandOutcome.PROTOCOL_ERROR
    if run_state is RunState.FAILED or command_state is CommandState.REJECTED:
        return CommandOutcome.FAILED
    if run_state is RunState.CANCELLED or command_state is CommandState.CANCELLED:
        return CommandOutcome.CANCELLED
    if run_state is RunState.COMPLETED:
        return CommandOutcome.COMPLETED
    return CommandOutcome.PENDING
