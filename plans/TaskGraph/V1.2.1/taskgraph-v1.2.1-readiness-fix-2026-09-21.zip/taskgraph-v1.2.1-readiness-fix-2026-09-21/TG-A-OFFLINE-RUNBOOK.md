> **历史合同/参考说明。V1.2.1 的执行顺序、参数化映射、runner补丁与C-proof许可，以 `V1.2.1-READINESS-AMENDMENT-2026-09-21.md` 和本包 STATE-GATES.md 为准；原业务语义、42/36case与断言不删。**

> **TG-READY-1.1 适用说明：**先读本包 `V1.1-PREP-CLOSURE-2026-09-21.md`。以下保留原规格；入口名称允许有证明的合同等价；当前仅 TG-A-prep。未完成 gate 以最新 `gates.current.json`/用户 handoff 为准。

# TG-A-prep：逐文件清单与可复制命令

**当前只准离线准备，不准打开TaskGraph或写生产库。**这份runbook替代TG-EXEC-2.0 §15.1中的系统`python`命令，不改变DDL/Schema。

## 1. 修改与输出范围

| 位置 | 当前可以做什么 | 不可以做什么 |
|---|---|---|
| 本 readiness 包 `tools/` | 运行只读采集、精确输入定位、隔离migration probe、nodeid绑定 | 调SDK业务入口/启用生产 |
| Host ignored `.local-test-evidence/…` | 源码快照、原始日志/JUnit、SQLite隔离库、工具输出 | 自动Git add或发布 |
| Host plans 文档目录 | 审阅后保存本交接、矩阵、无敏感summary/相对索引/hash | 复制raw logs/screenshots/db |
| 候选 `storage/schema.py/taskgraph_schema.py` | 只读接口/编号核对；拟议注册patch先在ignored副本评估 | 当前直接注册新迁移到dirty候选或生产 |
| 候选 `storage/store.py` | 核查真实runner，离线触发器smoke；有问题提出TG-A-RUNNER-01 | 自动改成executescript、删除trigger、修改旧checksum |
| H1-H producer文件 | source-map与测试核对，由原H1工作流实施 | TG-A填默认值越过H1 |
| 测试文件 | 固定target nodeid、复用映射与fixtures设计；离线运行已存在的合法fixture | 创建固定PASS壳或required skip |

## 2. 设置项目环境（从本包解压目录执行）

```bash
set -euo pipefail
OPT="$(pwd -P)"
SDK="/Users/denny/projects/simple-harness-sdk-h1h-impl"
SDK_MAIN="/Users/denny/projects/simple-harness-sdk"
HOST="/Users/denny/projects/simple_harness"
PY="$SDK/.venv/bin/python"
[ -x "$PY" ] || { printf '%s\n' 'BLOCKED: 候选project .venv不存在。不要用系统python或自动安装依赖。'; exit 2; }
RUN="$(TZ=Asia/Shanghai date +%Y%m%dT%H%M%S)-$$"
EVID="$HOST/.local-test-evidence/2026-09-21/taskgraph/$RUN"
export PYTHONDONTWRITEBYTECODE=1
# 不修改 .gitignore / .git/info/exclude；不忽略就先停止并交维护者处理。
git -C "$HOST" check-ignore -q "$EVID" || { printf '%s\n' 'BLOCKED: 原始证据目录未被Git忽略'; exit 2; }
[ -f "$OPT/source-requirements.json" ] && [ -f "$OPT/metadata/input-manifest.json" ]
```

若项目使用uv而未直接访问 `.venv/bin/python`，所有后续Python调用替换为**在候选目录**执行 `uv run --frozen --no-sync --group dev python`。不得为本次预检执行`uv sync/pip install`；项目环境缺依赖是环境阻塞，不是业务测试失败。

## 3. 采集真实候选、主线和Host（只读）

```bash
"$PY" "$OPT/tools/capture_sources.py" \
  --candidate "$SDK" --sdk-main "$SDK_MAIN" --host "$HOST" \
  --expected-head 102ad3dfa2db38d575ea929d39ec5ed1561a71da \
  --requirements "$OPT/source-requirements.json" \
  --equivalences "$OPT/equivalences.json" \
  --out "$EVID"
```

输出：`source-map.local.json`和`snapshot/sdk/`。缺失H1符号会如实列出，不会妨碍保存此次完整盘点；HEAD不符/采集中源码变化则退出3，不能继续用该快照。

**SOURCE_MAP_COMPLETE不会被脚本自动打开。**逐项审阅producer身份/SQL键/等价函数、将缺失项关联H1H任务，保存 `source-map.review.json`。未来NEW目标可以声明尚未实现；H1前置MISSING不能靠声明NEW消除。

后续SDK测试依据 `HEAD + controlled source hashes + index digest + dirty inventory`，不能只用`102ad3d`识别代码。snapshot中的dirty文件不会被reset成HEAD。

## 4. 精确定位输入资料包（按文件名和hash，不猜版本）

```bash
"$PY" "$OPT/tools/stage_taskgraph_input.py" \
  --search-root "$HOST/plans" \
  --input-manifest "$OPT/metadata/input-manifest.json" \
  --source-map "$EVID/source-map.local.json" \
  --out "$EVID/inputs"
KIT="$EVID/inputs/simpleharness-taskgraph-code-plan-kit"
```

找不到完全相同hash就停止。原zip在别处时只把`--search-root`指向已知存放目录；不下载新版替代。不修改原资料包。解压内含原reference日志，它们留在ignored evidence，不得整体拷入Git。

## 5. 真实SDK migration runner核对

历史参考入口为：

```text
agent_orchestrator.storage.store.Store.open(path)
  → Store._initialize_or_validate()
  → Store._apply_migration(connection, Migration)
  → schema.MIGRATIONS
```

必须以本地AST/source-map核实。若实际入口已换名，以review过的精确等价路径实现一个离线adapter；不得退回`executescript(TG_DDL)`并称作真实runner。

本轮runner风险：原TG DDL有25个trigger，历史runner `.split(';')` 会切碎trigger。先运行真实runner的trigger smoke，不修改候选也不替换runner。`reference/sql_statement_iterator.py`只是修复提案参考。

## 6. 在完整SDK schema的全新隔离库运行预检

```bash
"$PY" "$OPT/tools/offline_sdk_migration_probe.py" \
  --source-map "$EVID/source-map.local.json" \
  --kit "$KIT" \
  --parent-contract "$OPT/metadata/parent-contract-checks.json" \
  --out "$EVID/migration-probe"
```

脚本仅从已冻结的真实候选导入SDK，验证模块未从已装旧wheel误导入。它使用**真实Store.open**创建完整现有schema，从SQLite backup产生隔离复制库；不接受任意生产数据库参数。

它依次做：

| 次序 | 输入/动作 | 输出/通过条件 |
|---|---|---|
| TA01 | 当前候选锁文件、模块路径、Migration清单 | 本地identity、runner路径、每版name/checksum、完整链hash |
| TA02 | 实际Store.open创建`base-full-schema.sqlite3` | 真实全部已注册迁移通过；不是测试parent_fixture |
| TA03 | PRAGMA核对现有父表/列 | H1H四表及TG所需旧表均真实存在；缺失列精确列出 |
| TA04 | base复制库追加专用trigger smoke，调用原runner | trigger完整执行且确实拒绝非法插入；不只看CREATE成功 |
| TA05 | 本地最大migration+1、原TG DDL hash | 当前进程临时组装Migration描述符，不改schema.py、不占生产编号 |
| TA06 | Store.open新建full target与升级base复制库 | 新建/升级sqlite_master一致，原表逻辑内容不变 |
| TA07 | 升级库再次Store.open | 无重复迁移/表/事件；checkums与描述符一致 |
| TA08 | DDL尾部加入受控失败，调用原runner | 全部新schema共同回滚，原schema和数据hash不变 |
| TA09 | 本地副本旧checksum改坏 | runner明确拒绝，不能自动改正或继续迁移 |
| TA10 | foreign_key_check/integrity_check与缺Mission插入 | 完整性ok；FK真实拒绝非法记录；无生产业务数据 |

**任何H1H父表缺失：**TA03记录BLOCKED，允许TA04的隔离runner-smoke继续定位问题，但不进入TG完整新增DDL验证。禁止自动拼接H1H参考DDL、创建假父表或填假的grant/check数据。

退出0只表示 `OFFLINE_DESCRIPTOR_PROBE_PASS`。它**不等于注册到真实源码的迁移通过、不等于旧业务数据保持通过、不等于C06/C07全部PASS**。报告为这些项目保留PENDING。

## 7. 三个容易混淆的schema口径

1. **Current candidate full schema**：完整本地MIGRATIONS实跑，包含实际已注册H1H/NanoJev迁移。
2. **Offline candidate descriptor**：真实runner + 完整base + 进程内临时追加TG描述符。可提前暴露DDL/runner兼容问题，不能声称TG已注册。
3. **Registered source migration**：未来获准代码片把TG DDL注册进实际schema后，重新冻结source，直接原Store.open（不注入描述符），在真实populated legacy fixture与升级库完成C06。

如果TG表已存在但checksum/描述符不完全匹配，不重复CREATE，不重编号盲追加；报告冲突并核对实际来源。

## 8. 编号、checksum和组合迁移

- 从本地完整`schema.MIGRATIONS`和实际测试库`orch_schema_migrations`核对，不用远端“当前最大版本”。
- 新编号 = 本轮一致清单max+1；将基础链hash、DDL hash、提议编号写入报告。这个值不是跨团队永久预约。
- H1H/NanoJev抢先增加迁移后，旧候选编号失效；重新采集，显式决定新编号，旧checksum不可修改。
- TaskGraph代码最终注册前，H1H四表真实DDL必须已经注册并验证。H1H参考SQL＋TG SQL在一个parent fixture通过，不解除此要求。
- 不执行down migration。失败rollback=同一升级事务没提交时撤销；已成功升级需要恢复时使用完整schema副本/受控备份流程，而不是DROP九表“回滚”。

## 9. 若runner不支持trigger：条件式窄修复

当前只允许在ignored隔离源码副本构造`TG-A-RUNNER-01`拟议patch：

```python
# 提案；不是脚本已经改了SDK。
for statement in iter_sql_statements(migration.ddl):
    connection.execute(statement)
```

`iter_sql_statements`保持trigger整体、引号/注释内分号，尾部不完整时报错。`migration.ddl`原字节不变，旧checksum不变；保留原Store.transaction，不加内部commit，不使用executescript规避失败。

验证必须覆盖：每个旧Migration与新splitter兼容；新trigger多语句完整执行；string/comment分号；升级中途错误全回滚；真实子进程退出后不留下半迁移；已应用checksum逐项不变。仅在这些检查与独立核验后，另行准许将该极小patch接回候选。这不是本轮授权直接编辑dirty worktree。

## 10. 真实旧数据与C06/C07：不能编造fixture

在已有SDK测试目录定位项目真实的legacy创建fixture，记录实际qualified fixture/function、文件hash和pytest nodeid。通过原Store/Commit创建至少两个Mission与Task、结果/产物、事件和预算预留；源库由该fixture生成并留在ignored目录，保存producer回执。

升级前后比较旧行canonical bytes、旧Event payload/idempotency keys、旧migration checksums、预算facts/holds、默认kernel OFF。不得只比较空库的行数。创建与迁移在离线隔离库，绝不对生产.db试验。

C07还需实际Method/plan/Attempt/InputManifest等fixture，测试错Mission pins/source event/admission check/job target。TG-A当前可规划并测试相关FK机制；**完整C07在H1/图接线具备后执行，不能提前关闭**。

## 11. nodeid收集（先规划，满足对应依赖后实际collect）

所有collect也在ignored的source snapshot做；pytest collection会import代码，因此先按现有测试纪律审阅conftest/环境，禁止挂生产配置。外部source不存在时不创建空PASS测试。

```bash
# 当前可只做AST/测试规划；下列命令在真实目标测试文件已存在、环境审核后执行。
cd "$EVID/snapshot/sdk"
PYTHONPATH="$OPT/tools:$PWD/src${PYTHONPATH:+:$PYTHONPATH}" \
  "$PY" -m pytest --collect-only -q \
  -p pytest_readiness \
  -o cache_dir="$EVID/pytest-cache" \
  --readiness-source-map="$EVID/source-map.local.json" \
  --readiness-collection-out="$EVID/sdk-collection.json" \
  tests/orchestrator/full_target/taskgraph_exec \
  > "$EVID/collection.raw.log" 2>&1

"$PY" "$OPT/tools/map_collected_nodeids.py" \
  --mapping "$OPT/sdk-nodeid-map.json" \
  --collection "$EVID/sdk-collection.json" \
  --out "$EVID/sdk-nodeid-map.local.json"
```

collection失败、缺路径、缺plugin时结果仍为BLOCKED/未收集；不得加skip或偷跑reference tests充数。没有真实目标文件的阶段，当前任务仅是target nodeid规划。

legacy/fullH1/stateful/H1-I runner必须读取本地实际任务/核验书后把完整argv、cwd、环境policy、模型配置hash登记到`gate-commands.local.json`。本包不杜撰它们的脚本名。

## 12. Git证据卫生（独立操作人审阅，不自动add）

可提交：方案/allowlist/计划SQL变更、结论、执行命令、候选指纹、实际nodeid、原证据相对索引、SHA256。

不提交：raw log/JUnit全文件、截图、数据库及WAL/SHM、provider原回复、credential、源码snapshot、`/tmp`绝对路径作为唯一证据。

原始证据保留`$EVID`，Git文档只指向它。`git status --short`确认没有raw证据被意外列为待提交；一旦文件已tracked，.gitignore不会使它自动变安全，必须停止并单独处理，不自动删除用户历史。

可生成仅含身份/相对索引/hash的待review摘要（不会Git add）：

```bash
"$PY" "$OPT/tools/export_commit_index.py" \
  --source-map "$EVID/source-map.local.json" --host "$HOST" \
  --out "$EVID/reviewable-source-index.json"
```

人工审阅这份摘要后再另存到plans目录；不要直接提交完整local source-map或整个ignored证据目录。摘要仍为PENDING，不因脱敏就变成验收回执。

## 13. 本阶段Done

现在能够完成的是本地身份/接口盘点、H1依赖闭合清单、真实runner/完整schema预检报告与精确测试规划。未完成项保持BLOCKED/PENDING。**不要因为TG-A-prep做完，将TG-B、H1-H或生产标绿。**
