from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import zipfile
import venv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'reference'))
from collect_h1h import targets_from_registry
from collection_identity import physical_test_path, expand_selector, executed_fingerprint
from h1h_manifest import bind_collection
from prepare_runner_patch import patched_store
from sql_statement_iterator import iter_sql_statements
from review_source_candidates import report_candidates


class PathFixTests(unittest.TestCase):
    def test_physical_root_alias_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d); real = base / 'private'; real.mkdir()
            alias = base / 'var'; alias.symlink_to(real, target_is_directory=True)
            (real / 'test_a.py').write_text('def test_a(): pass\n')
            self.assertEqual(physical_test_path(alias, 'test_a.py::test_a'), real / 'test_a.py')
            reg = {'status': 'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED', 'cases': [
                {'id':'P01','actual_nodeids':['test_a.py::test_a']} ]}
            self.assertEqual(targets_from_registry(reg, alias), ['test_a.py::test_a'])
    def test_inner_symlink_escape_still_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'root';root.mkdir();outside=Path(d)/'out.py';outside.write_text('')
            (root/'test_a.py').symlink_to(outside)
            with self.assertRaises(ValueError):physical_test_path(root,'test_a.py::test_a')
    def test_lexical_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            for n in ['../a.py::a','/a.py::a','C:/a.py::a','t\\a.py::a']:
                with self.subTest(n=n), self.assertRaises(ValueError):physical_test_path(Path(d),n)
    def test_prefix_sibling_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'root';root.mkdir();other=Path(d)/'root-extra';other.mkdir()
            (other/'a.py').write_text('');(root/'a.py').symlink_to(other/'a.py')
            with self.assertRaises(ValueError):physical_test_path(root,'a.py::a')


def receipt(names):
    base='tests/test_p.py::test_state'
    return {'schema_version':2, 'candidate_fingerprint':'f', 'executed_source_fingerprint':'f',
            'collection_exitstatus':0,'collection_errors':[], 'sdk_tests_executed':False,
            'nodeids':[base+'['+name+']' for name in names],
            'items':[{'nodeid':base+'['+name+']','base_nodeid':base,
                      'identity_source':'PYTEST_FUNCTION_ORIGINALNAME','parametrized':True,
                      'parameter_id':name,'source_path':'tests/test_p.py','source_sha256':'a'*64}
                     for name in names]}


class ParameterFixTests(unittest.TestCase):
    def test_base_expands_all_three(self):
        c=receipt(['wait','no-change','declare-blocked']); r,mode=expand_selector('tests/test_p.py::test_state',c)
        self.assertEqual(set(r),set(c['nodeids'])); self.assertEqual(mode,'ALL_COLLECTED_PARAMETERS')
    def test_exact_parameter_only(self):
        c=receipt(['wait','no-change']); n=c['nodeids'][0]
        self.assertEqual(expand_selector(n,c),([n],'EXACT'))
    def test_missing_parameter_not_filled(self):
        self.assertEqual(expand_selector('tests/test_p.py::test_state[other]',receipt(['wait']))[0],[])
    def test_similar_function_is_not_match(self):
        self.assertEqual(expand_selector('tests/test_p.py::test_state_extra',receipt(['wait']))[0],[])
    def test_nested_bracket_id_not_split(self):
        c=receipt(['case[x]']); self.assertEqual(expand_selector('tests/test_p.py::test_state',c)[0],c['nodeids'])
    def test_no_metadata_no_invented_expansion(self):
        c=receipt(['wait']); c.pop('items');c.pop('schema_version')
        self.assertEqual(expand_selector('tests/test_p.py::test_state',c)[0],[])
    def test_partial_metadata_refused(self):
        c=receipt(['wait','no-change']); c['items'].pop()
        with self.assertRaises(ValueError):expand_selector('tests/test_p.py::test_state',c)
    def test_metadata_custom_collector_refused(self):
        c=receipt(['wait']); c['items'][0]['identity_source']='GUESSED_PREFIX'
        with self.assertRaises(ValueError):expand_selector('tests/test_p.py::test_state',c)
    def test_duplicate_collected_item_refused(self):
        c=receipt(['wait']); c['nodeids']*=2
        with self.assertRaises(ValueError):expand_selector('tests/test_p.py::test_state',c)
    def test_36_cases_remain_not_run(self):
        spec={'cases':[{'id':f'P{i:02}', 'required_assertions':'retain source-defined requirements'} for i in range(36)]}
        reg={'status':'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED','candidate_fingerprint':'f','runner_sha256':'a'*64,
             'registry_symbol':'CASES','cases':[{'id':r['id'],'actual_nodeids':['tests/test_p.py::test_state']} for r in spec['cases']]}
        out=bind_collection(reg,receipt(['wait','no-change','declare-blocked']),spec)
        self.assertEqual(out['status'],'COLLECTED_NOT_RUN');self.assertEqual(out['case_count'],36)
        self.assertEqual(out['unique_nodeid_count'],3);self.assertEqual(out['sdk_pass_cases'],0)
        self.assertTrue(all(r['execution_status']=='NOT_RUN' and len(r['actual_nodeids'])==3 for r in out['cases']))
    def test_overlapping_selectors_require_review(self):
        reg={'status':'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED','candidate_fingerprint':'f','runner_sha256':'a'*64,
             'registry_symbol':'CASES','cases':[{'id':'P01','actual_nodeids':['tests/test_p.py::test_state','tests/test_p.py::test_state[wait]']}]}
        with self.assertRaises(ValueError):bind_collection(reg,receipt(['wait']),{'cases':[{'id':'P01','required_assertions':'x'}]})
    def test_derived_receipt_does_not_bind_to_base(self):
        reg={'status':'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED','candidate_fingerprint':'f','runner_sha256':'a'*64,
             'registry_symbol':'CASES','cases':[{'id':'P01','actual_nodeids':['tests/test_p.py::test_state']}]}
        coll=receipt(['wait']);coll['executed_source_fingerprint']='patched'
        with self.assertRaises(ValueError):bind_collection(reg,coll,{'cases':[{'id':'P01','required_assertions':'x'}]})


class RealPytestCollectionTests(unittest.TestCase):
    def test_actual_pytest_metadata_and_no_test_bodies(self):
        with tempfile.TemporaryDirectory() as d:
            evidence=Path(d).resolve(); root=evidence/'snapshot';root.mkdir();(root/'tests').mkdir()
            (root/'tests/test_p.py').write_text(
                "import pytest\n@pytest.mark.parametrize('mode',['wait','no-change','declare-blocked'])\n"
                "def test_state(mode):\n    raise AssertionError('test body must not run')\n"
                "def test_state_extra():\n    raise AssertionError('must not run either')\n")
            sm=evidence/'sm.json';sm.write_text(json.dumps({'repositories':{'candidate':{'fingerprint':'f'}},'snapshot':{'path':str(root)}}))
            out=evidence/'collection.json'
            env={**os.environ,'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'tools')}
            env.pop('PYTEST_ADDOPTS',None)
            proc=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q','-p','pytest_readiness','--rootdir',str(root),
                                 '-o','addopts=','-o',f'cache_dir={evidence / "cache"}',
                                 '--readiness-source-map',str(sm),'--readiness-collection-out',str(out),
                                 'tests/test_p.py::test_state'],cwd=root,env=env,capture_output=True,text=True,timeout=30)
            self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)
            c=json.loads(out.read_text());self.assertFalse(c['sdk_tests_executed']);self.assertEqual(len(c['items']),3)
            self.assertEqual(c['collection_errors'],[])
            nodes,_=expand_selector('tests/test_p.py::test_state',c)
            self.assertEqual(len(nodes),3);self.assertNotIn('tests/test_p.py::test_state_extra',nodes)
    def test_collection_plugin_refuses_execution_mode_early(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'test_x.py').write_text("def test_x():\n    raise AssertionError('body cannot run')\n")
            env={**os.environ,'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONPATH':str(ROOT/'tools'),'PYTHONDONTWRITEBYTECODE':'1'}
            proc=subprocess.run([sys.executable,'-m','pytest','-p','pytest_readiness',
                                 '--readiness-collection-out',str(p/'out.json'),'test_x.py'],cwd=p,env=env,capture_output=True,text=True,timeout=30)
            self.assertNotEqual(proc.returncode,0);self.assertIn('requires --collect-only',proc.stderr+proc.stdout)
            self.assertFalse((p/'out.json').exists())


class RunnerPatchTests(unittest.TestCase):
    SOURCE=("# 非ASCII注释\nfrom . import schema\nclass Store:\n"
            "    def _apply_migration(self, connection, migration):\n"
            "        if migration.version == 2:\n            self.before(connection)\n"
            "        for statement in migration.ddl.split(';'):\n"
            "            if statement.strip():\n                connection.execute(statement)\n"
            "        self.after(connection, migration.checksum)\n")
    def test_patch_only_exact_runner_call(self):
        new=patched_store(self.SOURCE.encode()).decode()
        self.assertIn('iter_sql_statements(migration.ddl, allow_unterminated_final=True)',new)
        self.assertIn('self.before(connection)',new);self.assertIn('self.after(connection, migration.checksum)',new)
        self.assertNotIn('executescript',new);self.assertIn('from .sql_statements import iter_sql_statements',new)
    def test_ambiguous_split_refused(self):
        src=self.SOURCE.replace('self.after(connection, migration.checksum)',"self.after(migration.ddl.split(';'))")
        with self.assertRaises(ValueError):patched_store(src.encode())
    def test_preexisting_other_helper_not_overwritten(self):
        with self.assertRaises(ValueError):patched_store((self.SOURCE+'x=iter_sql_statements\n').encode())
    def test_other_function_split_unchanged(self):
        src=self.SOURCE+"def other(migration):\n    return migration.ddl.split(';')\n"
        self.assertTrue(patched_store(src.encode()).decode().endswith("return migration.ddl.split(';')\n"))
    def test_legacy_final_statement_without_delimiter(self):
        self.assertEqual(list(iter_sql_statements('SELECT 1',allow_unterminated_final=True)),['SELECT 1'])
    def test_unterminated_quote_and_trigger_rejected(self):
        for sql in ["SELECT 'broken",'CREATE TRIGGER t AFTER INSERT ON x BEGIN SELECT 1;']:
            with self.subTest(sql=sql),self.assertRaises(ValueError):list(iter_sql_statements(sql,allow_unterminated_final=True))
    def test_transaction_control_rejected(self):
        for sql in ['COMMIT;','--comment\nEND;','BEGIN IMMEDIATE;','SAVEPOINT x;','VACUUM;']:
            with self.subTest(sql=sql),self.assertRaises(ValueError):list(iter_sql_statements(sql))
    def test_legacy_comment_tail_and_quoted_semicolon(self):
        sql="SELECT 'a;''b'; -- remaining ; comment"
        parts=list(iter_sql_statements(sql));self.assertEqual(len(parts),1)
        con=sqlite3.connect(':memory:');self.assertEqual(con.execute(parts[0]).fetchone()[0],"a;'b");con.close()
    def test_trigger_smoke_then_rollback(self):
        con=sqlite3.connect(':memory:',isolation_level=None);con.execute('BEGIN IMMEDIATE')
        ddl="CREATE TABLE x(v); CREATE TRIGGER tr BEFORE INSERT ON x BEGIN SELECT CASE WHEN NEW.v<0 THEN RAISE(ABORT,'negative value; expected') END; SELECT 1; END;"
        for part in iter_sql_statements(ddl):con.execute(part)
        con.execute('INSERT INTO x VALUES(1)')
        with self.assertRaises(sqlite3.IntegrityError):con.execute('INSERT INTO x VALUES(-1)')
        self.assertTrue(con.in_transaction);con.rollback()
        self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE name IN ('x','tr')").fetchone()[0],0);con.close()
    def test_original_ddl_25_triggers_full_statements(self):
        with zipfile.ZipFile(ROOT/'inputs/simpleharness-taskgraph-code-plan-kit.zip') as z:
            names=[n for n in z.namelist() if n.endswith('sql/001_taskgraph_extension.sql')]
            self.assertEqual(len(names),1);raw=z.read(names[0])
        text=raw.decode();parts=list(iter_sql_statements(text))
        self.assertEqual(sum('CREATE TRIGGER' in p for p in parts),25)
        self.assertEqual(sum('CREATE TABLE taskgraph_' in p for p in parts),9)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),json.loads((ROOT/'metadata/parent-contract-checks.json').read_text())['ddl_sha256'])

    def test_original_extension_executes_inside_outer_transaction(self):
        with zipfile.ZipFile(ROOT/'inputs/simpleharness-taskgraph-code-plan-kit.zip') as z:
            ddl=z.read(next(n for n in z.namelist() if n.endswith('sql/001_taskgraph_extension.sql'))).decode()
            parent=z.read(next(n for n in z.namelist() if n.endswith('tests/parent_fixture.sql'))).decode()
        con=sqlite3.connect(':memory:',isolation_level=None)
        con.execute('PRAGMA foreign_keys=ON')
        # Explicitly a REFERENCE parent schema, NOT SDK migration evidence.
        for part in iter_sql_statements(parent,allow_unterminated_final=True):con.execute(part)
        con.execute('BEGIN IMMEDIATE')
        for part in iter_sql_statements(ddl):con.execute(part)
        self.assertTrue(con.in_transaction)
        self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0],25)
        self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name LIKE 'taskgraph_%'").fetchone()[0],9)
        con.rollback()
        self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name LIKE 'taskgraph_%'").fetchone()[0],0)
        con.close()

    def test_patch_cli_only_writes_derived_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d).resolve();candidate=base/'candidate';candidate.mkdir()
            venv.EnvBuilder(with_pip=False).create(candidate/'.venv')
            evidence=base/'evidence';frozen=evidence/'snapshot/sdk';store=frozen/'src/agent_orchestrator/storage/store.py'
            store.parent.mkdir(parents=True);raw=self.SOURCE.encode();store.write_bytes(raw)
            original_file=candidate/'DO_NOT_TOUCH';original_file.write_text('dirty user bytes')
            sm={'repositories':{'candidate':{'root':str(candidate),'fingerprint':'f'*64}},
                'head_matches_handoff':True,'candidate_unchanged_during_capture':True,
                'snapshot':{'path':str(frozen),'kind':'ISOLATED_SOURCE_SNAPSHOT_NOT_A_WORKTREE',
                            'files':[{'path':'src/agent_orchestrator/storage/store.py','sha256':hashlib.sha256(raw).hexdigest()}]}}
            mapfile=evidence/'source-map.local.json';mapfile.write_text(json.dumps(sm))
            out=evidence/'derived'
            proc=subprocess.run([str(candidate/'.venv/bin/python'),str(ROOT/'tools/prepare_runner_patch.py'),
                                 '--source-map',str(mapfile),'--out-dir',str(out)],
                                capture_output=True,text=True,timeout=30,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)
            self.assertEqual(store.read_bytes(),raw);self.assertEqual(original_file.read_text(),'dirty user bytes')
            revised=json.loads((out/'source-map.derived.json').read_text())
            self.assertEqual(revised['repositories']['candidate']['fingerprint'],'f'*64)
            self.assertNotEqual(revised['snapshot']['source_variant_fingerprint'],'f'*64)
            self.assertEqual(len(revised['snapshot']['files']),2)
            report=json.loads((out/'patch-report.json').read_text())
            self.assertFalse(report['candidate_modified']);self.assertFalse(report['schema_registration_modified'])
            self.assertFalse(report['tests_run']);self.assertFalse(report['production_enablement_allowed'])

    def test_base_and_variant_identity_distinct(self):
        src={'repositories':{'candidate':{'fingerprint':'base'}},'snapshot':{'source_variant_fingerprint':'patched'}}
        self.assertEqual(executed_fingerprint(src),'patched');self.assertEqual(src['repositories']['candidate']['fingerprint'],'base')



class SourceReviewTests(unittest.TestCase):
    def test_qualified_name_list_is_not_equivalence(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'source.py').write_text('class A:\n def get_request(self): pass\nclass B:\n def get_request(self): pass\n')
            rows=report_candidates(root,[{'id':'P02','path':'source.py','symbols':['get_request'],'category':'EXISTING_REUSE'}],{'P02'})
            self.assertIn('A.get_request',rows[0]['qualified_candidates'])
            self.assertIn('B.get_request',rows[0]['qualified_candidates'])
            self.assertEqual(rows[0]['equivalence'],'NOT_PROVEN');self.assertEqual(rows[0]['behavior_receipts'],[])
    def test_missing_source_does_not_get_hash(self):
        with tempfile.TemporaryDirectory() as d:
            rows=report_candidates(Path(d),[{'id':'P09','path':'absent.py','symbols':['read_running_work'],'category':'H1H_PREREQUISITE'}],{'P09'})
            self.assertEqual(rows[0]['status'],'MISSING');self.assertIsNone(rows[0]['file_sha256'])
    def test_missing_requirement_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):report_candidates(Path(d),[],{'P19'})

if __name__=='__main__':unittest.main()
