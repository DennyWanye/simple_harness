-- Named read/guard/CAS templates. Named parameters are bound values, NEVER interpolated.
-- These statements are not one executable migration. Use by the named Store methods in PLAN.

-- Q01: authoritative active pointer. More than one is prohibited by existing unique index.
SELECT revision,snapshot_hash FROM plan_revisions
 WHERE mission_id=:mission_id AND state='ACTIVE';

-- Q02: historical task contract. Never use latest_task_semantics for a historical revision.
SELECT p.occurrence_id,p.task_id,p.binding_revision,p.binding_hash,s.binding_json
 FROM taskgraph_member_pins p JOIN task_semantics s
 ON s.task_id=p.task_id AND s.binding_revision=p.binding_revision
 WHERE p.mission_id=:mission_id AND p.revision=:revision AND s.mission_id=:mission_id
 ORDER BY p.occurrence_id;

-- Q03: historical method adoption. Current method_instances.state is NOT historical adoption.
SELECT p.instance_id,p.goal_occurrence_id,p.adopted,p.draft_hash,i.draft_json
 FROM taskgraph_method_pins p JOIN method_instances i
 ON i.mission_id=p.mission_id AND i.instance_id=p.instance_id
 WHERE p.mission_id=:mission_id AND p.revision=:revision ORDER BY p.instance_id;

-- Q04: active shared consumers. Complete rows are hashed as a set in the read certificate.
SELECT d.* FROM taskgraph_demand_refs d JOIN plan_revisions r
 ON r.mission_id=d.mission_id AND r.revision=d.revision
 WHERE d.mission_id=:mission_id AND d.producer_occurrence_id=:producer_occurrence_id
 AND r.state='ACTIVE' ORDER BY d.consumer_instance_id,d.slot_key;

-- Q05: immutable Attempt input. No "latest producer" lookup on replay.
SELECT b.*,m.manifest_json FROM taskgraph_attempt_inputs b
 JOIN input_manifests m ON m.manifest_hash=b.manifest_hash
 WHERE b.mission_id=:mission_id AND b.attempt_id=:attempt_id;

-- Q06: authoritative fence. READY still fenced until commit or authorized safe abandonment.
SELECT t.job_id,t.occurrence_id,t.expected_generation,j.state,j.row_version
 FROM taskgraph_convergence_targets t JOIN taskgraph_convergence_jobs j ON j.job_id=t.job_id
 WHERE t.mission_id=:mission_id AND t.task_id=:task_id AND j.state IN ('FENCED','WAITING','READY');

-- Q07: convergence CAS. Caller validates legal transition and factual quiescence first.
UPDATE taskgraph_convergence_jobs SET state=:new_state,row_version=row_version+1,updated_at=:now
 WHERE job_id=:job_id AND mission_id=:mission_id AND state=:old_state AND row_version=:expected_version;
-- Require rowcount==1; 0 means conflict, NOT success.

-- Q08: complete endpoint audit for old tables (SQL FKs alone do not check these endpoints).
SELECT o.before_occurrence,o.after_occurrence FROM order_constraints o
 LEFT JOIN plan_memberships a ON a.mission_id=o.mission_id AND a.revision=o.plan_revision AND a.occurrence_id=o.before_occurrence
 LEFT JOIN plan_memberships b ON b.mission_id=o.mission_id AND b.revision=o.plan_revision AND b.occurrence_id=o.after_occurrence
 WHERE o.mission_id=:mission_id AND o.plan_revision=:revision AND (a.occurrence_id IS NULL OR b.occurrence_id IS NULL);
SELECT d.requirement_id FROM data_requirements d
 LEFT JOIN plan_memberships a ON a.mission_id=d.mission_id AND a.revision=d.plan_revision AND a.occurrence_id=d.producer_occurrence
 LEFT JOIN plan_memberships b ON b.mission_id=d.mission_id AND b.revision=d.plan_revision AND b.occurrence_id=d.consumer_occurrence
 WHERE d.mission_id=:mission_id AND d.plan_revision=:revision AND (a.occurrence_id IS NULL OR b.occurrence_id IS NULL);

-- Q09: notification claim. Select and update in ONE short transaction; no model inside it.
SELECT message_id,row_version FROM taskgraph_followups
 WHERE (delivery_state='PENDING' AND next_attempt_ms<=:now_ms)
 OR (delivery_state='LEASED' AND lease_until_ms<=:now_ms)
 ORDER BY next_attempt_ms,message_id LIMIT 1;
UPDATE taskgraph_followups SET delivery_state='LEASED',lease_owner=:owner,
 lease_until_ms=:lease_until_ms,attempts=attempts+1,row_version=row_version+1
 WHERE message_id=:message_id AND row_version=:expected_version
 AND ((delivery_state='PENDING' AND next_attempt_ms<=:now_ms) OR (delivery_state='LEASED' AND lease_until_ms<=:now_ms));

-- Q10: acknowledge only after existing consumer command/intent has a durable receipt.
UPDATE taskgraph_followups SET delivery_state='ACKED',consumer_receipt_json=:consumer_receipt_json,lease_owner=NULL,lease_until_ms=NULL,row_version=row_version+1
 WHERE message_id=:message_id AND delivery_state='LEASED' AND lease_owner=:owner AND row_version=:expected_version;

-- Q11: read-side watermark. Read in the SAME transaction as task/validity/graph rows.
SELECT COALESCE(MAX(seq),0) AS through_seq FROM events WHERE mission_id=:mission_id;

-- Q12: bounded notification retry. Classify the error before applying; no hidden model retry.
UPDATE taskgraph_followups SET delivery_state=CASE WHEN attempts>=5 THEN 'BLOCKED' ELSE 'PENDING' END,
 lease_owner=NULL,lease_until_ms=NULL,row_version=row_version+1,
 next_attempt_ms=:next_attempt_ms,last_error_code=:error_code
 WHERE message_id=:message_id AND delivery_state='LEASED' AND lease_owner=:owner AND row_version=:expected_version;

-- Q13: explicit operator recovery of a blocked notification, after real source repair.
UPDATE taskgraph_followups SET delivery_state='PENDING',row_version=row_version+1,
 next_attempt_ms=:now_ms,last_error_code=NULL,attempts=0
 WHERE message_id=:message_id AND mission_id=:mission_id AND delivery_state='BLOCKED' AND row_version=:expected_version;

-- Q14: immutable graph record read. Decoder verifies bytes, hash chain and complete pins.
SELECT * FROM taskgraph_revision_records WHERE mission_id=:mission_id AND revision=:revision;

-- Q15: current control binding (only for current runtime checks, never historical reconstruction).
SELECT binding_revision,binding_json,content_hash,input_binding_revision,dispatch_generation
 FROM task_semantics WHERE mission_id=:mission_id AND task_id=:task_id
 ORDER BY binding_revision DESC LIMIT 1;
