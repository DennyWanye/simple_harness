"""Reference-only; no SDK, jsonschema, network, credentials, or user databases."""
from pathlib import Path
import copy
import hashlib
import json
import sqlite3
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference"))
from contracts import (ContractError, parse_contract, validate_spec, validate_scope,
    validate_contribution, validate_outcome, check_required_criterion_coverage,
    check_scope_against_spec, check_outcome_identity, evaluate_coverage, evaluate_root_coverage)

H = "a" * 64
J = "b" * 64


def pin(identity="r1", revision=1, digest=H):
    return {"id": identity, "revision": revision, "content_hash": digest}


def effect(key="send-a"):
    return {"effect_key": key, "obligation_id": "obl-root", "criterion_ids": ["delivery"],
            "required_milestone": "delivered", "milestone_policy_ref": pin("delivery-policy"),
            "evidence_policy_ref": pin("receipt-policy"), "source_slot_key": key}


def spec(two=False, report_only=False):
    return {"schema_version": 1, "mission_id": "m1", "requirements_ref": pin(),
            "mode": "CONTENT_ONLY" if report_only else "REQUIRED_EFFECTS",
            "content_criterion_ids": ["report"],
            "effects": [] if report_only else [effect()] + ([effect("send-b")] if two else [])}


def scope(report_only=False):
    return {"schema_version": 1, "mission_id": "m1", "requirements_ref": pin(),
            "spec_hash": H, "plan_ref": {"revision": 3, "snapshot_hash": H},
            "occurrence_id": "root", "task_ref": pin("task"), "obligation_id": "obl-root",
            "role": "CONTENT" if report_only else "MIXED", "content_criterion_ids": ["report"],
            "required_effect_keys": [] if report_only else ["send-a"],
            "owned_effect_keys": [] if report_only else ["send-a"]}


def contribution(effect_key=None, report_only=False):
    return {"schema_version": 1, "mission_id": "m1", "acceptance_id": "acc-effect-" + effect_key if effect_key else "acc-report",
            "completion_scope_id": "scope-root", "spec_hash": H,
            "kind": "OPERATION_EFFECT" if effect_key else ("CONTENT" if report_only else "PREPARATION"),
            "content_criterion_ids": [] if effect_key else ["report"],
            "effect_keys": [effect_key] if effect_key else [],
            "output_artifact_refs": [] if effect_key else [pin("report-artifact")],
            "outcome_binding_id": "out-" + effect_key if effect_key else None,
            "delivery_receipt_ref": pin("delivery-" + effect_key) if effect_key else None}


def outcome(key="send-a"):
    return {"schema_version": 1, "mission_id": "m1", "spec_hash": H,
            "effect_key": key, "completion_scope_id": "scope-root", "intent_id": "intent-" + key,
            "operation_id": "operation-" + key, "operation_occurrence_id": "oo-" + key,
            "action_key": "action-" + key, "action_version": 2, "request_hash": H,
            "candidate_file_hash": H, "parameters_content_hash": H, "params_hash": H,
            "effect_contract_hash": H, "link_hash": H, "connector_profile_hash": H,
            "namespace_hash": H, "target_identity_hash": H,
            "milestone_policy_ref": pin("delivery-policy"), "observed_milestone": "delivered",
            "covered_handoff_ids": ["handoff-" + key], "source_receipt_refs": [pin("receipt-" + key)]}


def run_coverage(contributions, proofs=None, valid=None, two=False, report_only=False):
    return evaluate_coverage(spec(two, report_only), spec_hash=H,
        required_content={"report"}, required_effects=set() if report_only else ({"send-a", "send-b"} if two else {"send-a"}),
        contributions=contributions,
        applicable_acceptance_ids={c["acceptance_id"] for c in contributions} if valid is None else valid,
        verified_outcomes={} if proofs is None else proofs)


class CodecTests(unittest.TestCase):
    def test_four_contract_roundtrips(self):
        for kind, value in (("requirements", spec()), ("scope", scope()),
                            ("contribution", contribution()), ("outcome", outcome())):
            with self.subTest(kind=kind):
                result = parse_contract(kind, json.dumps(value).encode())
                self.assertEqual(result.value(), value)
                self.assertEqual(parse_contract(kind, result.canonical), result)
    def test_duplicate_json_keys(self):
        with self.assertRaises(ContractError):
            parse_contract("requirements", b'{"schema_version":1,"schema_version":1}')
    def test_invalid_enum_types_are_named_contract_errors(self):
        for value, field, validator in ((spec(), "mode", validate_spec), (scope(), "role", validate_scope), (contribution(), "kind", validate_contribution)):
            value[field] = []
            with self.subTest(field=field), self.assertRaises(ContractError): validator(value)
    def test_unknown_field(self):
        value = spec(); value["approved"] = True
        with self.assertRaises(ContractError): validate_spec(value)
    def test_boolean_revision(self):
        value = spec(); value["requirements_ref"]["revision"] = True
        with self.assertRaises(ContractError): validate_spec(value)
    def test_missing_effect_mapping_is_not_empty(self):
        value = spec(); del value["effects"]
        with self.assertRaises(ContractError): validate_spec(value)
    def test_explicit_report_only(self):
        validate_spec(spec(report_only=True))
    def test_effect_mode_cannot_be_empty(self):
        value = spec(); value["effects"] = []
        with self.assertRaises(ContractError): validate_spec(value)
    def test_no_duplicate_effect_or_origin_slot(self):
        value = spec(two=True); value["effects"][1]["source_slot_key"] = "send-a"
        with self.assertRaises(ContractError): validate_spec(value)
    def test_effect_cannot_also_be_content(self):
        value = spec(); value["content_criterion_ids"].append("delivery")
        with self.assertRaises(ContractError): validate_spec(value)
    def test_preparation_cannot_claim_effect(self):
        value = contribution(); value["effect_keys"] = ["send-a"]
        with self.assertRaises(ContractError): validate_contribution(value)
    def test_single_effect_contribution(self):
        value = contribution("send-a"); value["effect_keys"].append("send-b")
        with self.assertRaises(ContractError): validate_contribution(value)
    def test_nonempty_operation_id_is_not_an_outcome(self):
        with self.assertRaises(ContractError): validate_outcome({"operation_id": "op1"})
    def test_root_cannot_drop_required_effect(self):
        with self.assertRaises(ContractError):
            check_scope_against_spec(spec(), scope(report_only=True), spec_hash=H, root_occurrence="root")
    def test_content_sibling_does_not_inherit_every_effect(self):
        value = scope(report_only=True); value["occurrence_id"] = "prepare-child"
        check_scope_against_spec(spec(), value, spec_hash=H, root_occurrence="root")
    def test_required_criterion_coverage(self):
        check_required_criterion_coverage(spec(), {"report", "delivery"})
        with self.assertRaises(ContractError): check_required_criterion_coverage(spec(), {"report", "delivery", "secret"})
    def test_nonfinite_and_oversize(self):
        for raw in (b'{"value":NaN}', b"x" * 262145):
            with self.subTest(raw_length=len(raw)), self.assertRaises(ContractError):
                parse_contract("requirements", raw)


class CompletionTests(unittest.TestCase):
    def test_root_requirement_set_cannot_be_filtered_by_caller(self):
        result = evaluate_root_coverage(spec(two=True), spec_hash=H,
            contributions=[contribution(), contribution("send-a")],
            applicable_acceptance_ids={"acc-report", "acc-effect-send-a"},
            verified_outcomes={"out-send-a": outcome()})
        self.assertFalse(result.ready_for_review)
        self.assertEqual(result.pending_effects, ("send-b",))
    def test_preparation_only_still_pending(self):
        report = run_coverage([contribution()])
        self.assertFalse(report.ready_for_review)
        self.assertEqual(report.missing_content, ())
        self.assertEqual(report.pending_effects, ("send-a",))
    def test_no_intent_or_outcome_does_not_remove_required_slot(self):
        self.assertFalse(run_coverage([contribution()], proofs={}).ready_for_review)
    def test_correct_effect_and_report_ready_for_review(self):
        report = run_coverage([contribution(), contribution("send-a")], {"out-send-a": outcome()})
        self.assertTrue(report.ready_for_review)
    def test_received_not_delivered(self):
        proof = outcome(); proof["observed_milestone"] = "received"
        self.assertFalse(run_coverage([contribution(), contribution("send-a")], {"out-send-a": proof}).ready_for_review)
    def test_sent_not_delivered(self):
        proof = outcome(); proof["observed_milestone"] = "sent"
        self.assertFalse(run_coverage([contribution(), contribution("send-a")], {"out-send-a": proof}).ready_for_review)
    def test_wrong_semantic_policy(self):
        proof = outcome(); proof["milestone_policy_ref"] = pin("unrelated-policy")
        self.assertFalse(run_coverage([contribution(), contribution("send-a")], {"out-send-a": proof}).ready_for_review)
    def test_revoked_report_is_not_reused(self):
        self.assertFalse(run_coverage([contribution(), contribution("send-a")], {"out-send-a": outcome()}, valid={"acc-effect-send-a"}).ready_for_review)
    def test_revoked_outcome_is_not_reused(self):
        self.assertFalse(run_coverage([contribution(), contribution("send-a")], {"out-send-a": outcome()}, valid={"acc-report"}).ready_for_review)
    def test_new_requirement_hash_refuses_old_contribution(self):
        item = contribution(); item["spec_hash"] = J
        with self.assertRaises(ContractError): run_coverage([item])
    def test_two_required_effects_need_two_results(self):
        result = run_coverage([contribution(), contribution("send-a")], {"out-send-a": outcome()}, two=True)
        self.assertFalse(result.ready_for_review)
        self.assertEqual(result.pending_effects, ("send-b",))
    def test_both_effects_ready(self):
        result = run_coverage([contribution(), contribution("send-a"), contribution("send-b")],
            {"out-send-a": outcome(), "out-send-b": outcome("send-b")}, two=True)
        self.assertTrue(result.ready_for_review)
    def test_other_mission_rejected(self):
        proof = outcome(); proof["mission_id"] = "m2"
        with self.assertRaises(ContractError):
            run_coverage([contribution("send-a")], {"out-send-a": proof})
    def test_report_only_compatible(self):
        self.assertTrue(run_coverage([contribution(report_only=True)], report_only=True).ready_for_review)
    def test_identity_mismatches_are_not_hidden_by_milestone(self):
        for key in ("intent_id", "operation_id", "operation_occurrence_id", "action_key", "effect_key", "mission_id", "completion_scope_id"):
            changed = outcome(); changed[key] = "other"
            with self.subTest(key=key), self.assertRaises(ContractError): check_outcome_identity(changed, outcome())
        for key in ("request_hash", "effect_contract_hash", "params_hash", "link_hash", "target_identity_hash"):
            changed = outcome(); changed[key] = J
            with self.subTest(key=key), self.assertRaises(ContractError): check_outcome_identity(changed, outcome())
        changed = outcome(); changed["action_version"] = 3
        with self.assertRaises(ContractError): check_outcome_identity(changed, outcome())
    def test_handoff_or_receipt_substitution_rejected(self):
        for key, replacement in (("covered_handoff_ids", ["other"]), ("source_receipt_refs", [pin("other")])):
            changed = outcome(); changed[key] = replacement
            with self.subTest(key=key), self.assertRaises(ContractError): check_outcome_identity(changed, outcome())
    def test_same_proof_not_double_counted(self):
        item = contribution("send-a")
        with self.assertRaises(ContractError):
            run_coverage([item, copy.deepcopy(item)], {"out-send-a": outcome()})


# Deliberately minimal parent-key fixture. NOT the SDK's complete schema.
PARENTS = """
CREATE TABLE missions(mission_id TEXT PRIMARY KEY);
CREATE TABLE requirements_revisions(mission_id TEXT,revision INTEGER,PRIMARY KEY(mission_id,revision));
CREATE TABLE commit_receipts(commit_id TEXT PRIMARY KEY);
CREATE TABLE tasks(task_id TEXT PRIMARY KEY);
CREATE TABLE plan_memberships(mission_id TEXT,revision INTEGER,occurrence_id TEXT,PRIMARY KEY(mission_id,revision,occurrence_id));
CREATE TABLE task_semantics(task_id TEXT,binding_revision INTEGER,PRIMARY KEY(task_id,binding_revision));
CREATE TABLE operation_intent_bindings(intent_id TEXT PRIMARY KEY);
CREATE TABLE review_packages(package_id TEXT PRIMARY KEY);
CREATE TABLE acceptances(acceptance_id TEXT PRIMARY KEY);
"""


def statements(sql):
    buf = ""
    for char in sql:
        buf += char
        if char == ";" and sqlite3.complete_statement(buf):
            yield buf
            buf = ""
    if buf.strip():
        # This reference DDL ends with a complete statement; trailing comments
        # are permitted and do not become an executable fragment.
        if any(line.strip() and not line.lstrip().startswith("--") for line in buf.splitlines()):
            raise ValueError("unterminated SQL")


def database():
    connection = sqlite3.connect(":memory:", isolation_level=None)
    connection.execute("PRAGMA foreign_keys=ON")
    for statement in statements(PARENTS): connection.execute(statement)
    connection.execute("INSERT INTO missions VALUES ('m1')")
    connection.execute("INSERT INTO requirements_revisions VALUES ('m1',1)")
    connection.execute("INSERT INTO commit_receipts VALUES ('receipt')")
    connection.execute("BEGIN IMMEDIATE")
    for statement in statements((ROOT / "sql/operation_completion.sql").read_text()): connection.execute(statement)
    connection.execute("COMMIT")
    return connection


class SQLTests(unittest.TestCase):
    def setUp(self): self.db = database()
    def tearDown(self): self.db.close()
    def insert_spec(self, identity="spec", requirements_hash=H, receipt="receipt"):
        self.db.execute("INSERT INTO operation_completion_specs VALUES(?,?,?,?,?,?,?,?)",
            (identity, "m1", 1, requirements_hash, H, json.dumps(spec()), receipt, 0))
    def test_four_tables_and_eight_triggers(self):
        tables = self.db.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name IN ('operation_completion_specs','operation_completion_scopes','operation_outcome_review_bindings','operation_acceptance_scopes')").fetchone()[0]
        triggers = self.db.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
        self.assertEqual((tables, triggers), (4, 8))
    def test_requirement_revision_unique(self):
        self.insert_spec()
        with self.assertRaises(sqlite3.IntegrityError): self.insert_spec("spec2")
    def test_immediate_update_or_delete_rejected(self):
        self.insert_spec()
        for sql in ("UPDATE operation_completion_specs SET spec_hash='"+J+"'", "DELETE FROM operation_completion_specs"):
            with self.subTest(sql=sql), self.assertRaises(sqlite3.IntegrityError): self.db.execute(sql)
    def test_actual_receipt_fk_required(self):
        with self.assertRaises(sqlite3.IntegrityError): self.insert_spec(receipt="nonexistent")
    def test_transaction_can_link_later_receipt(self):
        self.db.execute("BEGIN IMMEDIATE")
        self.insert_spec(receipt="later")
        self.db.execute("INSERT INTO commit_receipts VALUES ('later')")
        self.db.execute("COMMIT")
        self.assertEqual(self.db.execute("PRAGMA foreign_key_check").fetchall(), [])
    def test_partial_insert_rolled_back(self):
        self.db.execute("BEGIN IMMEDIATE")
        self.insert_spec()
        with self.assertRaises(sqlite3.OperationalError): self.db.execute("INSERT INTO nonexistent VALUES (1)")
        self.db.execute("ROLLBACK")
        self.assertEqual(self.db.execute("SELECT count(*) FROM operation_completion_specs").fetchone()[0], 0)
    def test_whole_ddl_rollback(self):
        db = sqlite3.connect(":memory:", isolation_level=None)
        try:
            db.execute("PRAGMA foreign_keys=ON")
            for statement in statements(PARENTS): db.execute(statement)
            db.execute("BEGIN IMMEDIATE")
            for statement in statements((ROOT / "sql/operation_completion.sql").read_text()): db.execute(statement)
            self.assertTrue(db.in_transaction)
            db.execute("ROLLBACK")
            self.assertEqual(db.execute("SELECT count(*) FROM sqlite_master WHERE name='operation_completion_specs'").fetchone()[0], 0)
        finally: db.close()


if __name__ == "__main__": unittest.main(verbosity=2)
