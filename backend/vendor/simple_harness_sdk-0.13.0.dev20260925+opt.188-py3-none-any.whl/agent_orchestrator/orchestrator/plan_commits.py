# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""P2.3a: one plan revision is committed atomically, or not at all (§9.4, TG §7.4).

This is the ninth Commit Service mixin and the single writing entry point of the
hierarchical mode.  Everything it does is arranged around two checks:

    the plan revision is the structural concurrency gate — a delta is accepted only
    if it was built on the Mission's current plan revision, so of two concurrent
    proposals at most one commits; and the proposal's *semantic* read-set is
    checked item by item, so a fact, duty, acceptance or epoch the proposal read
    that has since moved refuses the commit — with no automatic rebase.

There is deliberately no automatic replay of a stale proposal (C19): a proposal
whose read went stale is handed back to its author to recompile against the new
snapshot, because replaying it would mean deciding, on the author's behalf, that a
fact it read did not matter.  Budget and planning authority are not read-set items;
they are re-read inside this transaction (gate 9 and the admission check).  Gate
numbers 3 and 4 are unused: the manager-epoch gate and the integer graph-version
gate were removed in stage D, and the remaining numbers are kept so references to
them stay valid.

Three further boundaries the plan states and this module keeps:

* **Legacy Missions stop at the door.**  A Mission whose
  ``orchestration_semantics_version`` is not ``hierarchical`` is refused after the
  ``missions`` row is read and before any migration-16 table is touched — no read,
  no write, no event (§18.5 rule 1).
* **No raw SQL, ever.**  Every row goes through :class:`HtnStore` /
  :class:`ObligationStore`, which stay the single writing authority for the new
  tables.  This module decides *whether*; storage decides *how*.
* **Nothing slow runs inside the transaction.**  No model, no solver, no tool.  The
  structural re-validation is pure computation over the snapshot the caller
  compiled plus the delta, which is the "check certificate, re-confirmed under the
  structural version" TG §7.4 asks for.

The command is refused with a named reason, never with a boolean: a stale read-set,
a cycle, an exhausted allowance and unreconciled running work are four different
repairs, and collapsing them would tell the proposer nothing about what to do next.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any

from simple_harness.contracts import canonical_json

from ..contracts import TERMINAL_MISSION, Budget, ContractError, MissionStatus, TaskStatus
from ..contracts.htn import (
    ContractRevision,
    DispatchGeneration,
    GraphStructureBudget,
    ObligationId,
    OccurrenceId,
    OccurrenceSpec,
    ProposedPlanDelta,
    ReadItem,
    ReadItemKind,
    RunningWorkPolicy,
    SemanticReadSet,
    TaskForm,
    TaskRef,
    TaskSemanticBindingV1,
    require_commit_ready,
)
from ..contracts.obligations import ObligationAccountView, ObligationLedger
from ..contracts.operation_completion import PlanRevisionPinV1
from ..contracts.semantic_base import content_hash_of
from ..governance.budget_limits import inherit_limits
from ..governance.budgets import BudgetError
from ..graph.projection_validation import (
    validate_execution_projection,
    validate_refinement_acyclic,
)
from ..graph.task_network import DEFAULT_PROJECTION_BUDGET, TaskNetworkSnapshot
from ..graph.taskgraph_validation import taskgraph_projection_report
from ..planning.htn.compiler import (
    BudgetRequirement,
    DemandAdmission,
    DemandNotAdmissible,
    apply_obligation_openings,
)
from ..planning.htn.graph_repair import affected_occurrences
from ..storage import planning_decision_store
from ..storage.htn_store import HtnStore, PlanCommitReceipt
from ..storage.obligation_store import ObligationStore
from ..storage.store import StoreError
from ..storage.taskgraph_store import NotBoundError, require_bound
from ._read_set import ReadSetChannelUnknown, SemanticReadSetChecker
from .accepted_outputs import criterion_linked_occurrences, owned_criteria
from .budget_accounts import mission_account, task_account
from .method_plan_reviews import REVIEW_REQUIRED, unreviewed_adopted_methods
from .occurrence_tasks import (
    COMPOUND_TOKENS,
    MIN_TOKEN_SHARE,
    Materialisation,
    OccurrenceTask,
    occurrence_task,
    task_pool_tokens,
)
from .operation_completion import freeze_plan_completion_scopes
from .repair_impact import read_repair_impact_indexes
from .state_machine import next_mission
from .taskgraph_demands import read_independent_demands

if TYPE_CHECKING:  # pragma: no cover - typing only
    from ..contracts import Event, Mission
    from ..governance.budgets import BudgetLedger
    from ..storage.store import Store
    from .taskgraph_plan_commit import TaskGraphPlanCommitParticipant

#: The one event type this module appends.  It is *new*, which is the whole point:
#: §18.5 rule 3 allows the hierarchical mode to add event types and forbids it to
#: rewrite the bytes of an existing one.
PLAN_REVISION_COMMITTED = "PlanRevisionCommitted"

#: P2.3c part 2.  Appended once per commit that put occurrences on the board, so
#: "which Task row is which occurrence" and the budget equation are durable facts
#: rather than something a reader has to re-derive from three tables.
OCCURRENCES_MATERIALISED = "PlanOccurrencesMaterialised"

#: The only orchestration mode.  ``LEGACY_SEMANTICS`` names the flat mode that was
#: removed on 2026-10-02: a request naming it is refused, and a library row created
#: under it is recognised (never served) so that Mission can be stopped by name.
HIERARCHICAL_SEMANTICS = "hierarchical"
LEGACY_SEMANTICS = "legacy"
#: Where the mode is recorded on the Mission.
SEMANTICS_KEY = "orchestration_semantics_version"


def normalise_semantics(value: object) -> str:
    """``hierarchical``, or raise: the flat mode is gone and nothing else exists."""

    text = HIERARCHICAL_SEMANTICS if value is None else str(value)
    if text == HIERARCHICAL_SEMANTICS:
        return text
    if text == LEGACY_SEMANTICS:
        raise ContractError(
            f"{SEMANTICS_KEY} {text!r}: the flat orchestration mode was removed on "
            f"2026-10-02; only {HIERARCHICAL_SEMANTICS!r} is served"
        )
    raise ContractError(
        f"{SEMANTICS_KEY} {text!r} is not an orchestration semantics version; "
        f"only {HIERARCHICAL_SEMANTICS!r} exists"
    )


def semantics_of(mission: Mission) -> str:
    """Which mode a stored Mission was created under (recognition only, never raises):
    a row without the key is a flat Mission left over from before 2026-10-02."""

    value = (mission.final_report or {}).get(SEMANTICS_KEY)
    return HIERARCHICAL_SEMANTICS if value == HIERARCHICAL_SEMANTICS else LEGACY_SEMANTICS


class PlanCommitRejected(StoreError):
    """The plan commit was refused; nothing was written.

    ``reason`` is a stable machine name — the proposer decides what to do next from
    it, so it is part of the contract and not a message to be reworded freely.
    """

    def __init__(self, reason: str, detail: str) -> None:
        super().__init__(f"{reason}: {detail}")
        self.reason = reason
        self.detail = detail


@dataclass(frozen=True, slots=True)
class PlanPrincipal:
    """Who is issuing the command, and inside which manager scope (§7.4 step 1)."""

    principal_id: str
    scope_id: str = "mission"

    def __post_init__(self) -> None:
        if not str(self.principal_id).strip():
            raise ContractError("a plan commit needs an identified principal")


@dataclass(frozen=True, slots=True)
class CommitPlanCommand:
    """One request to make ``delta`` the Mission's next plan revision.

    The command carries the *checked* delta, the task bindings the increment
    creates (TG §3.2 keeps those beside the delta, not inside it) and the resulting
    network the proposer compiled — the check certificate this commit re-confirms
    under the current structural state rather than trusts.
    """

    command_id: str
    mission_id: str
    delta: ProposedPlanDelta
    network: TaskNetworkSnapshot
    task_bindings: tuple[TaskSemanticBindingV1, ...] = ()
    issued_by: str = ""
    scope_id: str = "mission"
    running_work_policy: RunningWorkPolicy = RunningWorkPolicy.RETAIN_IF_BINDINGS_UNCHANGED
    superseded_occurrences: tuple[OccurrenceId, ...] = ()
    budget_requirement: BudgetRequirement | None = None
    structure_budget: GraphStructureBudget = DEFAULT_PROJECTION_BUDGET
    granted_fuel: Mapping[str, int] = field(default_factory=dict)
    source: Mapping[str, Any] = field(default_factory=dict)
    #: the deployment's own seed methods (what the planning world installed): the only
    #: methods adopted without a method review of this Mission
    seed_methods: tuple[Any, ...] = ()

    def __post_init__(self) -> None:
        if not str(self.command_id).strip():
            raise ContractError("a plan commit command needs a command_id (§17.4 idempotency)")
        require_commit_ready(self.delta)
        if not isinstance(self.network, TaskNetworkSnapshot):
            raise ContractError("command.network must be the resulting TaskNetworkSnapshot")
        object.__setattr__(
            self,
            "running_work_policy",
            RunningWorkPolicy(str(self.running_work_policy)),
        )

    @property
    def read_set(self) -> SemanticReadSet:
        return self.delta.read_set

    def intent_hash(self) -> str:
        """What this command *asks for*, independent of when it was delivered.

        Two deliveries of the same intent under one ``command_id`` are the same
        command (§17.4); a different intent under the same id is a conflict, which
        is why the delta, the bindings and the concurrency basis are all in here.
        """

        return content_hash_of(
            {
                "command_id": self.command_id,
                "mission_id": self.mission_id,
                "delta": self.delta.to_json(),
                "task_bindings": [binding.to_json() for binding in self.task_bindings],
                "scope_id": self.scope_id,
                "issued_by": self.issued_by,
                "running_work_policy": str(self.running_work_policy),
                "superseded_occurrences": sorted(str(item) for item in self.superseded_occurrences),
                "structure_budget": self.structure_budget.to_json(),
            }
        )


class PlanCommitsMixin:
    """Commit one PlanRevision: check everything, then write it in one transaction."""

    if TYPE_CHECKING:  # pragma: no cover - provided by CommitService
        _store: Store
        _ledger: BudgetLedger
        _deployed_layers: frozenset[str]

        def _emit(
            self,
            event_type: str,
            mission_id: str,
            *,
            key: str,
            task_id: str | None = None,
            attempt_id: str | None = None,
            payload: Mapping[str, Any] | None = None,
        ) -> Event: ...

        def _require_mission(self, mission_id: str) -> Mission: ...

        # Provided by ``ObligationCommitsMixin``, which ``CommitService`` inherits
        # alongside this one: admitting or withdrawing a demand is an authorisation
        # act with one audited entry point (P2.3c part 2d, decision 3).
        def admit_obligation_demand(
            self,
            mission_id: str,
            obligation_id: Any,
            *,
            principal: str,
            requester: Mapping[str, Any],
            evidence: Mapping[str, Any],
            parent_obligation_id: Any = None,
            relation: str | None = None,
            ledger: Any = None,
            plan_revision: int | None = None,
        ) -> ObligationAccountView: ...

        def withdraw_obligation_demand(
            self,
            mission_id: str,
            obligation_id: Any,
            *,
            principal: str,
            requester: Mapping[str, Any],
            evidence: Mapping[str, Any],
            parent_obligation_id: Any = None,
            relation: str | None = None,
            ledger: Any = None,
            plan_revision: int | None = None,
        ) -> ObligationAccountView: ...

    # ------------------------------------------------------------------ public entry
    def commit_plan_revision(
        self,
        command: CommitPlanCommand,
        principal: PlanPrincipal,
        *,
        precommit_guard: Callable[[], None] | None = None,
        taskgraph: TaskGraphPlanCommitParticipant | None = None,
    ) -> PlanCommitReceipt:
        """Apply one plan revision atomically; return the receipt (§9.4, TG §7.4)."""

        if not isinstance(command, CommitPlanCommand):
            raise PlanCommitRejected(
                "bad_command", "commit_plan_revision expects a CommitPlanCommand"
            )
        if not isinstance(principal, PlanPrincipal):
            raise PlanCommitRejected(
                "bad_principal", "commit_plan_revision expects a PlanPrincipal"
            )
        # §7.4: identity first — before the receipt lookup, so a forged replay of
        # someone else's command_id cannot read back their receipt.
        self._authorize(command, principal)
        intent = command.intent_hash()
        with self._store.transaction():
            mission = self._require_mission(command.mission_id)
            mode = semantics_of(mission)
            if mode != HIERARCHICAL_SEMANTICS:
                # The door.  Only the ``missions`` row was read; no migration-16
                # table is touched on this path, and no event is appended.
                raise PlanCommitRejected(
                    "SEMANTICS_NOT_HIERARCHICAL",
                    f"mission {mission.id} runs under {mode!r}; a plan revision is committed "
                    "only for a Mission that asked for the hierarchical semantics (§18.5 rule 1)",
                )
            semantics = HtnStore(self._store)
            replayed = self._replayed_receipt(semantics, command, intent)
            if replayed is not None:
                return replayed
            if precommit_guard is not None:
                precommit_guard()

            try:
                require_bound(self._store, command.mission_id)
            except NotBoundError:
                # A hierarchical Mission is bound when it is created (2026-10-03); the
                # one write path of plan_revisions never writes an unbound plan.
                raise PlanCommitRejected(
                    "TASKGRAPH_NOT_BOUND", "this Mission has no TaskGraph binding"
                ) from None
            # 按需导入：循环依赖（plan_commits ↔ taskgraph_plan_commit）
            from .taskgraph_plan_commit import TaskGraphPlanCommitParticipant

            if (
                not isinstance(taskgraph, TaskGraphPlanCommitParticipant)
                or taskgraph.store is not self._store
                or taskgraph.history.store is not self._store
            ):
                raise PlanCommitRejected(
                    "TASKGRAPH_COMMIT_PARTICIPANT_REQUIRED",
                    "the TaskGraph requires the installed same-Store commit participant",
                )
            graph_impact = taskgraph.prepare(command, principal)
            if mission.status in TERMINAL_MISSION:
                raise PlanCommitRejected(
                    "MISSION_NOT_WRITABLE",
                    f"mission {mission.id} is {mission.status!s} and accepts no new plan",
                )
            read_set = command.read_set
            self._check_read_set(semantics, command, read_set)
            base, new_revision = self._check_plan_revision(semantics, command)
            self._check_structure(semantics, command)
            self._check_method_reviews(command)
            self._check_binding_rewrites(semantics, command)
            obligations = ObligationStore(self._store)
            self._check_commit_ready(obligations, command)
            self._check_budget(semantics, obligations, command)
            revoked = self._revoke_running_work(
                semantics,
                command,
                revocation_targets=(
                    frozenset()
                    if graph_impact is None
                    else frozenset(item.occurrence_id for item in graph_impact.targets)
                ),
            )
            receipt = self._write(
                semantics,
                obligations,
                command,
                mission=mission,
                base=base,
                new_revision=new_revision,
                intent=intent,
                revoked=revoked,
            )
            taskgraph.record_applied(command, receipt)
            return receipt

    def _check_method_reviews(self, command: CommitPlanCommand) -> None:
        """审阅闸门（片 A 第 6 项）：采用规划器在本任务里提出的做法，须有通过的新做法审阅正式记录。

        放行的只有部署自带的种子做法（规划世界装入、随命令给出）；其余做法不管从哪来，都要有本任务通过的做法审阅（阶段 C3：复用也要审）。
        闸门不判断做法好不好，只认正式记录（或人对"判不下来"的裁决）。
        """

        if not command.delta.method_instances:
            return
        refused = unreviewed_adopted_methods(
            self._store, command.mission_id, command.delta.method_instances, command.seed_methods
        )
        if refused:
            raise PlanCommitRejected(
                REVIEW_REQUIRED,
                "a method is adopted in a Mission only after its independent "
                "review passed (or the person passed it): "
                + json.dumps(refused, ensure_ascii=False, sort_keys=True),
            )

    def _check_binding_rewrites(self, semantics: HtnStore, command: CommitPlanCommand) -> None:
        """H4 rewires lineage/input control; Task meaning and duty stay immutable."""
        if not command.delta.binding_rewrites:
            return

        if (
            planning_decision_store.PlanningDecisionStore(self._store).get_mission_protocol(
                command.mission_id
            )
            is None
        ):
            raise PlanCommitRejected(
                "DECISION_NOT_ENABLED_IN_PHASE",
                "binding rewrites require a planning-protocol binding",
            )
        revoked = {str(item) for item in command.superseded_occurrences} | self._retired_children(
            semantics, command
        )
        control_fields = {
            "contract_revision",
            "occurrence_binding",
            "adopted_method_instance_id",
            "input_binding_revision",
            "dispatch_generation",
        }
        # Accepted work keeps its immutable Task/result lineage. Changing its
        # input requires a successor, never clearing accepted_result_id in place.
        input_changes = [
            item.binding
            for item in command.delta.binding_rewrites
            if (old := semantics.task_semantics_of(command.mission_id, str(item.binding.task_id)))
            is not None
            and int(item.binding.input_binding_revision) != int(old.input_binding_revision)
        ]
        for changed in input_changes:
            task = self._store.get_task(str(changed.task_id))
            if task is None or task.mission_id != command.mission_id or task.accepted_result_id:
                raise PlanCommitRejected(
                    "REPAIR_NOT_ALLOWED",
                    "accepted or missing dependent requires an explicit successor",
                )
            if any(
                str(row.task_id) == str(changed.task_id) and str(row.validity) == "CURRENT"
                for row in semantics.list_acceptances(command.mission_id)
            ):
                raise PlanCommitRejected(
                    "REPAIR_NOT_ALLOWED", "accepted dependent requires an explicit successor"
                )
            # 夜间 N6：这是秩序约束，不是缺陷——结论是不可变的事实，原地改它的成员会让现行结论说的
            # 不再是它当时审过的那组步骤。目标要换，就换掉持有它的上级做法：被换下的做法细化出的
            # 子目标连同它下面采用的做法一起退役（compiler._retirement_closure），新子目标重新形成结论。
            if any(
                str(row.goal_task_id) == str(changed.task_id) and str(row.validity) == "CURRENT"
                for row in semantics.list_goal_resolutions(command.mission_id)
            ):
                raise PlanCommitRejected(
                    "REPAIR_NOT_ALLOWED",
                    # 规划器看到的拒绝理由截在 300 字以内：能做的那一步写在前面
                    f"resolved dependent requires an explicit successor: {changed.task_id} has a current "
                    "goal resolution; replace the method of the goal holding it (REPLACE_METHOD) "
                    "instead of changing it in place",
                )
        if input_changes:
            indexes = read_repair_impact_indexes(self._store, command.network, command.mission_id)
            required = {
                str(item)
                for item in affected_occurrences(
                    command.network, tuple(str(item.task_id) for item in input_changes), indexes
                )
            }
            if not required.issubset({str(item) for item in command.superseded_occurrences}):
                raise PlanCommitRejected(
                    "REQUEST_BINDING_STALE", "repair impact grew after preview"
                )
        for rewrite in command.delta.binding_rewrites:
            new = rewrite.binding
            old = semantics.task_semantics_of(command.mission_id, str(new.task_id))
            if old is None or content_hash_of(old.to_json()) != rewrite.expected_hash:
                raise PlanCommitRejected("REQUEST_BINDING_STALE", "rewritten Task binding changed")
            before, after = old.to_json(), new.to_json()
            if {k: v for k, v in before.items() if k not in control_fields} != {
                k: v for k, v in after.items() if k not in control_fields
            }:
                raise PlanCommitRejected(
                    "STRUCTURE_INVALID",
                    "a binding rewrite cannot change Task meaning or Obligation",
                )
            specs = [spec for spec in command.network.occurrences if spec.task_id == new.task_id]
            if not specs or not {str(spec.occurrence_id) for spec in specs}.issubset(revoked):
                raise PlanCommitRejected(
                    "RUNNING_WORK_NOT_RECONCILED",
                    "rewritten Task needs explicit execution-right revocation",
                )
            if (
                int(new.contract_revision) != int(old.contract_revision) + 1
                or int(new.dispatch_generation) != int(old.dispatch_generation) + 1
                or int(new.input_binding_revision)
                not in {int(old.input_binding_revision), int(old.input_binding_revision) + 1}
            ):
                raise PlanCommitRejected(
                    "STRUCTURE_INVALID", "binding control revisions must advance without resetting"
                )
            if command.network.binding_for_task(new.task_id) != new:
                raise PlanCommitRejected(
                    "STRUCTURE_INVALID",
                    "binding rewrite differs from the validated candidate network",
                )
            owner = new.occurrence_binding
            if owner is not None:
                try:
                    instance = command.network.instance(owner.method_instance_id)
                except KeyError as error:
                    raise PlanCommitRejected(
                        "STRUCTURE_INVALID", "rewritten owner is absent from candidate"
                    ) from error
                if not command.network.is_adopted(instance.instance_id) or not any(
                    child.slot_key == owner.slot_key
                    and (child.goal_occurrence_id or child.occurrence_id) == owner.occurrence_id
                    and owner.occurrence_id in {spec.occurrence_id for spec in specs}
                    for child in instance.child_bindings
                ):
                    raise PlanCommitRejected(
                        "STRUCTURE_INVALID", "rewritten Task is not owned by the exact adopted slot"
                    )

    # ------------------------------------------------------- the proposer's own side
    def read_item_for(self, mission_id: str, kind: ReadItemKind, subject_id: str) -> ReadItem:
        """The read-set entry a proposer should record for one subject, right now.

        The proposing side and the checking side must agree on *what* a subject's
        semantic revision is; writing that formula twice is how they stop agreeing.
        So the compiler-side entry is built by the same resolvers the commit uses,
        and a subject whose current state cannot be expressed as a revision plus a
        content hash is refused here rather than recorded as an unre-checkable read.
        """

        checker = self._read_set_checker(mission_id)
        try:
            return checker.read_item(kind, subject_id)
        except ReadSetChannelUnknown as unknown:
            raise PlanCommitRejected("READ_SET_UNRESOLVED", unknown.detail) from unknown

    def _read_set_checker(self, mission_id: str) -> SemanticReadSetChecker:
        """The one re-validation implementation, configured for the *plan* path.

        ``allow_task_control_channels`` stays off: a plan proposal's TASK ids are
        bare task ids, and leaving the namespaced dispatch-control ids unresolved is
        exactly what this path did before ``_read_set`` existed (§18.5 constraint 3 —
        the old behaviour is not redefined by sharing an implementation).
        """

        return SemanticReadSetChecker(
            self._store,
            HtnStore(self._store),
            mission_id=mission_id,
            resolvers={
                "goal": self._goal_state,
                "method": self._method_state,
                "observation": self._observation_state,
                "acceptance": self._acceptance_state,
                "obligation": self._obligation_state,
                "authority": self._authority_state,
            },
        )

    # -- one seam per channel: this path's own name for the shared resolver.  They
    # delegate rather than re-implement — ``_read_set`` is the single implementation
    # (§ADR-13 clause 2) — and they exist because the mutation suite weakens one
    # channel at a time through *this* class, which is also how a deployment would
    # override one without forking the check.
    def _goal_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).goal_state(semantics, mission_id, item)

    def _method_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).method_state(semantics, mission_id, item)

    def _observation_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).observation_state(
            semantics, mission_id, item
        )

    def _witness_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).witness_state(
            semantics, mission_id, item
        )

    def _acceptance_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).acceptance_state(
            semantics, mission_id, item
        )

    def _obligation_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).obligation_state(
            semantics, mission_id, item
        )

    def _authority_state(
        self, semantics: HtnStore, mission_id: str, item: ReadItem
    ) -> tuple[int, str] | None:
        return _shared(self._store, semantics, mission_id).authority_state(
            semantics, mission_id, item
        )

    # ------------------------------------------------------------------ gate 1: identity
    @staticmethod
    def _authorize(command: CommitPlanCommand, principal: PlanPrincipal) -> None:
        """Authorship is stated by the command and re-checked here, never inferred.

        An *unsigned* command is refused rather than attributed to whoever presents
        it: treating a blank ``issued_by`` as "no claim, so no mismatch" would let
        any principal holding the scope commit a proposal it did not author, and the
        receipt would then name a manager that never issued the command (§7.4).
        """

        if not str(command.issued_by).strip():
            raise PlanCommitRejected(
                "PRINCIPAL_MISMATCH",
                "the command names no issuer; a plan revision is committed on behalf of "
                "an identified manager, and an unsigned command is not attributed to "
                f"{principal.principal_id!r} by default (§7.4)",
            )
        if command.issued_by != principal.principal_id:
            raise PlanCommitRejected(
                "PRINCIPAL_MISMATCH",
                f"the command was issued by {command.issued_by!r} and presented by "
                f"{principal.principal_id!r}; authorship is not re-assignable at delivery",
            )
        if command.scope_id != principal.scope_id:
            raise PlanCommitRejected(
                "SCOPE_NOT_AUTHORIZED",
                f"{principal.principal_id!r} holds scope {principal.scope_id!r} and may not "
                f"commit into {command.scope_id!r}",
            )

    # --------------------------------------------------------------- gate 2: idempotency
    @staticmethod
    def _replayed_receipt(
        semantics: HtnStore, command: CommitPlanCommand, intent: str
    ) -> PlanCommitReceipt | None:
        """The receipt of an earlier delivery of this very command, if there is one.

        §17.4: the same command twice is one commit and one receipt.  A *different*
        intent under the same id is not a replay — it is two commands wearing one
        name, and answering it with the stored receipt would report work that was
        never done.
        """

        try:
            stored = semantics.get_commit_receipt(command.command_id)
        except StoreError:
            return None
        if stored.intent_hash != intent:
            raise PlanCommitRejected(
                "COMMAND_PAYLOAD_CONFLICT",
                f"command {command.command_id!r} was applied with intent {stored.intent_hash}, "
                f"and this delivery asks for {intent}",
            )
        return stored

    # ----------------------------------------------------------- gate 5: the read-set
    def _check_read_set(
        self, semantics: HtnStore, command: CommitPlanCommand, read_set: SemanticReadSet
    ) -> None:
        """ADR-13 clause 2: every channel, item by item, fail closed.

        The channel-by-channel work lives in :mod:`._read_set` so this path and the
        accept-side one cannot disagree about what a subject's semantic revision is
        (the P2.3c review found a second, five-channel copy).  What stays here is
        this path's own vocabulary: a channel that cannot be re-checked is refused
        separately from one that is out of date — "I could not tell" and "it changed"
        call for different work by the proposer, and reporting the first as the second
        would send them off to recompile something that was never the problem.
        """

        del semantics
        checker = self._read_set_checker(command.mission_id)
        try:
            verdict = checker.verify(read_set)
        except ReadSetChannelUnknown as unknown:
            raise PlanCommitRejected("READ_SET_UNRESOLVED", unknown.detail) from unknown
        if verdict.unresolved:
            raise PlanCommitRejected("READ_SET_UNRESOLVED", verdict.unresolved_detail())
        if verdict.stale:
            raise PlanCommitRejected("READ_SET_STALE", verdict.stale_detail())

    # ------------------------------------------------------- gate 6: the active plan
    @staticmethod
    def _check_plan_revision(semantics: HtnStore, command: CommitPlanCommand) -> tuple[int, int]:
        active = semantics.active_plan_revision(command.mission_id)
        current = 0 if active is None else active.revision
        base = int(command.delta.base_plan_revision)
        if base != current:
            raise PlanCommitRejected(
                "PLAN_REVISION_STALE",
                f"the delta is based on plan revision {base}; mission "
                f"{command.mission_id} is at {current}",
            )
        if int(command.network.plan_revision) != base + 1:
            # The network the proposer compiled is the *resulting* one, so it carries
            # the revision this commit is about to create.  Checking it here is what
            # stops a certificate for some other revision being presented instead.
            raise PlanCommitRejected(
                "PLAN_REVISION_STALE",
                f"the supplied network is at plan revision {int(command.network.plan_revision)}; "
                f"a delta based on {base} must compile to {base + 1}",
            )
        return current, current + 1

    # ---------------------------------------------------- gate 7: structure, again
    def _check_structure(self, semantics: HtnStore, command: CommitPlanCommand) -> None:
        """Re-validate the whole resulting network, not only the delta (TG §7.3).

        Two proposals that each add one edge can merge into a cycle, so a check that
        only looked at the increment would pass both.  The network the proposer
        compiled is re-checked here, under the current transaction, and its contents
        are pinned to the delta so a certificate for some *other* network cannot be
        presented instead.

        Three things are checked that a projection validator alone cannot see, because
        each of them is about the relation between the *supplied* network and what the
        Mission already holds:

        * the network must **preserve** the plan in force — an occurrence that simply
          vanishes, with no operation retiring or superseding it, is work silently
          dropped, and the projection of the smaller network is perfectly valid;
        * an alternative must *be* a method instance, and the delta may not adopt one
          the certificate does not hold — otherwise an adopted row is written past the
          network the snapshot invariant checked;
        * the delta's own bindings must agree with the network's (``assert_consistent_with``).
        """

        network = command.network
        delta = command.delta
        if str(network.mission_id) != command.mission_id:
            raise PlanCommitRejected(
                "STRUCTURE_INVALID",
                f"the supplied network belongs to mission {network.mission_id!s}",
            )
        present = {spec.occurrence_id for spec in network.occurrences}
        missing = sorted(
            str(spec.occurrence_id)
            for spec in delta.occurrences
            if spec.occurrence_id not in present
        )
        if missing:
            raise PlanCommitRejected(
                "STRUCTURE_INVALID",
                f"the supplied network does not contain the delta's occurrences: {missing}",
            )
        dangling = sorted(str(item) for item in delta.referenced_occurrences if item not in present)
        if dangling:
            raise PlanCommitRejected(
                "STRUCTURE_INVALID",
                f"the delta references occurrences the network does not hold: {dangling}",
            )
        self._check_preserves_plan(semantics, command, present)
        self._check_alternatives_are_method_instances(semantics, command)
        bindings = {binding.task_id: binding for binding in network.task_bindings}
        try:
            delta.assert_consistent_with(bindings)
        except ContractError as error:
            raise PlanCommitRejected("STRUCTURE_INVALID", str(error)) from error
        projection = validate_execution_projection(
            network.execution_projection(), command.structure_budget
        )

        projection = taskgraph_projection_report(network, projection)
        refinement = validate_refinement_acyclic(network)
        problems = [*projection.problems, *refinement.problems]
        if problems:
            raise PlanCommitRejected(
                "STRUCTURE_INVALID",
                "; ".join(f"{problem.kind!s}: {problem.detail}" for problem in problems),
            )

    def _check_preserves_plan(
        self, semantics: HtnStore, command: CommitPlanCommand, present: set[Any]
    ) -> None:
        """A revision may replace work; it may not quietly lose it (§9.4).

        The supplied network is the *resulting* plan, so anything the plan in force
        held and it does not is a removal.  A removal is legitimate only when the
        delta says so — the occurrence is named as superseded, or its parent method
        instance is being retired.  Otherwise the commit is refused: the projection
        of the smaller network is entirely valid, so no structural validator would
        notice, and the duty behind the dropped occurrence would be left with nobody
        working on it and no record that anyone decided that.
        """

        active = semantics.active_plan_revision(command.mission_id)
        if active is None:
            return
        previous = {
            spec.occurrence_id
            for spec in semantics.list_plan_memberships(command.mission_id, active.revision)
        }
        dropped = previous - set(present)
        if not dropped:
            return
        accounted = {str(item) for item in command.superseded_occurrences} | self._retired_children(
            semantics, command
        )
        orphaned = sorted(str(item) for item in dropped if str(item) not in accounted)
        if orphaned:
            raise PlanCommitRejected(
                "PLAN_NOT_PRESERVED",
                f"the supplied network drops occurrences {orphaned} that plan revision "
                f"{active.revision} holds, and the delta neither supersedes them nor retires "
                "the method instance that opened them; work is replaced by decision, "
                "never by omission (§9.4)",
            )

    @staticmethod
    def _check_alternatives_are_method_instances(
        semantics: HtnStore, command: CommitPlanCommand
    ) -> None:
        """§18.5: a choice lives in the method-instance layer, resolved, and only there.

        The graph layer has exactly one reading — several dependencies mean *all of
        them* — so an alternative can only be a second MethodInstance for one goal
        occurrence, of which at most one may be adopted.

        :class:`TaskNetworkSnapshot` already refuses to *exist* with two adopted
        instances over one occurrence ("alternatives are OR, not AND"), so the
        proposer cannot compile that network at all.  What it does not cover is the
        write path: :meth:`_write` inserts ``delta.method_instances`` as ``ADOPTED``
        without the network having to contain them, so a delta carrying an instance
        the certificate never included would land an adopted row the snapshot
        invariant never saw — and two of those over one occurrence is precisely the
        unresolved OR, assembled in the database instead of in the snapshot.

        Both halves are closed here: every instance this delta adopts must be one the
        supplied network holds *and* adopts, and it may not join an instance the store
        already has adopted over the same occurrence unless the delta retires it.
        """

        network = command.network
        adopted_in_network = {
            str(draft.instance_id)
            for draft in network.method_instances
            if draft.instance_id in network.adopted_instance_ids
        }
        smuggled = sorted(
            str(draft.instance_id)
            for draft in command.delta.method_instances
            if str(draft.instance_id) not in adopted_in_network
        )
        if smuggled:
            raise PlanCommitRejected(
                "OR_NOT_RESOLVED",
                f"the delta adopts method instances {smuggled} that the supplied network does "
                "not hold as adopted; an adopted row written past the certificate is how two "
                "alternatives end up adopted over one occurrence (§18.5)",
            )
        retiring = {str(item) for item in command.delta.retired_instance_ids}
        by_occurrence: dict[str, set[str]] = {}
        for draft in semantics.list_method_instances(command.mission_id, state="ADOPTED"):
            if str(draft.instance_id) in retiring:
                continue
            by_occurrence.setdefault(str(draft.effective_goal_occurrence_id), set()).add(
                str(draft.instance_id)
            )
        for draft in command.delta.method_instances:
            by_occurrence.setdefault(str(draft.effective_goal_occurrence_id), set()).add(
                str(draft.instance_id)
            )
        contested = {
            occurrence: sorted(instances)
            for occurrence, instances in by_occurrence.items()
            if len(instances) > 1
        }
        if contested:
            raise PlanCommitRejected(
                "OR_NOT_RESOLVED",
                "; ".join(
                    f"occurrence {occurrence!r} would have {len(instances)} adopted method "
                    f"instances {instances}; an alternative is a method instance and at most "
                    "one of them is adopted — the graph layer reads several dependencies as "
                    "AND, never as a choice (§18.5)"
                    for occurrence, instances in sorted(contested.items())
                ),
            )

    # --------------------------------------------- gate 8: the delta is commit-ready
    @staticmethod
    def _check_commit_ready(obligations: ObligationStore, command: CommitPlanCommand) -> None:
        """§18.3 / §6.1: every duty an occurrence names exists, and none is re-opened.

        Run as a *gate*, against the duties registered **before** this delta's own
        openings are applied.  It used to run in the write half, after the openings
        had been persisted — at which point a newly opened duty is indistinguishable
        from one that already existed, so a perfectly legitimate opening was reported
        as a re-opening and a bare ``ContractError`` escaped with no reason name on
        it.  Both halves of that are fixed here: the set is the pre-opening one, and
        the refusal carries a name the proposer can act on.
        """

        registered = frozenset(obligations.obligation_ids(command.mission_id))
        try:
            require_commit_ready(command.delta, registered_obligations=registered)
        except ContractError as error:
            raise PlanCommitRejected("DELTA_NOT_COMMIT_READY", str(error)) from error

    # ------------------------------------------------------------- gate 9: the budget
    @staticmethod
    def _check_budget(
        semantics: HtnStore, obligations: ObligationStore, command: CommitPlanCommand
    ) -> None:
        """Only a check.  The legacy token ledger is not consulted and not moved.

        Two allowances are in play and they are not the same thing: the *structural*
        budget (ADR-08) bounds how big a plan may get, and a duty's *recursion fuel*
        (§6.1) bounds how much re-planning one responsibility may buy.  Overrunning
        either is ``BOUND_REACHED`` / ``BUDGET_INSUFFICIENT``, never a silently
        trimmed plan.
        """

        budget = command.structure_budget
        network = command.network
        live = len(network.occurrences)
        if live > budget.max_live_tasks:
            raise PlanCommitRejected(
                "BOUND_REACHED",
                f"the plan would hold {live} occurrences, above max_live_tasks="
                f"{budget.max_live_tasks} (structure budget v{budget.budget_version})",
            )
        expanded = len(semantics.list_method_instances(command.mission_id)) + len(
            command.delta.method_instances
        )
        if expanded > budget.max_expanded_nodes:
            raise PlanCommitRejected(
                "BOUND_REACHED",
                f"the mission would have expanded {expanded} method instances, above "
                f"max_expanded_nodes={budget.max_expanded_nodes}",
            )
        declared = command.budget_requirement
        if declared is not None:
            actual = (
                len(command.delta.occurrences),
                len(command.delta.order_constraints),
                len(command.delta.data_requirements),
            )
            asked = (
                declared.new_occurrences,
                declared.new_order_constraints,
                declared.new_data_requirements,
            )
            if actual != asked:
                raise PlanCommitRejected(
                    "BUDGET_REQUIREMENT_MISMATCH",
                    f"the declared cost {asked} does not describe the delta {actual}",
                )
        # The fuel side is decided by the ledger itself: ``open_from`` refuses a share
        # the parent no longer has.  It runs here, on a throwaway ledger, so an
        # exhausted allowance refuses the command before anything is written.
        if command.delta.obligation_openings:
            ledger = obligations.load_ledger(command.mission_id)
            try:
                apply_obligation_openings(
                    ledger, command.delta, granted_fuel=dict(command.granted_fuel)
                )
            except DemandNotAdmissible as error:
                # P2.3c part 2d, decision 3.  "Nobody asked for this work" is not a
                # budget problem and does not get the budget's name (§7.4): the repair
                # is to adopt the slot that wants it, or not to open the duty.
                raise PlanCommitRejected("DEMAND_NOT_ADMITTED", str(error)) from error
            except ContractError as error:
                raise PlanCommitRejected("BUDGET_INSUFFICIENT", str(error)) from error

    # ------------------------------------------------ gate 10: work already in flight
    def _revoke_running_work(
        self,
        semantics: HtnStore,
        command: CommitPlanCommand,
        *,
        revocation_targets: frozenset[str],
    ) -> dict[str, int]:
        """Take away the execution right of everything this delta replaces (§9.4).

        It withdraws eligibility; it does not approve the new version and it does not
        cancel an Attempt.  The dispatch generation is bumped so a dispatch that was
        already handed out no longer matches, and a durable recheck entry is written
        so the reconciliation is somebody's job rather than a hope.  The targets are
        the TaskGraph participant's impact (TG §7.4).
        """

        targets = sorted(revocation_targets)
        if not targets:
            return {}
        by_occurrence = self._occurrence_tasks(semantics, command)
        epoch = semantics.epoch(command.mission_id, command.scope_id)
        revoked: dict[str, int] = {}
        rewrites = {
            str(item.binding.task_id): item.binding for item in command.delta.binding_rewrites
        }
        for occurrence in targets:
            task_id = by_occurrence.get(occurrence)
            if task_id is None:
                raise PlanCommitRejected(
                    "RUNNING_WORK_NOT_RECONCILED",
                    f"occurrence {occurrence!r} is named as replaced but belongs to no task "
                    "this mission holds",
                )
            binding = semantics.task_semantics_of(command.mission_id, task_id)
            if binding is None:
                raise PlanCommitRejected(
                    "MISSING_SEMANTIC_BINDING",
                    f"task {task_id} has no semantic binding; in the hierarchical mode a "
                    "missing binding is corruption, not a legacy fallback (§18.5)",
                )
            # A Task may have multiple occurrences. Its generation is global,
            # so revoke it once, while marking every affected occurrence dirty.
            superseded = (
                binding if task_id in revoked else rewrites.get(task_id, _superseded(binding))
            )
            if task_id not in revoked:
                semantics.put_task_semantics(command.mission_id, superseded)
            generation = int(superseded.dispatch_generation)
            semantics.mark_dirty(
                command.mission_id,
                subject_kind="occurrence",
                subject_id=occurrence,
                scope_id=command.scope_id,
                epoch=epoch,
                reason="dispatch_generation_revoked",
            )
            revoked[task_id] = generation
        return revoked

    def _held_by_retired_row(self, task: Any) -> int:
        """What a Task row the active plan no longer names still holds (P2.3j).

        Its settled usage plus whatever is still reserved on it — never more than its
        ceiling, and the ceiling itself when the account cannot be read (a row opened
        before accounts existed, or one this ledger does not know): counting *more*
        is the conservative failure, counting less would grant the same tokens twice.
        """

        ceiling = int(task.budget.max_tokens or 0)
        try:
            snapshot = self._ledger.account(task_account(task.id))
        except BudgetError:
            return ceiling
        held = int(snapshot.reserved_tokens) + int(snapshot.settled_tokens)
        return max(0, min(ceiling, held))

    @staticmethod
    def _retired_children(semantics: HtnStore, command: CommitPlanCommand) -> set[str]:
        found: set[str] = set()
        for instance_id in command.delta.retired_instance_ids:
            try:
                bindings = semantics.list_child_occurrences(command.mission_id, str(instance_id))
            except StoreError:  # pragma: no cover - list never raises today
                continue
            found.update(str(child.occurrence_id) for child in bindings)
        if command.delta.binding_rewrites:
            # A membership rewrite preserves unchanged shared work. Only dropped
            # memberships or explicitly rewritten bindings lose execution rights.
            retained = {str(spec.occurrence_id) for spec in command.network.occurrences}
            rewritten = {item.binding.task_id for item in command.delta.binding_rewrites}
            changed = {
                str(spec.occurrence_id)
                for spec in command.network.occurrences
                if spec.task_id in rewritten
            }
            found = (found - retained) | (found & changed)
        return found

    def _withdraw_retired_demands(
        self,
        semantics: HtnStore,
        obligations: ObligationStore,
        command: CommitPlanCommand,
        *,
        plan_revision: int,
    ) -> list[str]:
        """Retiring a slot ends **its own** interest, and nobody else's (§24.1 dec. 9).

        A duty that another adopted slot still binds keeps its demand: that is the
        shared-sub-goal case, where two consumers each hold a ``DemandRef`` and one
        leaving must not take the other's work away.  A duty whose last adopting slot
        just went is released, so it stops looking dispatchable to a plan that no
        longer contains it.
        """

        if not command.delta.retired_instance_ids:
            return []
        retiring = {str(item) for item in command.delta.retired_instance_ids}
        drafts = {
            str(item.instance_id): item
            for item in semantics.list_method_instances(command.mission_id)
        }
        orphaned: set[str] = set()
        for instance_id in sorted(retiring):
            try:
                children = semantics.list_child_occurrences(command.mission_id, instance_id)
            except StoreError:  # pragma: no cover - list never raises today
                continue
            held = drafts.get(instance_id)
            # A refinement slot carries the *parent's* duty and opened nothing (§6.1),
            # so retiring it cannot release an interest it never created — least of all
            # the Mission's own root duty, which the requirements ask for and no slot
            # above it holds.
            parent_duty = None if held is None else str(held.obligation_id)
            orphaned.update(
                str(child.obligation_id)
                for child in children
                if str(child.obligation_id) != parent_duty
            )
        for draft in semantics.list_method_instances(command.mission_id, state="ADOPTED"):
            if str(draft.instance_id) in retiring:
                continue
            orphaned -= {str(binding.obligation_id) for binding in draft.child_bindings}
        for draft in command.delta.method_instances:
            orphaned -= {str(binding.obligation_id) for binding in draft.child_bindings}

        accounts = tuple(
            obligations.account(command.mission_id, identity)
            for identity in obligations.obligation_ids(command.mission_id)
        )
        independent = read_independent_demands(self._store, command.mission_id, accounts)
        # This is the obligation ledger, not an occurrence identity lookup:
        # a retiring method cannot withdraw somebody else's independent duty.
        orphaned -= {item.obligation_id for item in independent}
        released: list[str] = []
        for duty in sorted(orphaned):
            account = obligations.account(command.mission_id, ObligationId(duty))
            if not account.has_admitted_demand:
                continue
            self.withdraw_obligation_demand(
                command.mission_id,
                ObligationId(duty),
                principal=command.issued_by or "commit-service",
                requester={"kind": "method_slot"},
                evidence={
                    "retired_method_instances": sorted(retiring),
                    "plan_revision": plan_revision,
                    "delta_id": command.delta.delta_id,
                },
                plan_revision=plan_revision,
            )
            released.append(duty)
        return released

    @staticmethod
    def _occurrence_tasks(semantics: HtnStore, command: CommitPlanCommand) -> dict[str, str]:
        """Occurrence → task, from the plan in force plus the one being proposed."""

        mapping: dict[str, str] = {}
        active = semantics.active_plan_revision(command.mission_id)
        if active is not None:
            for spec in semantics.list_plan_memberships(command.mission_id, active.revision):
                mapping[str(spec.occurrence_id)] = str(spec.task_id)
        for spec in command.network.occurrences:
            mapping.setdefault(str(spec.occurrence_id), str(spec.task_id))
        return mapping

    # ----------------------------------------------------------------- the write half
    def _write(
        self,
        semantics: HtnStore,
        obligations: ObligationStore,
        command: CommitPlanCommand,
        *,
        mission: Mission,
        base: int,
        new_revision: int,
        intent: str,
        revoked: Mapping[str, int],
    ) -> PlanCommitReceipt:
        delta = command.delta
        network = command.network
        proposal_id = delta.compiled_from_proposal_id or delta.delta_id

        # The duty set as it stands *before* this delta opens anything: that is the
        # set the "names a duty nobody opened / re-opens an existing duty" invariant
        # is about (§18.3).  Reading it after the openings were persisted is what made
        # every legitimate opening look like a re-opening.
        registered = frozenset(obligations.obligation_ids(command.mission_id))
        require_commit_ready(delta, registered_obligations=registered)
        # Duties next: an occurrence may not name a duty nobody opened, so the
        # openings have to exist before the membership that references them.
        admitted: list[str] = []
        if delta.obligation_openings:
            ledger = obligations.load_ledger(command.mission_id)
            opened_by_duty = {
                str(opening.obligation_id): opening for opening in delta.obligation_openings
            }

            def _admit(admission: DemandAdmission, held: ObligationLedger) -> ObligationAccountView:
                # P2.3c part 2d, decision 3: the admission is a *recorded* act, taken by
                # the principal this command was authorised under, inside the same
                # transaction as the revision that adopted the slot asking for it
                # (TG implementation design §7.3).
                admitted.append(str(admission.obligation_id))
                return self.admit_obligation_demand(
                    command.mission_id,
                    admission.obligation_id,
                    principal=command.issued_by or "commit-service",
                    requester=admission.requester(),
                    evidence={
                        "parent_obligation_id": str(admission.parent_obligation_id),
                        "plan_revision": new_revision,
                        "delta_id": delta.delta_id,
                        "requirement_refs": list(
                            opened_by_duty[str(admission.obligation_id)].requirement_refs
                        ),
                    },
                    parent_obligation_id=admission.parent_obligation_id,
                    relation=str(admission.relation),
                    ledger=held,
                    plan_revision=new_revision,
                )

            apply_obligation_openings(
                ledger, delta, granted_fuel=dict(command.granted_fuel), admit=_admit
            )
            obligations.persist(ledger)
        released = self._withdraw_retired_demands(
            semantics, obligations, command, plan_revision=new_revision
        )

        for binding in command.task_bindings:
            if semantics.task_semantics_of(command.mission_id, str(binding.task_id)) is None:
                semantics.put_task_semantics(command.mission_id, binding)

        # Binding rewrites were appended exactly once by _revoke_running_work,
        # together with their new generation, in this same transaction.

        semantics.insert_plan_revision(
            command.mission_id,
            new_revision,
            snapshot_hash=content_hash_of(_network_identity(network)),
            read_set=delta.read_set,
            state="PREPARED",
            base_revision=base or None,
            delta_id=delta.delta_id,
        )

        instance_of = _occurrence_instances(network)
        for draft in delta.method_instances:
            # The instance id is derived from (goal, occurrence, method, parameters),
            # so a repair that re-grounds the very method and parameters already stored
            # changes nothing and used to die on the table's UNIQUE constraint as an
            # internal error (real run 2026-09-27, mission-bc2c094e9dc5e3b5). Say what
            # the planner did instead; the whole commit rolls back.
            try:
                existing = semantics.method_instance_state(
                    command.mission_id, str(draft.instance_id)
                )
            except StoreError:
                existing = None
            if existing is not None:
                raise PlanCommitRejected(
                    "REPAIR_NOT_ALLOWED",
                    f"method {draft.method_ref.method_id} with these parameters is already "
                    f"instance {draft.instance_id} ({existing}) for goal {draft.goal_id}; "
                    "a repair must choose a different method or different parameters",
                )
        for draft in delta.method_instances:
            semantics.insert_method_instance(command.mission_id, draft, state="ADOPTED")
        for instance_id in delta.retired_instance_ids:
            semantics.set_method_instance_state(command.mission_id, str(instance_id), "RETIRED")
        for spec in network.occurrences:
            semantics.insert_plan_membership(
                command.mission_id,
                new_revision,
                spec,
                instance_id=instance_of.get(str(spec.occurrence_id)),
                adopted=True,
            )
        for constraint in network.order_constraints:
            semantics.insert_order_constraint(command.mission_id, new_revision, constraint)
        for requirement in network.data_requirements:
            semantics.insert_data_requirement(command.mission_id, new_revision, requirement)
        semantics.record_read_set(command.mission_id, proposal_id, delta.read_set)

        # PREPARED → ACTIVE, in this same transaction: §9.4 forbids half an old plan
        # and half a new one being dispatchable, so the switch is never a second step.
        semantics.activate_plan_revision(command.mission_id, new_revision)

        # P2.3c part 2: the occurrence → work bridge.  Same transaction as the
        # revision it belongs to, because a plan whose occurrences are only half on
        # the board is exactly the "half an old plan and half a new one" §9.4
        # forbids.  Materialising is idempotent by construction — a row that exists
        # is reused, never rewritten — so a crash between the revision and the next
        # cycle cannot double-materialise or double-charge.
        materialised = self._materialise_occurrences(
            semantics, command, mission=mission, plan_revision=new_revision
        )
        activated = self._activate_for_work(mission, materialised)

        pending = _pending_dispatch(network, delta)
        payload = {
            "command_id": command.command_id,
            "delta_id": delta.delta_id,
            "proposal_id": proposal_id,
            "base_plan_revision": base,
            "plan_revision": new_revision,
            "scope_id": command.scope_id,
            "intent_hash": intent,
            "read_set_hash": content_hash_of(delta.read_set.to_json()),
            "running_work_policy": str(command.running_work_policy),
            "adopted_method_instances": [str(item.instance_id) for item in delta.method_instances],
            "retired_method_instances": [str(item) for item in delta.retired_instance_ids],
            "added_occurrences": [str(spec.occurrence_id) for spec in delta.occurrences],
            "opened_obligations": [
                str(opening.obligation_id) for opening in delta.obligation_openings
            ],
            # P2.3c part 2d, decision 3: "opened" and "somebody asked for it" are two
            # different facts and the receipt carries both.
            "admitted_demands": sorted(admitted),
            "withdrawn_demands": sorted(released),
            "order_constraints": len(network.order_constraints),
            "data_requirements": len(network.data_requirements),
            "revoked_dispatch_generations": dict(sorted(revoked.items())),
            # Registered, not dispatched: the scheduler decides when, and P2.3c is
            # where it learns to read this.  Writing it here keeps the event and the
            # projection one call (§18.5) without this module dispatching anything.
            "pending_dispatch": pending,
            # P2.3c part 2: what the scheduler may now see, and under which equation.
            "materialised_tasks": list(materialised.created),
            "reused_tasks": list(materialised.reused),
            "budget_conservation": materialised.conservation(),
            "mission_status": str((activated or mission).status),
            "source": dict(command.source),
        }
        self._emit(
            PLAN_REVISION_COMMITTED,
            command.mission_id,
            key=f"{command.mission_id}:plan-{new_revision}",
            payload=payload,
        )
        receipt = semantics.record_commit_receipt(
            command.mission_id,
            command_id=command.command_id,
            delta_id=delta.delta_id,
            base_plan_revision=base,
            new_plan_revision=new_revision,
            intent_hash=intent,
            read_set=delta.read_set,
            output_identity={
                "plan_revision": new_revision,
                "snapshot_hash": content_hash_of(_network_identity(network)),
                "occurrences": sorted(str(spec.occurrence_id) for spec in network.occurrences),
                "adopted_method_instances": sorted(
                    str(item.instance_id) for item in delta.method_instances
                ),
                "pending_dispatch": pending,
            },
            detail={
                "mission_version": mission.version,
                "scope_id": command.scope_id,
                "principal_scope_epoch": semantics.epoch(command.mission_id, command.scope_id),
                "revoked_dispatch_generations": dict(sorted(revoked.items())),
                "running_work_policy": str(command.running_work_policy),
                "materialised_tasks": list(materialised.created),
                "budget_conservation": materialised.conservation(),
                "source": dict(command.source),
            },
        )

        freeze_plan_completion_scopes(
            self._store,
            mission_id=command.mission_id,
            plan=network,
            plan_ref=PlanRevisionPinV1(
                revision=new_revision, snapshot_hash=content_hash_of(_network_identity(network))
            ),
            plan_receipt_id=receipt.command_id,
        )
        return receipt

    # --------------------------------------------- P2.3c: occurrences become work
    def _materialise_occurrences(
        self,
        semantics: HtnStore,
        command: CommitPlanCommand,
        *,
        mission: Mission,
        plan_revision: int,
    ) -> Materialisation:
        """Give every occurrence of the new plan a ``Task`` row and an account.

        The rules, in the order they matter:

        1. **A row that already exists is reused, never rewritten.**  An occurrence
           keeps its Task across revisions (the occurrence id *is* the task id in the
           compiled network), and rewriting the row would throw away its attempts,
           its accepted artefacts and its budget history — the very facts §9.4's
           running-work reconciliation is about.  ``_revoke_running_work`` has
           already withdrawn the execution right of anything this delta replaces.
        2. **Every form gets a row; only a primitive gets a dispatchable one.**  See
           :mod:`.occurrence_tasks` — a compound row is BLOCKED and is refused by the
           form gate at three independent places.
        3. **The budget is a share of what the Mission's task pool still has.**
           ``open_account`` refuses limits that do not fit the parent, so a share is
           computed rather than guessed, and every other dimension is inherited from
           the Mission.  The dividend is the pool *minus what the existing rows
           already hold* and the divisor counts the compounds nobody has refined yet,
           so a later refinement round is still payable — see
           the fixed per-leaf allowance (V42: no even share).  An allowance that does not fit, or a
           pool that cannot pay for the new primitives at all, is a refusal
           (``BUDGET_INSUFFICIENT``), never a row with an account nobody can draw on.
        """

        network = command.network
        pool = task_pool_tokens(mission)
        requirements = semantics.latest_requirements_revision(command.mission_id)
        existing: dict[str, int] = {}
        reused: list[str] = []
        pending: list[tuple[OccurrenceSpec, TaskSemanticBindingV1]] = []
        stored = self._store.list_tasks(command.mission_id)
        # What the Mission has already handed out — every row, not only the ones this
        # network names: an occurrence a previous revision retired still holds the
        # account it was opened with, and leaving it out of the equation would let the
        # same tokens be granted twice.
        #
        # P2.3j: *holds* is read from the account for a row this network no longer
        # contains.  A retired occurrence's row keeps its ceiling as history, but
        # what it can never give back is only what it used or still has reserved;
        # counting the whole ceiling meant a Mission whose first plan had shared the
        # pool out over its leaves could not fund any replacement at all — the
        # rejected branch held every token it had never spent, and the repair round's
        # replacement was refused ``BUDGET_INSUFFICIENT`` (H-L3-C1-r1's shape: six
        # accepted leaves holding the entire pool).  A row the network still names is
        # counted at its ceiling as before, because it can still draw on it.
        named = {str(spec.task_id) for spec in network.occurrences}
        committed = sum(
            int(task.budget.max_tokens or 0)
            if task.id in named
            else self._held_by_retired_row(task)
            for task in stored
        )
        for spec in sorted(network.occurrences, key=lambda item: str(item.occurrence_id)):
            task_id = str(spec.task_id)
            current = self._store.get_task(task_id)
            if current is not None:
                reused.append(task_id)
                if current.budget.max_tokens is not None:
                    existing[task_id] = int(current.budget.max_tokens)
                continue
            binding = semantics.task_semantics_of(command.mission_id, task_id)
            if binding is None:
                # Unreachable through ``commit_plan_revision`` — ``_check_structure``
                # refuses a membership with no binding first — but a materialiser that
                # invented a meaning here would be the silent half-mode §18.5 forbids.
                raise PlanCommitRejected(
                    "MISSING_SEMANTIC_BINDING",
                    f"occurrence {spec.occurrence_id!s} names task {task_id} which carries no "
                    "TaskSemanticBindingV1; an occurrence is not materialised without its "
                    "meaning (§18.5)",
                )
            pending.append((spec, binding))
        funded_now = sum(1 for spec, _binding in pending if spec.form is TaskForm.PRIMITIVE)
        # One share held back per compound that still owes a refinement — the ones
        # already refined have their children on the board (or in ``pending``) and do
        # not need a second reservation.
        reserved = sum(
            1
            for spec in network.occurrences
            if spec.form is TaskForm.COMPOUND
            and network.adopted_instance_for(spec.occurrence_id) is None
        )

        cap = int(self._task_max_tokens)
        # 2026-10-11 user decision A（parse 重跑）：固定单步额度，不再平分。原来（2026-09-25）
        # 取"固定额度"与"池子平分份额"中较小的，多步任务里每步实际只有 500 万，用户定的
        # 1000 万不生效。现在每个新叶子都拿固定额度（不超过任务总额）；任务总额由账户链在
        # 每次预留时挡住（``reserve`` 走到父账户），所以"还剩多少"按任务账户的实际占用算
        # （已结清 + 预留中），不按每行的上限相加。
        snapshot = self._ledger.account(mission_account(command.mission_id))
        available = (
            None
            if pool is None
            else max(0, pool - snapshot.reserved_tokens - snapshot.settled_tokens)
        )
        if available is not None and funded_now and available < MIN_TOKEN_SHARE:
            raise PlanCommitRejected(
                "BUDGET_INSUFFICIENT",
                f"the Mission's task pool has {available} tokens left (after what its "
                f"accounts hold or have spent) and this revision needs to fund {funded_now} "
                "new primitive occurrence(s); a plan whose work cannot pay for anything is "
                "refused, not opened with an account nobody can draw on (§21.5)",
            )
        share = cap if pool is None else min(cap, pool)
        built: list[OccurrenceTask] = []
        ordinal = len(stored)
        # P2.3k verification P1-2: the occurrences a root criterion is linked to keep
        # ``code_test`` whatever their side effect declares (``verify-tests``).

        linked = criterion_linked_occurrences(network.obligation_coverage)

        owned = owned_criteria(network, semantics)
        claimed = frozenset(ref for items in owned.values() for ref, _ in items)
        if funded_now and "critic_review" not in self._deployed_layers:
            raise PlanCommitRejected(
                "VERIFIER_UNAVAILABLE", "scoped content requires a deployed Critic"
            )
        for spec, binding in pending:
            ordinal += 1
            tokens = COMPOUND_TOKENS if spec.form is TaskForm.COMPOUND else share
            built.append(
                occurrence_task(
                    mission,
                    spec,
                    binding,
                    criterion_linked=spec.occurrence_id in linked,
                    owned=owned.get(str(spec.occurrence_id), ()),
                    claimed=claimed,
                    plan_revision=plan_revision,
                    budget=inherit_limits(
                        Budget(max_tokens=tokens, max_attempts=mission.budget.max_attempts),
                        mission.budget,
                    ),
                    ordinal=ordinal,
                    deployed=frozenset(self._deployed_layers).intersection(
                        self.domain_for(mission.id).runs_layers
                    ),
                    requirements=requirements,
                    now=self._store.now,
                )
            )
        # The account *names* come from the host service, never spelled again here: a
        # second copy of the ``budget:`` prefix is a silent way to open a Task account
        # under a parent that does not exist, which ``open_account`` can only report as
        # "unknown budget account".  ``selection_commits`` reaches for them the same way.

        result = Materialisation(
            tasks=tuple(built),
            reused=tuple(reused),
            pool_tokens=pool,
            fixed_allowance=cap,
            available_tokens=available,
            committed_tokens=committed,
            funded_now=funded_now,
            reserved_subtrees=reserved,
            existing=existing,
        )
        equation = result.conservation()
        if not equation["holds"]:
            # Checked before a single row is written: the refusal is about the plan,
            # so it must not depend on the transaction being rolled back to be true.
            raise PlanCommitRejected(
                "BUDGET_INSUFFICIENT",
                f"materialising the plan would grant {result.granted_tokens} tokens on top of "
                f"the {committed} its rows already hold, out of a task pool of {pool}; a plan "
                "is not committed by overdrawing the Mission (§21.5 budget conservation)",
            )
        for item in built:
            self._store.insert_task(item.task, ordinal=item.ordinal)
            try:
                self._ledger.open_account(
                    account_id=task_account(item.task.id),
                    scope="task",
                    parent_id=mission_account(command.mission_id),
                    mission_id=command.mission_id,
                    limits=item.task.budget,
                )
            except BudgetError as error:
                raise PlanCommitRejected(
                    "BUDGET_INSUFFICIENT",
                    f"occurrence {item.occurrence_id} cannot be opened with "
                    f"{item.task.budget.to_json()}: {error}",
                ) from error
            self._emit(
                "TaskCommitted",
                command.mission_id,
                key=item.task.id,
                task_id=item.task.id,
                payload={
                    "commit_id": command.command_id,
                    "key": item.occurrence_id,
                    "dependencies": [],
                    "proposal": item.to_json(),
                    "source": {
                        **dict(command.source),
                        "materialised_by": "plan_revision",
                        "plan_revision": int(plan_revision),
                    },
                },
            )
        if built or reused:
            self._emit(
                OCCURRENCES_MATERIALISED,
                command.mission_id,
                key=f"{command.mission_id}:plan-{plan_revision}",
                payload={
                    "plan_revision": int(plan_revision),
                    "command_id": command.command_id,
                    **result.to_json(),
                },
            )
        return result

    def materialise_planning_subject(self, mission_id: str, spec: OccurrenceSpec) -> bool:
        """Give a goal that is being planned for its ``Task`` row before any plan names it.

        2026-10-01（HTN 精简 片 A）：根目标的任务行原来只在第一份计划提交时才建。规划器在
        那之前为根目标提做法，新做法审阅以这个目标为归属任务——审阅绑定、"归属任务是否还
        活着"的检查都要读任务行，行不存在就开不了审阅（数据库触发器直接拒绝）。

        这里建的就是计划提交会建的同一行（复合目标：BLOCKED、零额度、同样的账户与
        ``TaskCommitted`` 事件）；之后的计划提交按"已存在的行原样复用"处理它。已有行时什么
        都不做。必须在调用方的事务里调用。
        """

        task_id = str(spec.task_id)
        if self._store.get_task(task_id) is not None:
            return False
        semantics = HtnStore(self._store)
        binding = semantics.task_semantics_of(mission_id, task_id)
        if binding is None or spec.form is not TaskForm.COMPOUND:
            raise ContractError(
                f"planning subject {task_id} is not a compound goal of this Mission"
            )
        mission = self._require_mission(mission_id)

        item = occurrence_task(
            mission,
            spec,
            binding,
            plan_revision=0,
            budget=inherit_limits(
                Budget(max_tokens=COMPOUND_TOKENS, max_attempts=mission.budget.max_attempts),
                mission.budget,
            ),
            ordinal=len(self._store.list_tasks(mission_id)) + 1,
            deployed=frozenset(self._deployed_layers).intersection(
                self.domain_for(mission.id).runs_layers
            ),
            requirements=semantics.latest_requirements_revision(mission_id),
            now=self._store.now,
        )
        self._store.insert_task(item.task, ordinal=item.ordinal)
        self._ledger.open_account(
            account_id=task_account(item.task.id),
            scope="task",
            parent_id=mission_account(mission_id),
            mission_id=mission_id,
            limits=item.task.budget,
        )
        self._emit(
            "TaskCommitted",
            mission_id,
            key=item.task.id,
            task_id=item.task.id,
            payload={
                "commit_id": "planning-subject:" + item.task.id,
                "key": item.occurrence_id,
                "dependencies": [],
                "proposal": item.to_json(),
                "source": {"materialised_by": "planning_subject", "plan_revision": 0},
            },
        )
        return True

    def _activate_for_work(self, mission: Mission, materialised: Materialisation) -> Mission | None:
        """PLANNING → ACTIVE, by the formal rule rather than by a test helper.

        P2.3b's two guard tests had to call a ``_force_active`` helper because nothing
        moved a hierarchical Mission out of PLANNING — ``commit_task_graph`` does that
        for the legacy mode and it is never called here.  The rule is the same one:
        a Mission becomes ACTIVE when there is committed work to do.  "Committed work"
        is read from what this revision materialised, so a revision that put nothing
        dispatchable on the board leaves the Mission in PLANNING, which is the true
        statement about it.
        """

        if mission.status is not MissionStatus.PLANNING:
            return None
        if not any(item.dispatchable for item in materialised.tasks):
            if not any(
                (found := self._store.get_task(task_id)) is not None
                and found.status is not TaskStatus.CANCELLED
                and str(found.context.get("form", "")) == str(TaskForm.PRIMITIVE)
                for task_id in materialised.reused
            ):
                return None
        activated = next_mission(mission, MissionStatus.ACTIVE)
        self._store.update_mission(activated, expected_version=mission.version)
        return activated

    # ------------------------------------------------- the hierarchical graph gate


def _shared(store: Store, semantics: HtnStore, mission_id: str) -> SemanticReadSetChecker:
    """The shared resolver set, with no overrides — the implementation itself."""

    return SemanticReadSetChecker(store, semantics, mission_id=mission_id)


def _rebound(binding: TaskSemanticBindingV1, task_id: str) -> TaskSemanticBindingV1:
    """The same meaning on the id the Commit Service minted for it.

    The Planner names its nodes ``A``/``B``; the formal ids are assigned inside the
    commit.  Re-pointing the binding is therefore normal, and the contract hash is
    recomputed from the old one so the lineage stays readable.
    """

    return replace(
        binding,
        task_id=TaskRef(task_id),
        contract_hash=content_hash_of(
            {
                "task_id": task_id,
                "bound_from_task_id": str(binding.task_id),
                "bound_from_contract_hash": binding.contract_hash,
                "contract_revision": int(binding.contract_revision),
            }
        ),
    )


def _superseded(binding: TaskSemanticBindingV1) -> TaskSemanticBindingV1:
    """The same Task with its execution right withdrawn (§6.4).

    The dispatch generation is what an in-flight dispatch carries, so raising it is
    the revocation; the contract revision moves with it because the store keys a
    binding by ``(task_id, contract_revision)`` and the previous row is history, not
    something to overwrite.
    """

    return replace(
        binding,
        contract_revision=ContractRevision(int(binding.contract_revision) + 1),
        contract_hash=content_hash_of(
            {
                "superseded_contract_hash": binding.contract_hash,
                "task_id": str(binding.task_id),
                "contract_revision": int(binding.contract_revision) + 1,
                "dispatch_generation": int(binding.dispatch_generation) + 1,
            }
        ),
        dispatch_generation=DispatchGeneration(int(binding.dispatch_generation) + 1),
    )


def _occurrence_instances(network: TaskNetworkSnapshot) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for draft in network.method_instances:
        for child in draft.child_bindings:
            mapping[str(child.occurrence_id)] = str(draft.instance_id)
    return mapping


def _network_identity(network: TaskNetworkSnapshot) -> dict[str, Any]:
    """The bytes that identify one plan revision's shape.

    Deliberately the *structure*, not the whole snapshot: two snapshots that place
    the same occurrences under the same edges are the same plan, and a hash that
    moved with an unrelated field would make every receipt incomparable.
    """

    return {
        "mission_id": str(network.mission_id),
        "occurrences": sorted(str(spec.occurrence_id) for spec in network.occurrences),
        "adopted_instances": sorted(str(item) for item in network.adopted_instance_ids),
        "order": sorted(
            [str(item.before), str(item.after), str(item.release_condition)]
            for item in network.order_constraints
        ),
        "data": sorted(item.requirement_id for item in network.data_requirements),
    }


def _pending_dispatch(network: TaskNetworkSnapshot, delta: ProposedPlanDelta) -> list[str]:
    """The primitive occurrences this revision newly put on the board.

    Registered only.  Whether one of them may actually run is the scheduler's
    question (readiness, inputs, budget, form) and is answered in P2.3c; answering
    it here would be exactly the "approve the new version while committing it" the
    plan forbids.
    """

    added = {spec.occurrence_id for spec in delta.occurrences}
    return sorted(
        str(spec.occurrence_id)
        for spec in network.occurrences
        if spec.occurrence_id in added and spec.form is TaskForm.PRIMITIVE
    )


def canonical_payload(payload: Mapping[str, Any]) -> str:
    """The canonical bytes of a ``PlanRevisionCommitted`` payload (test helper)."""

    return canonical_json(dict(payload))


__all__ = (
    "HIERARCHICAL_SEMANTICS",
    "OCCURRENCES_MATERIALISED",
    "LEGACY_SEMANTICS",
    "PLAN_REVISION_COMMITTED",
    "SEMANTICS_KEY",
    "CommitPlanCommand",
    "PlanCommitRejected",
    "PlanCommitsMixin",
    "PlanPrincipal",
    "canonical_payload",
    "normalise_semantics",
    "semantics_of",
)
