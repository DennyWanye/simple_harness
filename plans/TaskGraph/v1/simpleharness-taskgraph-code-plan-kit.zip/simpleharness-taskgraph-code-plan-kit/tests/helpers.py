"""Isolated SQL fixture. Deliberately does not import or simulate the SDK runtime."""
from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]
H='a'*64
H2='b'*64
H3='c'*64

def connect(path=':memory:'):
    c=sqlite3.connect(str(path),isolation_level=None)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

def initialise(c):
    c.executescript((ROOT/'tests/parent_fixture.sql').read_text())
    c.executescript((ROOT/'sql/001_taskgraph_extension.sql').read_text())

def insert(c, table, **values):
    # Test-author controlled table and columns; never exposed to external input.
    cols=tuple(values)
    return c.execute(f'INSERT INTO {table}({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})', tuple(values[k] for k in cols))

def seed(c,m='m1',rev=1,baseline=False):
    insert(c,'missions',mission_id=m,tenant_id='tenant1')
    insert(c,'taskgraph_policy_bindings',mission_id=m,kernel_version='taskgraph-exec-v2',policy_hash=H,policy_json='{}',enabling_command_id=f'enable-{m}',enabling_receipt_hash=H,created_at=0.0)
    insert(c,'requirements_revisions',mission_id=m,revision=1)
    insert(c,'planning_requests',request_id=f'req-{m}',mission_id=m)
    insert(c,'planning_decisions',decision_id=f'dec-{m}',request_id=f'req-{m}')
    insert(c,'planning_admission_checks',check_id=f'check-{m}',request_id=f'req-{m}',phase='APPLIED')
    insert(c,'obligations',mission_id=m,obligation_id=f'obl-{m}')
    for suffix,form in [('root','compound'),('leaf','primitive')]:
        task=f'{m}-{suffix}'
        insert(c,'tasks',task_id=task,mission_id=m)
        insert(c,'task_semantics',task_id=task,binding_revision=1,mission_id=m,obligation_id=f'obl-{m}',form=form,input_binding_revision=1,dispatch_generation=1,content_hash=H,binding_json='{"marker":"original"}')
    insert(c,'method_instances',mission_id=m,instance_id=f'mi-{m}',goal_occurrence_id=f'occ-{m}-root',state='ADOPTED',draft_json='{}')
    insert(c,'method_child_occurrences',instance_id=f'mi-{m}',slot_key='leaf',mission_id=m,occurrence_id=f'occ-{m}-leaf',goal_occurrence_id=f'occ-{m}-leaf',obligation_id=f'obl-{m}',reuse_policy='new_work',requiredness='required',binding_json='{}')
    add_revision(c,m,rev,source_kind='CAPTURED_BASELINE' if baseline else 'SEED_COMMIT')
    insert(c,'input_manifests',manifest_hash=H,origin_mission_id=m,manifest_json='{}')
    insert(c,'input_manifest_bindings',mission_id=m,task_id=f'{m}-leaf',manifest_hash=H,input_binding_revision=1,attempt_id=None,request_id=None)

def revision_values(m,rev,source_kind='COMMIT',parent=None,parent_hash=None):
    return dict(mission_id=m,revision=rev,parent_revision=parent,parent_manifest_hash=parent_hash,source_kind=source_kind,requirements_revision=1,manifest_hash=H if rev==1 else H2,sdk_snapshot_hash=H,network_json='{}',certificate_json='{}',admission_check_id=None if source_kind=='CAPTURED_BASELINE' else f'check-{m}',event_id=f'event-{m}-{rev}',command_id=f'cmd-{m}-{rev}',created_at=0.0)

def add_revision(c,m,rev,source_kind='COMMIT',parent=None,parent_hash=None,pins=True):
    c.execute("UPDATE plan_revisions SET state='RETIRED' WHERE mission_id=? AND state='ACTIVE'",(m,))
    insert(c,'plan_revisions',mission_id=m,revision=rev,state='ACTIVE',snapshot_hash=H)
    insert(c,'events',event_id=f'event-{m}-{rev}',mission_id=m,type='TaskGraphRevisionRecorded',payload_json='{}')
    for suffix,form in [('root','compound'),('leaf','primitive')]:
        insert(c,'plan_memberships',mission_id=m,revision=rev,occurrence_id=f'occ-{m}-{suffix}',task_id=f'{m}-{suffix}',obligation_id=f'obl-{m}',form=form,member_json='{}')
    insert(c,'taskgraph_revision_records',**revision_values(m,rev,source_kind,parent,parent_hash))
    if pins:
        add_pins(c,m,rev)

def add_pins(c,m,rev):
    for suffix in ['root','leaf']:
        insert(c,'taskgraph_member_pins',mission_id=m,revision=rev,occurrence_id=f'occ-{m}-{suffix}',task_id=f'{m}-{suffix}',binding_revision=1,binding_hash=H)
    insert(c,'taskgraph_method_pins',mission_id=m,revision=rev,instance_id=f'mi-{m}',goal_occurrence_id=f'occ-{m}-root',adopted=1,draft_hash=H)
    insert(c,'taskgraph_demand_refs',mission_id=m,revision=rev,consumer_instance_id=f'mi-{m}',slot_key='leaf',slot_occurrence_id=f'occ-{m}-leaf',producer_occurrence_id=f'occ-{m}-leaf',obligation_id=f'obl-{m}',mode='new_work',requiredness='required',source_slot_hash=H)

def attempt_values(c,m='m1',n=1,baseline=False,create=True):
    aid=f'attempt-{m}-{n}'; iid=f'intent-{m}-{n}'
    if create:
        insert(c,'attempts',attempt_id=aid,task_id=f'{m}-leaf',mission_id=m)
        insert(c,'dispatch_intents',intent_id=iid,subject_id=aid,mission_id=m,creation_key=f'create-{m}-{n}',input_id=f'input-{m}-{n}',input_hash=H)
    return dict(attempt_id=aid,mission_id=m,task_id=f'{m}-leaf',occurrence_id=f'occ-{m}-leaf',source_revision=1,binding_revision=1,contract_hash=H,input_binding_revision=1,dispatch_generation=1,manifest_hash=H,intent_id=iid,creation_key=f'create-{m}-{n}',input_id=f'input-{m}-{n}',frozen_input_hash=H,admission_check_id=None if baseline else f'check-{m}',origin_hash=H,created_at=0.0)

def job_values(m='m1'):
    return dict(job_id=f'job-{m}',mission_id=m,decision_id=f'dec-{m}',request_id=f'req-{m}',command_id=f'conv-{m}',source_revision=1,candidate_hash=H,impact_hash=H2,state='FENCED',row_version=1,created_at=0.0,updated_at=0.0)

def target_values(m='m1'):
    return dict(job_id=f'job-{m}',mission_id=m,source_revision=1,occurrence_id=f'occ-{m}-leaf',task_id=f'{m}-leaf',expected_generation=1,target_kind='RETIRING')

def followup_values(m='m1',n=1):
    return dict(message_id=f'msg-{m}-{n}',mission_id=m,source_event_id=f'event-{m}-1',kind='REEVALUATE',subject_key=f'occ-{m}-leaf',dedupe_key=f'followup-{m}-{n}',payload_hash=H,payload_json='{}',delivery_state='PENDING',lease_owner=None,lease_until_ms=None,attempts=0,row_version=1,next_attempt_ms=0,last_error_code=None)
