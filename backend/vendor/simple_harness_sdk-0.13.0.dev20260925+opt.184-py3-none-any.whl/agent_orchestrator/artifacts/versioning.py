# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Artifact propagation and versioning across the DAG (§20.3, plan D3-7'/D3-8').

A downstream Attempt starts from the *accepted* artifacts of **all** its ancestors,
applied in topological order: a later producer overrides an earlier one only when
it depends (transitively) on that producer — it saw the earlier file and changed
it on purpose.  Two producers that are independent of each other (parallel
branches) giving the same path *different* content is an ``ArtifactConflict``
(never silently pick one); the same content is not a conflict.  The resulting
``(task_id, path, content_hash)`` set is frozen into the dispatch intent as the
Attempt's inputs, so a later inspection can tell exactly which upstream version a
result was built on — and the verifier re-materialises those inputs as protected
files (a downstream Worker may not rewrite what it was given).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ..contracts import Artifact, Task
from ..contracts.evidence_state import ValidityWitness
from ..contracts.htn import OccurrenceId, TaskSemanticBindingV1
from ..contracts.models import ContractError
from ..graph.projection_validation import require_topological_order
from ..graph.task_network import TaskNetworkSnapshot
from .input_bindings import (
    AcceptedOutputsIndex,
    InputManifest,
    ResolutionPolicy,
    ResolutionProblem,
    ResolutionResult,
    TargetRules,
    materialise_plan,
    resolve_declared_inputs,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .workspace import Workspace


class ArtifactConflict(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class UpstreamInput:
    task_id: str
    path: str
    content_hash: str
    artifact_id: str

    def to_json(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "path": self.path,
            "content_hash": self.content_hash,
            "artifact_id": self.artifact_id,
        }

    @classmethod
    def from_json(cls, value: Mapping[str, Any]) -> UpstreamInput:
        return cls(
            str(value["task_id"]),
            str(value["path"]),
            str(value["content_hash"]),
            str(value["artifact_id"]),
        )


def topological(tasks: Sequence[Task], tasks_by_id: Mapping[str, Task]) -> list[Task]:
    """Kahn over the given tasks' dependency edges (restricted to the set), ordinal as
    the deterministic tie-break."""

    members = {task.id: task for task in tasks}
    indegree = {tid: sum(1 for d in t.dependency_ids if d in members) for tid, t in members.items()}
    ready = sorted((tid for tid, n in indegree.items() if n == 0), key=_ordinal)
    order: list[Task] = []
    while ready:
        current = ready.pop(0)
        order.append(members[current])
        for tid, task in members.items():
            if current in task.dependency_ids:
                indegree[tid] -= 1
                if indegree[tid] == 0:
                    ready.append(tid)
                    ready.sort(key=_ordinal)
    if len(order) != len(members):  # a cycle can only come from a corrupted library
        order.extend(
            sorted((t for t in members.values() if t not in order), key=lambda t: _ordinal(t.id))
        )
    return order


def _ordinal(task_id: str) -> int:
    try:
        return int(task_id.rsplit("-", 1)[1])
    except (IndexError, ValueError):
        return 0


def next_versions(existing: Sequence[Artifact]) -> dict[str, int]:
    """Highest recorded version per path (Mission-wide lineage, D3-8')."""

    versions: dict[str, int] = {}
    for artifact in existing:
        versions[artifact.path] = max(versions.get(artifact.path, 0), artifact.version)
    return versions


# ======================================================================================
# P2.3b: the hierarchical mode's path (§24.1 decisions 3, 4 and 11; TG §10.1-10.3)
# ======================================================================================
#
# Above this line only ``topological`` remains of the legacy mode (§18.2: byte-for-byte
# unchanged, the suite hashes its source to hold that).  The all-ancestors sweep (four
# helpers that merged every ancestor's accepted files into a new Attempt's inputs)
# lost its last production caller when attribution moved to the root resolution's
# contribution list (2026-10-06 第 2 批车道 H) and was deleted with it (车道 I2).
# ``graph/terminal.py`` still orders by ``topological`` and keeps tolerating a damaged
# graph: an operator's view of a broken Mission must still render (decision 11).
#
# Below the line is the new mode, and it differs in three ways that are not details:
#
# 1. **Nothing is swept.**  A consumer starts from its resolved ``InputManifest`` and
#    from nothing else.  An ORDER-only predecessor contributes no file however many
#    artifacts it accepted — ORDER is a release condition, never a read permission
#    (§24.1 decision 1).
# 2. **A path collision is refused, not ranked.**  Two different hashes aimed at one
#    target place raise :class:`ArtifactConflict`; "B is further down the topological
#    order" is not a reason to pick B (TG §10.2).  The same hash at one place is one
#    file two bindings agree on, which is not a conflict — the same rule the legacy
#    merge already applied to exact paths, so decision 4's "do not relax the old
#    protection before the new path is wired" holds.
# 3. **A damaged projection stops the work.**  On this path an unorderable projection
#    raises :class:`~..graph.projection_validation.GraphIntegrityError` rather than
#    returning the healthy prefix, because the healthy prefix is a partial order and
#    not a plan.


def _require_orderable(network: TaskNetworkSnapshot | None) -> None:
    """Refuse to execute or materialise against a projection that cannot be ordered."""

    if network is None:
        return
    require_topological_order(network.execution_projection())


def _refuse(problems: Sequence[ResolutionProblem]) -> ArtifactConflict:
    """One conflict, with the candidates named.

    TG §10.2 asks the caller to *choose, convert or synthesise* — which it cannot do
    without knowing what the candidates were, so the artifact ids travel in the
    message and not only in the structured problem.
    """

    return ArtifactConflict(
        "; ".join(
            f"{problem.kind!s}: {problem.detail}"
            + (f" (candidates: {', '.join(problem.candidates)})" if problem.candidates else "")
            for problem in problems
        )
    )


def resolve_input_manifest(
    consumer: TaskSemanticBindingV1,
    network: TaskNetworkSnapshot,
    accepted: AcceptedOutputsIndex,
    *,
    consumer_occurrence: OccurrenceId,
    witnesses: Mapping[str, ValidityWitness],
    policy: ResolutionPolicy,
    check_topology: bool = True,
) -> ResolutionResult:
    """The new mode's answer to "what does this task read?" (TG §10.1).

    The declared DATA requirements of ``consumer_occurrence`` — *only* those — are
    resolved against the accepted outputs.  The requirement rows come from the
    network, so a requirement aimed at another consumer is not silently absorbed:
    :func:`~.input_bindings.resolve_declared_inputs` refuses it as
    ``FOREIGN_REQUIREMENT``.

    ``check_topology`` is True because this is the execution path.  A caller that is
    only *explaining* a Mission passes False and gets whatever the damaged network
    can still say, which is the diagnostic tolerance decision 11 preserves.
    """

    if not isinstance(network, TaskNetworkSnapshot):
        raise ContractError("resolve_input_manifest expects a TaskNetworkSnapshot")
    if check_topology:
        _require_orderable(network)
    requirements = [
        item
        for item in network.data_requirements
        if item.consumer_occurrence == consumer_occurrence
    ]
    return resolve_declared_inputs(
        consumer,
        requirements,
        accepted,
        witnesses=witnesses,
        policy=policy,
        consumer_occurrence=consumer_occurrence,
    )


def manifest_upstream_inputs(
    manifest: InputManifest,
    target_rules: TargetRules,
    *,
    network: TaskNetworkSnapshot | None = None,
) -> list[UpstreamInput]:
    """The manifest as the dispatch-intent input set (one entry per target place).

    Returned as :class:`UpstreamInput` on purpose: the recorded shape of "what this
    Attempt was built on" does not change between the modes, only *how the set is
    decided* does.  ``task_id`` therefore names the producer occurrence's task and
    ``path`` the place in the consumer's namespace, so a later inspection reads the
    same four fields whichever mode produced them.
    """

    _require_orderable(network)
    plan = materialise_plan(manifest, target_rules)
    if plan.problems:
        raise _refuse(plan.problems)
    bindings_by_id = {binding.binding_id: binding for binding in manifest.bindings}
    inputs: list[UpstreamInput] = []
    for entry in plan.entries:
        producer = next(
            (str(bindings_by_id[item].producer_task_ref) for item in entry.binding_ids
             if item in bindings_by_id and entry.artifact_ids
             and bindings_by_id[item].artifact_id == entry.artifact_ids[0]),
            "",
        )
        inputs.append(
            UpstreamInput(
                producer,
                entry.target.path,
                entry.content_hash,
                entry.artifact_ids[0] if entry.artifact_ids else "",
            )
        )
    return sorted(inputs, key=lambda item: item.path)


def materialise_v2(
    workspace: Workspace,
    manifest: InputManifest,
    artifacts_by_id: Mapping[str, Artifact],
    *,
    target_rules: TargetRules,
    network: TaskNetworkSnapshot | None = None,
) -> list[str]:
    """Write exactly the manifest's entries into ``workspace`` and nothing else.

    The bytes still come through :func:`~.store.read_verified` — hash re-checked,
    never through a symlink — and the placement still goes through
    :meth:`~.workspace.Workspace.materialise_manifest`, so the CAS and isolation
    guarantees of the old path are unchanged.  What changed is the *set*.

    The TaskGraph workspace binder calls this function for the first materialisation.
    Recovery never rewrites an active tree: it verifies the protected entries instead,
    so a changed file remains evidence of tampering rather than being silently repaired.
    """

    _require_orderable(network)
    plan = materialise_plan(manifest, target_rules)
    if plan.problems:
        raise _refuse(plan.problems)
    from .store import ArtifactStoreError, read_verified

    blobs: dict[str, bytes] = {}
    for entry in plan.entries:
        artifact = artifacts_by_id.get(entry.artifact_ids[0] if entry.artifact_ids else "")
        if artifact is None or artifact.content_hash != entry.content_hash:
            raise ArtifactConflict(
                f"manifest entry {entry.target.path!r} names artifact "
                f"{entry.artifact_ids!r}, which is missing or changed"
            )
        try:
            blobs[entry.target.path] = read_verified(artifact)
        except ArtifactStoreError as error:
            raise ArtifactConflict(
                f"manifest entry {entry.target.path!r} is not readable: {error}"
            ) from error
    return workspace.materialise_manifest(plan.entries, blobs)


__all__ = (
    "ArtifactConflict",
    "UpstreamInput",
    "topological",
    "manifest_upstream_inputs",
    "materialise_v2",
    "next_versions",
    "resolve_input_manifest",
)
