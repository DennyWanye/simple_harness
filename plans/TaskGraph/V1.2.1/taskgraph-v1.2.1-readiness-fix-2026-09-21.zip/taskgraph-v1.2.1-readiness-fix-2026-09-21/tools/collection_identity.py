"""Collection provenance and physical path identity; no SDK imports or gate writes."""
from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any


def relative_test_path(nodeid: str) -> str:
    if not isinstance(nodeid, str) or '::' not in nodeid or '\\' in nodeid or '\x00' in nodeid:
        raise ValueError('invalid pytest selector')
    rel = nodeid.split('::', 1)[0]
    path = PurePosixPath(rel)
    if path.is_absolute() or '..' in path.parts or not rel.endswith('.py') or ':' in rel:
        raise ValueError('selector must use a relative .py path inside the snapshot')
    return rel


def physical_test_path(root: Path, nodeid: str) -> Path:
    """Resolve BOTH sides: /var and /private/var may name the same root.

    Do not replace path prefixes or casefold. An in-tree symlink resolving outside
    the physical root remains invalid. Callers also check captured file hashes.
    """
    physical_root = root.expanduser().resolve(strict=True)
    target = (physical_root / relative_test_path(nodeid)).resolve(strict=True)
    if not target.is_relative_to(physical_root) or not target.is_file():
        raise ValueError('target missing/outside snapshot')
    return target


def executed_fingerprint(source: dict[str, Any]) -> str:
    # A derived runner patch has its own identity; never report it as base bytes.
    return source.get('snapshot', {}).get('source_variant_fingerprint') or source['repositories']['candidate']['fingerprint']


def collected_metadata(item: Any, root: Path) -> dict[str, Any]:
    """Use actual pytest Function identity, never split a nodeid at '['.

    A base selector names all parametrized cases of that Function. Explicitly
    parametrized selectors retain exact pytest nodeids. Custom collectors without
    Function metadata support exact matches only.
    """
    import hashlib
    physical_root = root.resolve(strict=True)
    path = Path(item.path).resolve(strict=True)
    if not path.is_relative_to(physical_root) or not path.is_file():
        raise ValueError('collected test source outside frozen snapshot')
    rel = path.relative_to(physical_root).as_posix()
    if relative_test_path(item.nodeid) != rel:
        raise ValueError('pytest rootdir/nodeid does not match frozen snapshot root')
    original = getattr(item, 'originalname', None)
    callspec = getattr(item, 'callspec', None)
    parametrized = callspec is not None
    if parametrized and not isinstance(original, str):
        raise ValueError('parametrized collector lacks exact Function.originalname')
    if isinstance(original, str) and original:
        selector = item.parent.nodeid + '::' + original
        proof = 'PYTEST_FUNCTION_ORIGINALNAME'
    else:
        selector = item.nodeid
        proof = 'EXACT_NODEID_ONLY'
    return {
        'nodeid': item.nodeid,
        'base_nodeid': selector,
        'identity_source': proof,
        'parametrized': parametrized,
        'parameter_id': callspec.id if parametrized else None,
        'source_path': rel,
        'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def expand_selector(selector: str, collection: dict[str, Any]) -> tuple[list[str], str]:
    """Exact first; otherwise all actual items with a proven exact Function base.

    Older receipts without metadata can still bind exact non-parameter targets.
    They cannot justify a guessed parameter expansion: recollect with this plugin.
    """
    relative_test_path(selector)
    nodeids = collection.get('nodeids')
    if not isinstance(nodeids, list) or any(not isinstance(n, str) for n in nodeids):
        raise ValueError('invalid collection nodeids')
    if len(nodeids) != len(set(nodeids)):
        raise ValueError('duplicate collected nodeid')
    if selector in nodeids:
        return [selector], 'EXACT'
    metadata = collection.get('items', [])
    if not isinstance(metadata, list):
        raise ValueError('invalid collection metadata')
    if collection.get('schema_version') == 2:
        ids = [row.get('nodeid') for row in metadata]
        if len(ids) != len(set(ids)) or set(ids) != set(nodeids):
            raise ValueError('collection metadata does not cover every collected nodeid')
    found: list[str] = []
    seen: set[str] = set()
    for row in metadata:
        n = row.get('nodeid')
        if n not in nodeids or n in seen:
            raise ValueError('metadata nodeid missing/duplicate')
        seen.add(n)
        if row.get('base_nodeid') == selector:
            if (row.get('identity_source') != 'PYTEST_FUNCTION_ORIGINALNAME'
                    or row.get('parametrized') is not True
                    or row.get('source_path') != relative_test_path(selector)):
                raise ValueError('unproven Function parameter expansion')
            found.append(n)
    return sorted(found), 'ALL_COLLECTED_PARAMETERS' if found else 'NOT_COLLECTED'
