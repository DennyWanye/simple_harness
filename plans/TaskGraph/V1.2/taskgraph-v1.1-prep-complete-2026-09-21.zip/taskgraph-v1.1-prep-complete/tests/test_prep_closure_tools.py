from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from verify_delivery import check, REQUIRED, safe_file
from h1h_manifest import extract_registry, normalize, bind_collection, RegistryUnsupported
from collect_h1h import targets_from_registry

class RegistryTests(unittest.TestCase):
    def test_literal_dict(self):
        r = extract_registry("CASES={'A01':'tests/a.py::test_a','A02':'tests/a.py::test_b'}", {'A01', 'A02'})
        self.assertEqual(r['registry_symbol'], 'CASES')
        self.assertEqual(r['status'], 'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED')
    def test_named_records(self):
        r = extract_registry("CASES=[{'case_id':'A01','nodeids':['tests/a.py::test_a[x]']}]", {'A01'})
        self.assertEqual(r['cases'][0]['actual_nodeids'], ['tests/a.py::test_a[x]'])
    def test_keyword_ctor_needs_explicit_name(self):
        text = "CASES=(H1Case(case_id='A01', nodeid='tests/a.py::test_a'),)"
        self.assertEqual(extract_registry(text, {'A01'})['status'], 'BLOCKED')
        self.assertNotEqual(extract_registry(text, {'A01'}, constructor='H1Case')['status'], 'BLOCKED')
    def test_positional_ctor_not_guessed(self):
        r = extract_registry("CASES=(H1Case('A01','tests/a.py::test_a'),)", {'A01'}, constructor='H1Case')
        self.assertEqual(r['status'], 'BLOCKED')
    def test_top_level_code_not_executed(self):
        text = "raise RuntimeError('DO NOT EXECUTE')\nCASES={'A01':'tests/a.py::test_a'}"
        self.assertNotEqual(extract_registry(text, {'A01'})['status'], 'BLOCKED')
    def test_expression_not_executed(self):
        r = extract_registry("CASES=load_tests_from_network()", {'A01'})
        self.assertEqual(r['status'], 'BLOCKED')
    def test_duplicate_case(self):
        r = extract_registry("CASES=[{'id':'A01','nodeid':'t.py::a'},{'id':'A01','nodeid':'t.py::b'}]", {'A01'})
        self.assertEqual(r['status'], 'BLOCKED')
    def test_duplicate_literal_key(self):
        r = extract_registry("CASES={'A01':'t.py::a','A01':'t.py::b'}", {'A01'})
        self.assertEqual(r['status'], 'BLOCKED')
    def test_missing_case_not_filled(self):
        r = extract_registry("CASES={'A01':'t.py::a'}", {'A01', 'A02'})
        self.assertEqual(r['status'], 'BLOCKED')
    def test_ambiguous_requires_symbol(self):
        text = "CASES={'A01':'t.py::a'}\nOTHER={'A01':'t.py::b'}"
        self.assertEqual(extract_registry(text, {'A01'})['status'], 'BLOCKED')
        self.assertEqual(extract_registry(text, {'A01'}, 'CASES')['registry_symbol'], 'CASES')
    def test_named_constant_ref(self):
        r = extract_registry("NODE='t.py::a'\nCASES={'A01':NODE}", {'A01'})
        self.assertEqual(r['cases'][0]['actual_nodeids'], ['t.py::a'])

class CoverageTests(unittest.TestCase):
    def fixtures(self):
        spec = {'cases': [{'id': 'A01', 'required_assertions': 'grant'}, {'id':'A02','required_assertions':'revoke'}]}
        reg = {'status':'STATIC_REGISTRY_EXTRACTED_NOT_COLLECTED','candidate_fingerprint':'f',
               'runner_sha256':'a'*64,'registry_symbol':'CASES',
               'cases':[{'id':'A01','actual_nodeids':['t.py::both']},{'id':'A02','actual_nodeids':['t.py::both']}]}
        coll={'candidate_fingerprint':'f','collection_exitstatus':0,'collection_errors':[],
              'sdk_tests_executed':False,'nodeids':['t.py::both']}
        return reg, coll, spec
    def test_many_cases_one_node_requires_review(self):
        r=bind_collection(*self.fixtures())
        self.assertEqual(r['case_count'],2);self.assertEqual(r['unique_nodeid_count'],1)
        self.assertEqual(r['sdk_pass_cases'],0)
        self.assertEqual(r['shared_nodeids'][0]['review'],'PENDING_PER_CASE_ASSERTIONS')
        self.assertTrue(all(c['execution_status']=='NOT_RUN' for c in r['cases']))
    def test_missing_collection_blocks(self):
        reg,c,s=self.fixtures();c['nodeids']=[];r=bind_collection(reg,c,s)
        self.assertEqual(r['status'],'BLOCKED_MISSING_NODEIDS');self.assertEqual(r['sdk_pass_cases'],0)
    def test_wrong_fingerprint_blocks(self):
        reg,c,s=self.fixtures();c['candidate_fingerprint']='other'
        with self.assertRaises(ValueError):bind_collection(reg,c,s)
    def test_collection_error_blocks(self):
        reg,c,s=self.fixtures();c['collection_exitstatus']=2
        with self.assertRaises(ValueError):bind_collection(reg,c,s)
    def test_no_tests_collected_exit_blocks(self):
        reg,c,s=self.fixtures();c['collection_exitstatus']=5
        with self.assertRaises(ValueError):bind_collection(reg,c,s)
    def test_execution_receipt_not_accepted_as_collection(self):
        reg,c,s=self.fixtures();c['sdk_tests_executed']=True
        with self.assertRaises(ValueError):bind_collection(reg,c,s)
    def test_actual_target_only(self):
        reg,c,s=self.fixtures()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'t.py').write_text('def both(): pass\n')
            self.assertEqual(targets_from_registry(reg,p),['t.py::both'])
    def test_outside_target_refused(self):
        reg,c,s=self.fixtures();reg['cases'][0]['actual_nodeids']=['../secret.py::x']
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):targets_from_registry(reg,Path(d))

class DeliveryTests(unittest.TestCase):
    def make_files(self, root):
        entries={}
        for rel in REQUIRED:
            p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fixture')
            entries[rel]=hashlib.sha256(b'fixture').hexdigest()
        return {'version':1,'files':entries}
    def test_missing_tool_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make_files(root);(root/'tools/capture_sources.py').unlink()
            r=check(root,m);self.assertEqual(r['status'],'BLOCKED')
            self.assertIn({'path':'tools/capture_sources.py','error':'MISSING'},r['failures'])
    def test_changed_tool_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make_files(root);(root/'tools/capture_sources.py').write_text('altered')
            self.assertEqual(check(root,m)['status'],'BLOCKED')
    def test_pass_is_only_delivery(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);r=check(root,self.make_files(root))
            self.assertEqual(r['status'],'PASS');self.assertFalse(r['sdk_verified']);self.assertFalse(r['production_enablement_allowed'])
    def test_path_escape(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):safe_file(Path(d),'../outside')
    def test_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'real').write_text('x');(root/'link').symlink_to(root/'real')
            with self.assertRaises(ValueError):safe_file(root,'link')
    def test_closure_has_36_not_run(self):
        c=json.loads((ROOT/'h1h/closure.json').read_text())
        self.assertEqual(len(c['cases']),36)
        self.assertTrue(all(r['status']=='NOT_RUN' for r in c['cases']))
        self.assertFalse(c['h1_h_ready']);self.assertIsNone(c['candidate_fingerprint_observed'])
    def test_equivalence_not_preapproved(self):
        r=json.loads((ROOT/'h1h/commit-seam-review.json').read_text())
        self.assertEqual(len(r['checks']),10);self.assertIsNone(r['decision'])
        self.assertTrue(all(c['status']=='NOT_REVIEWED' for c in r['checks']))
        self.assertEqual(json.loads((ROOT/'equivalences.json').read_text())['mappings'],[])

if __name__=='__main__':unittest.main()
