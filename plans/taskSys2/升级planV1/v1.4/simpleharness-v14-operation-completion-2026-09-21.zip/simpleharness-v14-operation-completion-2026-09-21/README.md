# V14-OP-COMPLETION-1.0

先读 `V1.4-Operation完成合同补遗-2026-09-21.md`，它只修订上次D1/D2的完成绑定，不改D3、不重开H1–H8。

本包提供：主文档、四种新内部document的标准库严格codec/参考覆盖规则、完整增量SQL、12组实际SDK待执行规格、来源/验证范围、交付清单。

从解压目录用项目环境执行：

```bash
SDK=/Users/denny/projects/simple-harness-sdk-h1h-impl
"$SDK/.venv/bin/python" verify_delivery.py
"$SDK/.venv/bin/python" -m unittest discover -s tests -v
```

不依赖jsonschema、不安装任何依赖。参考validator检查结构和给定fixture的一致性；它不能证明真实权限、official Review、connector证据真实性，也不是SDK补丁。`tests`的父表只用于SQL键验证，禁止当完整生产schema。源码生产decoder应复用SDK既有canonical/TypedRef/证据/权限生产链，不复制参考hash算法作第二份权威。

禁止把参考测试写成12组SDK验收通过。原始项目日志/DB/JUnit保留 `.local-test-evidence/`；本包不读取用户仓库、不注册迁移、不打开任何生产开关。
