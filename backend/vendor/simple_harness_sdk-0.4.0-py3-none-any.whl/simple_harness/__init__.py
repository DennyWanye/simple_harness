# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Public package surface for Simple Harness SDK.

Runtime exports are resolved lazily so importing the standalone observability
wire package does not initialize execution, providers, tools, or SQLite.
"""

from __future__ import annotations

from typing import Any

from .contracts import (
    CallId,
    ContentBlock,
    ContractValidationError,
    CorrelationIds,
    EffectId,
    ErrorCode,
    EventEnvelope,
    EventId,
    EventKind,
    ExecutionSessionId,
    FrozenJsonValue,
    HarnessError,
    JsonPrimitive,
    JsonValue,
    Message,
    MessageContent,
    MessageRole,
    RequestId,
    RunId,
    canonical_json,
    fingerprint_json,
    freeze_json,
    thaw_json,
    validate_json_value,
)
from .version import __version__

_RUNTIME_EXPORTS = frozenset(
    {
        "ROOT_PROFILE_KEY",
        "AdmissionPort",
        "AdmissionVerdict",
        "AgentIdentity",
        "AgentMemoryError",
        "AgentMemoryErrorCode",
        "AgentMemoryPort",
        "AllowAllAdmission",
        "CommittedTurn",
        "CommittedTurnReceipt",
        "CommittedTurnStatus",
        "ConsumerRuntimePolicies",
        "ConsumerRuntimePorts",
        "ContextPort",
        "ContextSnapshot",
        "ConversationContextBounds",
        "ConversationContextProviderPort",
        "ConversationContextRequest",
        "ConversationContextResult",
        "ConversationContinuationInput",
        "ConversationTurnInput",
        "ConversationTurnOutput",
        "CurrentMessageContextProvider",
        "DriverInvocation",
        "DriverResult",
        "MemoryFailurePolicy",
        "MemoryRecallBounds",
        "MemoryRecallRequest",
        "MemoryRecallResult",
        "MemoryRecallStatus",
        "MemoryReleaseRequest",
        "MemoryScopeKind",
        "MemoryScopeRef",
        "ProductionRuntimeConfig",
        "ResourceOwnership",
        "RunClient",
        "Runtime",
        "RuntimeDriver",
        "RuntimePorts",
        "RuntimeProfile",
        "RuntimeServices",
        "RuntimeUnitOfWork",
        "SqliteContextPort",
        "build_consumer_runtime",
        "build_production_runtime",
        "build_runtime",
    }
)


def __getattr__(name: str) -> Any:
    if name not in _RUNTIME_EXPORTS:
        raise AttributeError(name)
    from . import runtime

    value = getattr(runtime, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | _RUNTIME_EXPORTS)

__all__ = (
    "__version__",
    "JsonPrimitive",
    "JsonValue",
    "FrozenJsonValue",
    "validate_json_value",
    "canonical_json",
    "freeze_json",
    "thaw_json",
    "fingerprint_json",
    "ExecutionSessionId",
    "RunId",
    "RequestId",
    "CallId",
    "EffectId",
    "EventId",
    "CorrelationIds",
    "ContentBlock",
    "MessageRole",
    "Message",
    "MessageContent",
    "EventKind",
    "EventEnvelope",
    "ErrorCode",
    "HarnessError",
    "ContractValidationError",
    "ROOT_PROFILE_KEY",
    "AdmissionPort",
    "AdmissionVerdict",
    "AgentIdentity",
    "AgentMemoryError",
    "AgentMemoryErrorCode",
    "AgentMemoryPort",
    "AllowAllAdmission",
    "CommittedTurn",
    "CommittedTurnReceipt",
    "CommittedTurnStatus",
    "ConsumerRuntimePolicies",
    "ConsumerRuntimePorts",
    "ConversationContextBounds",
    "ConversationContextProviderPort",
    "ConversationContextRequest",
    "ConversationContextResult",
    "ContextPort",
    "ContextSnapshot",
    "ConversationContinuationInput",
    "ConversationTurnInput",
    "ConversationTurnOutput",
    "CurrentMessageContextProvider",
    "DriverInvocation",
    "DriverResult",
    "MemoryFailurePolicy",
    "MemoryRecallBounds",
    "MemoryRecallRequest",
    "MemoryRecallResult",
    "MemoryRecallStatus",
    "MemoryReleaseRequest",
    "MemoryScopeKind",
    "MemoryScopeRef",
    "ProductionRuntimeConfig",
    "RunClient",
    "Runtime",
    "RuntimeDriver",
    "RuntimePorts",
    "RuntimeProfile",
    "RuntimeServices",
    "RuntimeUnitOfWork",
    "ResourceOwnership",
    "SqliteContextPort",
    "build_runtime",
    "build_consumer_runtime",
    "build_production_runtime",
)
