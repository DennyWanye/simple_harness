# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Restore assistant ``tool_calls`` on the wire from the effect ledger.

Durable Context keeps a provider assistant message free of provider metadata, so a
``tool`` message would follow an assistant message without ``tool_calls`` and an
OpenAI-compatible endpoint rejects the request.  The facts are durable elsewhere:
every executed call lives in ``execution_effects`` with its raw provider call id,
tool name and canonical arguments.  This wrapper re-attaches them as
``metadata["provider_tool_calls"]`` on a *request copy* (never on the stored
Context), which ``OpenAICompatibleProvider`` serializes as ``tool_calls``.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
from dataclasses import replace

from simple_harness.contracts import JsonValue, Message, MessageRole
from simple_harness.providers import ProviderRequest, ProviderResponse
from simple_harness.providers.base import (
    PROVIDER_REASONING_KEY,
    ProviderContinuationCapability,
    ProviderContinuationMode,
)
from simple_harness.providers.errors import ProviderProtocolError

PROVIDER_TOOL_CALLS_KEY = "provider_tool_calls"
REQUEST_ID_MARKER = ":provider-turn:"


def continuation_capability_of(provider: object) -> ProviderContinuationCapability:
    """The continuation capability a provider declares (thinking mode), else the default."""

    capability = getattr(provider, "continuation_capability", None)
    if capability is None:
        return ProviderContinuationCapability()
    if not isinstance(capability, ProviderContinuationCapability):
        raise TypeError("provider continuation_capability must use ProviderContinuationCapability")
    return capability


def replays_reasoning(provider: object) -> bool:
    return continuation_capability_of(provider).mode is ProviderContinuationMode.REASONING_REPLAY


def _ledger_reasoning(connection: sqlite3.Connection, run_id: str) -> dict[int, str]:
    """Private reasoning of each succeeded provider turn of the run, by turn ordinal.

    Read from the durable response's private continuation (schema 2, REASONING_REPLAY);
    never from Context, which holds public content only."""

    reasoning: dict[int, str] = {}
    prefix = run_id + REQUEST_ID_MARKER
    for request_id, response_json in connection.execute(
        "SELECT request_id, response_json FROM provider_invocations"
        " WHERE run_id=? AND state='succeeded' AND response_json IS NOT NULL"
        " ORDER BY settled_at, invocation_id",
        (run_id,),
    ):
        request_id = str(request_id)
        if not request_id.startswith(prefix) or not request_id[len(prefix) :].isdigit():
            continue
        try:
            continuation = json.loads(str(response_json)).get("continuation") or {}
        except (TypeError, ValueError, AttributeError):
            continue
        text = continuation.get("reasoning_content") if isinstance(continuation, dict) else None
        if isinstance(text, str):
            reasoning[int(request_id[len(prefix) :])] = text
    return reasoning


def restore_reasoning(
    messages: tuple[Message, ...], reasoning: dict[int, str]
) -> tuple[Message, ...]:
    """Attach each assistant message's own earlier reasoning to a wire copy.

    Thinking mode with tools: the provider requires the reasoning of *every* earlier
    assistant message (with or without tool calls) and rejects the request when one is
    missing, which would repeat on every later turn.  An assistant message whose reasoning
    is not on record (a failed call, a turn from before the mode was chosen) is sent with an
    empty reasoning rather than none.
    """

    restored: list[Message] = []
    for message in messages:
        if message.role is MessageRole.ASSISTANT and PROVIDER_REASONING_KEY not in message.metadata:
            stamped = message.metadata.get("provider_turn_ordinal")
            text = (
                reasoning.get(stamped, "")
                if isinstance(stamped, int) and not isinstance(stamped, bool)
                else ""
            )
            message = Message(
                message.role,
                message.content,
                name=message.name,
                call_id=message.call_id,
                metadata={**dict(message.metadata), PROVIDER_REASONING_KEY: text},
            )
        restored.append(message)
    return tuple(restored)


def restore_wire_messages(
    messages: tuple[Message, ...],
    connection: sqlite3.Connection,
    run_id: str,
    *,
    replay_reasoning: bool,
) -> tuple[tuple[Message, ...], int]:
    """The wire copy of a request's messages: replayed reasoning (thinking mode) first,
    while the turn ordinal stamps are still present, then the issued tool calls."""

    if replay_reasoning and any(m.role is MessageRole.ASSISTANT for m in messages):
        messages = restore_reasoning(messages, _ledger_reasoning(connection, run_id))
    if any(m.role is MessageRole.TOOL for m in messages):
        return restore_tool_calls(messages, _ledger_groups(connection, run_id))
    return messages, 0


def run_id_from_request(request_id: str) -> str | None:
    if REQUEST_ID_MARKER not in request_id:
        return None
    return request_id.split(REQUEST_ID_MARKER, 1)[0]


def _ledger_groups(connection: sqlite3.Connection, run_id: str) -> dict[int, dict[str, dict]]:
    """Executed calls grouped by provider turn ordinal, keyed by raw provider call id."""

    groups: dict[int, dict[str, dict]] = {}
    for row in connection.execute(
        "SELECT raw_call_id, turn_ordinal, call_ordinal, tool_name, arguments_json"
        " FROM execution_effects WHERE run_id=? AND raw_call_id IS NOT NULL"
        " ORDER BY turn_ordinal, call_ordinal",
        (run_id,),
    ):
        try:
            arguments = json.loads(str(row[4]))
        except (TypeError, ValueError):
            arguments = {}
        groups.setdefault(int(row[1]), {})[str(row[0])] = {
            "name": str(row[3]),
            "arguments": arguments if isinstance(arguments, dict) else {},
        }
    return groups


def restore_tool_calls(
    messages: tuple[Message, ...],
    groups: list[dict[str, dict]] | dict[int, dict[str, dict]],
) -> tuple[tuple[Message, ...], int]:
    """Return a wire copy of ``messages`` plus the number of calls that fell back to ``{}``.

    An assistant message carrying ``provider_turn_ordinal`` metadata (stamped by the
    Journal Context port) is matched to that turn's ledger group, so history that
    rotated out never shifts the mapping (review S3-03).  Messages without the stamp
    are matched positionally, in issue order, as before.
    """

    by_ordinal: dict[int, dict[str, dict]] = (
        dict(groups) if isinstance(groups, dict) else dict(enumerate(groups, start=1))
    )
    positional = [by_ordinal[key] for key in sorted(by_ordinal)]
    restored: list[Message] = []
    fallbacks = 0
    group_index = 0
    index = 0
    while index < len(messages):
        message = messages[index]
        if message.role is not MessageRole.ASSISTANT:
            restored.append(message)
            index += 1
            continue
        followers: list[Message] = []
        cursor = index + 1
        while cursor < len(messages) and messages[cursor].role is MessageRole.TOOL:
            followers.append(messages[cursor])
            cursor += 1
        if not followers:
            restored.append(message)
            index += 1
            continue
        stamped = message.metadata.get("provider_turn_ordinal") if message.metadata else None
        if isinstance(stamped, int) and not isinstance(stamped, bool):
            group = by_ordinal.get(stamped, {})
        else:
            group = positional[group_index] if group_index < len(positional) else {}
            group_index += 1
        calls: list[JsonValue] = []
        for follower in followers:
            raw_id = follower.call_id.value if follower.call_id is not None else ""
            fact = group.get(raw_id)
            if fact is None:
                fallbacks += 1
                calls.append({"id": raw_id, "name": follower.name or "unknown", "arguments": {}})
            else:
                calls.append({"id": raw_id, "name": fact["name"], "arguments": fact["arguments"]})
        metadata: dict[str, JsonValue] = {
            key: value for key, value in message.metadata.items() if key != "provider_turn_ordinal"
        }
        metadata[PROVIDER_TOOL_CALLS_KEY] = calls
        restored.append(
            Message(message.role, message.content, name=message.name, metadata=metadata)
        )
        index += 1
    return tuple(restored), fallbacks


class ProviderEmptyResponseError(ProviderProtocolError):
    """The model returned neither public text nor tool calls (F-BA-1 / T10).

    Raised at the wire so the turn fails with a readable code instead of tripping the
    durable-state gate (``provider_response_not_durable``) deep in dispatch.  It is a
    definite failure: the invocation is settled, the turn fails, the Agent lives on.
    """

    __slots__ = ("detail",)
    error_code = "provider_empty_response"
    default_message = "Provider returned an empty response without tool calls."

    def __init__(self, *, detail: dict[str, JsonValue], public_message: str | None = None):
        super().__init__(public_message=public_message)
        # finish_reason + observed usage: the request really completed, so what it
        # cost is kept in the turn result even though the invocation settles failed.
        self.detail = detail


def _is_empty_final(response: ProviderResponse) -> bool:
    if response.tool_calls:
        return False
    content = response.message.content
    if isinstance(content, str):
        return not content.strip()
    return not content


class AgentProviderWire:
    """Consumer ``ProviderPort`` decorator used by ``assemble_runtime``."""

    def __init__(  # type: ignore[no-untyped-def]
        self,
        inner,
        database,
        *,
        request_guard=None,
        max_concurrent: int | None = None,
        requests_prepared: bool = False,
    ) -> None:
        self._inner = inner
        self._database = database
        self._guard = request_guard
        self._replay_reasoning = replays_reasoning(inner)
        self._requests_prepared = requests_prepared
        self._semaphore = None if max_concurrent is None else asyncio.Semaphore(max_concurrent)
        self.fallback_total = 0
        self.last_request: ProviderRequest | None = None
        self.in_flight = 0
        self.max_in_flight = 0

    @property
    def deployment_capacity(self):
        return getattr(self._inner, "deployment_capacity", None)

    @property
    def continuation_capability(self) -> ProviderContinuationCapability:
        return continuation_capability_of(self._inner)

    def prepare_request(self, request: ProviderRequest) -> ProviderRequest:
        """Freeze the actual wire copy before admission and physical handoff."""
        run_id = run_id_from_request(request.request_id.value)
        wire_request = request
        if run_id is not None and (
            any(m.role is MessageRole.TOOL for m in request.messages)
            or (
                self._replay_reasoning
                and any(m.role is MessageRole.ASSISTANT for m in request.messages)
            )
        ):
            messages, fallbacks = restore_wire_messages(
                tuple(request.messages),
                self._database.connection,
                run_id,
                replay_reasoning=self._replay_reasoning,
            )
            self.fallback_total += fallbacks
            wire_request = replace(request, messages=messages)
        if self._guard is not None and run_id is not None:
            # Final re-count of the rendered request (BA13); over budget is refused
            # before the call as a definite failure (BA16).
            self._guard.check(wire_request, run_id=run_id)
        return wire_request

    async def invoke(self, request: ProviderRequest, *, cancel) -> ProviderResponse:  # type: ignore[no-untyped-def]
        wire_request = request if self._requests_prepared else self.prepare_request(request)
        self.last_request = wire_request
        if self._semaphore is None:
            response = await self._invoke_counted(wire_request, cancel=cancel)
        else:
            async with self._semaphore:  # FIFO across Agents (BA35)
                response = await self._invoke_counted(wire_request, cancel=cancel)
        if _is_empty_final(response):
            finish = getattr(response, "finish_reason", None)
            usage = getattr(response, "usage", None)
            detail: dict[str, JsonValue] = {"finish_reason": finish}
            if usage is not None:
                detail["usage"] = {
                    "input_tokens": getattr(usage, "input_tokens", None),
                    "output_tokens": getattr(usage, "output_tokens", None),
                    "total_tokens": getattr(usage, "total_tokens", None),
                    "reasoning_tokens": getattr(usage, "reasoning_tokens", None),
                }
            raise ProviderEmptyResponseError(
                detail=detail,
                public_message=(
                    "Provider returned an empty response without tool calls"
                    + (f" (finish_reason={finish})." if finish else ".")
                ),
            )
        return response

    async def _invoke_counted(self, request: ProviderRequest, *, cancel):  # type: ignore[no-untyped-def]
        self.in_flight += 1
        self.max_in_flight = max(self.max_in_flight, self.in_flight)
        try:
            return await self._inner.invoke(request, cancel=cancel)
        finally:
            self.in_flight -= 1


__all__ = (
    "PROVIDER_TOOL_CALLS_KEY",
    "AgentProviderWire",
    "ProviderEmptyResponseError",
    "restore_tool_calls",
    "run_id_from_request",
)
