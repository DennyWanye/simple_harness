"""Collection-only receipt. No PASS inference; exact pytest parameter provenance."""
from __future__ import annotations
import json
from pathlib import Path
from collection_identity import collected_metadata, executed_fingerprint


def pytest_addoption(parser):
    group = parser.getgroup('taskgraph-readiness')
    group.addoption('--readiness-collection-out', default=None)
    group.addoption('--readiness-source-map', default=None)


_deselected: list[str] = []


def pytest_deselected(items):
    _deselected.extend(item.nodeid for item in items)


def pytest_configure(config):
    _deselected.clear()
    # Fail before test bodies could run, not only at session finish.
    if config.getoption('--readiness-collection-out') and not config.option.collectonly:
        raise RuntimeError('collection plugin requires --collect-only')


def pytest_sessionfinish(session, exitstatus):
    out = session.config.getoption('--readiness-collection-out')
    if not out:
        return
    sm = session.config.getoption('--readiness-source-map')
    if not sm:
        raise RuntimeError('source-map required')
    source = json.loads(Path(sm).read_text(encoding='utf-8'))
    root = Path(source['snapshot']['path']).resolve(strict=True)
    evidence = Path(sm).resolve(strict=True).parent
    target = Path(out).resolve()
    if not target.is_relative_to(evidence):
        raise RuntimeError('output outside evidence run')
    errors = [] if int(exitstatus) == 0 else [f'exitstatus={int(exitstatus)}']
    if _deselected:
        errors.append('collection deselected required selector items')
    metadata = []
    for item in session.items:
        try:
            metadata.append(collected_metadata(item, root))
        except (ValueError, OSError, KeyError) as error:
            errors.append(str(error))
    result = {
        'schema_version': 2, 'kind': 'PYTEST_COLLECTION_ONLY',
        'candidate_fingerprint': source['repositories']['candidate']['fingerprint'],
        'executed_source_fingerprint': executed_fingerprint(source),
        'rootdir_physical': str(root),
        'nodeids': [i.nodeid for i in session.items], 'items': metadata, 'deselected': list(_deselected),
        'collection_errors': errors, 'collection_exitstatus': int(exitstatus),
        'sdk_tests_executed': False,
    }
    with target.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
