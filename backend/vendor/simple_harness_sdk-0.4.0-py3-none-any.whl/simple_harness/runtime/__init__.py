# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""Durable runtime lifecycle public surface, resolved without eager cycles."""

from __future__ import annotations

from importlib import import_module
from typing import Any

_MODULE_EXPORTS = {
    ".admission": ("AdmissionPort", "AdmissionVerdict", "AllowAllAdmission"),
    ".agent_memory": (
        "AgentIdentity",
        "AgentMemoryError",
        "AgentMemoryErrorCode",
        "AgentMemoryPort",
        "CommittedTurn",
        "CommittedTurnReceipt",
        "CommittedTurnStatus",
        "MemoryFailurePolicy",
        "MemoryRecallBounds",
        "MemoryRecallRequest",
        "MemoryRecallResult",
        "MemoryRecallStatus",
        "MemoryReleaseRequest",
        "MemoryScopeKind",
        "MemoryScopeRef",
        "ResourceOwnership",
    ),
    ".child_runs": (
        "ChildLaunchRequest",
        "ChildRunHandle",
        "ChildRunUnitOfWork",
        "ProfileLaunchTicketRef",
    ),
    ".child_signal_runtime": ("ChildSignalRuntime", "ChildSignalUnitOfWork"),
    ".consumer_adapter": (
        "ConsumerRuntimePolicies",
        "ConsumerRuntimePorts",
        "build_consumer_runtime",
    ),
    ".context": ("ContextPort", "ContextSnapshot", "SqliteContextPort"),
    ".conversation_context": (
        "claim_context_preparation",
        "complete_context_stage",
        "context_input_hash",
        "context_query_id",
        "get_staged_context",
    ),
    ".conversation_context_provider": (
        "ConversationContextBounds",
        "ConversationContextProviderPort",
        "ConversationContextRequest",
        "ConversationContextResult",
        "CurrentMessageContextProvider",
        "source_snapshot_ref",
    ),
    ".conversation_memory": (
        "ConversationContinuationInput",
        "ConversationTurnInput",
        "ConversationTurnOutput",
    ),
    ".drivers.react": ("ReActDriver", "build_react_driver"),
    ".drivers.react_loop": ("AgentLoopCollaborator", "EffectBatchExecutor"),
    ".drivers.workflow": (
        "WORKFLOW_DRIVER_IMPLEMENTATION_FINGERPRINT",
        "WORKFLOW_DRIVER_KIND",
        "WorkflowRuntimeDriver",
        "build_workflow_runtime_driver",
    ),
    ".kernel": (
        "ROOT_PROFILE_KEY",
        "DriverCancellationCoordinator",
        "DriverCancellationRecovery",
        "DriverCancelOutcome",
        "DriverInvocation",
        "DriverResult",
        "RunClient",
        "Runtime",
        "RuntimeDriver",
        "RuntimeLifecycleState",
        "RuntimePorts",
        "RuntimeProfile",
        "RuntimeReconciliationPort",
        "RuntimeServices",
        "RuntimeUnitOfWork",
        "ToolCatalogGenerationPort",
        "build_runtime",
    ),
    ".ports": (
        "AuthorizationPort",
        "AuthorizationRequest",
        "AuthorizationResult",
        "ProviderPort",
        "ToolExecutorPort",
    ),
    ".production": ("ProductionRuntimeConfig", "build_production_runtime"),
    ".reconciler": (
        "STARTUP_RECONCILIATION_ORDER",
        "ReconciliationPhase",
        "StartupReconciler",
        "StartupReconciliationSteps",
    ),
    ".start_snapshot": ("RunStart", "StartSnapshot"),
    ".terminal": ("TerminalCoordinator", "ToolCatalogStale"),
    ".user_continuations": ("ContinuationUnitOfWork", "UserContinuationRuntime"),
}

_EXPORT_TO_MODULE = {
    name: module_name for module_name, names in _MODULE_EXPORTS.items() for name in names
}


def __getattr__(name: str) -> Any:
    module_name = _EXPORT_TO_MODULE.get(name)
    if module_name is None:
        raise AttributeError(name)
    value = getattr(import_module(module_name, __name__), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(_EXPORT_TO_MODULE))


__all__ = (
    "ROOT_PROFILE_KEY",
    "STARTUP_RECONCILIATION_ORDER",
    "WORKFLOW_DRIVER_IMPLEMENTATION_FINGERPRINT",
    "WORKFLOW_DRIVER_KIND",
    "AdmissionPort",
    "AdmissionVerdict",
    "AgentIdentity",
    "AgentMemoryError",
    "AgentMemoryErrorCode",
    "AgentMemoryPort",
    "AgentLoopCollaborator",
    "AllowAllAdmission",
    "AuthorizationPort",
    "AuthorizationRequest",
    "AuthorizationResult",
    "ChildLaunchRequest",
    "ChildRunHandle",
    "ChildRunUnitOfWork",
    "ChildSignalRuntime",
    "ChildSignalUnitOfWork",
    "ConsumerRuntimePorts",
    "ConsumerRuntimePolicies",
    "CommittedTurn",
    "CommittedTurnReceipt",
    "CommittedTurnStatus",
    "ContextPort",
    "ContextSnapshot",
    "ContinuationUnitOfWork",
    "ConversationContinuationInput",
    "ConversationContextBounds",
    "ConversationContextProviderPort",
    "ConversationContextRequest",
    "ConversationContextResult",
    "ConversationTurnInput",
    "ConversationTurnOutput",
    "DriverCancelOutcome",
    "DriverCancellationCoordinator",
    "DriverCancellationRecovery",
    "DriverInvocation",
    "DriverResult",
    "EffectBatchExecutor",
    "CurrentMessageContextProvider",
    "MemoryFailurePolicy",
    "MemoryRecallBounds",
    "MemoryRecallRequest",
    "MemoryRecallResult",
    "MemoryRecallStatus",
    "MemoryReleaseRequest",
    "MemoryScopeKind",
    "MemoryScopeRef",
    "ProfileLaunchTicketRef",
    "ProviderPort",
    "ProductionRuntimeConfig",
    "ReconciliationPhase",
    "ReActDriver",
    "ResourceOwnership",
    "RunClient",
    "RunStart",
    "Runtime",
    "RuntimeLifecycleState",
    "RuntimeDriver",
    "RuntimePorts",
    "RuntimeProfile",
    "RuntimeReconciliationPort",
    "RuntimeServices",
    "RuntimeUnitOfWork",
    "SqliteContextPort",
    "StartSnapshot",
    "StartupReconciler",
    "StartupReconciliationSteps",
    "TerminalCoordinator",
    "ToolCatalogGenerationPort",
    "ToolCatalogStale",
    "ToolExecutorPort",
    "UserContinuationRuntime",
    "WorkflowRuntimeDriver",
    "build_consumer_runtime",
    "build_production_runtime",
    "build_runtime",
    "build_react_driver",
    "build_workflow_runtime_driver",
    "claim_context_preparation",
    "complete_context_stage",
    "context_input_hash",
    "context_query_id",
    "get_staged_context",
    "source_snapshot_ref",
)
