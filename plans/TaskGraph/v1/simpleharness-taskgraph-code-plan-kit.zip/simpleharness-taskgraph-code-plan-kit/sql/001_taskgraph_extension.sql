-- TG-EXEC-2.0, additive migration. Never execute on a live database by hand.
-- Register next UNUSED migration after H1H-ADM-1.0. Existing table names/keys are checked in preflight.
-- Requires SQLite STRICT support, foreign_keys=ON. Transaction owned by Store migration runner.
CREATE TABLE taskgraph_policy_bindings (
 mission_id TEXT PRIMARY KEY NOT NULL REFERENCES missions(mission_id),
 kernel_version TEXT NOT NULL CHECK(kernel_version='taskgraph-exec-v2'),
 policy_hash TEXT NOT NULL CHECK(length(policy_hash)=64),
 policy_json TEXT NOT NULL CHECK(json_valid(policy_json)),
 enabling_command_id TEXT NOT NULL UNIQUE,
 enabling_receipt_hash TEXT NOT NULL CHECK(length(enabling_receipt_hash)=64),
 created_at REAL NOT NULL
) STRICT;

-- Immutable replay source; existing plan_revisions remains the ONLY active pointer.
-- network_json is canonical NetworkDocumentV1. Runtime states/permissions are NOT copied into it.
CREATE TABLE taskgraph_revision_records (
 mission_id TEXT NOT NULL REFERENCES taskgraph_policy_bindings(mission_id),
 revision INTEGER NOT NULL CHECK(revision>=0),
 parent_revision INTEGER,
 parent_manifest_hash TEXT,
 source_kind TEXT NOT NULL CHECK(source_kind IN ('SEED_COMMIT','COMMIT','CAPTURED_BASELINE')),
 requirements_revision INTEGER NOT NULL CHECK(requirements_revision>=0),
 manifest_hash TEXT NOT NULL CHECK(length(manifest_hash)=64),
 sdk_snapshot_hash TEXT NOT NULL CHECK(length(sdk_snapshot_hash)=64),
 network_json TEXT NOT NULL CHECK(json_valid(network_json)),
 certificate_json TEXT NOT NULL CHECK(json_valid(certificate_json)),
 admission_check_id TEXT REFERENCES planning_admission_checks(check_id),
 event_id TEXT NOT NULL REFERENCES events(event_id),
 command_id TEXT NOT NULL,
 created_at REAL NOT NULL,
 PRIMARY KEY(mission_id,revision),
 UNIQUE(mission_id,revision,manifest_hash),
 UNIQUE(mission_id,command_id),
 FOREIGN KEY(mission_id,revision) REFERENCES plan_revisions(mission_id,revision),
 FOREIGN KEY(mission_id,requirements_revision) REFERENCES requirements_revisions(mission_id,revision),
 FOREIGN KEY(mission_id,parent_revision,parent_manifest_hash)
   REFERENCES taskgraph_revision_records(mission_id,revision,manifest_hash),
 CHECK((source_kind='CAPTURED_BASELINE' AND admission_check_id IS NULL) OR
       (source_kind IN ('SEED_COMMIT','COMMIT') AND admission_check_id IS NOT NULL)),
 CHECK((parent_revision IS NULL AND parent_manifest_hash IS NULL AND source_kind IN ('SEED_COMMIT','CAPTURED_BASELINE')) OR
       (parent_revision IS NOT NULL AND parent_manifest_hash IS NOT NULL AND length(parent_manifest_hash)=64 AND revision=parent_revision+1 AND source_kind='COMMIT'))
) STRICT;

CREATE TABLE taskgraph_member_pins (
 mission_id TEXT NOT NULL,
 revision INTEGER NOT NULL,
 occurrence_id TEXT NOT NULL,
 task_id TEXT NOT NULL,
 binding_revision INTEGER NOT NULL CHECK(binding_revision>=0),
 binding_hash TEXT NOT NULL CHECK(length(binding_hash)=64),
 PRIMARY KEY(mission_id,revision,occurrence_id),
 FOREIGN KEY(mission_id,revision) REFERENCES taskgraph_revision_records(mission_id,revision),
 FOREIGN KEY(mission_id,revision,occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id),
 FOREIGN KEY(task_id,binding_revision) REFERENCES task_semantics(task_id,binding_revision)
) STRICT;
CREATE INDEX taskgraph_member_pins_task_idx ON taskgraph_member_pins(mission_id,task_id,revision);

CREATE TABLE taskgraph_method_pins (
 mission_id TEXT NOT NULL,
 revision INTEGER NOT NULL,
 instance_id TEXT NOT NULL,
 goal_occurrence_id TEXT NOT NULL,
 adopted INTEGER NOT NULL CHECK(adopted IN (0,1)),
 draft_hash TEXT NOT NULL CHECK(length(draft_hash)=64),
 PRIMARY KEY(mission_id,revision,instance_id),
 FOREIGN KEY(mission_id,revision) REFERENCES taskgraph_revision_records(mission_id,revision),
 FOREIGN KEY(mission_id,instance_id) REFERENCES method_instances(mission_id,instance_id),
 FOREIGN KEY(mission_id,revision,goal_occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id)
) STRICT;
CREATE UNIQUE INDEX taskgraph_one_adopted_per_goal_idx
 ON taskgraph_method_pins(mission_id,revision,goal_occurrence_id) WHERE adopted=1;

-- Derived demand index, not a second financial ledger. One row per adopted slot.
CREATE TABLE taskgraph_demand_refs (
 mission_id TEXT NOT NULL,
 revision INTEGER NOT NULL,
 consumer_instance_id TEXT NOT NULL,
 slot_key TEXT NOT NULL,
 slot_occurrence_id TEXT NOT NULL,
 producer_occurrence_id TEXT NOT NULL,
 obligation_id TEXT NOT NULL,
 mode TEXT NOT NULL CHECK(mode IN ('new_work','reuse_accepted','share_active')),
 requiredness TEXT NOT NULL CHECK(requiredness IN ('required','optional_authorized','conditional')),
 source_slot_hash TEXT NOT NULL CHECK(length(source_slot_hash)=64),
 PRIMARY KEY(mission_id,revision,consumer_instance_id,slot_key),
 FOREIGN KEY(mission_id,revision,consumer_instance_id) REFERENCES taskgraph_method_pins(mission_id,revision,instance_id),
 FOREIGN KEY(consumer_instance_id,slot_key) REFERENCES method_child_occurrences(instance_id,slot_key),
 FOREIGN KEY(mission_id,revision,slot_occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id),
 FOREIGN KEY(mission_id,revision,producer_occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id),
 FOREIGN KEY(mission_id,obligation_id) REFERENCES obligations(mission_id,obligation_id)
) STRICT;
CREATE INDEX taskgraph_demand_producer_idx ON taskgraph_demand_refs(mission_id,revision,producer_occurrence_id);

-- Existing input_manifest_bindings may collapse repeated attempts with equal bytes;
-- this is the exact per-attempt association, not another manifest content store.
CREATE TABLE taskgraph_attempt_inputs (
 attempt_id TEXT PRIMARY KEY NOT NULL REFERENCES attempts(attempt_id),
 mission_id TEXT NOT NULL,
 task_id TEXT NOT NULL,
 occurrence_id TEXT NOT NULL,
 source_revision INTEGER NOT NULL,
 binding_revision INTEGER NOT NULL,
 contract_hash TEXT NOT NULL CHECK(length(contract_hash)=64),
 input_binding_revision INTEGER NOT NULL CHECK(input_binding_revision>=0),
 dispatch_generation INTEGER NOT NULL CHECK(dispatch_generation>=0),
 manifest_hash TEXT NOT NULL REFERENCES input_manifests(manifest_hash),
 intent_id TEXT NOT NULL UNIQUE REFERENCES dispatch_intents(intent_id),
 creation_key TEXT NOT NULL UNIQUE,
 input_id TEXT NOT NULL,
 frozen_input_hash TEXT NOT NULL CHECK(length(frozen_input_hash)=64),
 admission_check_id TEXT REFERENCES planning_admission_checks(check_id),
 origin_hash TEXT NOT NULL CHECK(length(origin_hash)=64),
 created_at REAL NOT NULL,
 FOREIGN KEY(mission_id,source_revision,occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id),
 FOREIGN KEY(task_id,binding_revision) REFERENCES task_semantics(task_id,binding_revision)
) STRICT;
CREATE INDEX taskgraph_attempt_inputs_occ_idx ON taskgraph_attempt_inputs(mission_id,occurrence_id,dispatch_generation);

-- Durable convergence coordination. It never records the external effect as resolved.
CREATE TABLE taskgraph_convergence_jobs (
 job_id TEXT PRIMARY KEY NOT NULL,
 mission_id TEXT NOT NULL REFERENCES taskgraph_policy_bindings(mission_id),
 decision_id TEXT NOT NULL REFERENCES planning_decisions(decision_id),
 request_id TEXT NOT NULL REFERENCES planning_requests(request_id),
 command_id TEXT NOT NULL,
 source_revision INTEGER NOT NULL,
 candidate_hash TEXT NOT NULL CHECK(length(candidate_hash)=64),
 impact_hash TEXT NOT NULL CHECK(length(impact_hash)=64),
 state TEXT NOT NULL CHECK(state IN ('FENCED','WAITING','READY','APPLIED','ABANDONED')),
 row_version INTEGER NOT NULL CHECK(row_version>=1),
 created_at REAL NOT NULL,
 updated_at REAL NOT NULL,
 UNIQUE(mission_id,decision_id),
 FOREIGN KEY(mission_id,source_revision) REFERENCES taskgraph_revision_records(mission_id,revision)
) STRICT;
CREATE TABLE taskgraph_convergence_targets (
 job_id TEXT NOT NULL REFERENCES taskgraph_convergence_jobs(job_id),
 mission_id TEXT NOT NULL,
 source_revision INTEGER NOT NULL,
 occurrence_id TEXT NOT NULL,
 task_id TEXT NOT NULL,
 expected_generation INTEGER NOT NULL CHECK(expected_generation>=0),
 target_kind TEXT NOT NULL CHECK(target_kind IN ('RETIRING','INPUT_REPLACED')),
 PRIMARY KEY(job_id,occurrence_id),
 FOREIGN KEY(mission_id,source_revision,occurrence_id) REFERENCES plan_memberships(mission_id,revision,occurrence_id)
) STRICT;
CREATE INDEX taskgraph_fence_lookup_idx ON taskgraph_convergence_targets(mission_id,task_id,job_id);

-- Only graph follow-up notifications. Original dispatch_intents remains the work handoff authority.
CREATE TABLE taskgraph_followups (
 message_id TEXT PRIMARY KEY NOT NULL,
 mission_id TEXT NOT NULL REFERENCES taskgraph_policy_bindings(mission_id),
 source_event_id TEXT NOT NULL REFERENCES events(event_id),
 kind TEXT NOT NULL CHECK(kind IN ('REEVALUATE','CONVERGE','REQUEST_COMPOSITION')),
 subject_key TEXT NOT NULL,
 dedupe_key TEXT NOT NULL UNIQUE,
 payload_hash TEXT NOT NULL CHECK(length(payload_hash)=64),
 payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
 delivery_state TEXT NOT NULL CHECK(delivery_state IN ('PENDING','LEASED','ACKED','BLOCKED')),
 lease_owner TEXT,
 lease_until_ms INTEGER,
 attempts INTEGER NOT NULL CHECK(attempts>=0),
 row_version INTEGER NOT NULL CHECK(row_version>=1),
 next_attempt_ms INTEGER NOT NULL CHECK(next_attempt_ms>=0),
 last_error_code TEXT,
 consumer_receipt_json TEXT CHECK(consumer_receipt_json IS NULL OR json_valid(consumer_receipt_json)),
 CHECK((delivery_state='ACKED' AND consumer_receipt_json IS NOT NULL) OR
       (delivery_state<>'ACKED' AND consumer_receipt_json IS NULL)),
 CHECK((delivery_state='LEASED' AND lease_owner IS NOT NULL AND lease_until_ms IS NOT NULL) OR
       (delivery_state<>'LEASED' AND lease_owner IS NULL AND lease_until_ms IS NULL))
) STRICT;
CREATE INDEX taskgraph_followups_poll_idx ON taskgraph_followups(delivery_state,next_attempt_ms,mission_id);

CREATE TRIGGER tg_revision_source_guard BEFORE INSERT ON taskgraph_revision_records BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM events e WHERE e.event_id=NEW.event_id AND e.mission_id=NEW.mission_id
 ) THEN RAISE(ABORT,'TG_REVISION_EVENT_MISMATCH') END;
 SELECT CASE WHEN NEW.source_kind<>'CAPTURED_BASELINE' AND NOT EXISTS (
  SELECT 1 FROM planning_admission_checks c JOIN planning_requests r ON r.request_id=c.request_id
  WHERE c.check_id=NEW.admission_check_id AND c.phase='APPLIED' AND r.mission_id=NEW.mission_id
 ) THEN RAISE(ABORT,'TG_REVISION_ADMISSION_MISMATCH') END;
END;
CREATE TRIGGER tg_pin_subject_guard BEFORE INSERT ON taskgraph_member_pins BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM task_semantics s JOIN plan_memberships m
    ON m.mission_id=NEW.mission_id AND m.revision=NEW.revision AND m.occurrence_id=NEW.occurrence_id
  WHERE s.task_id=NEW.task_id AND s.binding_revision=NEW.binding_revision
    AND s.mission_id=NEW.mission_id AND m.task_id=s.task_id AND m.obligation_id=s.obligation_id
    AND m.form=s.form AND s.content_hash=NEW.binding_hash
 ) THEN RAISE(ABORT,'TG_PIN_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_method_subject_guard BEFORE INSERT ON taskgraph_method_pins BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM method_instances i WHERE i.mission_id=NEW.mission_id AND i.instance_id=NEW.instance_id
   AND i.goal_occurrence_id=NEW.goal_occurrence_id
 ) THEN RAISE(ABORT,'TG_METHOD_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_demand_subject_guard BEFORE INSERT ON taskgraph_demand_refs BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM taskgraph_method_pins p JOIN method_child_occurrences c
   ON c.instance_id=p.instance_id AND c.mission_id=p.mission_id
  WHERE p.mission_id=NEW.mission_id AND p.revision=NEW.revision
   AND p.instance_id=NEW.consumer_instance_id AND p.adopted=1 AND c.slot_key=NEW.slot_key
   AND c.occurrence_id=NEW.slot_occurrence_id AND c.goal_occurrence_id=NEW.producer_occurrence_id
   AND c.obligation_id=NEW.obligation_id AND c.reuse_policy=NEW.mode AND c.requiredness=NEW.requiredness
 ) THEN RAISE(ABORT,'TG_DEMAND_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_attempt_identity_guard BEFORE INSERT ON taskgraph_attempt_inputs BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM attempts a JOIN dispatch_intents d ON d.subject_id=a.attempt_id
  JOIN plan_memberships m ON m.mission_id=a.mission_id AND m.task_id=a.task_id
  JOIN task_semantics s ON s.task_id=a.task_id AND s.binding_revision=NEW.binding_revision
  JOIN taskgraph_revision_records rr ON rr.mission_id=NEW.mission_id AND rr.revision=NEW.source_revision
  LEFT JOIN planning_admission_checks c ON c.check_id=NEW.admission_check_id
  LEFT JOIN planning_requests r ON r.request_id=c.request_id
  JOIN input_manifest_bindings b ON b.mission_id=a.mission_id AND b.task_id=a.task_id
   AND b.manifest_hash=NEW.manifest_hash AND b.input_binding_revision=NEW.input_binding_revision
  WHERE a.attempt_id=NEW.attempt_id AND a.mission_id=NEW.mission_id AND a.task_id=NEW.task_id
   AND d.intent_id=NEW.intent_id AND d.mission_id=NEW.mission_id
   AND d.creation_key=NEW.creation_key AND d.input_id=NEW.input_id AND d.input_hash=NEW.frozen_input_hash
   AND m.revision=NEW.source_revision AND m.occurrence_id=NEW.occurrence_id AND m.form='primitive'
   AND s.mission_id=NEW.mission_id AND s.form='primitive'
   AND s.input_binding_revision=NEW.input_binding_revision AND s.dispatch_generation=NEW.dispatch_generation
   AND ((rr.source_kind='CAPTURED_BASELINE' AND rr.admission_check_id IS NULL AND NEW.admission_check_id IS NULL)
     OR (rr.source_kind<>'CAPTURED_BASELINE' AND rr.admission_check_id=NEW.admission_check_id
         AND r.mission_id=NEW.mission_id AND c.phase='APPLIED'))
 ) THEN RAISE(ABORT,'TG_ATTEMPT_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_convergence_identity_guard BEFORE INSERT ON taskgraph_convergence_jobs BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM planning_requests r JOIN planning_decisions d ON d.request_id=r.request_id
  WHERE r.request_id=NEW.request_id AND d.decision_id=NEW.decision_id AND r.mission_id=NEW.mission_id
 ) THEN RAISE(ABORT,'TG_CONVERGENCE_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_target_identity_guard BEFORE INSERT ON taskgraph_convergence_targets BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM taskgraph_convergence_jobs j JOIN plan_memberships m
   ON m.mission_id=j.mission_id AND m.revision=j.source_revision
  WHERE j.job_id=NEW.job_id AND j.mission_id=NEW.mission_id AND j.source_revision=NEW.source_revision
   AND m.occurrence_id=NEW.occurrence_id AND m.task_id=NEW.task_id
 ) THEN RAISE(ABORT,'TG_TARGET_IDENTITY_MISMATCH') END;
END;
CREATE TRIGGER tg_followup_owner_guard BEFORE INSERT ON taskgraph_followups BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM events e WHERE e.event_id=NEW.source_event_id AND e.mission_id=NEW.mission_id
 ) THEN RAISE(ABORT,'TG_FOLLOWUP_OWNER_MISMATCH') END;
END;

CREATE TRIGGER taskgraph_policy_bindings_no_update BEFORE UPDATE ON taskgraph_policy_bindings BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_policy_bindings_no_delete BEFORE DELETE ON taskgraph_policy_bindings BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_revision_records_no_update BEFORE UPDATE ON taskgraph_revision_records BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_revision_records_no_delete BEFORE DELETE ON taskgraph_revision_records BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_member_pins_no_update BEFORE UPDATE ON taskgraph_member_pins BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_member_pins_no_delete BEFORE DELETE ON taskgraph_member_pins BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_method_pins_no_update BEFORE UPDATE ON taskgraph_method_pins BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_method_pins_no_delete BEFORE DELETE ON taskgraph_method_pins BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_demand_refs_no_update BEFORE UPDATE ON taskgraph_demand_refs BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_demand_refs_no_delete BEFORE DELETE ON taskgraph_demand_refs BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_attempt_inputs_no_update BEFORE UPDATE ON taskgraph_attempt_inputs BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_attempt_inputs_no_delete BEFORE DELETE ON taskgraph_attempt_inputs BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

CREATE TRIGGER taskgraph_convergence_targets_no_update BEFORE UPDATE ON taskgraph_convergence_targets BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER taskgraph_convergence_targets_no_delete BEFORE DELETE ON taskgraph_convergence_targets BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;

-- These constrain permitted database transitions, but DO NOT replace real convergence/receipt checks.
CREATE TRIGGER tg_convergence_transition BEFORE UPDATE ON taskgraph_convergence_jobs BEGIN
 SELECT CASE WHEN NEW.job_id<>OLD.job_id OR NEW.mission_id<>OLD.mission_id
  OR NEW.decision_id<>OLD.decision_id OR NEW.request_id<>OLD.request_id
  OR NEW.command_id<>OLD.command_id OR NEW.source_revision<>OLD.source_revision
  OR NEW.candidate_hash<>OLD.candidate_hash OR NEW.impact_hash<>OLD.impact_hash
  OR NEW.row_version<>OLD.row_version+1
  THEN RAISE(ABORT,'TG_CONVERGENCE_IDENTITY_OR_VERSION') END;
 SELECT CASE WHEN NOT (
   (OLD.state='FENCED' AND NEW.state IN ('WAITING','READY','ABANDONED')) OR
   (OLD.state='WAITING' AND NEW.state IN ('WAITING','READY','ABANDONED')) OR
   (OLD.state='READY' AND NEW.state IN ('WAITING','APPLIED','ABANDONED'))
 ) THEN RAISE(ABORT,'TG_CONVERGENCE_TRANSITION') END;
END;
CREATE TRIGGER tg_convergence_no_delete BEFORE DELETE ON taskgraph_convergence_jobs BEGIN
 SELECT RAISE(ABORT,'TG_IMMUTABLE'); END;
CREATE TRIGGER tg_followup_transition BEFORE UPDATE ON taskgraph_followups BEGIN
 SELECT CASE WHEN NEW.message_id<>OLD.message_id OR NEW.mission_id<>OLD.mission_id
  OR NEW.source_event_id<>OLD.source_event_id OR NEW.kind<>OLD.kind
  OR NEW.subject_key<>OLD.subject_key OR NEW.dedupe_key<>OLD.dedupe_key
  OR NEW.payload_hash<>OLD.payload_hash OR NEW.payload_json<>OLD.payload_json
  OR NEW.row_version<>OLD.row_version+1
  THEN RAISE(ABORT,'TG_FOLLOWUP_IDENTITY_OR_VERSION') END;
 SELECT CASE WHEN NOT (
   (OLD.delivery_state='PENDING' AND NEW.delivery_state='LEASED') OR
   (OLD.delivery_state='LEASED' AND NEW.delivery_state IN ('PENDING','LEASED','ACKED','BLOCKED')) OR
   (OLD.delivery_state='BLOCKED' AND NEW.delivery_state='PENDING')
 ) THEN RAISE(ABORT,'TG_FOLLOWUP_TRANSITION') END;
END;
