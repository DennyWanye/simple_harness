# 42组真实SDK验收

全部待执行；reference结果不填写到本表。

| ID | 场景 | 前置/执行 | 必须断言 |
|---|---|---|---|
| S01 | 历史结构准确读取 | 同一Mission r1固定binding1；r2修改binding且退役旧Method；分别读r1和r2；重启后再读 | r1返回原binding/draft/adoption/hash；不得读取latest；不同tenant拒绝 |
| S02 | Method与slot身份 | 注册两个同目标不同版本Method、含重复slot的坏候选；各自ground；坏候选preview | 参数/版本/hash准确；同输入ID稳定；重复slot拒绝，不能静默dedupe |
| S03 | 候选来源完整 | 合法REFINE的真实package及H1 grant；删除一个必需producer；两次preview再尝试Commit | 正常候选hash一致零写；缺来源SOURCE_UNAVAILABLE；不得默认形状通过 |
| S04 | AND-OR采用 | 根goal含两种替代方法，一种含两个required孩子；只采用一种；尝试同时采用两种 | 只采用的方法可运行；两种同goal采用拒绝；未选路线不阻塞合法根目标 |
| S05 | compound入口出口 | compound内两个独立primitive和组合Review；嵌套compound；生成projection、驱动实际调度 | 无父子死等；primitive可并行；compound/gate没有Attempt或模型费用 |
| S06 | 图损坏与环 | 缺端点、自环、ORDER+DATA形成环、refinement自祖先；preview/reader/物化入口分别执行 | 具名拒绝；无部分拓扑执行、不滤坏边；其余Mission可继续 |
| S07 | pending与检查完整 | 尚未展开compound但现存结构合法；另缺EvidenceSnapshot；运行完整validator | 前者显式pending且不可派Worker；后者NOT_CHECKED拒绝；不可共用skip |
| S08 | 边界与确定性 | 等于及超过实际GraphStructureBudget；打乱无关节点顺序；重复投影；测时间/SQL数；运行+1 | 边界成功/超限BOUND_REACHED；无截断；非语义顺序不改变结果 |
| D01 | ORDER与DATA分离 | A有两个输出；B只ORDER依赖A；C的一个端口DATA绑定A指定输出；运行真实resolver/工作区物化 | B不自动收到A文件；C只有声明输出；拒绝未授权路径和替换 |
| D02 | 合法空与未取得 | 一任务无输入要求；另一必需port未绑定；另源读取异常；调用实际resolver、admissions、派发 | 只有第一项得到明确frozen空manifest；其余等待/拒绝，不fallback空 |
| D03 | schema与选择 | 相同schema、显式声明、需要converter、两份同port不同revision；resolve并dispatch | 不推测兼容；converter未运行不得改schema标签；歧义拒绝不选最新 |
| D04 | ORDER真实结算 | ACCEPTED/FAILED/CANCELLED加实际IN_FLIGHT/UNKNOWN/已结算组合；分别检查accepted和settled_terminal边 | 失败不满足accepted；有未决真实调用时CANCELLED也不释放cleanup |
| D05 | 物化与资源身份 | 两个不同namespace同路径；同namespace大小写别名/path逃逸/symlink；实际TargetRules+CAS读取+workspace物化 | 隔离同路径可共存；真实冲突/越界拒绝；不因ORDER授覆盖权 |
| D06 | 每Attempt冻结输入 | 同Task两个合法Attempt使用同manifest；另v2变更；创建真实Attempt/intent/绑定，重启恢复旧Attempt | 两条attempt关联一份内容；恢复各自input_id/hash；不升级到latest |
| A01 | 真实caller/启用 | 两个tenant、legacy/新协议；已认证caller和未授权caller；enable_taskgraph_contract、读写接口 | 仅获准新协议写新表；旧默认无变化；payload伪造principal无效 |
| A02 | 冻结request | H1 package/visible refs/subject/request真实绑定；混入不可见ref、旧request及decode-only决定 | 拒绝原H1语义；不把方法修复跳过request；decode-only无图写入 |
| A03 | grant与Commit竞态 | 合法grant生成preview；Commit前revoke/expire；调用最终原Commit入口；重送已成功旧command | 未提交者拒绝；已提交历史receipt按当前读权可读，无新写 |
| A04 | Validity目的与来源 | PLAN witness用于START、其他consumer、过期epoch、新反证；准备manifest/dispatch/accept | 目的/consumer/support/epoch均检查；新反证使旧缓存重算；历史事实保留 |
| A05 | 能力和权限 | 实际PlanningWorld声明与当前Tool授权不同；缺targetRules；尝试规划和handoff | 声明不是调用权限；未部署或未经授权不能执行；无默认True |
| A06 | 预算守恒 | 父账户剩余不足、UNKNOWN hold、共享任务、换Method/Task；并发reserve与改图 | 不新增资金；尾部保护；UNKNOWN不释放；Obligation消耗与失败不归零 |
| R01 | 共享保留 | 两个adopted消费者依赖同只读producer；其中一个退休；preview effects然后Commit | 保留producer及另一个消费者；不撤其generation/预算；仅退出对应需求 |
| R02 | 局部影响 | A→DATA→B；Z只ORDER关联；输入/支持改变；运行impact和Validity重算 | B进入revalidate；不因ORDER复制失效；不完整覆盖保守处理有标记 |
| R03 | 非法修复不先取消 | 旧Method兄弟Attempt在跑，新候选有cycle；触发REPAIR/REPLACE | 先拒绝形状；原工作和派发权不被preview取消 |
| R04 | 收敛完整闭环 | 合法替换，旧工作在途；fence持久写入；强退后advance，原runtime收敛，最终Commit | 同一decision无需第二LLM；READY仍fenced；Commit代次只增一次 |
| R05 | 最后需求并发 | 最后consumer退休与另consumer新增同时提交；两个连接barrier控制读/写次序 | 至少一个stale/冲突或按当前完整集合重评；不误取消仍需的工作 |
| R06 | 退役操作仍UNKNOWN | 旧方法留下Operation link/action UNKNOWN，另链读取失败；尝试新图和恢复mapper | 仍扫描所有历史关联；读失败!=空；换方法不创建新现实动作 |
| R07 | 晚到结果 | A换输入且generation增加；B不变但global plan变；接收A/B原结果和Verifier回执 | A只归档费用不批准新输入；B原合同仍可合法接受 |
| R08 | 延期/撤权/取消 | convergence WAITING时grant变化或用户取消；重复唤醒/abandon请求 | 不回活旧权限；无证不释放fence/hold；收敛责任可查且有界 |
| C01 | 一写事务与幂等 | 合法H1决定生成candidate，准备原Commit；各写点异常，随后同command重送和异内容重送 | 计划/记录/预算/事件/回执全有或全无；同key复用，异内容冲突 |
| C02 | 并发计划环 | 同base两提案A→B与B→A；独立SQLite连接提交 | H1第二个stale，无自动rebase；新base验证环拒绝；无半图 |
| C03 | 进程强退四点 | 真实测试DB，原Store/Commit/dispatch；before Commit、after Commit before receipt、after reserve before intent、after executor receipt四点os._exit | 未提交rollback；已提交找原receipt/AgentTurn；不重复reserve/operation |
| C04 | 离线图重建 | 两revision真实记录后删除新离线目标投影；rebuild_projection并篡改一个源hash重试 | 相同结构hash；坏源拒绝；不读当前状态猜历史；零Provider/tool |
| C05 | 通知至少一次投递 | source event+followup原子保存，消费者已完成持久意图但没ACK；强退恢复重新投递 | 相同下游command复用一次意图；ACK后无重复工作 |
| C06 | 迁移兼容 | 真实0.12.x及当前H1H-ADM测试库copy，旧迁移checksum；用原runner新建和升级；故意FK/alias错误 | 原历史bytes/checksum不变；新约束有效；错误不部分迁移 |
| C07 | SQL跨Mission负控 | 两Mission实际图/Method/Attempt/manifest/event；尝试交叉插pin、action check、source event、jobtarget | DB触发器/外键或API拒绝；源JSON全hash另测 |
| C08 | Attempt原子绑定 | 实际创建Attempt/reserve/input/intent中途失败；两次相同manifest；真实transaction和重启 | 无孤立可派发intent；每Attempt源关联唯一；缺关联不可用latest修复 |
| V01 | 组合验收不可省 | 两child各自ACCEPTED但接口不兼容，另全兼容版本；真实独立Verifier+root resolution | 前者根拒绝、后者根通过；不是all child statuses shortcut |
| V02 | 不改图决定 | 有UNKNOWN或budget耗尽但合法状态回复；WAIT/NO_CHANGE/DECLARE_BLOCKED逐项执行 | 不调用preview/operations mapper；不写新PlanRevision；WAIT不丢唤醒 |
| V03 | 完整方法修复 | 合法Method A失败、共享C有效、改B并新增D；真实H1 Planner/worker/Verifier/Commit整链 | 保留C；按DATA给D/Join正确输入；旧A回执不能批准B；根closeout正确 |
| V04 | Host一致视图 | 当前/历史revision、未知错误消息、权限切换；TaskGraphReadApi和实际Host组件打开/重连 | 同readtoken；历史frontiers为空；错误保留stale画面；UI不直接改状态 |
| V05 | Shadow隔离与回归 | 同seed/fixed model输出，在NanoJev有无shadow下运行；比较正式plan、input、authorization路径；跑legacygolden | shadow不绕producer或替代HTN；旧Prompt/package/事件/默认行为不变 |
| V06 | 真实模型与规模 | H1后同候选/获准GPT-5.6配置，四代表场景各3trial；冻结manifest执行，记录所有失败/成本；运行bound及+1 | 安全不变量全成立；质量结果原样报告；未跑不写PASS；性能不凭感觉 |
