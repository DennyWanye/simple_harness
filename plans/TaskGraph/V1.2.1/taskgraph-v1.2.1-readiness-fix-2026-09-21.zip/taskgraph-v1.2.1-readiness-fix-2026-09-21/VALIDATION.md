# V1.2.1 实际验证报告

本轮环境：Linux，Python 3.13.5，pytest 9.0.2，SQLite 3.46.1。

执行命令：`PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v`（这是交付生成环境的实际命令，不替代用户项目.venv要求）。

**90项工具/参考测试通过，0失败、0错误、0跳过。** 包含原56项和新增34项；这是本包工具的回归，不是90个SDK场景。

实际复现旧工具：根路径alias被错误拒绝；基础nodeid对参数化collection错误标missing。新版本的回归包含alias等价、内部symlink逃逸拒绝、三个参数完整展开、错误metadata/混合源码身份拒绝、真实pytest仅collection且测试主体不得执行、runner精确AST补丁只改新副本、SQL trigger/字符串/注释/rollback。

原TaskGraph 9张表/25个trigger在**明确reference父schema**中由完整语句迭代运行，外层事务保持且回滚。此项不证明真实SDK parent schema兼容。

原附件ZIP在本环境原56工具测试通过；用户macOS原包55/1及改过副本56/56仍按handoff另记，不被本环境结果覆盖。本轮未在macOS运行；合法alias模拟不是macOS实机验收。

没有运行用户候选、C01–C10、真实SDK migration、H1H36case、两套mutation、Host或GPT-5.6。新的候选dirty fingerprint未采集。SDK各gate继续BLOCKED/PENDING。

原始本轮工具日志未打包；摘要哈希：`79ebc3c1f8f30f0c71479fe402159f7631afaa0c84a2e01051c1e4b2c0d37b1d`。完整结构化摘要在metadata/tool-validation.json。每个本地复测仍需保存自己的ignored原始日志/命令/收据。

JSON解析、Python AST语法检查通过；原inputs归档与42/12/36规范文件hash均保留。DELIVERY-MANIFEST覆盖本包实际交付文件；完整ZIP另有外置SHA256，二者只证明字节完整性。
