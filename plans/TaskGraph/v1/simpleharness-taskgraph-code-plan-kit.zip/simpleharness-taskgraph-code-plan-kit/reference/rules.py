"""Executable local reference for TG-EXEC-2.0. Not an SDK runtime replacement.

Only pure graph/data/identity rules live here. No model calls, authority issuance,
external actions or production database writes. Production adapters reuse SDK codecs.
"""
from __future__ import annotations
import hashlib
import heapq
import json
from dataclasses import dataclass
from collections import deque
from typing import Iterable, Mapping

class Rejected(ValueError):
    def __init__(self, code: str, detail: str = ''):
        super().__init__(f'{code}: {detail}')
        self.code = code


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value: object) -> str:
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def checked_int(value: object, *, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise Rejected('PARAMETER_INVALID', 'integer required; booleans are not integers')
    return value


def topological(nodes: Iterable[str], edges: Iterable[tuple[str, str]]) -> tuple[str, ...]:
    nodes = tuple(nodes)
    if len(set(nodes)) != len(nodes):
        raise Rejected('STRUCTURE_INVALID', 'duplicate nodes')
    graph = {n: set() for n in nodes}
    degree = {n: 0 for n in nodes}
    for a, b in edges:
        if a not in graph or b not in graph:
            raise Rejected('STRUCTURE_INVALID', 'dangling endpoint')
        if a == b:
            raise Rejected('ORDER_CYCLE', 'self cycle')
        if b not in graph[a]:
            graph[a].add(b)
            degree[b] += 1
    queue = [n for n, d in degree.items() if d == 0]
    heapq.heapify(queue)
    result = []
    while queue:
        n = heapq.heappop(queue)
        result.append(n)
        for child in sorted(graph[n]):
            degree[child] -= 1
            if degree[child] == 0:
                heapq.heappush(queue, child)
    if len(result) != len(nodes):
        raise Rejected('ORDER_CYCLE', ','.join(sorted(n for n,d in degree.items() if d)))
    return tuple(result)


@dataclass(frozen=True)
class Occurrence:
    id: str
    form: str


@dataclass(frozen=True)
class Slot:
    key: str
    occurrence: str
    required: bool


@dataclass(frozen=True)
class Method:
    id: str
    parent: str
    slots: tuple[Slot, ...]


@dataclass(frozen=True)
class Order:
    before: str
    after: str
    release: str = 'accepted'


@dataclass(frozen=True)
class Data:
    id: str
    producer: str
    output: str
    consumer: str
    input: str


@dataclass(frozen=True)
class Projection:
    nodes: tuple[str, ...]
    edges: tuple[tuple[str, str], ...]
    billable_occurrences: tuple[str, ...]


def node_id(occ: str, side: str) -> str:
    return f'{len(occ)}:{occ}:{side}'


def project(occurrences: tuple[Occurrence, ...], methods: tuple[Method, ...],
            adopted: tuple[str, ...], roots: tuple[str, ...],
            orders: tuple[Order, ...] = (), data: tuple[Data, ...] = ()) -> Projection:
    by_occ = {n.id: n for n in occurrences}
    if len(by_occ) != len(occurrences):
        raise Rejected('STRUCTURE_INVALID', 'duplicate occurrence')
    by_method = {m.id: m for m in methods}
    if len(by_method) != len(methods) or len(set(adopted)) != len(adopted):
        raise Rejected('STRUCTURE_INVALID', 'duplicate method/adoption')
    selected = {}
    for mid in adopted:
        if mid not in by_method:
            raise Rejected('STRUCTURE_INVALID', 'unknown method')
        m = by_method[mid]
        if m.parent not in by_occ or by_occ[m.parent].form != 'compound':
            raise Rejected('STRUCTURE_INVALID', 'invalid refinement parent')
        if m.parent in selected:
            raise Rejected('OR_NOT_RESOLVED', 'two adopted methods')
        keys = [s.key for s in m.slots]
        if len(set(keys)) != len(keys):
            raise Rejected('STRUCTURE_INVALID', 'duplicate slot')
        if not any(s.required for s in m.slots):
            raise Rejected('COVERAGE_GAP', 'adopted method has no gating child')
        selected[m.parent] = m
    for root in roots:
        if root not in by_occ:
            raise Rejected('STRUCTURE_INVALID', 'unknown root')
    # Refinement cycle detection is separate from execution cycle detection.
    refine_edges = [(m.parent,s.occurrence) for m in selected.values() for s in m.slots]
    try:
        topological(by_occ, refine_edges)
    except Rejected as error:
        if error.code == 'ORDER_CYCLE':
            raise Rejected('REFINEMENT_CYCLE') from error
        raise
    reachable, todo = set(), list(roots)
    while todo:
        n = todo.pop()
        if n in reachable:
            continue
        reachable.add(n)
        if n in selected:
            todo.extend(s.occurrence for s in selected[n].slots)
    entry, exit_, node_list, billable = {}, {}, [], []
    for oid in sorted(reachable):
        n = by_occ[oid]
        if n.form == 'compound':
            entry[oid],exit_[oid] = node_id(oid,'entry'),node_id(oid,'exit')
            node_list.extend((entry[oid],exit_[oid]))
        elif n.form == 'primitive':
            entry[oid]=exit_[oid]=node_id(oid,'node')
            node_list.append(entry[oid]); billable.append(oid)
        else:
            raise Rejected('STRUCTURE_INVALID','unknown form')
    edges = []
    for oid in sorted(reachable):
        if by_occ[oid].form != 'compound':
            continue
        m=selected.get(oid)
        if m is None:
            # Only a structural span. Never certifies completion or dispatches a worker.
            edges.append((entry[oid],exit_[oid]))
        else:
            for s in m.slots:
                edges.append((entry[oid],entry[s.occurrence]))
                if s.required:
                    edges.append((exit_[s.occurrence],exit_[oid]))
    for o in orders:
        if o.before not in reachable or o.after not in reachable:
            raise Rejected('STRUCTURE_INVALID','inactive ORDER endpoint')
        if o.release not in ('accepted','settled_terminal'):
            raise Rejected('STRUCTURE_INVALID','unknown release')
        edges.append((exit_[o.before],entry[o.after]))
    for d in data:
        if d.producer not in reachable or d.consumer not in reachable:
            raise Rejected('STRUCTURE_INVALID','inactive DATA endpoint')
        edges.append((exit_[d.producer],entry[d.consumer]))
    topological(node_list, edges)
    return Projection(tuple(sorted(node_list)),tuple(sorted(set(edges))),tuple(billable))


@dataclass(frozen=True)
class Accepted:
    producer: str
    port: str
    result_id: str
    acceptance_id: str
    artifact_id: str
    hash: str
    revision: str
    schema: str
    current: bool
    disclosed: bool


def resolve_inputs(*, consumer: str, required_ports: frozenset[str],
                   requirements: tuple[Data,...], outputs: tuple[Accepted,...],
                   pins: Mapping[str,str], schemas: Mapping[str,str],
                   complete_sources: bool) -> tuple[Accepted,...]:
    if not complete_sources:
        raise Rejected('SOURCE_UNAVAILABLE')
    selected=[]; used=set()
    for d in requirements:
        if d.consumer != consumer:
            raise Rejected('DATA_UNBOUND','foreign consumer')
        if d.input in used:
            raise Rejected('DATA_UNBOUND','single port bound twice')
        used.add(d.input)
        if d.id not in pins:
            raise Rejected('DATA_UNBOUND','must pin an authorized source revision')
        matches=[a for a in outputs if (a.producer,a.port,a.revision)==(d.producer,d.output,pins[d.id])]
        if len(matches)!=1:
            raise Rejected('DATA_UNBOUND','source absent or ambiguous')
        a=matches[0]
        if not a.current or not a.disclosed:
            raise Rejected('STALE_BINDING')
        if a.schema!=schemas.get(d.input):
            raise Rejected('DATA_UNBOUND','unregistered schema conversion')
        selected.append(a)
    if required_ports-used:
        raise Rejected('DATA_UNBOUND','required ports are unbound')
    return tuple(selected)


def order_is_released(outcome: str, release: str, *, settled: bool) -> bool:
    if release not in ('accepted','settled_terminal'):
        raise Rejected('STRUCTURE_INVALID')
    if outcome=='UNKNOWN':
        return False
    if release=='accepted':
        return outcome=='ACCEPTED'
    return settled and outcome in {'ACCEPTED','FAILED','CANCELLED','SETTLED_OTHER'}


def impact(changed: frozenset[str], data: tuple[Data,...],
           support_consumers: Mapping[str,tuple[str,...]], universe: frozenset[str],
           *, complete: bool) -> tuple[frozenset[str],frozenset[str]]:
    if not complete:
        return frozenset(),universe
    reverse: dict[str,set[str]]={}
    for d in data: reverse.setdefault(d.producer,set()).add(d.consumer)
    for source, consumers in support_consumers.items():
        reverse.setdefault(source,set()).update(consumers)
    seen=set(changed);todo=deque(sorted(changed))
    while todo:
        for n in sorted(reverse.get(todo.popleft(),())):
            if n not in seen: seen.add(n);todo.append(n)
    affected=frozenset(seen)&universe
    return universe-affected, affected


def must_preserve_shared(producer: str, consumers_after: Mapping[str,tuple[str,...]],
                         *, independent_demand: bool, unresolved_effect: bool) -> bool:
    return independent_demand or unresolved_effect or bool(consumers_after.get(producer))


def accepts_parent(required_children: frozenset[str], accepted_children: frozenset[str],
                   *, adopted_method: bool, composition_accepted: bool,
                   requirements_covered: bool, validity_current: bool) -> bool:
    return (bool(required_children) and adopted_method and required_children<=accepted_children
            and composition_accepted and requirements_covered and validity_current)


def check_dispatch_origin(*, expected: Mapping[str,object], current: Mapping[str,object],
                          fence_active: bool, valid_inputs: bool, has_demand: bool) -> None:
    # Global plan revision is NOT an identity component of already handed-off work.
    for name in ('mission','task','occurrence','contract_hash','input_binding_revision','dispatch_generation'):
        if name not in expected or expected[name]!=current.get(name):
            raise Rejected('STALE_BINDING',name)
    if fence_active or not has_demand: raise Rejected('NOT_SELECTED')
    if not valid_inputs: raise Rejected('STALE_BINDING','validity')


def same_command_receipt(existing_intent: str | None, requested_intent: str) -> str:
    if existing_intent is None: return 'NEW'
    if existing_intent!=requested_intent: raise Rejected('COMMAND_PAYLOAD_CONFLICT')
    return 'REPLAY'
