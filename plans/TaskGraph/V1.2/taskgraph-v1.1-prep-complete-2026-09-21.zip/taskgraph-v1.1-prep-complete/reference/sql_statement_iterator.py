"""Reference only: preserve full trigger bodies while retaining caller transaction.
Not installed into the SDK by any readiness script. No executescript, no COMMIT.
"""
from __future__ import annotations
import sqlite3
from collections.abc import Iterator

def comments_only(text: str) -> bool:
    i=0
    while i<len(text):
        if text[i].isspace():i+=1;continue
        if text.startswith('--',i):
            n=text.find('\n',i+2);i=len(text) if n<0 else n+1;continue
        if text.startswith('/*',i):
            n=text.find('*/',i+2)
            if n<0:return False
            i=n+2;continue
        return False
    return True

def iter_sql_statements(ddl: str) -> Iterator[str]:
    start=0
    for i,ch in enumerate(ddl):
        if ch==';' and sqlite3.complete_statement(ddl[start:i+1]):
            statement=ddl[start:i+1]
            if not comments_only(statement):yield statement
            start=i+1
    if not comments_only(ddl[start:]):
        raise ValueError('Incomplete trailing SQL; no silent truncation')
