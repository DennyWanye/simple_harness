# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""P2.3l / N7: a non-root compound in ``composition_review`` forms a GoalResolution.

A compound whose gating children are accepted parks in ``composition_review``.  The
root has a ``MISSION_FINAL`` coordinator; an inner compound had none, so ORDER
successors (M3's ``revert``) stayed ``WAITING_ORDER`` forever.

This assembly is the missing trigger.  It does **not** ask a model and it does
**not** invent PASS (AER I05):

* the package is a ``ReviewPurpose.COMPOSITION`` anchor over the children's
  CURRENT Acceptances;
* the record transcribes each parent criterion from the linked child's official
  review — missing or non-PASS becomes ``UNKNOWN``;
* ``composition_obligation_passed`` is the record's own verdict;
* ``commit_goal_resolution`` (``is_mission_root=False``) is the only writer.

Why not reuse the root-reviewer service intent: §6.3 / ``leaf_acceptance`` already
say a compound is satisfied out of its children's acceptances, never by a review
of its own.  Those children already had independent TASK_CONTENT reviews.  A
second model call would charge ``PARENT_COMPOUND_TASK`` against a 0-token
compound budget, and M3's assess compound has no root requirements to judge.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from ..contracts.evidence_state import (
    Availability,
    TruthValue,
    Validity,
    ValidityWitness,
    WitnessDecision,
    WitnessPurpose,
)
from ..contracts.htn import (
    MethodInstanceId,
    OccurrenceId,
    ReadItem,
    ReadItemKind,
    ScopeEpochRead,
    SemanticReadSet,
    TaskForm,
)
from ..contracts.models import ContractError
from ..contracts.resolution import (
    CheckExecution,
    Criterion,
    CriterionOutcome,
    CriterionVerdict,
    GoalResolution,
    GoalResolutionId,
    RequirementsRevision,
    ResolutionCriterion,
    ReviewBinding,
    ReviewPackage,
    ReviewPackageId,
    ReviewPurpose,
    ReviewRecord,
    ReviewRecordId,
    ReviewVerdict,
    WorkspaceAccess,
)
from ..contracts.semantic_base import (
    TypedRef,
    TypedRefKind,
    content_hash_of,
)
from ..graph.task_network import GATING_REQUIREDNESS
from ..knowledge.validity import NO_SUBJECT, witness_subject
from ..storage.htn_store import HtnStore
from ..storage.store import StoreError
from ..verification.acceptance_rules import CompoundFacts, ExecutionPosture, IndependenceFacts
from .accepted_outputs import carried_criteria_in_revision
from .hierarchical_dispatch import CompoundPhase, HierarchicalDispatch, next_compound_phase
from .resolution_commits import (
    CommitGoalResolutionCommand,
    GoalResolutionReceipt,
    ResolutionCommitRejected,
    ResolutionPrincipal,
)

COMPOSITION_REVIEW_POLICY = "hierarchical-composition-review-v1"
COMPOSITION_REVIEWER = "composition-reviewer"
COMPOSITION_UNCOVERED = "composition_criterion_uncovered"
REVIEWER_ACCESS = WorkspaceAccess.READ_ONLY


def assured_composition_action(record: Any, ruling: Mapping[str, Any] | None) -> str:
    """What an official COMPOSITION record calls for: resolve / ask / repair.

    ACCEPT resolves; INCONCLUSIVE with no ruling asks the person; a ruling of
    "pass" resolves, of "fail" repairs; REWORK / REJECTED repair.
    """
    if record.verdict is ReviewVerdict.ACCEPT:
        return "resolve"
    if record.verdict is ReviewVerdict.INCONCLUSIVE:
        if ruling is None:
            return "ask"
        return "resolve" if ruling.get("decision") == "pass" else "repair"
    return "repair"


@dataclass(frozen=True, slots=True)
class CompositionAcceptanceAssembly:
    """Form a non-root ``GoalResolution`` from children's CURRENT Acceptances."""

    store: Any
    commit: Any
    dispatch: HierarchicalDispatch
    scope_id: str = "mission"
    issued_by: str = "orchestrator"
    #: 2026-10-01（第 3 项）：保证通道下正式组合审阅记录的两个出口，由编排循环提供——
    #: 复审后仍判不下来 → ``ask_person(record, task_id, occurrence_id)``；
    #: 打回 / 拒绝（或人裁决打回）→ ``on_rejected(record, package, task_id, occurrence_id)``。
    ask_person: Any = None
    on_rejected: Any = None
    #: 片 B：某个中间目标这一轮出不了结论、且原因是报错（审阅开不起来、提交被拒）时，
    #: ``on_deferred(occurrence, task_id, goal_type, error)``——如实记下来，不再静默吞掉。
    on_deferred: Any = None

    @property
    def semantics(self) -> HtnStore:
        return HtnStore(self.store)

    def resolve_ready(self, mission_id: str) -> tuple[GoalResolutionReceipt, ...]:
        """Resolve every non-root compound that is waiting on composition review.

        Idempotent: an occurrence that already has an adopted GoalResolution is
        skipped.  A refusal is noted by raising into the caller; this method
        swallows ``ResolutionCommitRejected`` so one stuck compound does not
        block its siblings.
        """

        view = self.dispatch.read(mission_id)
        formed: list[GoalResolutionReceipt] = []
        for spec in view.network.occurrences:
            if spec.form is not TaskForm.COMPOUND:
                continue
            if spec.occurrence_id in view.network.root_occurrence_ids:
                continue
            if spec.occurrence_id in view.resolved:
                continue
            children = {
                binding.occurrence_id: view.outcomes[binding.occurrence_id]
                for binding in view.network.adopted_children(spec.occurrence_id)
                if binding.occurrence_id in view.outcomes
            }
            phase = next_compound_phase(
                spec,
                view.network,
                view.reports[spec.occurrence_id],
                child_outcomes=children,
                resolved=False,
            )
            if phase is not CompoundPhase.COMPOSITION_REVIEW:
                continue
            try:
                receipt = self.resolve_one(mission_id, spec.occurrence_id)
            except (ContractError, ResolutionCommitRejected, StoreError) as error:
                # One stuck compound does not block its siblings — but it is said, not hidden.
                if self.on_deferred is not None:
                    binding = view.network.binding_for_occurrence(spec.occurrence_id)
                    self.on_deferred(str(spec.occurrence_id), str(spec.task_id),
                                     str(binding.goal_signature.signature_id), error)
                continue
            if receipt is not None:
                formed.append(receipt)
        if formed:
            self.dispatch.advance_compound_phases(mission_id)
        return tuple(formed)

    def resolve_one(
        self, mission_id: str, occurrence_id: OccurrenceId
    ) -> GoalResolutionReceipt | None:
        """Build the COMPOSITION anchors and commit, or return None if not ready."""

        view = self.dispatch.read(mission_id)
        spec = view.network.occurrence(occurrence_id)
        adopted = view.network.adopted_instance_for(occurrence_id)
        if adopted is None:
            return None
        instance_id = str(adopted.instance_id)
        gating = [
            binding
            for binding in view.network.adopted_children(occurrence_id)
            if binding.requiredness in GATING_REQUIREDNESS
        ]
        accepted = self._accepted_children(
            mission_id, view.network.adopted_children(occurrence_id)
        )
        if any(str(binding.occurrence_id) not in accepted for binding in gating):
            return None
        binding = view.network.binding_for_occurrence(occurrence_id)
        now_ms = int(self.store.now * 1000)
        producers = self._producers(mission_id, accepted)
        # The goal's criteria and success expression are its frozen completion scope's.
        from .scoped_composition_review import read_compound_projection

        projection = read_compound_projection(
            self.store, mission_id, str(occurrence_id), str(spec.task_id)
        )
        revision = projection.requirements
        manifest = self._manifest_hash(mission_id, str(spec.task_id))
        from ..storage.assurance_store import AssuranceStore

        assured = AssuranceStore(self.store).lane(mission_id) == "ASSURANCE_1_1"
        package = self._package(
            mission_id,
            spec,
            binding,
            revision,
            accepted,
            producers,
            manifest_hash=manifest,
            method_instance_id=instance_id,
            criteria=projection.criteria,
            expression=projection.expression,
            persist=not assured,
        )
        if assured:
            # BW03: an assured Mission's composition is judged by an independent
            # review on the round transport. The self-composed record and the
            # legacy witness below never license it; consuming the official
            # COMPOSITION record in commit_goal_resolution is the terminal-writer
            # work and is not licensed from here.
            from ..assurance.codec import AssuranceError
            from .assurance_purpose_reviews import assurance_review_runtime

            mission = self.store.get_mission(mission_id)
            try:
                assurance_review_runtime(self.commit).ensure_composition(
                    mission, package=package, occurrence_id=str(occurrence_id), accepted=accepted
                )
            except AssuranceError as error:
                raise ContractError(f"Assurance COMPOSITION review unavailable: {error}") from error
            # 2026-10-01（第 3 项）：消费正式记录。此前这里直接返回，记录进来后没人读它，
            # 中间目标永远收不了尾（真机库里从没跑过三层计划，所以没暴露）。
            from .review_adjudication import adjudication_of

            record = self.semantics.official_review_record(str(package.package_id))
            if record is None:
                return None
            ruling = (adjudication_of(self.store, str(record.record_id))
                      if record.verdict is ReviewVerdict.INCONCLUSIVE else None)
            action = assured_composition_action(record, ruling)
            if action == "ask":
                if self.ask_person is not None:
                    self.ask_person(record, str(spec.task_id), str(occurrence_id))
                return None
            if action == "repair":
                if self.on_rejected is not None:
                    self.on_rejected(record, package, str(spec.task_id), str(occurrence_id))
                return None
            return self._commit_assured_composition(
                mission_id, spec, binding, revision, package, record, accepted, producers,
                instance_id=instance_id, manifest=manifest, now_ms=now_ms,
            )
        record = self._record(mission_id, package, occurrence_id, accepted, gating)
        if record.verdict is not ReviewVerdict.ACCEPT:
            return None
        witness = self._witness(mission_id, str(spec.task_id), now_ms=now_ms)
        resolution = GoalResolution(
            resolution_id=GoalResolutionId(
                f"res-{occurrence_id}-{content_hash_of(str(package.package_id))[:16]}"
            ),
            mission_id=mission_id,
            obligation_id=str(spec.obligation_id),
            goal_task_id=str(spec.task_id),
            requirements_version=int(revision.revision),
            contract_revision=int(binding.contract_revision),
            method_instance_id=instance_id,
            input_manifest_hash=manifest,
            artifact_refs=(),
            child_resolution_ids=tuple(ref.id for ref in package.candidate_refs
                if ref.kind is TypedRefKind.RESOLUTION),
            criteria=tuple(
                ResolutionCriterion(criterion_id=item.criterion_id, verdict=item.verdict)
                for item in record.criteria
            ),
            review_receipt_id=str(record.record_id),
            verdict=ReviewVerdict.ACCEPT,
            validity=Validity.CURRENT,
        )
        command = CommitGoalResolutionCommand(
            command_id=f"compose:{occurrence_id}:{int(view.network.plan_revision)}",
            mission_id=mission_id,
            resolution=resolution,
            package=package,
            record=record,
            requirements=revision,
            witness_id=witness.witness_id,
            independence=IndependenceFacts(
                producer_agent_ids=producers,
                reviewer_can_write_candidate=False,
            ),
            posture=ExecutionPosture(),
            read_set=self._read_set(mission_id, binding, revision),
            decided_at_ms=now_ms,
            purpose=ReviewPurpose.COMPOSITION,
            compound=CompoundFacts(
                selected_method_legal=True,
                contributing_occurrence_ids=tuple(sorted(accepted)),
                composition_obligation_passed=record.verdict is ReviewVerdict.ACCEPT,
            ),
            is_mission_root=False,
            semantic_review_required=True,
            issued_by=self.issued_by,
            scope_id=self.scope_id,
            source={"occurrence_id": str(occurrence_id), "policy": COMPOSITION_REVIEW_POLICY},
        )
        principal = ResolutionPrincipal(
            principal_id=self.issued_by,
            scope_id=self.scope_id,
            manager_epoch=self.semantics.epoch(mission_id, self.scope_id),
        )
        return self.commit.commit_goal_resolution(command, principal)

    def _commit_assured_composition(
        self, mission_id, spec, binding, revision, package, record, accepted, producers, *,
        instance_id, manifest, now_ms,
    ):  # type: ignore[no-untyped-def]
        """Form the compound's GoalResolution from its official COMPOSITION record.

        The licence is the record's current use certificate (prepared here outside
        the write lock, committed by ``commit_goal_resolution`` under it); every
        criterion verdict is restated from the certificate's current effective grades,
        never asserted here (review F4, as for the root).
        """
        validity = getattr(self.commit, "_assurance_validity", None)
        if validity is None:
            raise ContractError("USE_CERTIFICATE_REQUIRED")
        resolution_id = f"res-{spec.occurrence_id}-{content_hash_of(str(package.package_id))[:16]}"
        candidate = validity.prepare_composition_use(record, resolution_id=resolution_id)
        grades = candidate.effective_grades
        resolution = GoalResolution(
            resolution_id=GoalResolutionId(resolution_id),
            mission_id=mission_id,
            obligation_id=str(spec.obligation_id),
            goal_task_id=str(spec.task_id),
            requirements_version=int(revision.revision),
            contract_revision=int(binding.contract_revision),
            method_instance_id=instance_id,
            input_manifest_hash=manifest,
            artifact_refs=(),
            child_resolution_ids=tuple(ref.id for ref in package.candidate_refs
                if ref.kind is TypedRefKind.RESOLUTION),
            criteria=tuple(
                ResolutionCriterion(
                    criterion_id=item.criterion_id,
                    verdict=CriterionVerdict(grades.get(str(item.criterion_id), "UNKNOWN")),
                )
                for item in package.criteria
            ),
            review_receipt_id=str(record.record_id),
            verdict=ReviewVerdict.ACCEPT,
            validity=Validity.CURRENT,
        )
        command = CommitGoalResolutionCommand(
            command_id=f"compose:{spec.occurrence_id}:{str(package.package_id)}",
            mission_id=mission_id,
            resolution=resolution,
            package=package,
            record=record,
            requirements=revision,
            witness_id=candidate.certificate_id,
            independence=IndependenceFacts(
                producer_agent_ids=producers,
                reviewer_can_write_candidate=False,
            ),
            posture=ExecutionPosture(),
            read_set=self._read_set(mission_id, binding, revision),
            decided_at_ms=now_ms,
            purpose=ReviewPurpose.COMPOSITION,
            compound=CompoundFacts(
                selected_method_legal=True,
                contributing_occurrence_ids=tuple(sorted(accepted)),
                composition_obligation_passed=True,  # the official record, or the person, said so
            ),
            is_mission_root=False,
            semantic_review_required=True,
            issued_by=self.issued_by,
            scope_id=self.scope_id,
            source={"occurrence_id": str(spec.occurrence_id), "policy": COMPOSITION_REVIEW_POLICY},
        )
        principal = ResolutionPrincipal(
            principal_id=self.issued_by,
            scope_id=self.scope_id,
            manager_epoch=self.semantics.epoch(mission_id, self.scope_id),
        )
        return self.commit.commit_goal_resolution(command, principal)

    def _accepted_children(
        self, mission_id: str, gating: Sequence[Any]
    ) -> dict[str, tuple[str, ...]]:
        from .completion_support import current_child_supports

        return current_child_supports(self.store, mission_id, gating)

    def _producers(
        self, mission_id: str, accepted: Mapping[str, tuple[str, ...]]
    ) -> tuple[str, ...]:
        from .completion_support import read_completion_support

        agents: list[str] = []
        for ids in accepted.values():
            for source_id in ids:
                support = read_completion_support(self.store, mission_id, source_id)
                agents.extend(support.package.producer_agent_ids)
        return tuple(dict.fromkeys(item for item in agents if item))

    def _manifest_hash(self, mission_id: str, task_id: str) -> str:
        document: dict[str, Any] = {"consumer_task_ref": str(task_id), "bindings": []}
        return self.semantics.insert_input_manifest(mission_id, str(task_id), document)

    def _package(
        self,
        mission_id: str,
        spec: Any,
        binding: Any,
        revision: RequirementsRevision,
        accepted: Mapping[str, tuple[str, ...]],
        producers: Sequence[str],
        *,
        manifest_hash: str,
        method_instance_id: str,
        criteria: tuple[Criterion, ...],
        expression: Any,
        persist: bool = True,
    ) -> ReviewPackage:
        # ``accepted`` 装的是子步骤的支撑（验收或复用的目标结论），引用由支撑读取给出。
        from .completion_support import read_completion_support

        supports = tuple(read_completion_support(self.store, mission_id, source_id)
            for source_ids in accepted.values() for source_id in source_ids)
        child_refs = tuple(item.ref for item in supports if item.ref.kind is TypedRefKind.ACCEPTANCE)
        resolution_refs = tuple(item.ref for item in supports if item.ref.kind is TypedRefKind.RESOLUTION)
        identity: dict[str, Any] = {
            "occ": str(spec.occurrence_id), "rev": revision.revision,
            "method_instance_id": method_instance_id, "manifest_hash": manifest_hash,
            "supports": [ref.to_json() for ref in (*child_refs, *resolution_refs)],
        }
        digest = content_hash_of(identity)[:32]
        package = ReviewPackage(
            package_id=ReviewPackageId(f"pkg-compose-{digest}"),
            purpose=ReviewPurpose.COMPOSITION,
            binding=ReviewBinding(
                mission_id=mission_id,
                obligation_id=str(spec.obligation_id),
                subject_ref=TypedRef(
                    kind=TypedRefKind.TASK,
                    id=str(spec.task_id),
                    revision=int(binding.contract_revision),
                    content_hash=binding.contract_hash,
                ),
                requirements_revision=int(revision.revision),
                input_manifest_hash=manifest_hash,
                policy_ref=TypedRef(
                    kind=TypedRefKind.SOURCE,
                    id=COMPOSITION_REVIEW_POLICY,
                    revision=1,
                    content_hash=content_hash_of(COMPOSITION_REVIEW_POLICY),
                ),
            ),
            criteria=criteria,
            success_expression=expression,
            child_acceptance_refs=child_refs,
            candidate_refs=resolution_refs,
            producer_agent_ids=tuple(producers),
            reviewer_workspace_access=REVIEWER_ACCESS,
            requirements_content_hash=revision.content_hash(),
            method_instance_id=MethodInstanceId(method_instance_id),
        )
        if not persist:
            return package
        try:
            stored = self.semantics.get_review_package(str(package.package_id))
        except StoreError:
            self.semantics.insert_review_package(package)
            return package
        if stored.content_hash() != package.content_hash():
            self.semantics.insert_review_package(package)
        return package

    def _record(
        self,
        mission_id: str,
        package: ReviewPackage,
        occurrence_id: OccurrenceId,
        accepted: Mapping[str, tuple[str, ...]],
        gating: Sequence[Any],
    ) -> ReviewRecord:
        outcomes = self._outcomes(mission_id, package, occurrence_id, accepted)
        passed = all(item.verdict is CriterionVerdict.PASS for item in outcomes) and all(
            str(binding.occurrence_id) in accepted for binding in gating
        )
        record = ReviewRecord(
            record_id=ReviewRecordId(f"rec-{content_hash_of(str(package.package_id))[:32]}"),
            package_id=package.package_id,
            purpose=package.purpose,
            binding=package.binding,
            reviewer_agent_id=COMPOSITION_REVIEWER,
            reviewer_turn_id=f"compose-{occurrence_id}",
            evidence_manifest_hash=content_hash_of(
                {key: list(refs) for key, refs in accepted.items()}
            ),
            criteria=outcomes,
            verdict=ReviewVerdict.ACCEPT if passed else ReviewVerdict.REJECTED,
        )
        official = self.semantics.official_review_record(str(package.package_id))
        if official is None or official.to_json() != record.to_json():
            self.semantics.insert_review_record(record, official=True)
        return record

    def _outcomes(
        self,
        mission_id: str,
        package: ReviewPackage,
        occurrence_id: OccurrenceId,
        accepted: Mapping[str, tuple[str, ...]],
    ) -> tuple[CriterionOutcome, ...]:
        semantics = self.semantics
        active = semantics.active_plan_revision(mission_id)
        links = (
            ()
            if active is None
            else tuple(
                item
                for item in carried_criteria_in_revision(
                    semantics, mission_id, int(active.revision)
                )
                if str(item.parent_task_id)
                == str(package.binding.subject_ref.id)
            )
        )
        by_parent: dict[str, list[Any]] = {}
        for link in links:
            by_parent.setdefault(str(link.parent_criterion_id), []).append(link)
        outcomes: list[CriterionOutcome] = []
        for criterion in package.criteria:
            name = str(criterion.criterion_id)
            # AER I05/I07: ``c-composition`` is a synthetic local name used when
            # the compound's goal signature published no coverage_criteria.  Child
            # acceptances are not a mapping and must not become PASS.
            linked = by_parent.get(name, ())
            verdict = CriterionVerdict.UNKNOWN
            for link in linked:
                child_key = str(link.occurrence_id)
                if child_key not in accepted:
                    continue
                if self._child_covers(mission_id, accepted[child_key], link.leaf_criterion_id):
                    verdict = CriterionVerdict.PASS
                    break
            limitations = (
                (COMPOSITION_UNCOVERED,)
                if verdict is CriterionVerdict.UNKNOWN
                else ()
            )
            outcomes.append(
                CriterionOutcome(
                    criterion_id=name,
                    verdict=verdict,
                    check_execution=(
                        CheckExecution.SUCCEEDED
                        if verdict is CriterionVerdict.PASS
                        else CheckExecution.NOT_RUN
                    ),
                    limitations=limitations,
                )
            )
        del occurrence_id
        return tuple(outcomes)

    def _child_covers(
        self, mission_id: str, acceptance_ids: Sequence[str], leaf_criterion_id: str
    ) -> bool:
        from .completion_support import read_completion_support

        for source_id in acceptance_ids:
            support = read_completion_support(self.store, mission_id, source_id)
            if any(item.criterion_id == leaf_criterion_id and item.verdict is CriterionVerdict.PASS
                   for item in support.record.criteria):
                return True
        return False

    def _witness(self, mission_id: str, task_id: str, *, now_ms: int) -> ValidityWitness:
        semantics = self.semantics
        epoch = int(semantics.epoch(mission_id, self.scope_id))
        support_revision = len(semantics.list_acceptances(mission_id))
        witness = ValidityWitness(
            witness_id="wit-"
            + content_hash_of(
                {
                    "consumer": str(task_id),
                    "purpose": str(WitnessPurpose.ACCEPT),
                    "scope": self.scope_id,
                    "epoch": epoch,
                    "support_revision": int(support_revision),
                    "subject": NO_SUBJECT,
                    "lane": "composition",
                }
            )[:32],
            consumer_ref=TypedRef(
                kind=TypedRefKind.TASK,
                id=str(task_id),
                revision=1,
                content_hash=content_hash_of(str(task_id)),
            ),
            purpose=WitnessPurpose.ACCEPT,
            truth=TruthValue.TRUE,
            freshness=Validity.CURRENT,
            availability=Availability.READABLE,
            decision=WitnessDecision.USABLE,
            scope_id=self.scope_id,
            scope_epoch=epoch,
            support_revision=int(support_revision),
            as_of_ms=int(now_ms),
        )
        subject = witness_subject(witness)
        try:
            return semantics.get_validity_witness(witness.witness_id)
        except StoreError:
            semantics.insert_validity_witness(mission_id, witness, subject=subject)
            return witness

    def _read_set(
        self, mission_id: str, binding: Any, revision: RequirementsRevision
    ) -> SemanticReadSet:
        epoch = self.semantics.epoch(mission_id, self.scope_id)
        return SemanticReadSet(
            requirements_revision=int(revision.revision),
            manager_epoch=epoch,
            scope_epochs=(ScopeEpochRead(scope_id=self.scope_id, validity_epoch=epoch),),
            goal_revisions=(
                ReadItem(
                    kind=ReadItemKind.TASK,
                    id=str(binding.task_id),
                    semantic_revision=int(binding.contract_revision),
                    content_hash=binding.contract_hash,
                ),
            ),
        )
