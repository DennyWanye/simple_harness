"""Read-only delivery check. It does not approve any SDK or deployment gate."""
from pathlib import Path
import hashlib
import json
import sys


def main() -> int:
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'DELIVERY-MANIFEST.json').read_text(encoding='utf-8'))
    errors = []
    expected = set()
    for entry in manifest['files']:
        relative = entry['path']
        file = root / relative
        expected.add(relative)
        try:
            if not file.resolve(strict=True).is_relative_to(root) or not file.is_file():
                errors.append(f'not a contained regular file: {relative}')
                continue
            raw = file.read_bytes()
            if len(raw) != entry['size'] or hashlib.sha256(raw).hexdigest() != entry['sha256']:
                errors.append(f'size/hash mismatch: {relative}')
        except OSError:
            errors.append(f'missing: {relative}')
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'DELIVERY-MANIFEST.json'}
    errors.extend(f'unmanifested file: {path}' for path in sorted(actual - expected))
    print(json.dumps({'scope':'DELIVERY_FILE_INTEGRITY_ONLY','status':'FAIL' if errors else 'PASS',
                      'files_checked':len(expected),'errors':errors},ensure_ascii=False,indent=2))
    return 2 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
