# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0
"""Per-handoff token admission against the original Task/Mission reservation.

The Commit adapter uses the orchestration transaction as the cancellation fence.
Only synchronous SDK handoff is inside that fence (Orch -> SDK lock order).
Transport and slot waiting are outside both databases. An uncertain request keeps
both its allowance and slot until actual SDK reconciliation, never a TTL guess.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import dataclass, replace
from hashlib import sha256
from types import MappingProxyType
from typing import Any

from simple_harness.contracts import canonical_json
from simple_harness.execution.provider_admission import (
    ProviderAdmissionDenied,
    ProviderAdmissionFailure,
    ProviderAdmissionTicket,
    TokenEstimatorPort,
)
from simple_harness.execution.provider_invocations import provider_request_fingerprint

from ..contracts import TERMINAL_ATTEMPT, TERMINAL_MISSION, TERMINAL_TASK, TaskStatus
from ..governance.budgets import BudgetExhausted
from ..orchestrator.assurance_review_import import carried_review_alive
from ..storage.operation_completion_store import OperationCompletionStore
from ..storage.operation_intent_store import OperationIntentStore
from ..storage.store import StoreError
from .first_request_budget import (
    INPUT_CAP_PROTOCOL,
    FirstRequestBudgetUnknown,
    FirstRequestInputCapExceeded,
    ProviderInputCap,
    enforce_final_wire_input_cap,
    frozen_provider_input_cap,
)

HELD = ("RESERVED", "HANDED_OFF", "UNKNOWN")

# Additive, versioned auxiliary table in the shared orchestration store: the grants whose
# SDK call has terminated on the wire (succeeded/failed) while their usage stays
# unresolved.  They keep their allowance (state UNKNOWN, awaiting late accounting) but no
# longer occupy a physical slot — and every pool reads this from the shared store, never
# from its own SDK library (rule 2026-09-24: may overcount, never freeze).
WIRE_TERMINAL_TABLE = "provider_grant_wire_terminal_v1"
_HELD_GRANTS_SQL = (
    "SELECT g.invocation_id, g.state, i.config_json FROM provider_token_grants g "
    "LEFT JOIN dispatch_intents i ON i.intent_id=g.intent_id "
    "WHERE g.state IN ('RESERVED','HANDED_OFF','UNKNOWN') AND NOT ("
    "g.state='UNKNOWN' AND EXISTS(SELECT 1 FROM " + WIRE_TERMINAL_TABLE + " w"
    " WHERE w.invocation_id=g.invocation_id AND w.handoff_ordinal=g.handoff_ordinal))"
)


@dataclass(frozen=True, slots=True)
class HandoffOutcomeCheck:
    """One hand-off's own call key, re-read before anything is asked again (第 2 批 A27，
    Assurance 原计划 §6.2：原 Provider UNKNOWN 由 runtime 核对，不能靠 ordinal2 重复请求).

    ``verdict``:

    * ``no_handoff`` — the intent never handed a request off through this guard (or the
      SDK never claimed it): nothing is on the wire, nothing to replace;
    * ``result_known`` — the same invocation is now ``succeeded`` / ``failed`` (or reconciled
      ``completed``): the ordinary collector imports it, nobody asks again;
    * ``confirmed_not_started`` — the SDK's reconciliation says the request never went out;
    * ``refused_on_wire`` — the call ended ``unknown`` but the provider answered with an
      HTTP status (``http_status`` on the record): the request was received and refused,
      no answer was produced (2026-09-28 用户决定：服务端报错原地重试)；
    * ``unresolved`` — ``unknown`` with no server verdict, still ``handed_off``, or the
      runtime cannot be read: the outcome is genuinely unknown.
    """

    verdict: str
    invocation_id: str | None = None
    handoff_ordinal: int | None = None
    record_state: str | None = None
    error_code: str | None = None
    http_status: int | None = None

    def to_json(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "invocation_id": self.invocation_id,
            "handoff_ordinal": self.handoff_ordinal,
            "record_state": self.record_state,
            "error_code": self.error_code,
            "http_status": self.http_status,
        }


#: what a resend's record says it stands on, per verdict
RESEND_GROUNDS = MappingProxyType(
    {
        "no_handoff": "nothing_sent",
        "result_known": "result_known_import_pending",
        "confirmed_not_started": "confirmed_not_started",
        "refused_on_wire": "provider_refused_on_wire",
        "unresolved": "outcome_unconfirmed",
    }
)


def check_unknown_handoff(store, uow, *, intent_id: str) -> HandoffOutcomeCheck:
    """Re-read the SDK record of ``intent_id``'s latest hand-off (same invocation, same
    handoff ordinal) and its reconciliation resolution.  Reads only; the grant itself is
    settled by ``observe`` / ``recover`` as before."""

    row = store.connection.execute(
        "SELECT invocation_id, handoff_ordinal FROM provider_token_grants WHERE intent_id=?"
        " ORDER BY handoff_ordinal DESC, created_at DESC LIMIT 1",
        (intent_id,),
    ).fetchone()
    if row is None:
        return HandoffOutcomeCheck("no_handoff")
    invocation_id, ordinal = str(row[0]), int(row[1])
    if uow is None:
        return HandoffOutcomeCheck("unresolved", invocation_id, ordinal)
    record = uow.read_effective_provider_invocation(invocation_id)
    if record is None:
        return HandoffOutcomeCheck("unresolved", invocation_id, ordinal)
    state = str(record.state)
    usage = record.usage_json if isinstance(record.usage_json, Mapping) else {}
    status = usage.get("http_status")
    http_status = status if isinstance(status, int) and not isinstance(status, bool) else None
    found = HandoffOutcomeCheck(
        "unresolved", invocation_id, ordinal, state, record.error_code, http_status
    )
    if state in {"succeeded", "failed"}:
        return replace(found, verdict="result_known")
    if state == "claimed":  # never handed off: nothing reached the wire
        return replace(found, verdict="no_handoff")
    if state != "unknown":  # handed_off: the call is still on the wire
        return found
    resolution = uow.read_reconciliation_resolution(
        kind="provider",
        ledger_identity=record.invocation_id,
        handoff_attempt=int(record.handoff_attempt),
    )
    if resolution is not None:
        outcome = str(resolution.outcome)
        if outcome == "confirmed_not_started":
            return replace(found, verdict="confirmed_not_started")
        if outcome == "completed":
            return replace(found, verdict="result_known")
    if http_status is not None:
        return replace(found, verdict="refused_on_wire")
    return found


def resend_record(check: HandoffOutcomeCheck, *, ordinal: int | None) -> dict[str, Any]:
    """What the next ask replaces: the round ordinal that is being left behind, the call
    key it handed off, and the ground the check gives.  Written into the round's rejection
    (``PlanningRejected``) or the review's abandonment record, so a later reader can tell
    which earlier call a resend stood in for."""

    return {
        "replaces_ordinal": ordinal,
        "replaces_invocation_id": check.invocation_id,
        "replaces_handoff_ordinal": check.handoff_ordinal,
        "ground": RESEND_GROUNDS[check.verdict],
    }


def _deny(
    reason: str, *, reason_code: str = "authority_rejected", **detail
) -> ProviderAdmissionDenied:
    return ProviderAdmissionDenied(
        public_message=reason,
        admission_detail=ProviderAdmissionFailure(reason_code=reason_code, **detail),
    )


#: 2026-10-02 真机（强杀后端再重启）：新进程接着跑被打断的那一轮，但这次尝试的执行权——
#: 租约、执行图的当前派发、运行时租约——还记在已经不在了的那个进程名下。准入照样拒绝，
#: 但这不是"授权不对"：是这一轮被打断了，主循环应当原地重做（新的一次尝试会在当前
#: 进程名下重新取得执行权），而不是判这一步失败。所以单独一个原因码。
LEASE_LOST = "lease_lost"


def _tokens(value: object, name: str, *, positive: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < int(positive):
        raise _deny(f"invalid {name} for provider admission")
    return value


def _positive(value: object) -> int | None:
    return value if type(value) is int and value > 0 else None


def valid_usage(record) -> tuple[int, int] | None:
    """The call's reported usage as ``(input, output)`` — only when it is a usable report.

    Rule (user decision 2026-09-24): the accounts may overcount, never undercount.  A missing
    report, or one that says zero (some relays answer 0/0/0 on every call), is not evidence
    of a zero charge: it is *unresolved*, so the grant stays UNKNOWN with its reservation held
    until late accounting resolves it.  Non-integer values remain a protocol violation.
    """

    usage = record.usage_json
    if not isinstance(usage, Mapping) or not isinstance(usage.get("usage"), Mapping):
        return None
    values = usage["usage"]
    actual = (
        _tokens(values.get("input_tokens"), "actual input"),
        _tokens(values.get("output_tokens"), "actual output"),
    )
    return None if 0 in actual else actual


def request_output_cap(record) -> int | None:
    """The proven upper bound of a call's output: its request's own ``max_output_tokens``."""

    request = getattr(record, "request_json", None)
    return _positive(request.get("max_output_tokens")) if isinstance(request, Mapping) else None


_usage = valid_usage


def ensure_wire_terminal_table(store) -> None:
    store.connection.execute(
        f"CREATE TABLE IF NOT EXISTS {WIRE_TERMINAL_TABLE} ("
        " invocation_id TEXT NOT NULL,"
        " handoff_ordinal INTEGER NOT NULL CHECK(handoff_ordinal > 0),"
        " marked_at REAL NOT NULL,"
        " PRIMARY KEY(invocation_id, handoff_ordinal))"
    )


def held_guarded_grants(store) -> int:
    """Guarded grants occupying a physical slot, as every pool sharing the store counts them."""
    ensure_wire_terminal_table(store)
    return int(
        store.connection.execute("SELECT COUNT(*) FROM (" + _HELD_GRANTS_SQL + ")").fetchone()[0]
    )


class ProviderBudgetCommitAdapter:
    """Narrow accounting writer; shares CommitService's Store and BudgetLedger."""

    def __init__(self, commit, *, owner: str, fingerprint: str) -> None:
        self.commit = commit
        self.store = commit.store
        self.owner = owner
        self.fingerprint = fingerprint

    def authority(self, *, agent_id: str, turn_id: str):
        rows = self.store.connection.execute(
            "SELECT intent_id FROM dispatch_intents WHERE agent_id=? AND expected_turn_id=?",
            (agent_id, turn_id),
        ).fetchall()
        if len(rows) != 1:
            raise _deny("provider request has no unique durable dispatch intent")
        intent = self.store.get_intent(rows[0][0])
        mission = self.store.get_mission(intent.mission_id)
        if mission is None or mission.status in TERMINAL_MISSION:
            raise _deny("provider subject Mission is terminal")
        if intent.state not in {"AGENT_CREATED", "SUBMITTED"}:
            raise _deny("provider dispatch intent is stopped")
        if intent.config.get("provider_admission_fingerprint") != self.fingerprint:
            raise _deny("provider admission differs from frozen intent")
        task_id = intent.config.get("task_id")
        lease = intent
        if intent.kind == "attempt":
            attempt = self.store.get_attempt(intent.subject_id)
            if attempt is None or attempt.status in TERMINAL_ATTEMPT:
                raise _deny("provider Attempt is terminal")
            task_id = attempt.task_id
            lease = attempt
        elif intent.config.get("attempt_id"):
            parent_attempt = self.store.get_attempt(str(intent.config["attempt_id"]))
            if parent_attempt is not None:
                # TaskGraph 补全第四批：重审已验收的结果——原尝试与任务早已结束是常态，
                # 它活着 = 这一步还在现行计划里（与审阅交接处同一个判断）
                carried = intent.config.get("carried_requirements_revision") is not None
                if carried:
                    if not carried_review_alive(self.store, mission.id, parent_attempt.task_id):
                        raise _deny("the step under re-review left the current plan")
                elif parent_attempt.status in TERMINAL_ATTEMPT:
                    raise _deny("provider parent Attempt is terminal")
                task_id = None if carried else parent_attempt.task_id
        if task_id:
            task = self.store.get_task(str(task_id))
            if (
                task is None
                or task.mission_id != mission.id
                or (
                    task.status in TERMINAL_TASK
                    and not self._accepted_operation_review(intent, task)
                )
            ):
                raise _deny("provider Task is terminal or differs from Mission")

        try:
            self.commit.require_taskgraph_handoff(intent)
        except StoreError as error:
            raise _deny("TaskGraph attempt authority changed", reason_code=LEASE_LOST) from error
        # Service intent leases govern pre-submit claiming, not an ongoing SDK
        # turn. SUBMITTED service authority additionally uses the SDK Run lease
        # CAS inside handoff. Attempts have an independently renewed live lease.
        require_live_lease = intent.kind == "attempt" or intent.state != "SUBMITTED"
        if require_live_lease and (
            lease.lease_owner != self.owner
            or (lease.lease_expires_at is None or lease.lease_expires_at <= self.store.now)
        ):
            raise _deny(
                "provider subject lease is expired or owned by another executor",
                reason_code=LEASE_LOST,
            )
        reservation = self.commit.ledger.reservation(intent.subject_id)
        if reservation is None or reservation["state"] != "RESERVED":
            raise _deny("provider subject has no live budget reservation")
        return intent, reservation

    def _accepted_operation_review(self, intent, task) -> bool:

        if intent.kind != "plan" or task.status is not TaskStatus.COMPLETED:
            return False
        role = intent.config.get("role")
        if role not in {"operation_proposal_reviewer", "operation_outcome_reviewer"}:
            return False
        source = OperationIntentStore(self.store).get(
            str(intent.config.get("operation_intent_id", ""))
        )
        if (
            source is None
            or source["mission_id"] != intent.mission_id
            or source["producer_task_id"] != task.id
            or source["source_result_id"] != task.accepted_result_id
        ):
            return False
        if role == "operation_proposal_reviewer":
            return intent.config.get("review_package_id") == source["review_package_id"]
        outcome = OperationCompletionStore(self.store).get_outcome_binding_exact(
            intent.mission_id, str(intent.config.get("outcome_binding_id", ""))
        )
        return (
            outcome is not None
            and outcome["document"].intent_id == source["intent_id"]
            and outcome["review_package_id"] == intent.config.get("review_package_id")
        )

    def grow(self, reservation, *, required: int) -> None:
        if required <= reservation["reserved_tokens"]:
            return
        self.commit.ledger.grow(subject_id=reservation["subject_id"], tokens=required)


class ProviderBudgetGuard:
    input_cap_protocol = INPUT_CAP_PROTOCOL

    def __init__(
        self,
        commit,
        *,
        owner: str,
        estimator: TokenEstimatorPort,
        max_slots: int,
        poll_seconds: float = 0.01,
        profile_slots: Mapping[str, int] | None = None,
    ) -> None:
        if not owner or not callable(getattr(estimator, "estimate_input_tokens", None)):
            raise ValueError("provider admission requires owner and an explicit estimator")
        for name in ("fingerprint", "bound_protocol"):
            if not isinstance(getattr(estimator, name, None), str) or not getattr(estimator, name):
                raise ValueError(f"provider estimator requires {name}")
        if type(getattr(estimator, "requires_prior_output_reserve", None)) is not bool:
            raise ValueError("estimator must declare its prior-output protocol")
        self.max_slots = _tokens(max_slots, "physical slots", positive=True)
        self.profile_slots = (
            None if profile_slots is None else MappingProxyType(dict(profile_slots))
        )
        if self.profile_slots is not None and (
            not self.profile_slots
            or any(
                not isinstance(key, str) or not key or type(value) is not int or value < 1
                for key, value in self.profile_slots.items()
            )
        ):
            raise ValueError("profile physical slots require named positive integer limits")
        if not 0 < poll_seconds <= 1:
            raise ValueError("provider admission polling must be in (0,1]")
        self.estimator = estimator
        # NEXT-TG-1.0 §9 多任务并发 (2026-09-29): the physical slot count is capacity, not
        # how one frozen request is accounted, so it stays out of the identity and raising
        # the slots keeps every frozen intent's identity.  v4 (2026-10-03) accounts tokens
        # only: no price contract is part of it.
        self.fingerprint = self._identity()
        self.adapter = ProviderBudgetCommitAdapter(
            commit, owner=owner, fingerprint=self.fingerprint
        )
        self.store = commit.store
        self.poll_seconds = poll_seconds
        self._waiting: dict[str, tuple[str, str]] = {}
        self._clock = time.time

    async def acquire(
        self, *, request, record, cancel, uow, execution_lease
    ) -> ProviderAdmissionTicket:
        try:
            return await self._acquire(
                request=request,
                record=record,
                cancel=cancel,
                uow=uow,
                execution_lease=execution_lease,
            )
        except ProviderAdmissionDenied as exc:
            exc.admission_detail = replace(
                exc.admission_detail,
                invocation_id=record.invocation_id,
                handoff_ordinal=record.handoff_attempt + 1,
                bound_protocol=self.estimator.bound_protocol,
            )
            exc.detail = exc.admission_detail.to_json()
            raise
        finally:
            self._waiting.pop(record.invocation_id, None)

    def _identity(self) -> str:
        body: dict[str, Any] = {
            "estimator": self.estimator.fingerprint,
            "protocol": self.estimator.bound_protocol,
            "prior_output": self.estimator.requires_prior_output_reserve,
            "version": 4,
        }
        return "provider-budget-admission-v4:" + sha256(canonical_json(body).encode()).hexdigest()

    def accepts(self, fingerprint: object) -> bool:
        """A frozen request's admission identity is this accounting (any slot count)."""
        return fingerprint == self.fingerprint

    def waiting_for_slot(self, *, agent_id: str, turn_id: str) -> bool:
        """Actual local waiters only; not a synthetic SDK progress increment."""
        return (agent_id, turn_id) in self._waiting.values()

    async def _acquire(
        self, *, request, record, cancel, uow, execution_lease
    ) -> ProviderAdmissionTicket:
        # Resolve identities from SDK records, never provider-message metadata.
        binding = uow.read_agent_binding_for_run(record.run_id.value)
        turn = uow.read_open_agent_turn(record.run_id.value)
        if binding is None or turn is None or binding.agent_id != turn.agent_id:
            raise _deny("provider admission requires a live SDK Agent turn")
        profile = binding.config_json.get("model_profile_ref")
        if self.profile_slots is not None and profile not in self.profile_slots:
            raise _deny("provider profile has no declared physical slot limit")
        limits = binding.config_json.get("limits", {})
        seconds = limits.get("turn_deadline_seconds")
        if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or seconds <= 0:
            raise _deny("provider admission requires a finite SDK turn deadline")
        deadline = turn.created_at + seconds
        self.recover(uow)
        try:
            public_input = _tokens(self.estimator.estimate_input_tokens(request), "input allowance")
        except ProviderAdmissionDenied:
            raise
        except Exception as exc:
            raise _deny(
                "provider input estimator unavailable for this request",
                reason_code="estimator_unavailable",
            ) from exc
        output = _tokens(request.max_output_tokens, "maximum output", positive=True)
        wire_hash = provider_request_fingerprint(request)
        ticket = ProviderAdmissionTicket(
            record.invocation_id, record.handoff_attempt + 1, wire_hash, self.fingerprint
        )
        while True:
            if self._clock() >= deadline:
                raise _deny(
                    "provider slot wait exceeded the SDK turn deadline", reason_code="deadline"
                )
            if cancel.is_cancelled:
                raise _deny("provider cancelled before admission", reason_code="cancelled")
            with self.store.transaction():
                actual_lease = uow.read_provider_runtime_lease(record.run_id.value)
                if (
                    actual_lease is None
                    or actual_lease.owner_id != execution_lease.owner_id
                    or actual_lease.epoch != execution_lease.epoch
                    or actual_lease.expires_at <= self._clock()
                ):
                    raise _deny(
                        "provider SDK runtime lease is no longer current", reason_code=LEASE_LOST
                    )
                intent, reservation = self.adapter.authority(
                    agent_id=binding.agent_id, turn_id=turn.turn_id
                )
                # The grant and ticket carry the identity the request was frozen with
                # (accepted by ``authority``), so every later equality check agrees.
                ticket = ProviderAdmissionTicket(
                    ticket.invocation_id,
                    ticket.handoff_ordinal,
                    ticket.wire_fingerprint,
                    str(intent.config["provider_admission_fingerprint"]),
                )
                if (
                    self.profile_slots is not None
                    and intent.config.get("runtime_profile_id") != profile
                ):
                    raise _deny("provider slot profile differs from original dispatch identity")
                if uow.read_agent_turn_cancel(turn.turn_id) is not None:
                    raise _deny("SDK turn cancelled before admission", reason_code="cancelled")
                if intent.kind == "critic" and isinstance(intent.config.get("attempt_id"), str):
                    attempt_id = intent.config["attempt_id"]
                    if intent.subject_id == f"{attempt_id}:critic:1":
                        worker = self.store.get_intent_for_subject(attempt_id)
                        frozen_first = (
                            None if worker is None else worker.config.get("first_critic_budget")
                        )
                        if frozen_first is not None and (
                            not isinstance(frozen_first, Mapping)
                            or intent.config.get("provider_input_cap")
                            != frozen_first.get("provider_input_cap")
                            or intent.config.get("provider_output_ceiling")
                            != frozen_first.get("output_ceiling")
                        ):
                            raise _deny(
                                "FIRST Critic cap differs from original protected tail",
                                reason_code="input_cap_identity",
                            )
                frozen_cap = intent.config.get("provider_input_cap")
                if frozen_cap is not None:
                    try:
                        cap: Any = ProviderInputCap.from_json(frozen_cap)
                    except (TypeError, ValueError) as exc:
                        raise _deny(
                            "invalid frozen provider input cap", reason_code="input_cap_identity"
                        ) from exc
                    if (
                        intent.kind != "critic"
                        or binding.config_json.get("model_profile_ref") != cap.profile_id
                        or intent.config.get("runtime_profile_id") != cap.profile_id
                        or intent.config.get("model") != cap.model
                        or cap.estimator_fingerprint != self.estimator.fingerprint
                    ):
                        raise _deny(
                            "provider input cap identity differs from frozen intent",
                            reason_code="input_cap_identity",
                        )
                    expected_cap = frozen_provider_input_cap(
                        profile_id=cap.profile_id,
                        model=cap.model,
                        runtime_context=intent.config.get("runtime_context"),
                        estimator_fingerprint=self.estimator.fingerprint,
                    )
                    if isinstance(expected_cap, FirstRequestBudgetUnknown) or expected_cap != cap:
                        raise _deny(
                            "provider input cap differs from frozen context",
                            reason_code="input_cap_identity",
                        )
                    ceiling = intent.config.get("provider_output_ceiling")
                    if type(ceiling) is not int or ceiling < 1 or output > ceiling:
                        raise _deny(
                            "provider output exceeds frozen FIRST Critic ceiling",
                            reason_code="input_cap_identity",
                        )
                    if public_input < 1:
                        raise _deny(
                            "provider estimator returned no input count",
                            reason_code="estimator_unavailable",
                        )
                    # The frozen FIRST floor covers input_budget(), not the context
                    # renderer's optional slack. Refuse slack before any handoff.
                    try:
                        enforce_final_wire_input_cap(
                            provider_input_cap=cap, actual_input_tokens=public_input
                        )
                    except FirstRequestInputCapExceeded as exc:
                        raise _deny(
                            "final provider wire input exceeds its frozen cap",
                            reason_code="provider_input_cap_exceeded",
                            request_tokens=public_input,
                            remaining=cap.max_input_tokens,
                            mission_id=intent.mission_id,
                            subject_id=intent.subject_id,
                        ) from exc
                prior_output = 0
                for previous in uow.list_provider_invocations(record.run_id):
                    previous = uow.read_effective_provider_invocation(previous.invocation_id)
                    assert previous is not None
                    if previous.invocation_id == record.invocation_id:
                        continue
                    if str(previous.state) == "claimed":
                        continue  # a proven never-handed-off request has no usage
                    actual = (
                        _usage(previous) if str(previous.state) in {"succeeded", "failed"} else None
                    )
                    if actual is not None:
                        prior_output += actual[1]
                        continue
                    # Rule 2026-09-24 (may overcount, never undercount): an earlier call whose
                    # usage is unresolved keeps its own grant held (UNKNOWN, awaiting
                    # late accounting) but never freezes the Agent's next call — its output is
                    # bounded by its request's own cap, a proven upper bound.
                    cap = request_output_cap(previous)
                    if cap is None:
                        raise _deny(
                            "prior provider usage is unresolved and unbounded; allowance held",
                            reason_code="usage_unresolved",
                        )
                    prior_output += cap
                extra = prior_output if self.estimator.requires_prior_output_reserve else 0
                upper = public_input + extra + output
                row = self._row(ticket)
                if row is not None and row["state"] != "RELEASED":
                    raise _deny("provider invocation already owns an admission grant")
                if row is not None:
                    expected = {
                        "mission_id": intent.mission_id,
                        "subject_id": intent.subject_id,
                        "agent_id": binding.agent_id,
                        "turn_id": turn.turn_id,
                        "intent_id": intent.intent_id,
                        "fingerprint": ticket.authority_fingerprint,
                        "request_hash": record.request_fingerprint,
                        "wire_hash": wire_hash,
                        "public_input_upper": public_input,
                        "prior_output_upper": extra,
                        "output_ceiling": output,
                        "total_upper": upper,
                    }
                    if any(row[key] != value for key, value in expected.items()):
                        raise _deny("released provider grant identity or allowance changed")
                # 2026-10-10（parse 重跑）：一次调用报回的输出比请求的上限多 2 个 token（32,770 对
                # 32,768，线路的计数口径），以前这里从此拒绝该 Mission 的每一次调用，任务整个停掉。
                # 记账硬规则（2026-09-24）：可以多算、不可以少算、不冻结——超出的那次照实记成
                # OVERRUN（实际数照记、照结账），后面的调用照常准入；不再有"Mission 准入停止"。
                # A physical slot is held by every grant still in flight; a grant whose
                # call terminated on the wire with unresolved usage keeps only its
                # allowance (see WIRE_TERMINAL_TABLE).
                held = self.held_grant_rows()
                active = len(held)
                # 按需导入：循环依赖（provider_budget_guard ↔ legacy_provider_slots）
                from .legacy_provider_slots import held_legacy_slots

                active += held_legacy_slots(self.store)
                profile_available = True
                if self.profile_slots is not None:
                    # Count durable grants in the shared orchestration transaction:
                    # separate SDK pools cannot each acquire a copy of this allowance.
                    held_profiles = []
                    for existing in held:
                        config = json.loads(existing[2]) if existing[2] else {}
                        held_profile = config.get("runtime_profile_id")
                        agent_profile = (config.get("agent_config") or {}).get("model_profile_ref")
                        if held_profile not in self.profile_slots or agent_profile != held_profile:
                            raise _deny(
                                "held provider grant has no confirmed profile identity",
                                reason_code="profile_identity_unknown",
                            )
                        held_profiles.append(held_profile)
                    own_active = held_profiles.count(profile) + held_legacy_slots(
                        self.store, profile
                    )
                    profile_available = own_active < self.profile_slots[profile]
                if active < self.max_slots and profile_available:
                    spent = self.store.connection.execute(
                        "SELECT COALESCE(SUM(CASE WHEN actual_tokens IS NOT NULL THEN actual_tokens"
                        " ELSE total_upper END),0) FROM provider_token_grants"
                        " WHERE subject_id=? AND state!='RELEASED'",
                        (intent.subject_id,),
                    ).fetchone()[0]
                    # Previous unguarded history cannot be silently omitted from the envelope.
                    known_ids = {
                        r[0]
                        for r in self.store.connection.execute(
                            "SELECT invocation_id FROM provider_token_grants WHERE agent_id=?",
                            (binding.agent_id,),
                        )
                    }
                    if any(
                        p.handoff_attempt and p.invocation_id not in known_ids
                        for p in uow.list_provider_invocations(record.run_id)
                        if p.invocation_id != record.invocation_id
                    ):
                        raise _deny(
                            "existing Agent history predates the provider admission contract"
                        )
                    try:
                        self.adapter.grow(reservation, required=int(spent) + upper)
                    except BudgetExhausted as exc:
                        raise _deny(
                            str(exc),
                            reason_code="budget_exhausted",
                            account_id=exc.account_id,
                            dimension=exc.dimension,
                            requested=exc.requested,
                            remaining=exc.remaining,
                            mission_id=intent.mission_id,
                            subject_id=intent.subject_id,
                            request_tokens=upper,
                        ) from exc
                    self.store.connection.execute(
                        "INSERT INTO provider_token_grants("
                        "invocation_id,handoff_ordinal,mission_id,"
                        "subject_id,agent_id,turn_id,intent_id,owner,sdk_owner,sdk_epoch,"
                        "fingerprint,request_hash,wire_hash,"
                        "public_input_upper,prior_output_upper,output_ceiling,total_upper,"
                        "state,created_at,updated_at)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'RESERVED',?,?)"
                        " ON CONFLICT(invocation_id,handoff_ordinal) DO UPDATE SET "
                        "owner=excluded.owner,"
                        "sdk_owner=excluded.sdk_owner,sdk_epoch=excluded.sdk_epoch,"
                        "state='RESERVED',updated_at=excluded.updated_at,version=version+1"
                        " WHERE provider_token_grants.state='RELEASED'",
                        (
                            ticket.invocation_id,
                            ticket.handoff_ordinal,
                            intent.mission_id,
                            intent.subject_id,
                            binding.agent_id,
                            turn.turn_id,
                            intent.intent_id,
                            self.adapter.owner,
                            execution_lease.owner_id,
                            execution_lease.epoch,
                            ticket.authority_fingerprint,
                            record.request_fingerprint,
                            wire_hash,
                            public_input,
                            extra,
                            output,
                            upper,
                            self.store.now,
                            self.store.now,
                        ),
                    )
                    return ticket
            self._waiting[record.invocation_id] = (binding.agent_id, turn.turn_id)
            await asyncio.sleep(self.poll_seconds)

    def held_grant_rows(self) -> list:
        """Grants occupying a physical slot: in flight, or UNKNOWN without a wire-terminal
        mark.  Read from the shared store only, so every pool counts the same set."""
        self._ensure_wire_terminal_table()
        return self.store.connection.execute(_HELD_GRANTS_SQL).fetchall()

    def _ensure_wire_terminal_table(self) -> None:
        ensure_wire_terminal_table(self.store)

    def _mark_wire_terminal(self, ticket) -> None:
        self._ensure_wire_terminal_table()
        self.store.connection.execute(
            f"INSERT OR IGNORE INTO {WIRE_TERMINAL_TABLE} (invocation_id, handoff_ordinal, marked_at)"
            " VALUES (?,?,?)",
            (ticket.invocation_id, ticket.handoff_ordinal, self.store.now),
        )

    def _row(self, ticket):
        return self.store.connection.execute(
            "SELECT * FROM provider_token_grants WHERE invocation_id=? AND handoff_ordinal=?",
            (ticket.invocation_id, ticket.handoff_ordinal),
        ).fetchone()

    def _update(self, ticket, state: str, **values: Any) -> None:
        assignments = ",".join(f"{key}=?" for key in values)
        self.store.connection.execute(
            "UPDATE provider_token_grants SET state=?,version=version+1,updated_at=?"
            + ("," + assignments if assignments else "")
            + " WHERE invocation_id=? AND handoff_ordinal=?",
            (state, self.store.now, *values.values(), ticket.invocation_id, ticket.handoff_ordinal),
        )

    @contextmanager
    def handoff(self, ticket, *, request, cancel):
        with self.store.transaction():
            row = self._row(ticket)
            if row is None or row["state"] != "RESERVED" or row["owner"] != self.adapter.owner:
                raise _deny("provider grant is not owned and reserved")
            if cancel.is_cancelled:
                raise _deny("provider cancelled before handoff", reason_code="cancelled")
            if (
                not self.accepts(ticket.authority_fingerprint)
                or row["fingerprint"] != ticket.authority_fingerprint
                or row["wire_hash"] != provider_request_fingerprint(request)
            ):
                raise _deny("provider wire changed after admission")
            self.adapter.authority(agent_id=row["agent_id"], turn_id=row["turn_id"])
            # Only synchronous SDK CAS is allowed inside this cancellation fence.
            yield
            self._update(ticket, "HANDED_OFF")

    def observe(self, ticket, *, record) -> None:
        with self.store.transaction():
            self._observe_in_transaction(ticket, record=record)

    def _observe_in_transaction(self, ticket, *, record) -> bool:
        """Record actual usage.  Returns whether it exceeded the admitted bound: the grant
        row then says OVERRUN with the actual numbers (a recorded fact, charged as it is);
        nothing is refused because of it (2026-10-10, count rule: never freeze)."""
        row = self._row(ticket)
        if row is None or row["state"] in {"SETTLED", "OVERRUN"}:
            return False
        if row["state"] == "RELEASED" and row["actual_tokens"] is not None:
            return False
        if record is None:
            return False  # no evidence that a different pool's call never started
        if record.request_fingerprint != row["request_hash"]:
            raise _deny("SDK record differs from admission identity")
        state = str(record.state)
        if record.handoff_attempt < ticket.handoff_ordinal and state == "claimed":
            # This callback runs after the synchronous SDK CAS returned/failed.
            if row["state"] == "RESERVED" and row["owner"] == self.adapter.owner:
                self._update(ticket, "RELEASED")
            return False
        if record.handoff_attempt != ticket.handoff_ordinal:
            return False
        actual = _usage(record) if state in {"succeeded", "failed"} else None
        if actual is None:
            if state in {"succeeded", "failed", "unknown"}:
                # Terminated on the wire, usage unresolved: allowance held, slot free.  An
                # SDK "unknown" record is settled after the local call ended (transport
                # error / cancel after hand-off): its charge stays at the upper bound, but
                # it must not hold the pool's slot forever (host-final-arp10, 2026-09-24).
                self._mark_wire_terminal(ticket)
            if row["state"] in HELD and row["state"] != "UNKNOWN":
                self._update(ticket, "UNKNOWN")
            return False
        total = sum(actual)
        overrun = total > row["total_upper"] or actual[1] > row["output_ceiling"]
        self._update(
            ticket,
            "OVERRUN" if overrun else "SETTLED",
            actual_tokens=total,
            actual_output_tokens=actual[1],
        )
        return overrun

    def release_held_grants(
        self, *, intent_id: str, reason: str = "provider_outcome_unknown"
    ) -> int:
        """Release HELD grants for one intent so a later admission is not refused by them.

        P2.3l / N5.  After the bounded unknown-outcome wait the request is treated as
        confirmed-not-started for *grant* accounting: the SDK invocation stays
        UNKNOWN (the truth — it may have reached the model) but the grant no longer
        occupies a slot or the subject's spent envelope.  Called immediately before
        a service-intent re-hand-off, and again when the round is given up.
        """

        del reason
        released = 0
        with self.store.transaction():
            rows = self.store.connection.execute(
                "SELECT * FROM provider_token_grants"
                " WHERE intent_id=? AND state IN ('RESERVED','HANDED_OFF','UNKNOWN')",
                (intent_id,),
            ).fetchall()
            for row in rows:
                ticket = ProviderAdmissionTicket(
                    row["invocation_id"],
                    row["handoff_ordinal"],
                    row["wire_hash"],
                    row["fingerprint"],
                )
                self._update(ticket, "RELEASED")
                released += 1
        return released

    def _owner_gone(self, uow, binding, row) -> bool:
        """The process that handed this grant off no longer holds the run it ran in."""

        lease = uow.read_provider_runtime_lease(binding.run_id)
        return (
            lease is None
            or lease.owner_id != row["sdk_owner"]
            or lease.epoch != row["sdk_epoch"]
            or lease.expires_at <= self._clock()
        )

    def recover(self, uow, *, missions: frozenset[str] | None = None) -> None:
        """``missions`` narrows this pass to those Missions' grants; None is every grant."""
        # Read and fence in Orch -> SDK order; no remote reconciliation under this lock.
        with self.store.transaction():
            rows = self.store.connection.execute(
                "SELECT * FROM provider_token_grants"
                " WHERE state IN ('RESERVED','HANDED_OFF','UNKNOWN')"
                " OR (state='RELEASED' AND actual_tokens IS NULL)"
            ).fetchall()
            if missions is not None:
                rows = [row for row in rows if row["mission_id"] in missions]
            for row in rows:
                binding = uow.read_agent_binding(row["agent_id"])
                if binding is None:
                    continue  # another pool's database is not negative evidence
                record = uow.read_effective_provider_invocation(row["invocation_id"])
                ticket = ProviderAdmissionTicket(
                    row["invocation_id"],
                    row["handoff_ordinal"],
                    row["wire_hash"],
                    row["fingerprint"],
                )
                if record is not None:
                    turn = uow.read_agent_turn(row["turn_id"])
                    intent = self.store.get_intent(row["intent_id"])
                    rehanded = intent is not None and (
                        intent.agent_id != row["agent_id"]
                        or intent.expected_turn_id != row["turn_id"]
                    )
                    if (
                        record.invocation_id != row["invocation_id"]
                        or record.run_id.value != binding.run_id
                        or record.request_fingerprint != row["request_hash"]
                        or binding.agent_id != row["agent_id"]
                        or turn is None
                        or turn.agent_id != binding.agent_id
                        or intent is None
                        or intent.expected_turn_id != turn.turn_id
                        or intent.agent_id != binding.agent_id
                        or intent.input_id != turn.input_id
                        or intent.subject_id != row["subject_id"]
                        or intent.mission_id != row["mission_id"]
                    ):
                        # P2.3l / N5: re-hand-off rewrites the live intent onto a new
                        # executor.  The abandoned grant is no longer this pool's live
                        # authority — releasing it is the bounded-wait answer, not a
                        # TTL guess, and denying recover here used to lock every later
                        # admission as authority_rejected.
                        if rehanded:
                            # P2.3l P1-1: a rewritten intent is not a deny, but a
                            # succeeded/failed record must be observed before the
                            # grant is dropped, or a later charge is lost.
                            if record is not None and str(record.state) in {
                                "succeeded",
                                "failed",
                            }:
                                self._observe_in_transaction(ticket, record=record)
                            current = self._row(ticket)
                            if current is not None and current["state"] in HELD:
                                self._update(ticket, "RELEASED")
                            continue
                        raise _deny("recovery SDK/intent/grant identities differ")
                if record is not None and str(record.state) in {"succeeded", "failed"}:
                    self._observe_in_transaction(ticket, record=record)
                elif record is not None and record.handoff_attempt >= row["handoff_ordinal"]:
                    resolution = uow.read_reconciliation_resolution(
                        kind="provider",
                        ledger_identity=record.invocation_id,
                        handoff_attempt=row["handoff_ordinal"],
                    )
                    if (
                        resolution is not None
                        and str(resolution.outcome) == "confirmed_not_started"
                    ):
                        self._update(ticket, "RELEASED")
                    else:
                        if row["state"] in HELD and row["state"] != "UNKNOWN":
                            self._update(ticket, "UNKNOWN")
                        if (
                            str(record.state) == "unknown"
                            and record.handoff_attempt == row["handoff_ordinal"]
                        ):
                            # Older libraries: an unknown call already ended on the wire.
                            self._mark_wire_terminal(ticket)
                        elif self._owner_gone(uow, binding, row):
                            # Desktop 2026-09-27: the app quit with a call on the wire;
                            # its connection died with the process that held the run.
                            # The charge stays unknown (counted at its bound); only the
                            # physical slot is freed — before, the next Mission's first
                            # request waited for it until its own deadline.
                            self._mark_wire_terminal(ticket)
                elif row["state"] == "RESERVED":
                    # Do not release a live competing owner's pre-handoff grant.
                    intent = self.store.get_intent(row["intent_id"])
                    attempt = self.store.get_attempt(row["subject_id"])
                    mission = self.store.get_mission(row["mission_id"])
                    sdk_lease = uow.read_provider_runtime_lease(binding.run_id)
                    parent_task = None if attempt is None else self.store.get_task(attempt.task_id)
                    if (
                        mission.status in TERMINAL_MISSION
                        or intent is None
                        or intent.state not in {"AGENT_CREATED", "SUBMITTED"}
                        or (
                            attempt is not None
                            and (
                                attempt.status in TERMINAL_ATTEMPT
                                or parent_task is None
                                or parent_task.status in TERMINAL_TASK
                            )
                        )
                        or sdk_lease is None
                        or sdk_lease.owner_id != row["sdk_owner"]
                        or sdk_lease.epoch != row["sdk_epoch"]
                        or sdk_lease.expires_at <= self._clock()
                    ):
                        self._update(ticket, "RELEASED")


__all__ = (
    "HandoffOutcomeCheck",
    "ProviderBudgetCommitAdapter",
    "ProviderBudgetGuard",
    "check_unknown_handoff",
    "resend_record",
)
