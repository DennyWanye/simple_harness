#!/usr/bin/env python3
"""Check a complete offline delivery, without importing SDK or changing gates."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

REQUIRED = (
    'README.md', 'V1.1-PREP-CLOSURE-2026-09-21.md', 'STATE-GATES.md',
    'V1.2.1-READINESS-AMENDMENT-2026-09-21.md', 'tools/collection_identity.py',
    'tools/prepare_runner_patch.py', 'tools/review_source_candidates.py',
    'h1h/commit-proof-plan.json', 'metadata/workagent-v12-handoff.json',
    'TG-A-OFFLINE-RUNBOOK.md', 'H1-H-DEPENDENCIES-ALLOWLIST-TESTS.md',
    'TEST-NODEID-MAP-42-12.md', 'sdk-nodeid-map.json', 'mutation-nodeid-map.json',
    'h1h-nodeid-map.json', 'source-map.seed.json', 'source-requirements.json',
    'equivalences.json', 'h1h/closure.json', 'h1h/commit-seam-review.json',
    'h1h/assertion-review.json', 'tools/capture_sources.py',
    'tools/offline_sdk_migration_probe.py', 'tools/h1h_manifest.py', 'tools/collect_h1h.py',
    'tools/pytest_readiness.py', 'tools/verify_delivery.py',
    'reference/sql_statement_iterator.py', 'metadata/parent-contract-checks.json',
    'metadata/input-manifest.json', 'inputs/simpleharness-taskgraph-code-plan-kit.zip',
)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def safe_file(root: Path, rel: str) -> Path:
    posix = PurePosixPath(rel)
    if posix.is_absolute() or not posix.parts or any(p in ('..', '.') for p in posix.parts) or '\\' in rel:
        raise ValueError(f'unsafe manifest path: {rel}')
    p = root.joinpath(*posix.parts)
    for parent in (p, *p.parents):
        if parent == root: break
        if parent.is_symlink(): raise ValueError(f'symlink in delivery path: {rel}')
    if not p.resolve().is_relative_to(root.resolve()): raise ValueError('manifest path escape')
    return p

def check(root: Path, manifest: dict) -> dict:
    entries = manifest.get('files')
    if manifest.get('version') != 1 or not isinstance(entries, dict): raise ValueError('invalid delivery manifest')
    failures = []
    for rel in REQUIRED:
        if rel not in entries: failures.append({'path': rel, 'error': 'NOT_IN_MANIFEST'})
    for rel, expected in entries.items():
        if not isinstance(expected, str) or len(expected) != 64: raise ValueError('invalid digest')
        p = safe_file(root, rel)
        if not p.is_file(): failures.append({'path': rel, 'error': 'MISSING'})
        elif sha256(p) != expected: failures.append({'path': rel, 'error': 'HASH_MISMATCH'})
    return {'kind': 'DELIVERY_FILE_INTEGRITY', 'status': 'PASS' if not failures else 'BLOCKED',
            'checked_files': len(entries), 'failures': failures,
            'sdk_verified': False, 'source_map_complete': False,
            'h1_h_ready': False, 'production_enablement_allowed': False}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    manifest_path = root / 'DELIVERY-MANIFEST.json'
    if manifest_path.is_symlink(): raise ValueError('symlink manifest refused')
    report = check(root, json.loads(manifest_path.read_text(encoding='utf-8')))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'PASS' else 3

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print(json.dumps({'status': 'BLOCKED', 'error': str(error), 'sdk_verified': False}, ensure_ascii=False))
        raise SystemExit(3)
