> **TG-READY-1.1 适用说明：**先读本包 `V1.1-PREP-CLOSURE-2026-09-21.md`。以下保留原规格；入口名称允许有证明的合同等价；当前仅 TG-A-prep。未完成 gate 以最新 `gates.current.json`/用户 handoff 为准。

# 42 场景 + 12 mutation：执行映射

保留TG-EXEC-2.0原ID和完整断言，JSON中含原arrange/execute/assertions。以下是**拟创建或映射的精确target nodeid，不是已确认的本地测试**；actual_nodeids当前全部为空。

生产文件为原计划落点；本地source-map可登记经review的等价文件，不得只改测试让其通过。

## 42组

| ID | 原场景 | 目标pytest nodeid | 前置/排程 |
|---|---|---|---|
| S01 | 历史结构准确读取 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S01_historical_structure_pins` | TG-A_AFTER_SCHEMA_SOURCES |
| S02 | Method与slot身份 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S02_method_slot_identity` | TG-B |
| S03 | 候选来源完整 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S03_candidate_sources_complete` | TG-B |
| S04 | AND-OR采用 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S04_and_or_adoption` | TG-B |
| S05 | compound入口出口 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S05_compound_gates_no_worker` | TG-B |
| S06 | 图损坏与环 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S06_corruption_cycle_refused` | TG-B |
| S07 | pending与检查完整 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S07_pending_not_partial_check` | TG-B |
| S08 | 边界与确定性 | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S08_bounds_and_determinism` | TG-B |
| D01 | ORDER与DATA分离 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D01_order_does_not_supply_data` | TG-B |
| D02 | 合法空与未取得 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D02_empty_vs_unavailable_inputs` | TG-B |
| D03 | schema与选择 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D03_schema_and_version_selection` | TG-B |
| D04 | ORDER真实结算 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D04_order_requires_real_settlement` | TG-B |
| D05 | 物化与资源身份 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D05_materialization_identity` | TG-B |
| D06 | 每Attempt冻结输入 | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D06_per_attempt_frozen_inputs` | TG-B |
| A01 | 真实caller/启用 | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A01_caller_and_kernel_enablement` | TG-C |
| A02 | 冻结request | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A02_frozen_request_and_decode_only` | TG-C |
| A03 | grant与Commit竞态 | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A03_grant_commit_race` | TG-C |
| A04 | Validity目的与来源 | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A04_validity_scope_purpose` | TG-C |
| A05 | 能力和权限 | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A05_capability_not_authority` | TG-C |
| A06 | 预算守恒 | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A06_budget_conservation` | TG-C |
| R01 | 共享保留 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R01_retain_shared_producer` | TG-D |
| R02 | 局部影响 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R02_local_impact` | TG-D |
| R03 | 非法修复不先取消 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R03_invalid_repair_no_cancel` | TG-D |
| R04 | 收敛完整闭环 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R04_convergence_lifecycle` | TG-D |
| R05 | 最后需求并发 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R05_last_demand_race` | TG-D |
| R06 | 退役操作仍UNKNOWN | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R06_retired_unknown_operation` | TG-D |
| R07 | 晚到结果 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R07_late_result_binding` | TG-D |
| R08 | 延期/撤权/取消 | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R08_defer_revoke_cancel` | TG-D |
| C01 | 一写事务与幂等 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C01_atomic_commit_idempotency` | TG-C |
| C02 | 并发计划环 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C02_concurrent_plan_cycle` | TG-C |
| C03 | 进程强退四点 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C03_process_crash_boundaries` | TG-C |
| C04 | 离线图重建 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C04_offline_graph_replay` | TG-D |
| C05 | 通知至少一次投递 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C05_followup_at_least_once` | TG-D |
| C06 | 迁移兼容 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C06_sdk_migration_compatibility` | TG-A_AFTER_SCHEMA_SOURCES |
| C07 | SQL跨Mission负控 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C07_cross_mission_sql_guards` | TG-C_REAL_GRAPH_FIXTURES |
| C08 | Attempt原子绑定 | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C08_atomic_attempt_input_binding` | TG-C |
| V01 | 组合验收不可省 | `tests/orchestrator/full_target/taskgraph_exec/test_acceptance_host.py::test_V01_composition_not_optional` | TG-E |
| V02 | 不改图决定 | `tests/orchestrator/full_target/taskgraph_exec/test_acceptance_host.py::test_V02_nonmutating_decisions` | TG-E |
| V03 | 完整方法修复 | `tests/orchestrator/full_target/taskgraph_exec/test_acceptance_host.py::test_V03_full_method_repair` | TG-E |
| V04 | Host一致视图 | `tests/orchestrator/full_target/taskgraph_exec/test_acceptance_host.py::test_V04_host_consistent_view` | TG-E |
| V05 | Shadow隔离与回归 | `tests/orchestrator/full_target/taskgraph_exec/test_acceptance_host.py::test_V05_shadow_and_legacy` | TG-E |
| V06 | 真实模型与规模 | `tests/orchestrator/full_target/taskgraph_exec/test_model_seam.py::test_V06_real_model_and_scale` | TG-E_REAL_MODEL |

## 12个变异

| ID | 精确行为变化 | 必须击中的测试 |
|---|---|---|
| M01 | remove planning grant recheck | `tests/orchestrator/full_target/taskgraph_exec/test_admission.py::test_A03_grant_commit_race` |
| M02 | operation read error returns empty | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R06_retired_unknown_operation` |
| M03 | historical reader selects latest | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S01_historical_structure_pins` |
| M04 | ORDER implicitly supplies files | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D01_order_does_not_supply_data` |
| M05 | failed resolver becomes empty manifest | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D02_empty_vs_unavailable_inputs` |
| M06 | drop source collection digest | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C02_concurrent_plan_cycle` |
| M07 | cancel every retired parent child | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R01_retain_shared_producer` |
| M08 | remove dispatch generation check | `tests/orchestrator/full_target/taskgraph_exec/test_repair.py::test_R07_late_result_binding` |
| M09 | Task cancelled means externally settled | `tests/orchestrator/full_target/taskgraph_exec/test_data.py::test_D04_order_requires_real_settlement` |
| M10 | NOT_CHECKED treated as valid | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S07_pending_not_partial_check` |
| M11 | lost receipt mints a new command | `tests/orchestrator/full_target/taskgraph_exec/test_transactions.py::test_C03_process_crash_boundaries` |
| M12 | compound sent to ordinary Worker | `tests/orchestrator/full_target/taskgraph_exec/test_structure.py::test_S05_compound_gates_no_worker` |

## 收集与执行规则
1. 所有nodeid先在隔离源码副本`--collect-only`实际收集。新增/等价映射须附实际参数化nodeids，不能用`pytest -k S01`的模糊匹配冒充精确覆盖。
2. `tools/map_collected_nodeids.py`只填COLLECTED_NOT_EXECUTED，不产SDK PASS。不完整/错误collection不得更新已完成状态。
3. Store、Compiler、Commit、Validity、manifest resolver、H1权威producer必须是真实现。provider固定回复和受控外部测试目标可stub；不能mock内部PASS。V06实际模型部分不stub。
4. C06完整migration可在TG-A隔离库做；C07跨Mission/实际图/Attempt集成需真实业务fixture，后置到TG-C。不能拿单一FK插入负测关闭C07。
5. V04先验证SDK返回合同，再跑真实Host transport/store/component，两种证据缺一不可。pytest包装器不能空跑外部UI。实际UI命令由Host source-map核实后填，不猜路径。
6. V06拆排程不改完成定义：规模边界可先跑；真实GPT-5.6四场景各3trial最后跑。全部满足才关闭V06。
7. 变异只在新的隔离源码副本应用。先原版相同nodeids PASS，再保存唯一review过的patch、before/after hash。只有预期业务assertion失败才KILLED；import/setup/timeout不计。
8. 每次安全相关切片提交就跑相关负控，不等42组终验才发现回归。

## 单独排程（不增加或删掉42组）
| 测试层 | 执行时机 | 输出 |
|---|---|---|
| Reference及本包工具自测 | 随时可离线；不充SDK覆盖 | 原结果scope=REFERENCE/READINESS_TOOLING |
| TG-A migration纯离线 | 当前允许；缺父表/runner时BLOCKED | 完整schema、新建/升级/rollback/checksum/FK报告 |
| H1-H focused 36组/12mutations/独立review | 独立前置工作流 | H1_H_READY |
| SDK相关42组子集 | TG-B/C/D各片后 | 精确nodeid+实际receipt |
| Stateful property | 内核接线后，独立job | 200×50，seed、最小反例、reference model对照 |
| legacy/full H1 gate | H1改变后和候选冻结时 | 现有真实runner命令及Junit |
| Host/V04 | TG-E、SDK artifact固定后 | Host fingerprint+实际组件证据 |
| GPT-5.6/V06及H1-I | 确定性门通过后 | 冻结模型配置、预算、全部结果 |

**现有14局H1题集、legacy/fullH1 runner的路径本轮未取得。必须从本地原任务/核验书读取并登记命令hash；不能为了“命令齐全”新编不存在的入口。**

## 已有等价测试的机器映射

不必重写同一测试。每个case可追加`nodeid_equivalence`，必须含`reviewed_by/source_sha256/candidate_fingerprint/assertion_coverage/nodeids[]`；仅同一候选且已审阅的精确nodeid可复用。收集器检查全部nodeids均收集到，否则PARTIALLY_COLLECTED，不变为PASS。原target_nodeid保留用于追踪，不静默改成另一项测试。
