# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""The sandbox executor port and its two adapters (P3.2 plan v3 D1 / D2; plan review
round 1 P0-2 / P1-2 / P1-3 / P1-4, round 2 P1-2 / P2-1 / P2-9).

Every piece of model-written code this build runs — ``run_tests``, the ``code_test`` layer,
Mission ``pytest:`` criteria, the evaluator's oracle — goes through
:meth:`SandboxExecutorPort.execute`, which returns an :class:`ExecutionReceipt` saying what
really happened: exit code, bounded output (the tail is kept, where pytest puts its
summary), whether the wall clock or a limit stopped it, and whether every process of the
run is gone — measured after the reaping, never assumed.

``SeatbeltExecutor`` (macOS ``sandbox-exec``) is the sandbox: no network, no file content
outside a read whitelist computed from the interpreter it runs, no writes outside the run's
own copy and scratch directory, no signals to processes outside the sandbox, no mach
lookups, no information about other processes.  Its processes are found by *sandbox
identity*: each run's profile allows reading one canary path and denies a decoy, and
``sandbox_check()`` asked about every process of this user picks out exactly the processes
of this run — however they left the process tree (``setsid``, double fork, ``chdir("/")``,
closed descriptors).  ``ProcessOnlyExecutor`` is not a sandbox and says so
(``isolated=False``): it follows the parent chain and the run's directory, and a full
daemonize can leave it — for trusted code only.

Honest limits (plan §2): CPU time and file size are hard limits (``setrlimit``, inherited
by every descendant); memory and the process count are *soft* limits — sampled while the
run lasts and enforced by reaping, because this platform has no cgroups, ``RLIMIT_AS`` /
``RLIMIT_DATA`` cannot be set and ``RLIMIT_NPROC`` counts every process of the user.
"""

from __future__ import annotations

import asyncio
import ctypes
import fcntl
import hashlib
import json
import os
import pwd
import resource
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

SANDBOX_VERSION = "sandbox-v1"
SANDBOX_EXEC = "/usr/bin/sandbox-exec"
PS = "/bin/ps"
LSOF = "/usr/sbin/lsof"
DEFAULT_PATH = "/usr/bin:/bin"
# read-only system locations every interpreter needs (plan v3 D1; "/" itself is listed by
# the interpreter at start-up — without it every program aborts, review round 2 P2-1)
SYSTEM_READ_PATHS = ("/System", "/usr", "/bin", "/private/etc", "/private/var/db/timezone")
DEVICE_READ_LITERALS = ("/dev/null", "/dev/zero", "/dev/random", "/dev/urandom")
PROBE_SECRET = "P32-PROBE-SECRET"


class SandboxUnavailable(RuntimeError):
    """The deployment asked for a sandbox this machine cannot provide (plan D2)."""


# ------------------------------------------------------------------ contracts
@dataclass(frozen=True, slots=True)
class SandboxSpec:
    cpu_seconds: int = 120
    wall_seconds: float = 120.0
    max_processes: int = 64
    max_rss_bytes: int = 2 * 1024 * 1024 * 1024
    max_output_bytes: int = 1024 * 1024
    max_file_bytes: int = 64 * 1024 * 1024
    env: Mapping[str, str] = field(default_factory=dict)
    network: str = "none"

    def __post_init__(self) -> None:
        if self.network != "none":
            raise ValueError("this build only runs model-written code without a network")
        if self.cpu_seconds < 1 or self.wall_seconds <= 0 or self.max_output_bytes < 1:
            raise ValueError("sandbox limits must be positive")

    def effective_limits(self, *, isolated: bool = True) -> dict[str, dict[str, Any]]:
        """What this run is really held to.  ``cpu_seconds`` is a *per-process* rlimit, not
        a total for the run; the network is only denied when an adapter isolates the run —
        an unsandboxed one says so rather than claiming a limit it does not apply (code
        review round 1 P1-3 / P2-5)."""

        return {
            "cpu_seconds": {"value": self.cpu_seconds, "enforcement": "hard", "scope": "process"},
            "wall_seconds": {"value": self.wall_seconds, "enforcement": "hard"},
            "max_file_bytes": {"value": self.max_file_bytes, "enforcement": "hard"},
            "max_output_bytes": {"value": self.max_output_bytes, "enforcement": "hard"},
            "max_rss_bytes": {"value": self.max_rss_bytes, "enforcement": "soft"},
            "max_processes": {"value": self.max_processes, "enforcement": "soft"},
            "network": (
                {"value": self.network, "enforcement": "hard"}
                if isolated
                else {"value": "unrestricted", "enforcement": "none"}
            ),
        }


@dataclass(frozen=True, slots=True)
class ExecutionReceipt:
    execution_id: str
    kind: str  # seatbelt | process_only
    isolated: bool
    environment_digest: str
    effective_limits: Mapping[str, Any]
    exit_code: int | None
    output: str
    truncated: bool
    timed_out: bool
    limit_exceeded: str | None  # cpu | rss | processes
    tree_killed: bool
    residual_pids: tuple[int, ...]
    status: str  # ok | error (a process of the run could not be removed)

    def to_json(self) -> dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "kind": self.kind,
            "isolated": self.isolated,
            "environment_digest": self.environment_digest,
            "effective_limits": dict(self.effective_limits),
            "exit_code": self.exit_code,
            "output": self.output,
            "truncated": self.truncated,
            "timed_out": self.timed_out,
            "limit_exceeded": self.limit_exceeded,
            "tree_killed": self.tree_killed,
            "residual_pids": list(self.residual_pids),
            "status": self.status,
        }


class SandboxExecutorPort(Protocol):
    kind: str
    isolated: bool
    interpreter: str

    @property
    def environment_digest(self) -> str: ...

    async def execute(
        self, command: Sequence[str], *, cwd: str, spec: SandboxSpec
    ) -> ExecutionReceipt: ...


# ------------------------------------------------------------------ process table
@dataclass(frozen=True, slots=True)
class _Proc:
    pid: int
    ppid: int
    uid: int
    rss_kb: int
    zombie: bool


def _process_table(*, strict: bool = False, timeout: float = 10) -> list[_Proc]:
    try:
        completed = subprocess.run(
            [PS, "-A", "-o", "pid=,ppid=,uid=,rss=,stat="],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if strict and completed.returncode != 0:
            raise SandboxUnavailable("process inventory failed")
        out = completed.stdout
    except (OSError, subprocess.SubprocessError) as error:
        if strict:
            raise SandboxUnavailable("process inventory unavailable") from error
        return []
    table = []
    for line in out.splitlines():
        parts = line.split()
        if not parts:
            continue
        if len(parts) < 5:
            if strict:
                raise SandboxUnavailable("process inventory contains an incomplete row")
            continue
        try:
            pid, ppid, uid, rss = (int(value) for value in parts[:4])
            table.append(_Proc(pid, ppid, uid, rss, parts[4][:1] == "Z"))
        except ValueError as error:
            if strict:
                raise SandboxUnavailable("process inventory contains an invalid row") from error
            continue
    if strict and not any(proc.pid == os.getpid() for proc in table):
        raise SandboxUnavailable("process inventory incomplete")
    return table


def _descendants(table: Sequence[_Proc], root: int) -> set[int]:
    found = {root}
    changed = True
    while changed:
        changed = False
        for proc in table:
            if proc.ppid in found and proc.pid not in found:
                found.add(proc.pid)
                changed = True
    return found


def _sigkill(pid: int) -> None:
    try:
        os.kill(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def _preexec(cpu_seconds: int, max_file_bytes: int) -> Callable[[], None]:
    def apply() -> None:  # runs in the child before exec: inherited by every descendant
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
        resource.setrlimit(resource.RLIMIT_FSIZE, (max_file_bytes, max_file_bytes))

    return apply


class _Tail:
    """Keeps the last ``cap`` bytes of a stream (pytest's summary is at the end)."""

    def __init__(self, cap: int) -> None:
        self.cap = cap
        self.data = bytearray()
        self.total = 0

    async def drain(self, stream: asyncio.StreamReader) -> None:
        while True:
            chunk = await stream.read(65536)
            if not chunk:
                return
            self.total += len(chunk)
            self.data.extend(chunk)
            if len(self.data) > self.cap:
                del self.data[: len(self.data) - self.cap]

    def text(self) -> tuple[str, bool]:
        truncated = self.total > self.cap
        # a character cut at the front is dropped rather than replaced: the bound holds
        return self.data.decode("utf-8", "ignore" if truncated else "replace"), truncated


class SandboxExecutionLedger(Protocol):
    """子进程身份与回收材料的账本（§14.4，车道 J H04）。

    ``record_start`` 在子进程起来、身份读到之后立刻调用；写不进去的运行不许继续（先把刚起的进程
    组收掉再报错）——没有回收材料的子进程不能存在。``record_finish`` 在收尾后写结果。"""

    def record_start(self, record: Mapping[str, Any]) -> None: ...

    def record_finish(self, execution_id: str, outcome: str) -> None: ...


def process_identity(pid: int) -> dict[str, Any] | None:
    """这一刻进程号 ``pid`` 的身份（只做 macOS，用户决定 A#9）：进程组、会话、启动时间、命令行。
    进程不在了返回 ``None``；``ps`` 本身不可用抛 :class:`SandboxUnavailable`。"""

    try:
        completed = subprocess.run(
            [PS, "-p", str(int(pid)), "-o", "lstart=,command="],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError) as error:
        raise SandboxUnavailable("process identity query unavailable") from error
    line = completed.stdout.strip()
    if completed.returncode != 0 or not line:
        return None
    parts = line.split()
    if len(parts) < 5:
        raise SandboxUnavailable("process identity output unreadable")
    # macOS 的 ``ps -o sess`` 只打印 0：进程组与会话用系统调用读，进程刚没了就按"不在"算
    try:
        group, session = os.getpgid(int(pid)), os.getsid(int(pid))
    except ProcessLookupError:
        return None
    except PermissionError:
        group, session = None, None
    return {
        "process_group": group,
        "session_id": session,
        "process_started_at": " ".join(parts[:5]),
        "command": " ".join(parts[5:]),
    }


def identity_matches(recorded: Mapping[str, Any], current: Mapping[str, Any]) -> bool:
    """落库的身份与此刻同一个进程号上的进程是不是同一个：启动时间必须一样，进程组/会话有记就要
    一样。命令行只作记录（沙箱里的程序可以改自己的 argv），不参与判定。"""

    if str(recorded.get("process_started_at") or "") != str(current.get("process_started_at") or ""):
        return False
    for key in ("process_group", "session_id"):
        if recorded.get(key) is not None and int(recorded[key]) != int(current[key]):
            return False
    return True


def reclaim_recorded_executions(
    rows: Sequence[Mapping[str, Any]],
    *,
    kill: Callable[[int], None] | None = None,
    sweeps: int = 3,
) -> list[dict[str, Any]]:
    """重启后的孤儿回收（恢复协议第 7 步）：对每条没记结束的子进程，先按落库身份核对此刻的进程，
    对上了才终止它的进程组；对不上（进程号被别人复用）一个不碰；进程不在了记 ``gone``；
    ``ps`` 不可用记 ``unverifiable``。返回每条的结果（``execution_id``、``outcome``、``pids``）。"""

    reports: list[dict[str, Any]] = []
    signal_one = kill or _sigkill
    for row in rows:
        execution_id = str(row["execution_id"])
        pid = int(row["root_pid"])
        try:
            current = process_identity(pid)
        except SandboxUnavailable as error:
            reports.append({"execution_id": execution_id, "outcome": "unverifiable",
                            "root_pid": pid, "reason": str(error), "pids": []})
            continue
        if current is None:
            reports.append({"execution_id": execution_id, "outcome": "gone", "root_pid": pid, "pids": []})
            continue
        if not identity_matches(row, current):
            reports.append({"execution_id": execution_id, "outcome": "identity_mismatch", "root_pid": pid,
                            "recorded": {k: row.get(k) for k in ("process_group", "session_id", "process_started_at")},
                            "current": current, "pids": []})
            continue
        group = current["process_group"]
        signalled: set[int] = set()
        for _ in range(max(1, sweeps)):
            if group is not None:
                try:
                    os.killpg(int(group), signal.SIGKILL)
                    signalled.add(int(group))
                except (ProcessLookupError, PermissionError):
                    pass
            signal_one(pid)
            signalled.add(pid)
            time.sleep(0.05)
            again = process_identity(pid)
            if again is None or not identity_matches(row, again):
                break
        after = process_identity(pid)
        alive = after is not None and identity_matches(row, after)
        reports.append({"execution_id": execution_id, "outcome": "residual" if alive else "reclaimed",
                        "root_pid": pid, "pids": sorted(signalled)})
    return reports


# ------------------------------------------------------------------ the shared engine
class _Executor:
    kind = ""
    isolated = False

    def __init__(
        self,
        interpreter: str | None = None,
        *,
        poll_interval: float = 0.1,
        kill: Callable[[int], None] | None = None,
        max_sweeps: int = 6,
        exec_root: str | Path | None = None,
    ) -> None:
        self.interpreter = str(interpreter or sys.executable)
        self._poll = poll_interval
        self._kill = kill or _sigkill  # seam: what removes a descendant
        self._max_sweeps = max(1, max_sweeps)
        self._exec_root = (
            Path(exec_root)
            if exec_root is not None
            else Path(tempfile.gettempdir()).resolve() / f"orch-exec-{os.getuid()}"
        )
        #: 车道 J H04：子进程身份与回收材料的账本；编排启动时绑上（``StoreSandboxLedger``）。
        self.ledger: SandboxExecutionLedger | None = None

    @property
    def environment_digest(self) -> str:
        return _digest({"kind": self.kind, "version": SANDBOX_VERSION, **self._identity()})

    def _identity(self) -> dict[str, Any]:
        return {"interpreter": os.path.realpath(self.interpreter)}

    # subclass hooks -------------------------------------------------------
    def _argv(self, command: Sequence[str], run: _Run) -> list[str]:
        return list(command)

    def _members(self, run: _Run) -> set[int]:
        raise NotImplementedError

    def _survivors(self, run: _Run) -> set[int]:
        raise NotImplementedError

    # the run ----------------------------------------------------------------
    async def execute(
        self, command: Sequence[str], *, cwd: str, spec: SandboxSpec
    ) -> ExecutionReceipt:
        run = _Run.start(self._exec_root, Path(cwd).resolve())
        safe_to_delete = False
        if self.isolated:
            run.register(self.kind, self.environment_digest)
        env = {
            "PATH": DEFAULT_PATH,
            "HOME": str(run.scratch),
            "TMPDIR": str(run.scratch / "tmp"),
            "USER": run.user,
            "LOGNAME": run.user,
            "LANG": os.environ.get("LANG") or "en_US.UTF-8",
            **dict(spec.env),
        }
        tail = _Tail(spec.max_output_bytes)
        timed_out = False
        limit: str | None = None
        residual: set[int] = set()
        recorded = False
        try:
            process = await asyncio.create_subprocess_exec(
                *self._argv(command, run),
                cwd=str(run.cwd),
                env=env,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                start_new_session=True,
                preexec_fn=_preexec(spec.cpu_seconds, spec.max_file_bytes),
            )
            run.root_pid = process.pid
            recorded = self._record_start(run, command, process.pid)
            assert process.stdout is not None
            reader = asyncio.ensure_future(tail.drain(process.stdout))
            waiter = asyncio.ensure_future(process.wait())
            loop = asyncio.get_running_loop()
            deadline = loop.time() + spec.wall_seconds
            try:
                while not waiter.done():
                    remaining = deadline - loop.time()
                    if remaining <= 0:
                        timed_out = True
                        break
                    await asyncio.wait({waiter}, timeout=min(self._poll, remaining))
                    if waiter.done():
                        break
                    members, rss = await asyncio.to_thread(self._sample, run)
                    if len(members) > spec.max_processes:
                        limit = "processes"
                        break
                    if rss > spec.max_rss_bytes:
                        limit = "rss"
                        break
            except asyncio.CancelledError:
                residual = await asyncio.shield(asyncio.to_thread(self._reap, run, root_alive=True))
                safe_to_delete = not residual
                raise
            # code review round 1 P1-5: once ``process.wait()`` has returned, the child is
            # reaped and its pid may already belong to someone else — never signal it then
            residual = await asyncio.to_thread(self._reap, run, root_alive=not waiter.done())
            safe_to_delete = not residual
            returncode = await waiter
            try:
                await asyncio.wait_for(reader, timeout=2.0)
            except TimeoutError:  # a survivor still holds the pipe: keep what was read
                reader.cancel()
        finally:
            run.close(clean=safe_to_delete)
            if recorded:
                self._record_finish(run.execution_id, "residual" if residual else "exited")
        if limit is None and returncode == -signal.SIGXCPU:
            limit = "cpu"
        output, truncated = tail.text()
        return ExecutionReceipt(
            execution_id=run.execution_id,
            kind=self.kind,
            isolated=self.isolated,
            environment_digest=self.environment_digest,
            effective_limits=spec.effective_limits(isolated=self.isolated),
            exit_code=None if timed_out else returncode,
            output=output,
            truncated=truncated,
            timed_out=timed_out,
            limit_exceeded=limit,
            tree_killed=not residual,
            residual_pids=tuple(sorted(residual)),
            status="ok" if not residual else "error",
        )

    def _record_start(self, run: _Run, command: Sequence[str], pid: int) -> bool:
        """子进程一起来就把身份与回收材料落账（§14.4）。账本写不进去：先把刚起的进程组收掉，
        再报不可用——不留没有回收材料的子进程。没有账本（单测直接用执行器）就不记。"""

        if self.ledger is None:
            return False
        try:
            identity = process_identity(pid) or {}
            self.ledger.record_start({
                "execution_id": run.execution_id, "kind": self.kind, "root_pid": pid,
                "process_group": identity.get("process_group"), "session_id": identity.get("session_id"),
                "process_started_at": identity.get("process_started_at"), "command": list(command),
                "cwd": str(run.cwd), "scratch": str(run.scratch),
            })
        except Exception as error:  # noqa: BLE001 - the ledger is what makes the run recoverable
            self._reap(run, root_alive=True)
            raise SandboxUnavailable("sandbox execution ledger unavailable") from error
        return True

    def _record_finish(self, execution_id: str, outcome: str) -> None:
        if self.ledger is None:
            return
        try:
            self.ledger.record_finish(execution_id, outcome)
        except Exception:  # noqa: BLE001 - the run is over; an unfinished row is reclaimed at restart
            pass

    def _sample(self, run: _Run) -> tuple[set[int], int]:
        members = self._members(run)
        run.seen |= members
        rss = sum(p.rss_kb for p in run.table if p.pid in members) * 1024
        return members, rss

    def _reap(self, run: _Run, *, root_alive: bool = True) -> set[int]:
        """Kill every process of the run, sweep again until none is left or the sweeps
        run out; what is still alive afterwards is returned (``tree_killed`` = empty).

        ``root_alive`` says whether the run's own process is still running.  After a normal
        exit it is not, and its pid may have been handed to an unrelated process — signalling
        the group then could kill a stranger (code review round 1 P1-5)."""

        for _ in range(self._max_sweeps):
            if root_alive and run.root_pid is not None:
                try:
                    os.killpg(run.root_pid, signal.SIGKILL)  # the run's own group
                except (ProcessLookupError, PermissionError):
                    pass
                _sigkill(run.root_pid)
            root_alive = False  # after one sweep the run's own process is gone either way
            survivors = self._survivors(run)
            if not survivors:
                return set()
            for pid in survivors:
                self._kill(pid)
            time.sleep(0.05)
        return self._survivors(run)


@dataclass
class _Run:
    execution_id: str
    cwd: Path
    scratch: Path
    marks: Path  # canary / decoy: outside every write path of the run
    user: str
    root_pid: int | None = None
    seen: set[int] = field(default_factory=set)
    table: list[_Proc] = field(default_factory=list)
    index: Path | None = None
    owner_fd: int | None = None
    identity: dict[str, Any] | None = None

    @property
    def canary(self) -> Path:
        return self.marks / "canary"

    @property
    def decoy(self) -> Path:
        return self.marks / "decoy"

    @classmethod
    def start(cls, exec_root: Path, cwd: Path) -> _Run:
        exec_root = exec_root.resolve()
        exec_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        execution_id = uuid.uuid4().hex
        scratch = exec_root / execution_id
        marks = exec_root / f"{execution_id}.marks"
        (scratch / "tmp").mkdir(parents=True, mode=0o700)
        marks.mkdir(mode=0o700)
        (marks / "canary").write_text("canary", encoding="utf-8")
        (marks / "decoy").write_text("decoy", encoding="utf-8")
        return cls(execution_id, cwd, scratch, marks, pwd.getpwuid(os.getuid()).pw_name)

    def register(self, kind: str, environment_digest: str) -> None:
        # Outside cwd/scratch: sandbox children cannot erase their recovery identity.
        registry = self.cwd.parent / SANDBOX_RUNS
        registry.mkdir(mode=0o700, exist_ok=True)
        self.index = registry / f"{self.execution_id}.run.json"
        self.owner_fd = os.open(self.marks / "owner.lock", os.O_CREAT | os.O_RDWR, 0o600)
        fcntl.flock(self.owner_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        body = {
            "schema_version": 1,
            "execution_id": self.execution_id,
            "kind": kind,
            "uid": os.getuid(),
            "cwd": str(self.cwd),
            "scratch": str(self.scratch),
            "marks": str(self.marks),
            "environment_digest": environment_digest,
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        }
        self.identity = {**body, "identity_sha256": _digest(body)}
        try:
            _durable_json(self.marks / "identity.json", self.identity)
            _durable_json(self.index, self.identity)
        except BaseException:
            os.close(self.owner_fd)
            self.owner_fd = None
            raise

    def close(self, *, clean: bool = True) -> None:
        try:
            if clean:
                if self.index is not None and self.identity is not None:
                    _finish_sandbox_cleanup(self.index, self.identity, mode="live")
                else:
                    shutil.rmtree(self.scratch, ignore_errors=True)
                    shutil.rmtree(self.marks, ignore_errors=True)
            # An uncertain/error run deliberately retains marks, identity and cwd.
        finally:
            if self.owner_fd is not None:
                os.close(self.owner_fd)
                self.owner_fd = None


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode("utf-8")).hexdigest()


# Durable discovery lives beside execution copies, never in a child's writable tree.
SANDBOX_RUNS = ".sandbox-runs"


def _durable_json(path: Path, body: Mapping[str, Any]) -> None:
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(body, stream, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _cleanup_receipt(index: Path) -> Path:
    return index.with_name(index.name.replace(".run.json", ".cleanup.json"))


def _record_cleanup(index: Path, receipt: dict[str, Any]) -> None:
    # Keep previous failed/uncertain attempts when a later cold retry succeeds.
    history = index.with_name(index.stem + "." + uuid.uuid4().hex + ".cleanup.json")
    _durable_json(history, receipt)
    _durable_json(_cleanup_receipt(index), receipt)


def _finish_sandbox_cleanup(index: Path, identity: dict[str, Any], *, mode: str) -> dict[str, Any]:
    receipt = {"status": "reaped", "mode": mode, "identity": identity, "residual_pids": []}
    # Commit proof first: a crash during directory deletion can resume this exact cleanup.
    _record_cleanup(index, receipt)
    for key in ("scratch", "marks"):
        target = Path(identity[key])
        try:
            shutil.rmtree(target)
        except FileNotFoundError:
            pass  # another cleanup may have completed the same durable proof
    index.unlink(missing_ok=True)
    return receipt


def _sandbox_members(run: _Run, *, uid_only: bool = True, timeout: float = 2) -> set[int]:
    check = _sandbox_check()
    run.table = _process_table(strict=True, timeout=timeout)
    members = set()
    for proc in run.table:
        if proc.zombie or proc.pid == os.getpid() or (uid_only and proc.uid != os.getuid()):
            continue
        allowed, denied = check(proc.pid, str(run.canary)), check(proc.pid, str(run.decoy))
        if allowed == 0 and denied == 1:
            members.add(proc.pid)
        elif allowed not in (0, 1) or denied not in (0, 1):
            try:
                os.kill(proc.pid, 0)
            except ProcessLookupError:
                continue  # exited between ps and sandbox_check
            raise SandboxUnavailable("sandbox identity query unavailable")
    return members


def pending_workspace_executions(root: Path, cwd: Path) -> bool:
    """Deletion must not erase a still-live or unclassified execution's only copy."""
    for index in (root / SANDBOX_RUNS).glob("*.run.json"):
        try:
            identity = json.loads(index.read_text())
            if not isinstance(identity, dict):
                return True
            body = {key: value for key, value in identity.items() if key != "identity_sha256"}
            if _digest(body) != identity.get("identity_sha256"):
                return True
            if identity["cwd"] == str(cwd.resolve()):
                return True
        except (OSError, ValueError, KeyError, TypeError):
            return True  # cannot assign the damaged identity safely; retain copies
    return False


def recover_workspace_executions(
    root: Path,
    *,
    kill: Callable[[int], None] | None = None,
    max_sweeps: int = 6,
    timeout_seconds: float = 5,
) -> list[dict[str, Any]]:
    """Cold seatbelt cleanup, with no PID/parent-tree authority from the dead host.

    Each active executor holds a non-inherited flock. Only an orphan can be claimed;
    every signal is based on the original canary/decoy sandbox identity. Failed scans
    or surviving members retain the identity and copy, with an explicit receipt.
    """
    reports: list[dict[str, Any]] = []
    root = root.resolve()
    for index in sorted((root / SANDBOX_RUNS).glob("*.run.json")):
        descriptor = None
        identity: dict[str, Any] = {}
        residual: set[int] = set()
        try:
            identity = json.loads(index.read_text())
            if not isinstance(identity, dict):
                raise ValueError("invalid sandbox recovery record")
            body = {key: value for key, value in identity.items() if key != "identity_sha256"}
            execution_id = identity["execution_id"]
            cwd, scratch, marks = (Path(identity[key]) for key in ("cwd", "scratch", "marks"))
            if (
                identity["schema_version"] != 1
                or identity["kind"] != "seatbelt"
                or identity["uid"] != os.getuid()
                or _digest(body) != identity["identity_sha256"]
                or index.name != f"{execution_id}.run.json"
                or cwd.parent != root
                or scratch.name != execution_id
                or marks != scratch.with_name(execution_id + ".marks")
                or any(path.is_symlink() for path in (index, cwd, scratch, marks))
            ):
                raise ValueError("invalid sandbox recovery identity")
            prior_paths = [
                _cleanup_receipt(index),
                *index.parent.glob(index.stem + ".*.cleanup.json"),
            ]
            reaped = False
            for prior_path in prior_paths:
                if prior_path.exists():
                    prior = json.loads(prior_path.read_text())
                    if prior.get("status") == "reaped" and prior.get("identity") == identity:
                        reaped = True
                        break
            if reaped:
                reports.append(_finish_sandbox_cleanup(index, identity, mode="resume_cleanup"))
                continue
            descriptor = os.open(marks / "owner.lock", os.O_RDWR | os.O_NOFOLLOW)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                reports.append({"status": "active", "identity": identity, "residual_pids": []})
                continue
            if json.loads((marks / "identity.json").read_text()) != identity:
                raise ValueError("sandbox recovery identity differs from original marks")
            if not all((marks / name).is_file() for name in ("canary", "decoy")):
                raise ValueError("original sandbox identity marks are missing")
            run = _Run(execution_id, cwd, scratch, marks, pwd.getpwuid(os.getuid()).pw_name)
            deadline = time.monotonic() + timeout_seconds
            for sweep in range(max_sweeps + 1):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("sandbox cleanup deadline exceeded")
                residual = _sandbox_members(run, timeout=min(2, remaining))
                if not residual:
                    reports.append(_finish_sandbox_cleanup(index, identity, mode="cold"))
                    break
                if sweep == max_sweeps:
                    report = {
                        "status": "residual",
                        "identity": identity,
                        "residual_pids": sorted(residual),
                    }
                    _record_cleanup(index, report)
                    reports.append(report)
                    break
                check = _sandbox_check()
                for pid in residual:
                    # Recheck immediately before signalling: never trust a recycled PID.
                    if check(pid, str(run.canary)) == 0 and check(pid, str(run.decoy)) == 1:
                        (kill or _sigkill)(pid)
                time.sleep(0.05)
        except (OSError, ValueError, KeyError, TypeError, SandboxUnavailable) as error:
            report = {
                "status": "unknown",
                "identity": identity,
                "residual_pids": sorted(residual),
                "reason": type(error).__name__,
            }
            _record_cleanup(index, report)
            reports.append(report)
        finally:
            if descriptor is not None:
                os.close(descriptor)
    return reports


# ------------------------------------------------------------------ process only
class ProcessOnlyExecutor(_Executor):
    """No sandbox: a child in its own session with the hard rlimits, reaped along the
    parent chain and by the processes holding its directory.  For trusted code only."""

    kind = "process_only"
    isolated = False

    def __init__(self, interpreter: str | None = None, **options: Any) -> None:
        options.setdefault("poll_interval", 0.1)
        super().__init__(interpreter, **options)

    @property
    def usable(self) -> bool:
        return True

    def _members(self, run: _Run) -> set[int]:
        run.table = _process_table()
        if run.root_pid is None:
            return set()
        alive = {p.pid for p in run.table if not p.zombie}
        return _descendants(run.table, run.root_pid) & alive

    def _survivors(self, run: _Run) -> set[int]:
        run.table = _process_table()
        alive = {p.pid for p in run.table if not p.zombie and p.uid == os.getuid()}
        found = set(run.seen)
        if run.root_pid is not None:
            found |= _descendants(run.table, run.root_pid)
        found |= _holding(run.cwd)
        found.discard(os.getpid())
        return found & alive


def _holding(directory: Path) -> set[int]:
    """Processes of this user whose cwd or an open file lies in ``directory``."""

    if not Path(LSOF).exists():
        return set()
    try:
        # bounded on purpose: a reap runs this once per sweep, and on a loaded machine an
        # unbounded scan made a single reap take over a minute (wheel verification 0.10.0).
        # Missing a slow answer costs a sweep, never correctness — the pid set only grows.
        out = subprocess.run(
            [LSOF, "-t", "-u", str(os.getuid()), "-a", "+D", str(directory)],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return set()
    return {int(line) for line in out.split() if line.strip().isdigit()}


# ------------------------------------------------------------------ seatbelt
_CHECK: Callable[[int, str], int] | None = None


def _sandbox_check() -> Callable[[int, str], int]:
    """``sandbox_check(pid, "file-read-data", PATH | NO_REPORT, path)``: 0 allowed, 1 denied
    (an undocumented libsystem_sandbox export, used the way WebKit and Chromium do)."""

    global _CHECK
    if _CHECK is None:
        library = ctypes.CDLL("/usr/lib/system/libsystem_sandbox.dylib")
        no_report = ctypes.c_int.in_dll(library, "SANDBOX_CHECK_NO_REPORT").value
        function = library.sandbox_check
        function.restype = ctypes.c_int
        function.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int]  # fixed part only
        filter_path = 1  # SANDBOX_FILTER_PATH

        def check(pid: int, path: str) -> int:
            target = ctypes.c_char_p(os.fsencode(path))  # the variadic argument, typed
            return int(function(pid, b"file-read-data", filter_path | no_report, target))

        _CHECK = check
    return _CHECK


def _quote(path: str | Path) -> str:
    return json.dumps(str(path))  # an SBPL string literal


def _interpreter_facts(interpreter: str) -> dict[str, Any]:
    probe = (
        "import json, os, sys; print(json.dumps({'prefix': sys.prefix, 'base': sys.base_prefix,"
        " 'executable': sys.executable, 'path': sys.path, 'version': sys.version}))"
    )
    try:
        done = subprocess.run(
            [interpreter, "-I", "-c", probe],
            cwd="/",
            env={"PATH": DEFAULT_PATH},
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        return json.loads(done.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as error:
        message = f"cannot inspect the interpreter {interpreter}: {error}"
        raise SandboxUnavailable(message) from error


class SeatbeltExecutor(_Executor):
    kind = "seatbelt"
    isolated = True

    def __init__(
        self,
        interpreter: str,
        *,
        read_paths: Sequence[str],
        python_version: str = "",
        **options: Any,
    ) -> None:
        if sys.platform != "darwin" or not Path(SANDBOX_EXEC).exists():
            raise SandboxUnavailable("the seatbelt sandbox needs macOS sandbox-exec")
        options.setdefault("poll_interval", 0.25)
        super().__init__(interpreter, **options)
        self._read_paths = tuple(dict.fromkeys(read_paths))
        self._python_version = python_version
        self.probe_report: ProbeReport | None = None
        try:
            _sandbox_check()
        except (OSError, AttributeError, ValueError) as error:
            raise SandboxUnavailable(f"sandbox_check is not available: {error}") from error

    @classmethod
    def for_interpreter(
        cls,
        interpreter: str | None = None,
        *,
        extra_read_paths: Sequence[str] = (),
        **options: Any,
    ) -> SeatbeltExecutor:
        """The read whitelist comes from the interpreter the runs use (review round 2
        P2-9): its prefix, base prefix, the directory of its real executable and every
        existing ``sys.path`` entry (``.pth`` paths included) — plus the system paths."""

        chosen = str(interpreter or sys.executable)
        facts = _interpreter_facts(chosen)
        paths: list[str] = list(SYSTEM_READ_PATHS)
        for raw in (
            facts["prefix"],
            facts["base"],
            os.path.dirname(os.path.realpath(facts["executable"])),
            os.path.dirname(os.path.realpath(chosen)),
            *facts["path"],
        ):
            if raw and raw != "/" and os.path.exists(raw):
                paths.append(os.path.realpath(raw))
        paths.extend(os.path.realpath(p) for p in extra_read_paths)
        return cls(chosen, read_paths=paths, python_version=str(facts["version"]), **options)

    @property
    def base_read_paths(self) -> tuple[str, ...]:
        return self._read_paths

    @property
    def usable(self) -> bool:
        return (
            self.probe_report is not None
            and self.probe_report.ok
            and self.probe_report.environment_digest == self.environment_digest
        )

    def _identity(self) -> dict[str, Any]:
        return {
            "interpreter": os.path.realpath(self.interpreter),
            "python": self._python_version,
            "read_paths": list(self._read_paths),
            "profile": _profile("<cwd>", "<scratch>", "<canary>", self._read_paths),
        }

    def _argv(self, command: Sequence[str], run: _Run) -> list[str]:
        profile = _profile(run.cwd, run.scratch, run.canary, self._read_paths)
        return [SANDBOX_EXEC, "-p", profile, *command]

    def _identified(self, run: _Run, *, uid_only: bool = True) -> set[int]:
        return _sandbox_members(run, uid_only=uid_only)

    def _members(self, run: _Run) -> set[int]:
        return self._identified(run)

    def _survivors(self, run: _Run) -> set[int]:
        return self._identified(run)


def _profile(cwd: Any, scratch: Any, canary: Any, read_paths: Sequence[str]) -> str:
    reads = " ".join(f"(subpath {_quote(p)})" for p in read_paths)
    devices = " ".join(f"(literal {_quote(p)})" for p in DEVICE_READ_LITERALS)
    return (
        "(version 1)\n"
        "(allow default)\n"
        "(deny network*)\n"
        '(deny file-read-data (subpath "/"))\n'
        f'(allow file-read-data (literal "/") {devices} {reads} '
        f"(subpath {_quote(cwd)}) (subpath {_quote(scratch)}) (literal {_quote(canary)}))\n"
        '(deny file-write* (subpath "/"))\n'
        f"(allow file-write* (subpath {_quote(cwd)}) (subpath {_quote(scratch)}) "
        '(literal "/dev/null"))\n'
        "(deny signal)\n"
        "(allow signal (target same-sandbox))\n"
        "(deny mach-lookup)\n"
        "(deny process-info* (target others))\n"
    )


# ------------------------------------------------------------------ the capability probe
@dataclass(frozen=True, slots=True)
class ProbeReport:
    ok: bool
    items: tuple[dict[str, Any], ...]
    targets: tuple[str, ...]
    disjoint: bool
    environment_digest: str

    def to_json(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "items": [dict(item) for item in self.items],
            "targets": list(self.targets),
            "disjoint": self.disjoint,
            "environment_digest": self.environment_digest,
            "version": SANDBOX_VERSION,
        }


_ACCESS_PROBE = """
import json, os, socket, sys
cfg = json.loads(sys.argv[1])
out = {}
def attempt(name, fn):
    try:
        fn()
        out[name] = "ALLOWED"
    except Exception as error:
        out[name] = type(error).__name__
attempt("read_home", lambda: os.listdir(cfg["home"]))
attempt("read_other_temp", lambda: open(cfg["secret"]).read())
attempt("write_outside", lambda: open(cfg["escape"], "w").write("x"))
attempt("network_tcp", lambda: socket.create_connection(("127.0.0.1", cfg["port"]), timeout=2))
def unix():
    s = socket.socket(socket.AF_UNIX)
    s.connect(cfg["unix"])
attempt("network_unix", unix)
attempt("signal_host", lambda: os.kill(cfg["host_pid"], 0))
open("probe.json", "w").write(json.dumps(out))
"""
_DAEMON_PROBE = """
import os, sys, time
if os.fork() == 0:
    os.setsid()
    if os.fork() == 0:
        open("daemon.pid", "w").write(str(os.getpid()))
        os.chdir("/")
        os.closerange(0, 256)
        time.sleep(600)
    os._exit(0)
time.sleep(0.5)
"""


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _under(path: str, roots: Sequence[str]) -> bool:
    resolved = Path(path).resolve()
    return any(resolved == Path(r) or Path(r) in resolved.parents for r in roots)


async def probe_sandbox(executor: SeatbeltExecutor) -> ProbeReport:
    """Eight behavioural checks (plan v3 D1); any miss makes the adapter unusable.  Every
    target is computed here, apart from the read whitelist, and must lie outside it."""

    home = str(Path.home().resolve())
    with (
        tempfile.TemporaryDirectory(prefix="orch-probe-other-") as raw_other,
        tempfile.TemporaryDirectory(prefix="orch-probe-ws-") as raw_ws,
    ):
        other = Path(raw_other).resolve()
        workdir = Path(raw_ws).resolve()
        secret = other / "secret.txt"
        secret.write_text(PROBE_SECRET, encoding="utf-8")
        escape = other / "escape.txt"
        unix_path = other / "u.sock"
        targets = (home, str(other), str(secret), str(escape), str(unix_path))
        disjoint = not any(_under(t, executor.base_read_paths) for t in targets)
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        unix = socket.socket(socket.AF_UNIX)
        unix.bind(str(unix_path))
        unix.listen(1)
        items: list[dict[str, Any]] = []
        try:
            cfg = {
                "home": home,
                "secret": str(secret),
                "escape": str(escape),
                "port": listener.getsockname()[1],
                "unix": str(unix_path),
                "host_pid": os.getpid(),
            }
            script = workdir / "access_probe.py"
            script.write_text(_ACCESS_PROBE, encoding="utf-8")
            receipt = await executor.execute(
                [executor.interpreter, str(script), json.dumps(cfg)],
                cwd=str(workdir),
                spec=SandboxSpec(cpu_seconds=30, wall_seconds=60),
            )
            try:
                seen = json.loads((workdir / "probe.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                seen = {}

            def denied(name: str) -> bool:
                return seen.get(name) == "PermissionError"

            for name, ok in (
                ("read_home", denied("read_home")),
                ("read_other_temp", denied("read_other_temp")),
                ("write_outside", denied("write_outside") and not escape.exists()),
                ("network", denied("network_tcp") and denied("network_unix")),
                ("signal_host", denied("signal_host")),
            ):
                items.append(
                    {
                        "name": name,
                        "ok": bool(ok) and receipt.exit_code == 0,
                        "observed": {k: v for k, v in seen.items() if k.startswith(name[:7])}
                        or seen.get(name),
                    }
                )
            script = workdir / "daemon_probe.py"
            script.write_text(_DAEMON_PROBE, encoding="utf-8")
            receipt = await executor.execute(
                [executor.interpreter, str(script)],
                cwd=str(workdir),
                spec=SandboxSpec(cpu_seconds=30, wall_seconds=30),
            )
            try:
                daemon = int((workdir / "daemon.pid").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                daemon = None
            gone = daemon is not None and not _alive(daemon)
            if daemon is not None and not gone:
                _sigkill(daemon)
            items.append(
                {
                    "name": "daemon_reaped",
                    "ok": gone and receipt.tree_killed,
                    "observed": {"pid": daemon, "tree_killed": receipt.tree_killed},
                }
            )
            receipt = await executor.execute(
                [executor.interpreter, "-c", "import sys; sys.stdout.write('x' * 100000)"],
                cwd=str(workdir),
                spec=SandboxSpec(cpu_seconds=30, wall_seconds=30, max_output_bytes=4096),
            )
            items.append(
                {
                    "name": "output_truncated",
                    "ok": receipt.truncated and len(receipt.output.encode()) <= 4096,
                    "observed": {"truncated": receipt.truncated},
                }
            )
            receipt = await executor.execute(
                [executor.interpreter, "-c", "while True:\n    pass"],
                cwd=str(workdir),
                spec=SandboxSpec(cpu_seconds=1, wall_seconds=30),
            )
            items.append(
                {
                    "name": "cpu_killed",
                    "ok": receipt.limit_exceeded == "cpu" and not receipt.timed_out,
                    "observed": {"limit_exceeded": receipt.limit_exceeded},
                }
            )
        finally:
            listener.close()
            unix.close()
    report = ProbeReport(
        ok=disjoint and all(item["ok"] for item in items),
        items=tuple(items),
        targets=targets,
        disjoint=disjoint,
        environment_digest=executor.environment_digest,
    )
    executor.probe_report = report
    return report


# ------------------------------------------------------------------ resolving a deployment
def resolve_executor(deployment: Any, executor: Any = None) -> SandboxExecutorPort | None:
    """The executor a deployment runs model-written code with (plan v3 D2): ``off`` →
    none; ``process_only`` → the given one or a process executor; ``sandboxed`` → only a
    seatbelt executor whose probe passed on this very environment."""

    mode = getattr(deployment, "code_execution", "process_only")
    if mode == "off":
        return None
    if mode == "sandboxed":
        if not isinstance(executor, SeatbeltExecutor):
            raise SandboxUnavailable(
                "code_execution='sandboxed' needs a SeatbeltExecutor whose probe passed"
            )
        if not executor.usable:
            raise SandboxUnavailable("the seatbelt executor has not passed its probe here")
        return executor
    return executor if executor is not None else ProcessOnlyExecutor()


__all__ = (
    "ExecutionReceipt",
    "ProbeReport",
    "ProcessOnlyExecutor",
    "SANDBOX_VERSION",
    "SandboxExecutionLedger",
    "SandboxExecutorPort",
    "SandboxSpec",
    "SandboxUnavailable",
    "SeatbeltExecutor",
    "identity_matches",
    "probe_sandbox",
    "process_identity",
    "reclaim_recorded_executions",
    "resolve_executor",
)
