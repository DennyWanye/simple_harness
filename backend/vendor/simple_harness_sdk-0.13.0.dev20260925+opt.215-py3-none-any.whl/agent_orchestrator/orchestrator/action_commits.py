# SPDX-FileCopyrightText: 2026 DennyWanye
# SPDX-License-Identifier: Apache-2.0

"""The Commit Service's step-7 half: the action ledger and the approvals (plan D7-2 /
D7-4 / D7-5 / D7-9).  It is a mixin of ``CommitService`` so the single-writer rule holds:
every row of ``actions`` / ``approvals`` / ``approval_decisions`` / ``human_overrides`` and
every related event is written here, inside a Store transaction.

Action states (this build's convention, plan §6.1; the vocabulary follows the SDK's tool
effects): PROPOSED (L0/L1, runs without approval) · AWAITING_APPROVAL · APPROVED ·
HANDED_OFF · SUCCEEDED · FAILED · UNKNOWN · REJECTED · REVOKED · EXPIRED · SUPERSEDED ·
REFUSED.  Approval request states: PENDING · GRANTED · REJECTED · REVOKED · EXPIRED ·
SUPERSEDED."""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Mapping, Sequence
from typing import TYPE_CHECKING, Any, cast

from simple_harness.contracts import canonical_json

from ..contracts import ContractError, MissionStatus
from ..contracts.error_table import HANDOFF_VALIDITY_STALE
from ..contracts.operation_payloads import OperationParametersV1
from ..deployment.root import current_statements
from ..governance.budgets import BudgetError, BudgetExhausted
from ..governance.permissions import (
    Principal,
    binding_matches,
    binding_of,
    decision_receipt_hash,
)
from ..governance.policies import ActionDecision, DeploymentPolicy, action_decision
from ..runtime import planning_operations
from ..runtime.action_params import PUBLISH, bind_artifact_refs
from ..runtime.action_schema import (
    BOUND_ARTIFACT_FIELDS,
    CANDIDATE_FIELDS,
    parse_action_criterion,
)
from ..runtime.connectors import Receipt, human_ruling_receipt, level_rank, params_hash
from ..runtime.operation_reconciliation import nonapplication_outcome, stored_negative_proof
from ..runtime.operation_ref_resolver import (
    OperationReferenceResolver,
    OperationReferenceUnavailable,
)
from ..runtime.planning_operations import BoundPlanningOperationOrigin
from ..storage import htn_store
from ..storage.operation_intent_store import OperationIntentStore
from ..storage.planning_admission_store import PlanningAdmissionStore
from ..storage.store import StoreConflict
from . import step_actions
from .assurance_point_use import (
    ACTION_CONSUMER,
    EvidenceClaim,
    certify_point_use_locked,
    record_point_use_locked,
)
from .budget_accounts import mission_account
from .taskgraph_dispatch import require_taskgraph_unfenced

if TYPE_CHECKING:
    from ..contracts import Event
    from ..governance.budgets import BudgetLedger
    from ..storage.store import Store
    from .operation_materialization import OperationMaterializationRuntime

OPEN_ACTION_STATES = frozenset({"PROPOSED", "AWAITING_APPROVAL", "APPROVED"})
IN_FLIGHT_ACTION_STATES = frozenset({"HANDED_OFF", "UNKNOWN"})
CLOSED_ACTION_STATES = frozenset(
    {"SUCCEEDED", "FAILED", "REJECTED", "REVOKED", "EXPIRED", "SUPERSEDED", "CANCELLED", "REFUSED"}
)
HANDOFF_READY_STATES = frozenset({"APPROVED", "PROPOSED"})
MAX_HANDOFFS_PER_ACTION = 2  # one hand-off + at most one re-hand-off (SDK rehandoff_count <= 1)
OUTCOME_EVENTS = {
    "SUCCEEDED": "ActionSucceeded",
    "FAILED": "ActionFailed",
    "UNKNOWN": "ActionOutcomeUnknown",
}


def _decision_source(principal: Any, decision: str, nonce: str, approval_source: str) -> bool:
    """决定的形状：调用方身份、决定种类、去重号、来源；返回是不是主机代批。"""

    if not isinstance(principal, Principal):
        raise ActionCommitError("a decision needs an authenticated Principal from the caller")
    if decision not in {"grant", "reject"}:
        raise ActionCommitError(f"unknown decision {decision!r}")
    if approval_source not in {"HUMAN", "HOST_AUTO_PERMISSION"}:
        raise ActionCommitError(f"unknown approval source {approval_source!r}")
    automatic = approval_source == "HOST_AUTO_PERMISSION"
    if automatic and decision != "grant":
        raise ActionCommitError("the host only grants on the user's behalf")
    if not nonce.strip():
        raise ActionCommitError("a decision needs a nonce")
    return automatic


class ActionCommitError(RuntimeError):
    """A decision or transition the ledger refuses (nothing was written)."""


class CandidateRejected(ContractError):
    """A candidate the policy, the Mission's scope or the schema does not allow (plan
    D7-2'' / D7-3').  Verification FAILs on it; accept re-checks and fails the result."""

    def __init__(self, reason: str, detail: str = "") -> None:
        super().__init__(f"{reason}: {detail}" if detail else reason)
        self.reason = reason


def validate_candidate(candidate: Mapping[str, Any]) -> dict[str, Any]:
    """申请单（系统按已批准效果生成的 candidate）的字段形状；别的都不是申请单。"""

    if not isinstance(candidate, Mapping):
        raise ContractError("an action candidate must be a JSON object")
    missing = [name for name in CANDIDATE_FIELDS if name not in candidate]
    if missing:
        raise ContractError(f"action candidate lacks {missing}")
    extra = sorted(set(candidate) - set(CANDIDATE_FIELDS))
    if extra:  # e.g. "approved", "level", "idempotency_key" — never the model's to set
        raise ContractError(f"action candidate has unknown fields {extra}")
    for name in ("connector", "operation", "target", "reason"):
        if not isinstance(candidate[name], str) or not candidate[name].strip():
            raise ContractError(f"action candidate field {name!r} must be a non-empty string")
    if not isinstance(candidate["params"], Mapping):
        raise ContractError("action candidate field 'params' must be an object")
    return {name: candidate[name] for name in CANDIDATE_FIELDS}


def _normalize(connector: Any, target: str) -> str:
    normalize = getattr(connector, "normalize_target", None)
    return str(normalize(target)) if callable(normalize) else target.strip()


def allowed_actions(
    criteria: Sequence[str], connectors: Mapping[str, Any]
) -> set[tuple[str, str, str]]:
    """The Mission charter's action scope = its action criteria, normalised (D7-3')."""

    allowed = set()
    for criterion in criteria:
        parsed = parse_action_criterion(criterion)
        if parsed is not None:
            name, operation, target = parsed
            allowed.add((name, operation, _normalize(connectors.get(name), target)))
    return allowed


def check_candidate(
    candidate: Mapping[str, Any],
    *,
    criteria: Sequence[str],
    connectors: Mapping[str, Any],
    deployment: DeploymentPolicy,
) -> tuple[dict[str, Any], ActionDecision]:
    """Schema, deployment policy and Mission scope, in that order; raises
    ``CandidateRejected`` with a stable reason.  The system's operation preparation and the
    proposal transaction both run it on the exact candidate bytes."""

    try:
        cand = validate_candidate(candidate)
    except ContractError as error:
        raise CandidateRejected("invalid_candidate", str(error)) from error
    connector = connectors.get(cand["connector"])
    decision = action_decision(deployment, connector, cand["operation"])
    if decision.refused is not None:
        raise CandidateRejected(decision.refused, f"{cand['connector']}.{cand['operation']}")
    cand["target"] = _normalize(connector, cand["target"])
    triple = (cand["connector"], cand["operation"], cand["target"])
    if triple not in allowed_actions(criteria, connectors):
        raise CandidateRejected("action_out_of_scope", ".".join(triple[:2]) + ":" + triple[2])
    return cand, decision


def bind_artifact_params(params: Mapping[str, Any], artifacts: Mapping[str, Any]) -> dict[str, Any]:
    """Bind which Artifact an action publishes (P3.2 plan v3 D6).

    A candidate may name *which* file of its own Result to act on (``artifact_path``); it
    may never state that file's identity.  The system fills in the id, the content hash,
    the size and where the bytes are stored from this very Result's accepted Artifacts, so
    ``params_hash`` — and with it the approval — is bound to those exact bytes.
    """

    bound = dict(params)
    # unconditional (code review round 1 P2-4): a candidate may not state an Artifact's
    # identity even when it names no artifact_path at all
    set_by_model = sorted(BOUND_ARTIFACT_FIELDS & set(bound))
    if set_by_model:
        raise CandidateRejected(
            "invalid_candidate", f"a candidate may not set {set_by_model}: the system binds them"
        )
    path = bound.get("artifact_path")
    if path is None:
        return bound
    if not isinstance(path, str) or not path.strip():
        raise CandidateRejected("invalid_candidate", "artifact_path must be a non-empty string")
    artifact = artifacts.get(path.strip())
    if artifact is None:
        raise CandidateRejected("artifact_not_in_result", str(path))
    bound.update(
        artifact_path=artifact.path,
        artifact_id=artifact.id,
        content_hash=artifact.content_hash,
        size=artifact.size_bytes,
        storage_uri=artifact.storage_uri,
    )
    return bound


def bind_operation_params(
    candidate: Mapping[str, Any], artifacts: Mapping[str, Any]
) -> dict[str, Any]:
    """申请单参数的绑定，只这一处：文件发布按 ``bind_artifact_params`` 平铺绑定；应用连接器把
    参数里的 ``{"$artifact": 路径}`` 换成产物引用（``bind_artifact_refs``）。准备申请单与建动作
    两处都调它，两边算出的参数与哈希才对得上。"""

    if (str(candidate["connector"]), str(candidate["operation"])) == PUBLISH:
        return bind_artifact_params(candidate["params"], artifacts)
    try:
        return dict(bind_artifact_refs(candidate["params"], artifacts))
    except ContractError as error:
        raise CandidateRejected("artifact_not_in_result", str(error)) from error


def judgment_key(tasks: Sequence[Any]) -> str:
    """D7-7' ①: the integrated tree is fixed by the live Tasks' accepted results."""

    raw = "|".join(sorted(f"{task.id}={task.accepted_result_id}" for task in tasks))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def business_action_id(mission_id: str, connector: str, operation: str, target: str) -> str:
    """ORCH §12.3 stable business action id: the same Mission doing the same operation on
    the same target is the same real-world action across Attempts (plan D7-2)."""

    raw = "\x1f".join((mission_id, connector, operation, target))
    return "action-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def receipt_mismatch(action: Mapping[str, Any], receipt: Receipt | None) -> str | None:
    """A receipt counts only when it names this very action version (D7-5 ③)."""

    if receipt is None:
        return "missing"
    for name in ("idempotency_key", "params_hash", "target", "connector", "operation"):
        if getattr(receipt, name) != action.get(name):
            return name
    return None


class ActionCommitsMixin:
    if TYPE_CHECKING:
        _store: Store
        # Bound by ``OperationMaterializationCommitsMixin.bind_operation_materialization_runtime``.
        _operation_materialization_runtime: OperationMaterializationRuntime | None
        _ledger: BudgetLedger

        def _validate_source_binding(self, request: Mapping[str, Any]) -> None: ...

        def _validate_source_approval(self, request: Mapping[str, Any]) -> None: ...

        def _apply_source_approval(self, request: dict[str, Any], principal: Principal) -> None: ...

        def _settle_subject(
            self,
            subject_id: str,
            mission_id: str,
            *,
            task_id: str | None,
            tool_calls: int | None = None,
        ) -> Mapping[str, Any]: ...

        def record_reservation_held(
            self, subject_id: str, mission_id: str, *, task_id: str | None, reason: str
        ) -> Event: ...

        def _emit(
            self,
            event_type: str,
            mission_id: str,
            *,
            key: str,
            task_id: str | None = None,
            attempt_id: str | None = None,
            payload: Mapping[str, Any] | None = None,
            actor_type: str = ...,
            actor_id: str = ...,
        ) -> Event: ...

        def record_human_nonapplication(
            self, action_key: str, *, override: dict[str, Any], principal_id: str
        ) -> dict[str, Any]: ...

    # ------------------------------------------------------------ proposals
    def propose_action(
        self,
        candidate: Mapping[str, Any],
        *,
        mission_id: str,
        task_id: str,
        result_id: str,
        attempt_id: str,
        artifact_id: str,
        artifact_hash: str,
        connectors: Mapping[str, Any],
        deployment: DeploymentPolicy,
        planning_origin: BoundPlanningOperationOrigin | None = None,
        operation_parameters: Any | None = None,
        reason_source: str = "model (untrusted)",
    ) -> dict[str, Any]:
        """Register one verified candidate (D7-2 / D7-2').  Policy and scope refusals raise
        ``CandidateRejected`` and write nothing; the ledger's own rules (in flight, already
        executed) write a REFUSED row.  The same content again returns the existing version;
        different content supersedes an *open* version only."""

        with self._store.transaction():
            mission = self._store.get_mission(mission_id)
            if mission is None or mission.status is not MissionStatus.ACTIVE:
                raise CandidateRejected("mission_not_active", mission_id)
            cand, decision = check_candidate(
                candidate,
                criteria=current_statements(self._store, mission),
                connectors=connectors,
                deployment=deployment,
            )
            if operation_parameters is not None:
                frozen = operation_parameters
                if planning_origin is None or not isinstance(frozen, OperationParametersV1):
                    raise CandidateRejected("operation_mapping_incomplete")
                intent = OperationIntentStore(self._store).get(frozen.intent_id)
                if intent is None or (
                    intent["mission_id"],
                    intent["source_result_id"],
                    intent["source_attempt_id"],
                    intent["candidate_artifact_id"],
                    intent["candidate_file_hash"],
                    intent["submission_receipt_id"],
                    intent["parameters_content_hash"],
                ) != (
                    mission_id,
                    result_id,
                    attempt_id,
                    artifact_id,
                    artifact_hash,
                    planning_origin.provenance_receipt_id,
                    frozen.content_hash(),
                ):
                    raise CandidateRejected("operation_origin_identity_mismatch")
                result = self._store.get_result(result_id)
                if result is None:
                    raise CandidateRejected("artifact_not_in_result")
                accepted_pins = {
                    (ref.id, ref.revision, ref.content_hash)
                    for accepted in frozen.accepted_input_refs
                    for ref in htn_store.HtnStore(self._store)
                    .get_acceptance(accepted.id)
                    .artifact_refs
                }
                artifacts = {}
                for output_id in result.artifacts:
                    output = self._store.get_artifact(output_id)
                    if (
                        output is not None
                        and (output.id, output.version, output.content_hash) in accepted_pins
                    ):
                        if output.path in artifacts:
                            raise CandidateRejected(
                                "artifact_not_in_result", "ambiguous accepted path"
                            )
                        artifacts[output.path] = output
                effective = bind_operation_params(cand, artifacts)
                if (
                    cand["connector"],
                    cand["operation"],
                    cand["target"],
                    effective,
                    params_hash(effective),
                ) != (
                    frozen.connector_id,
                    frozen.operation_name,
                    frozen.normalized_target_ref,
                    dict(frozen.effective_params),
                    frozen.params_hash,
                ):
                    raise CandidateRejected("operation_payload_hash_mismatch")
                cand["params"] = effective
            action_id = business_action_id(
                mission_id, cand["connector"], cand["operation"], cand["target"]
            )
            versions = self._store.list_action_versions(action_id)
            live = [v for v in versions if v["state"] != "REFUSED"]
            latest = live[-1] if live else None
            phash = params_hash(cand["params"])

            # 阶段 B 裁决第 1 类: a failed version that left our hands is offered again only
            # once it is proven not to have happened; same content is then a new version,
            # never "the same candidate delivered again".
            handed_failure = (
                latest is not None
                and latest["state"] == "FAILED"
                and int(latest.get("handoffs") or 0) >= 1
            )
            # handed_failure 为真时上面已确认 latest 非空
            proven_failure = handed_failure and stored_negative_proof(
                self._store, cast("dict[str, Any]", latest)
            )
            unproven_failure = handed_failure and not proven_failure
            if (
                latest is not None
                and latest["params_hash"] == phash
                and latest["artifact_hash"] == artifact_hash
                and not proven_failure
                and not unproven_failure
            ):
                if planning_origin is not None:
                    marker = {
                        "operation_id": planning_origin.operation_id,
                        "operation_occurrence_id": planning_origin.operation_occurrence_id,
                        "request_hash": planning_origin.request_hash,
                        "envelope_hash": planning_origin.envelope_hash,
                    }
                    self._link_planning_origin(latest, planning_origin)
                    if latest.get("planning_origin") != marker:
                        latest["planning_origin"] = marker
                        self._store.put_action(latest)
                return latest  # the same candidate delivered again
            refused: str | None = None
            after: str | None = None
            if latest is not None:
                if unproven_failure:
                    refused = "action_outcome_unproven"  # it may have happened: never send again
                elif latest["state"] in IN_FLIGHT_ACTION_STATES:
                    refused = "action_in_flight"  # never race a handed-off version
                elif latest["state"] == "SUCCEEDED":
                    refused = "action_already_executed"  # reality moved; a new Mission asks again
                elif latest["state"] not in OPEN_ACTION_STATES:
                    after = str(latest["state"])  # a new, legitimate attempt after a failure
            version = len(versions) + 1
            record: dict[str, Any] = {
                "action_key": f"{action_id}:v{version}",
                "action_id": action_id,
                "version": version,
                "mission_id": mission_id,
                "task_id": task_id,
                "result_id": result_id,
                "attempt_id": attempt_id,
                "artifact_id": artifact_id,
                "artifact_hash": artifact_hash,
                "connector": cand["connector"],
                "operation": cand["operation"],
                "target": cand["target"],
                "params": dict(cand["params"]),
                "params_hash": phash,
                "reason": cand["reason"],
                **(
                    {"reason_source": reason_source} if reason_source != "model (untrusted)" else {}
                ),
                "level": decision.level,
                "required_approvals": decision.required_approvals,
                "idempotency_key": None if refused else f"{action_id}:v{version}",
                "approval_request_id": None,
                "after": after,
                "handoffs": 0,
                "receipt": None,
                "history": [],
                "created_at": self._store.now,
            }
            if proven_failure:
                # The facts the next card carries: how the last attempt did not happen.
                # proven_failure 蕴含 handed_failure，latest 非空
                record["previous_attempt"] = nonapplication_outcome(
                    self._store, cast("dict[str, Any]", latest)
                )
            if refused is not None:
                blocked_by = "" if latest is None else str(latest["action_key"])
                record.update(state="REFUSED", refused=refused, blocked_by=blocked_by)
                self._store.put_action(record)
                self._emit(
                    "ActionRefused",
                    mission_id,
                    key=record["action_key"],
                    task_id=task_id,
                    payload={
                        "action_key": record["action_key"],
                        "reason": refused,
                        "blocked_by": blocked_by,
                        **decision.to_json(),
                    },
                )
                return record
            if latest is not None and latest["state"] in OPEN_ACTION_STATES:
                self._supersede_action(latest, by=record["action_key"])
            opened = self._open_action(
                record,
                decision,
                deployment=deployment,
                payload={"artifact_hash": artifact_hash, "after": after},
            )
            if planning_origin is not None:
                opened["planning_origin"] = {
                    "operation_id": planning_origin.operation_id,
                    "operation_occurrence_id": planning_origin.operation_occurrence_id,
                    "request_hash": planning_origin.request_hash,
                    "envelope_hash": planning_origin.envelope_hash,
                }
                self._store.put_action(opened)
                self._link_planning_origin(opened, planning_origin)
            return opened

    # ------------------------------------------------------------ step proposals
    def propose_step_action(
        self,
        request: step_actions.ActionRequest,
        *,
        mission_id: str,
        task_id: str,
        attempt_id: str,
        result_id: str,
        prepared_params: Mapping[str, Any] | None,
        prepare_refusal: str | None,
        connectors: Mapping[str, Any],
        deployment: DeploymentPolicy,
    ) -> tuple[dict[str, Any] | None, str | None]:
        """步骤中途提议的动作进账本（在记这次结果的同一个事务里调）：连接器与操作存在、风险不超上限、
        每个任务的提议上限；名单（``allowed_actions``）外的一律要人批。返回 ``(动作行, None)`` 或
        ``(None, 拒绝原因)``；拒绝写 ``StepActionRefused`` 事件，模型下次看得到。"""

        mission = self._store.get_mission(mission_id)
        if mission is None or mission.status is not MissionStatus.ACTIVE:
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, "mission_not_active"
            )
        if prepare_refusal is not None:
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, prepare_refusal
            )
        connector = connectors.get(request.connector)
        if request.connector == PUBLISH[0]:
            # 内置发布连接器的参数是按产物引用解析的，只走建任务时写的要求
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, "connector_not_proposable"
            )
        decision = action_decision(deployment, connector, request.operation)
        if decision.refused is not None:
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, decision.refused
            )
        assert connector is not None  # 没拒就有连接器
        spec = connector.operations[request.operation]
        params = dict(prepared_params if prepared_params is not None else request.params)
        missing = [name for name in getattr(spec, "required_params", ()) if name not in params]
        if missing:
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, "missing_params:" + ",".join(missing)
            )
        proposed = [
            a
            for a in self._store.list_actions(mission_id)
            if step_actions.is_step_action(a) and a.get("state") != "REFUSED"
        ]
        action_id = step_actions.step_action_id(mission_id, result_id, request)
        versions = self._store.list_action_versions(action_id)
        if versions:
            return versions[-1], None  # 同一结果再记一次：同一个动作
        if len(proposed) >= int(deployment.max_step_actions_per_mission):
            return self._refuse_step_action(
                request, mission_id, task_id, attempt_id, "step_action_cap"
            )
        target = _normalize(connector, request.target)
        in_scope = f"{request.connector}.{request.operation}" in step_actions.scope_names(mission)
        if not in_scope:
            # 超出任务授权范围：不丢，但必须有人批，自动模式也不代批
            decision = ActionDecision(
                level=decision.level,
                required_approvals=max(1, decision.required_approvals),
                refused=None,
                person_required=True,
            )
        phash = params_hash(params)
        record: dict[str, Any] = {
            "action_key": f"{action_id}:v1",
            "action_id": action_id,
            "version": 1,
            "origin": step_actions.ORIGIN,
            "request_id": f"step-request-{result_id}",
            "out_of_scope": not in_scope,
            "mission_id": mission_id,
            "task_id": task_id,
            "result_id": result_id,
            "attempt_id": attempt_id,
            "artifact_id": "",
            "artifact_hash": "",
            "connector": request.connector,
            "operation": request.operation,
            "target": target,
            "params": params,
            "params_hash": phash,
            "reason": request.reason,
            "reason_source": "model (untrusted)",
            "level": decision.level,
            "required_approvals": decision.required_approvals,
            "idempotency_key": f"{action_id}:v1",
            "approval_request_id": None,
            "after": None,
            "handoffs": 0,
            # 只交接一次的连接器：结果不明从不重发
            "max_handoffs": (
                1
                if step_actions.delivery_of(connector) == step_actions.AT_MOST_ONCE
                else MAX_HANDOFFS_PER_ACTION
            ),
            "receipt": None,
            "history": [],
            "created_at": self._store.now,
        }
        opened = self._open_action(
            record,
            decision,
            deployment=deployment,
            payload={"origin": step_actions.ORIGIN, "out_of_scope": not in_scope},
        )
        self._emit(
            step_actions.REQUESTED,
            mission_id,
            key=record["request_id"],
            task_id=task_id,
            attempt_id=attempt_id,
            payload={
                "request_id": record["request_id"],
                "action_key": record["action_key"],
                "request": request.to_json(),
                "params_hash": phash,
                "level": decision.level,
                "out_of_scope": not in_scope,
                "person_required": decision.person_required,
                "approval_request_id": opened.get("approval_request_id"),
            },
            actor_type="agent",
            actor_id=attempt_id,
        )
        return opened, None

    def _refuse_step_action(
        self,
        request: step_actions.ActionRequest,
        mission_id: str,
        task_id: str,
        attempt_id: str,
        reason: str,
    ) -> tuple[None, str]:
        self._emit(
            step_actions.REFUSED,
            mission_id,
            key=f"step-refused-{attempt_id}-{hashlib.sha256(reason.encode()).hexdigest()[:8]}",
            task_id=task_id,
            attempt_id=attempt_id,
            payload={"request": request.to_json(), "reason": reason},
        )
        return None, reason

    def _step_handoff_refusal(self, action: Mapping[str, Any]) -> str | None:
        """中途动作交接前：这一步还在当前计划里、没被验收、没被取消或暂停。"""

        task = self._store.get_task(str(action["task_id"]))
        if task is None or task.mission_id != action["mission_id"]:
            return "step_task_missing"
        if task.accepted_result_id:
            return "step_task_accepted"
        if str(task.status) not in {"READY", "ACTIVE", "VERIFYING"} or task.paused:
            return f"step_task_not_active:{task.status}"
        htn = htn_store.HtnStore(self._store)
        active = htn.active_plan_revision(str(action["mission_id"]))
        if active is None:
            return "step_not_in_current_plan"
        memberships = htn.list_plan_memberships(str(action["mission_id"]), int(active.revision))
        if not any(str(spec.task_id) == task.id for spec in memberships):
            return "step_not_in_current_plan"
        return None

    def refuse_step_before_handoff(self, action_key: str, reason: str) -> dict[str, Any]:
        """一个中途动作在交接前就不能执行了（交接前检查不过、再次整理的参数对不上）：记 FAILED，
        带原因；这一步照样续做，模型看得到为什么。"""

        with self._store.transaction():
            action = self._store.get_action(action_key)
            if action is None:
                raise ActionCommitError(f"unknown action {action_key}")
            if action["state"] not in HANDOFF_READY_STATES:
                return action
            if action.get("approval_request_id"):
                request = self._store.get_approval(str(action["approval_request_id"]))
                if request is not None and request["state"] in {"PENDING", "GRANTED"}:
                    request.update(
                        state="SUPERSEDED",
                        closed_at=self._store.now,
                        version=int(request["version"]) + 1,
                        reason=reason,
                    )
                    self._store.put_approval(request)
            return self._resolve_action(action, "FAILED", error=reason)

    def _link_planning_origin(
        self, action: Mapping[str, Any], origin: BoundPlanningOperationOrigin
    ) -> dict[str, Any]:
        """Persist an exact operation→action identity bridge in this Store transaction."""

        if str(action.get("mission_id")) != origin.mission_id:
            raise ActionCommitError("operation_origin_mission_mismatch")
        adapter = PlanningAdmissionStore(self._store)
        identity = adapter.get_operation_identity(origin.operation_id)
        binding = adapter.get_operation_binding(origin.operation_occurrence_id)
        if identity is None or binding is None:
            raise ActionCommitError("operation_mapping_incomplete")
        if (
            str(identity["mission_id"]),
            str(identity["request_hash"]),
            str(identity["envelope_hash"]),
        ) != (
            origin.mission_id,
            origin.request_hash,
            origin.envelope_hash,
        ):
            raise ActionCommitError("operation_origin_identity_mismatch")
        if (
            str(binding["operation_id"]),
            str(binding["request_hash"]),
            str(binding["mission_id"]),
            str(binding["operation_occurrence_id"]),
        ) != (
            origin.operation_id,
            origin.request_hash,
            origin.mission_id,
            origin.operation_occurrence_id,
        ):
            raise ActionCommitError("operation_origin_binding_mismatch")
        if (
            str(binding["principal_id"]),
            str(binding["scope_id"]),
            str(binding["obligation_id"]),
        ) != (origin.principal_id, origin.scope_id, origin.obligation_id) or str(
            binding["envelope_hash"]
        ) != origin.envelope_hash:
            raise ActionCommitError("operation_origin_binding_mismatch")
        link_body: dict[str, Any] = {
            "operation_id": origin.operation_id,
            "request_hash": origin.request_hash,
            "operation_occurrence_id": origin.operation_occurrence_id,
            "mission_id": origin.mission_id,
            "envelope_hash": origin.envelope_hash,
            "principal_id": origin.principal_id,
            "scope_id": origin.scope_id,
            "obligation_id": origin.obligation_id,
            "producer_task_id": origin.producer_task_id,
            "producer_htn_occurrence_id": origin.producer_htn_occurrence_id,
            "producer_contract_revision": int(origin.producer_contract_revision),
            "producer_plan_revision": int(origin.producer_plan_revision),
            "action_key": str(action["action_key"]),
            "action_id": str(action["action_id"]),
            "action_version": int(action["version"]),
            "params_hash": str(action["params_hash"]),
            "idempotency_key": str(action.get("idempotency_key") or ""),
            "provenance_receipt_id": origin.provenance_receipt_id,
        }

        link_body["link_hash"] = hashlib.sha256(
            canonical_json(link_body).encode("utf-8")
        ).hexdigest()
        link_body["link_json"] = canonical_json({**link_body})
        try:
            PlanningAdmissionStore(self._store).put_operation_action_link(link_body)
        except Exception as error:
            if isinstance(error, ActionCommitError):
                raise
            raise ActionCommitError(str(error)) from error
        return link_body

    def _open_action(
        self,
        record: dict[str, Any],
        decision: ActionDecision,
        *,
        deployment: DeploymentPolicy,
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Put one new action version on the ledger: its approval request when the level
        needs one, the row itself, and the events."""

        mission_id = str(record["mission_id"])
        task_id = record.get("task_id")
        record["state"] = "AWAITING_APPROVAL" if decision.required_approvals else "PROPOSED"
        if decision.required_approvals:
            request_id = f"approval-{record['action_key']}"
            record["approval_request_id"] = request_id
            self._store.put_approval(
                {
                    "request_id": request_id,
                    "kind": "action",
                    "mission_id": mission_id,
                    "subject_key": record["action_key"],
                    "state": "PENDING",
                    "version": 1,
                    "binding": binding_of(record),
                    "level": decision.level,
                    # D7-4': the deployment's rules are frozen into the request
                    "required_count": decision.required_approvals,
                    "distinct_principals": bool(deployment.l3_distinct_principals),
                    "person_required": decision.person_required,
                    "expires_at": self._store.now + float(deployment.approval_ttl_seconds),
                    "grant_count": 0,
                    "granted_by": [],
                    "summary": {
                        "connector": record["connector"],
                        "operation": record["operation"],
                        "target": record["target"],
                        "params": record["params"],
                        "reason": record["reason"],
                        # 2026-09-29：系统按已批准效果写的申请单理由不是模型写的，卡片不该标"未核实"
                        "reason_source": record.get("reason_source", "model (untrusted)"),
                        # 步骤中途提议的动作：卡片要能看出来是哪一步提的、在不在任务授权范围内
                        **(
                            {
                                "origin": record["origin"],
                                "task_id": record.get("task_id"),
                                "out_of_scope": bool(record.get("out_of_scope")),
                                "request_id": record.get("request_id"),
                            }
                            if record.get("origin")
                            else {}
                        ),
                        **(
                            {"previous_attempt": record["previous_attempt"]}
                            if record.get("previous_attempt")
                            else {}
                        ),
                    },
                    "comments": [],
                    "created_at": self._store.now,
                }
            )
        self._store.put_action(record)
        self._emit(
            "ActionProposed",
            mission_id,
            key=record["action_key"],
            task_id=task_id,
            payload={
                "action_key": record["action_key"],
                "action_id": record["action_id"],
                "version": record["version"],
                "connector": record["connector"],
                "operation": record["operation"],
                "target": record["target"],
                "params_hash": record["params_hash"],
                "level": decision.level,
                **dict(payload or {}),
            },
        )
        if record["approval_request_id"]:
            self._emit(
                "ApprovalRequested",
                mission_id,
                key=record["approval_request_id"],
                task_id=task_id,
                payload={
                    "request_id": record["approval_request_id"],
                    "kind": "action",
                    "action_key": record["action_key"],
                    "level": decision.level,
                    "required_count": decision.required_approvals,
                    "binding": binding_of(record),
                },
            )
        return record

    def _supersede_action(self, action: Mapping[str, Any], *, by: str) -> None:
        old = dict(action)
        old.update(state="SUPERSEDED", superseded_by=by)
        old["history"] = [
            *old.get("history", []),
            {"state": "SUPERSEDED", "at": self._store.now, "by": by},
        ]
        self._store.put_action(old)
        self._emit(  # step 8 (plan D8-2'): every action state change is on record
            "ActionSuperseded",
            old["mission_id"],
            key=str(old["action_key"]),
            task_id=old.get("task_id"),
            payload={"action_key": old["action_key"], "superseded_by": by},
        )
        request_id = old.get("approval_request_id")
        if request_id:
            request = self._store.get_approval(request_id)
            if request is not None and request["state"] in {"PENDING", "GRANTED"}:
                request.update(
                    state="SUPERSEDED",
                    closed_at=request.get("closed_at") or self._store.now,
                    version=int(request["version"]) + 1,
                    superseded_by=by,
                )
                self._store.put_approval(request)
                self._emit(
                    "ApprovalSuperseded",
                    old["mission_id"],
                    key=request_id,
                    task_id=old.get("task_id"),
                    payload={
                        "request_id": request_id,
                        "action_key": old["action_key"],
                        "superseded_by": by,
                    },
                )

    def _set_action_state(self, action_key: str, state: str, **fields: Any) -> dict[str, Any]:
        action = self._store.get_action(action_key)
        if action is None:
            raise ActionCommitError(f"unknown action {action_key}")
        action.update(state=state, **fields)
        action["history"] = [*action.get("history", []), {"state": state, "at": self._store.now}]
        self._store.put_action(action)
        return action

    # ------------------------------------------------------------ decisions
    def decide_approval(
        self,
        request_id: str,
        *,
        principal: Principal,
        decision: str,
        nonce: str,
        deployment: DeploymentPolicy,
        reason: str = "",
        approval_source: str = "HUMAN",
    ) -> tuple[dict[str, Any], str]:
        """A decision on an approval request (original §22 ApprovalGranted / ApprovalRejected).
        Returns the request after the decision and the decision's receipt hash; replaying the
        same nonce returns the original receipt and changes nothing.

        ``approval_source="HOST_AUTO_PERMISSION"``（用户 2026-10-20）：自动模式下主机按用户的
        模式代批一个动作。如实记成主机的决定（事件执行者是主机，不是人），一次决定就让请求
        成为 GRANTED——L3 不伪造第二个人；应用标了"总要人批"的请求不接受代批。"""

        automatic = _decision_source(principal, decision, nonce, approval_source)
        pre = self._store.get_approval(request_id)
        if pre is not None and pre["kind"] in {"action", "source_change"}:
            # review P2-3: an expiry is committed on its own, never rolled back with a refusal
            self.expire_approvals(str(pre["mission_id"]))
        with self._store.transaction():
            request = self._store.get_approval(request_id)
            if request is None:
                raise ActionCommitError(f"unknown approval request {request_id}")
            if request["kind"] not in {"action", "source_change"}:
                raise ActionCommitError(f"{request_id} is a {request['kind']} request")
            if automatic and (request["kind"] != "action" or request.get("person_required")):
                raise ActionCommitError(f"{request_id} needs a person's decision")
            receipt = decision_receipt_hash(
                request_id=request_id,
                binding=request["binding"],
                principal_id=principal.principal_id,
                decision=decision,
                nonce=nonce,
            )
            known = {d["receipt_hash"] for d in self._store.list_decisions(request_id)}
            if receipt in known:
                return request, receipt  # the same receipt replayed: counted once, never twice
            mission = self._store.get_mission(str(request["mission_id"]))
            if mission is None or (
                request["kind"] == "action" and mission.status is not MissionStatus.ACTIVE
            ):
                raise ActionCommitError(f"mission {request['mission_id']} is not ACTIVE")  # D7-4'
            source_rejection = request["kind"] == "source_change" and decision == "reject"
            if (
                request["state"] == "PENDING"
                and not source_rejection
                and request.get("expires_at") is not None
                and self._store.now >= float(request["expires_at"])
            ):
                raise ActionCommitError(f"approval {request_id} expired")
            if request["state"] != "PENDING" and not (
                source_rejection
                and request["state"] == "EXPIRED"
                and request.get("consumed_at") is None
            ):
                raise ActionCommitError(f"approval {request_id} is {request['state']}")
            if request["kind"] == "source_change":
                # Applying a grant needs a current head and readable CAS. A human may
                # still dismiss an invalidated request, but never a tampered binding.
                self._validate_source_binding(request)
                if decision == "grant":
                    self._validate_source_approval(request)
            inserted = self._store.insert_decision(
                {
                    "receipt_hash": receipt,
                    "request_id": request_id,
                    "principal_id": principal.principal_id,
                    "decision": decision,
                    "nonce": nonce,
                    "reason": reason,
                    "principal": principal.to_json(),
                    "approval_source": approval_source,
                    "at": self._store.now,
                }
            )
            if not inserted:  # the same nonce with a different decision / person
                raise ActionCommitError(f"nonce {nonce!r} was already used on {request_id}")
            action_key = str(request["subject_key"])
            actor = {
                "actor_type": "system" if automatic else "user",
                "actor_id": ("host-auto:" if automatic else "") + principal.principal_id,
            }
            if decision == "reject":
                request.update(
                    state="REJECTED",
                    closed_at=self._store.now,
                    version=int(request["version"]) + 1,
                    rejected_by=principal.principal_id,
                    reason=reason,
                )
                self._store.put_approval(request)
                if request["kind"] == "action":
                    # 驳回原因要让提议的那一步看到（真实模型局：模型拿到 REJECTED 却不知为何，
                    # 原样再提一遍）
                    self._set_action_state(action_key, "REJECTED", decision_note=reason)
                self._emit(
                    "ApprovalRejected",
                    request["mission_id"],
                    key=f"{request_id}:{receipt[:16]}",
                    payload={"request_id": request_id, "receipt_hash": receipt, "reason": reason},
                    **actor,
                )
                return request, receipt
            # every recorded grant counts: the decision receipts are the authorisation (D7-4')
            request["granted_by"] = [*list(request.get("granted_by") or []), principal.principal_id]
            request["grant_count"] = int(request.get("grant_count", 0)) + 1
            request["version"] = int(request["version"]) + 1
            if automatic:
                request["approval_source"] = approval_source
            if automatic or int(request["grant_count"]) >= int(request["required_count"]):
                request["state"] = "GRANTED"
                request["closed_at"] = self._store.now
                request["granted_at"] = self._store.now
            self._store.put_approval(request)
            self._emit(
                "ApprovalGranted",
                request["mission_id"],
                key=f"{request_id}:{receipt[:16]}",
                payload={
                    "request_id": request_id,
                    "receipt_hash": receipt,
                    "counted": True,
                    "grant_count": request["grant_count"],
                    "required_count": request["required_count"],
                    "state": request["state"],
                    "approval_source": approval_source,
                },
                **actor,
            )
            if request["state"] == "GRANTED" and request["kind"] == "action":
                self._set_action_state(action_key, "APPROVED", approved_at=self._store.now)
            elif request["state"] == "GRANTED" and request["kind"] == "source_change":
                self._apply_source_approval(request, principal)
            return request, receipt

    def revoke_approval(
        self, request_id: str, *, principal: Principal, reason: str
    ) -> dict[str, Any]:
        """Withdraw a grant before the action was handed off (S7-04)."""

        if not isinstance(principal, Principal):
            raise ActionCommitError("a revocation needs an authenticated Principal from the caller")
        with self._store.transaction():
            request = self._store.get_approval(request_id)
            if request is None:
                raise ActionCommitError(f"unknown approval request {request_id}")
            if request["kind"] != "action":
                raise ActionCommitError(f"{request_id} is a {request['kind']} request")
            if (
                request["state"] != "GRANTED"
            ):  # review P2-2: a PENDING request is rejected, not revoked
                raise ActionCommitError(f"approval {request_id} is {request['state']}")
            action = (
                self._store.get_action(str(request["subject_key"]))
                if request["kind"] == "action"
                else None
            )
            if action is not None and action["state"] not in OPEN_ACTION_STATES:
                raise ActionCommitError(
                    f"action {action['action_key']} is already {action['state']}"
                )
            request.update(
                state="REVOKED",
                closed_at=request.get("closed_at") or self._store.now,
                version=int(request["version"]) + 1,
                revoked_by=principal.principal_id,
                reason=reason,
            )
            self._store.put_approval(request)
            if action is not None:
                self._set_action_state(action["action_key"], "REVOKED")
            self._emit(
                "ApprovalRevoked",
                request["mission_id"],
                key=request_id,
                payload={"request_id": request_id, "reason": reason},
                actor_type="user",
                actor_id=principal.principal_id,
            )
            return request

    def _expire_request(self, request: dict[str, Any]) -> None:
        request.update(
            state="EXPIRED",
            closed_at=request.get("closed_at") or self._store.now,
            version=int(request["version"]) + 1,
        )
        self._store.put_approval(request)
        if request["kind"] == "action":
            action = self._store.get_action(str(request["subject_key"]))
            if action is not None and action["state"] in OPEN_ACTION_STATES:
                self._set_action_state(action["action_key"], "EXPIRED")
        self._emit(
            "ApprovalExpired",
            request["mission_id"],
            key=str(request["request_id"]),
            payload={"request_id": request["request_id"], "expires_at": request["expires_at"]},
        )

    def expire_approvals(self, mission_id: str | None = None) -> list[dict[str, Any]]:
        """Requests past their validity that were not handed off yet expire (S7-04)."""

        expired = []
        with self._store.transaction():
            for request in self._store.list_approvals(mission_id, "PENDING", "GRANTED"):
                if request["kind"] == "source_change" and request.get("consumed_at") is not None:
                    continue  # source mutation already committed with the grant
                if request.get("expires_at") is None or self._store.now < float(
                    request["expires_at"]
                ):
                    continue
                if request["kind"] == "action":
                    action = self._store.get_action(str(request["subject_key"]))
                    if action is not None and action["state"] not in OPEN_ACTION_STATES:
                        continue  # already handed off: the grant was used in time
                self._expire_request(request)
                expired.append(request)
        return expired

    # ------------------------------------------------------------ hand-off (D7-5')
    def begin_handoff(
        self,
        action_key: str,
        *,
        owner: str,
        lease_seconds: float,
        connectors: Mapping[str, Any],
        deployment: DeploymentPolicy,
        rehandoff: bool = False,
        deployment_guard: Callable[[Mapping[str, Any]], str | None] | None = None,
    ) -> tuple[dict[str, Any] | None, str | None]:
        """The outbox step of a real action, in one transaction: re-check everything the
        approval was bound to, reserve the budget, then write HANDED_OFF with the owner, a
        lease and the decision receipts that authorised it.  ``(action, None)`` = the caller
        may now call the connector; ``(None, reason)`` = it may not."""

        with self._store.transaction():
            action = self._store.get_action(action_key)
            if action is None:
                raise ActionCommitError(f"unknown action {action_key}")
            reason = self._handoff_refusal(
                action, connectors=connectors, deployment=deployment, rehandoff=rehandoff
            )
            if reason is None and action.get("task_id"):
                try:
                    require_taskgraph_unfenced(
                        self._store, str(action["mission_id"]), str(action["task_id"])
                    )
                except StoreConflict:
                    reason = "taskgraph_target_fenced"
            start_use = None
            step = step_actions.is_step_action(action)
            if reason is None and step:
                reason = self._step_handoff_refusal(action)
            if reason is None and action.get("task_id") and not step:
                start_use, reason = self._start_use(action)
            # Every requirement action is linked to the operation it was materialised from
            # (2026-10-02: the flat mode, whose actions carried no link, was removed); a step
            # proposal is its own frozen request (the row), checked above.
            if reason is None and not step:
                bridge = PlanningAdmissionStore(self._store).get_operation_action_link_for_action(
                    str(action_key)
                )
                if bridge is None:
                    reason = "operation_link_missing"
                elif (
                    str(bridge.get("mission_id")) != str(action.get("mission_id"))
                    or str(bridge.get("action_key")) != str(action_key)
                    or str(bridge.get("action_id")) != str(action.get("action_id"))
                    or int(bridge.get("action_version", -1)) != int(action.get("version", -2))
                    or str(bridge.get("params_hash")) != str(action.get("params_hash"))
                    or str(bridge.get("idempotency_key")) != str(action.get("idempotency_key"))
                ):
                    reason = "operation_link_mismatch"
                else:
                    # The marker is descriptive, never the switch that grants an
                    # exemption. Re-read the exact frozen identities under this
                    # handoff transaction before any reservation or outbox write.
                    try:
                        planning_operations.build_operation_snapshot(
                            str(action["mission_id"]),
                            reader=planning_operations.StoreOperationReader(self._store),
                        )
                    except planning_operations.SourceUnavailable:
                        reason = "operation_link_mismatch"
                    if reason is None:
                        # Every link is a T0 link: a broken chain cannot reserve or send.
                        # 按需导入：循环依赖（action_commits ↔ operation_profiles_deployment）
                        from ..runtime.operation_profiles_deployment import (
                            DeploymentOperationProfiles,
                        )

                        # 按需导入：循环依赖（action_commits ↔ operation_materialization_inputs）
                        from .operation_materialization_inputs import (
                            OperationMaterializationInputError,
                        )

                        try:
                            resolver = OperationReferenceResolver(
                                self._store,
                                (
                                    # 条件里的 getattr 已确认运行时非空
                                    cast(
                                        "OperationMaterializationRuntime",
                                        self._operation_materialization_runtime,
                                    ).profiles
                                    if getattr(self, "_operation_materialization_runtime", None)
                                    is not None
                                    else DeploymentOperationProfiles(connectors)
                                ),
                            )
                            resolver.resolve_for_handoff(action, bridge)
                        except (OperationReferenceUnavailable, OperationMaterializationInputError):
                            reason = "operation_ref_unavailable"
                    if (
                        reason is None
                        and rehandoff
                        and not self._planning_rehandoff_proven(action, bridge)
                    ):
                        reason = "rehandoff_needs_authoritative_not_applied_proof"
            # The executor knows physical deployment roots. Check them against the
            # same registry snapshot as this handoff, before charging or writing the
            # outbox; use the ordinary refusal/reconciliation path below.
            if reason is None and deployment_guard is not None:
                reason = deployment_guard(action)
            subject = f"action:{action_key}"
            if reason is None:
                try:  # re-hand-off finds the held reservation (idempotent per subject)
                    self._ledger.reserve(
                        account_id=mission_account(str(action["mission_id"])),
                        subject_id=subject,
                        tokens=0,
                        counts_attempt=False,
                        tool_calls=1,
                        mission_id=str(action["mission_id"]),
                    )
                except BudgetExhausted:
                    reason = "budget_exhausted"
            if reason is not None:
                self._emit(
                    "ActionHandoffRefused",
                    str(action["mission_id"]),
                    key=f"{action_key}:{reason}",
                    task_id=action.get("task_id"),
                    payload={"action_key": action_key, "reason": reason, "rehandoff": rehandoff},
                )
                # A refused re-hand-off never resolves UNKNOWN or releases its hold: only
                # complete negative proof or a person's ruling settles it.
                if reason == "approval_expired":
                    request = self._store.get_approval(str(action["approval_request_id"]))
                    if request is not None and request["state"] in {"PENDING", "GRANTED"}:
                        self._expire_request(request)
                return None, reason
            request_id = action.get("approval_request_id")
            receipts = (
                []
                if not request_id
                else [
                    d["receipt_hash"]
                    for d in self._store.list_decisions(str(request_id))
                    if d["decision"] == "grant"
                ]
            )
            handoffs = int(action.get("handoffs") or 0) + 1
            if start_use is not None and start_use.certificate is not None:
                record_point_use_locked(self._store, start_use)
            updated = self._set_action_state(
                action_key,
                "HANDED_OFF",
                owner=owner,
                lease_expires_at=self._store.now + float(lease_seconds),
                handoffs=handoffs,
                handed_off_at=self._store.now,
                decision_receipts=receipts,
                reservation_subject=subject,
                reconcile=None,
            )
            self._emit(
                "ActionHandedOff",
                str(action["mission_id"]),
                key=f"{action_key}:h{handoffs}",
                task_id=action.get("task_id"),
                payload={
                    "action_key": action_key,
                    "idempotency_key": action["idempotency_key"],
                    "handoff": handoffs,
                    "owner": owner,
                    "decision_receipts": receipts,
                    "rehandoff": rehandoff,
                },
            )
            return updated, None

    def _handoff_refusal(
        self,
        action: Mapping[str, Any],
        *,
        connectors: Mapping[str, Any],
        deployment: DeploymentPolicy,
        rehandoff: bool,
    ) -> str | None:
        mission = self._store.get_mission(str(action["mission_id"]))
        if mission is None or mission.status is not MissionStatus.ACTIVE:
            return "mission_not_active"
        if rehandoff:
            if action["state"] != "UNKNOWN" or action.get("reconcile") != "CONFIRMED_NOT_STARTED":
                return "rehandoff_needs_confirmed_not_started"
            if int(action.get("handoffs") or 0) >= int(
                action.get("max_handoffs") or MAX_HANDOFFS_PER_ACTION
            ):
                return "rehandoff_exhausted"
        elif action["state"] not in HANDOFF_READY_STATES:
            return f"not_ready:{action['state']}"
        live = [
            v
            for v in self._store.list_action_versions(str(action["action_id"]))
            if v["state"] != "REFUSED"
        ]
        if not live or live[-1]["action_key"] != action["action_key"]:
            return "not_current_version"
        if params_hash(action.get("params") or {}) != action.get("params_hash"):
            return "params_hash_mismatch"  # review P2-5: the stored parameters were altered
        decision = action_decision(
            deployment, connectors.get(str(action["connector"])), str(action["operation"])
        )
        if decision.refused is not None:
            return decision.refused
        if level_rank(decision.level) > level_rank(str(action["level"])):
            return "level_raised"  # the approval was given under a milder level
        if int(action.get("required_approvals") or 0):
            request = self._store.get_approval(str(action.get("approval_request_id") or ""))
            if request is None or request["state"] != "GRANTED":
                return "approval_not_granted"
            if self._store.now >= float(request["expires_at"]):
                return "approval_expired"
            if not binding_matches(request, action):
                return "binding_mismatch"
        if not rehandoff and not step_actions.is_step_action(action):
            # 要求动作的交接上限；步骤中途提议的动作有自己的上限（提议时核），不占这个额度
            started = sum(
                1
                for a in self._store.list_actions(str(action["mission_id"]))
                if int(a.get("handoffs") or 0) > 0 and not step_actions.is_step_action(a)
            )
            if started >= int(deployment.max_action_handoffs_per_mission):
                return "handoff_cap_reached"
        return None

    def _start_use(self, action: Mapping[str, Any]) -> tuple[Any, str | None]:
        """Before anything leaves the system, the step this operation belongs to must still
        stand on current ground: a START use certificate (推后第 1 批 A26; 原计划 AER §9.4
        "handoff 前成立，记录带时间的开始见证"; 阶段 C 第 5 条的交接核对搬进签发方).

        The ground is judged once, by the issuer, with the witness contract's own
        ``is_fresh_for`` and ``acceptance_is_current``.  A certificate that cannot be issued
        refuses the hand-off with ``validity_stale:<named reason>``: the refusal changes
        nothing and costs nothing, the action stays ready and is tried again next round; it is
        not a wait on a person, so ground that does not come back ends in the stall record,
        with the refusal named, and the Planner decides.  The certificate is recorded beside
        the HANDED_OFF write, in this same transaction."""

        task_id = str(action["task_id"])
        use = certify_point_use_locked(
            self,
            mission_id=str(action["mission_id"]),
            purpose="START",
            consumer_kind=ACTION_CONSUMER,
            consumer_id=str(action["action_key"]),
            claims=(EvidenceClaim.step_ground(task_id),),
            subject=("task", task_id),
            record=False,
        )
        if not use.usable:
            return None, HANDOFF_VALIDITY_STALE + use.refusals[0]
        return use, None

    def _planning_rehandoff_proven(
        self, action: Mapping[str, Any], bridge: Mapping[str, Any]
    ) -> bool:

        return stored_negative_proof(self._store, action, bridge)

    def _update_action(self, action_key: str, **fields: Any) -> dict[str, Any]:
        action = self._store.get_action(action_key)
        if action is None:
            raise ActionCommitError(f"unknown action {action_key}")
        action.update(fields)
        self._store.put_action(action)
        return action

    def _resolve_action(
        self,
        action: Mapping[str, Any],
        state: str,
        *,
        receipt: Receipt | None = None,
        error: str = "",
        event: str | None = None,
        extra: Mapping[str, Any] | None = None,
        actor: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """HANDED_OFF / UNKNOWN → SUCCEEDED / FAILED settle the reservation with the calls
        actually made; → UNKNOWN holds it (ORCH §12.2)."""

        key = str(action["action_key"])
        mission_id = str(action["mission_id"])
        subject = str(action.get("reservation_subject") or f"action:{key}")
        fields: dict[str, Any] = {"error": error or None}
        if receipt is not None:
            fields["receipt"] = receipt.to_json()
        updated = self._set_action_state(key, state, **fields)
        if state in {"SUCCEEDED", "FAILED"}:
            if self._ledger.reservation(subject) is not None:
                try:
                    self._settle_subject(
                        subject,
                        mission_id,
                        task_id=None,
                        tool_calls=int(action.get("handoffs") or 0),
                    )
                except BudgetError:
                    # Persist the real outcome even while an earlier handoff or
                    # incomplete negative proof prevents releasing its account.
                    self.record_reservation_held(
                        subject,
                        mission_id,
                        task_id=None,
                        reason="taskgraph_action_physical_work_unresolved",
                    )
        else:
            self.record_reservation_held(
                subject, mission_id, task_id=None, reason="action_outcome_unknown"
            )
        self._emit(
            event or OUTCOME_EVENTS[state],
            mission_id,
            key=f"{key}:h{int(action.get('handoffs') or 0)}:{state}",
            task_id=action.get("task_id"),
            payload={
                "action_key": key,
                "state": state,
                "error": error or None,
                "receipt_hash": None if receipt is None else receipt.receipt_hash,
                **dict(extra or {}),
            },
            **dict(actor or {}),
        )
        return updated

    def record_action_outcome(
        self,
        action_key: str,
        *,
        owner: str,
        outcome: str,
        receipt: Receipt | None = None,
        error: str = "",
    ) -> dict[str, Any]:
        """What the connector call returned (D7-5 ③④).  Only the owner of the live hand-off
        may record it; a late answer after someone else resolved the action is ignored."""

        if outcome not in {"succeeded", "failed", "unknown"}:
            raise ActionCommitError(f"unknown outcome {outcome!r}")
        with self._store.transaction():
            action = self._store.get_action(action_key)
            if action is None:
                raise ActionCommitError(f"unknown action {action_key}")
            if action["state"] != "HANDED_OFF" or action.get("owner") != owner:
                return action
            if outcome == "succeeded":
                mismatch = receipt_mismatch(action, receipt)
                if mismatch is not None:  # a receipt for something else proves nothing
                    outcome, error, receipt = "unknown", f"receipt_mismatch:{mismatch}", None
            state = {"succeeded": "SUCCEEDED", "failed": "FAILED", "unknown": "UNKNOWN"}[outcome]
            return self._resolve_action(action, state, receipt=receipt, error=error)

    def record_reconciliation(
        self, action_key: str, *, verdict: str, receipt: Receipt | None = None
    ) -> dict[str, Any]:
        """The answer of an authoritative lookup by idempotency key (D7-5 ⑤): COMPLETED →
        SUCCEEDED; CONFIRMED_NOT_STARTED → may be handed off again with the *same* key;
        STILL_UNKNOWN → stays UNKNOWN and waits for a person.  A HANDED_OFF action whose
        lease lapsed without an outcome (a crash) is UNKNOWN first."""

        if verdict not in {"COMPLETED", "CONFIRMED_NOT_STARTED", "STILL_UNKNOWN"}:
            raise ActionCommitError(f"unknown reconciliation verdict {verdict!r}")
        with self._store.transaction():
            action = self._store.get_action(action_key)
            if action is None:
                raise ActionCommitError(f"unknown action {action_key}")
            lapsed = (
                action["state"] == "HANDED_OFF"
                and float(action.get("lease_expires_at") or 0.0) <= self._store.now
            )
            if action["state"] != "UNKNOWN" and not lapsed:
                return action
            if lapsed:
                action = self._resolve_action(
                    action, "UNKNOWN", error="lease_lapsed_without_outcome"
                )
            handoffs = int(action.get("handoffs") or 0)
            note = None
            if verdict == "COMPLETED":
                mismatch = receipt_mismatch(action, receipt)
                if mismatch is None:
                    return self._resolve_action(
                        action,
                        "SUCCEEDED",
                        receipt=receipt,
                        event="ActionReconciled",
                        extra={"verdict": verdict},
                    )
                verdict, note = "STILL_UNKNOWN", f"receipt_mismatch:{mismatch}"
            if verdict == "CONFIRMED_NOT_STARTED":
                updated = self._update_action(action_key, reconcile=verdict)
            else:
                updated = self._update_action(
                    action_key, reconcile=verdict, needs_human=True, reconcile_note=note
                )
            self._emit(
                "ActionReconciled",
                str(action["mission_id"]),
                key=f"{action_key}:h{handoffs}:{verdict}",
                task_id=action.get("task_id"),
                payload={"action_key": action_key, "verdict": verdict, "note": note},
            )
            return updated

    def override_action_outcome(
        self,
        action_key: str,
        *,
        principal: Principal,
        outcome: str,
        basis: str,
        evidence: Mapping[str, Any],
    ) -> dict[str, Any]:
        """A person rules on an UNKNOWN action the lookup cannot settle (D7-5' human exit):
        a HumanOverride with basis and evidence; the ruling covers this version only."""

        if not isinstance(principal, Principal):
            raise ActionCommitError("a ruling needs an authenticated Principal from the caller")
        if outcome not in {"succeeded", "failed"}:
            raise ActionCommitError(f"a ruling is succeeded or failed, not {outcome!r}")
        if not basis.strip() or not evidence:
            raise ActionCommitError("a ruling on an UNKNOWN action needs a basis and evidence")

        with self._store.transaction():
            action = self._store.get_action(action_key)
            linked = (
                action is not None
                and PlanningAdmissionStore(self._store).get_operation_action_link_for_action(
                    action_key
                )
                is not None
            )
            # 阶段 B 裁决第 3 类: a failed action that left our hands without a proof that it
            # did not happen keeps the operation gate shut; a person may rule it not applied.
            unproven_failure = (
                action is not None
                and action["state"] == "FAILED"
                and linked
                and int(action.get("handoffs") or 0) >= 1
                and not stored_negative_proof(self._store, action)
            )
            if action is None or not (action["state"] == "UNKNOWN" or unproven_failure):
                raise ActionCommitError(f"only an UNKNOWN action takes a ruling ({action_key})")
            if unproven_failure and outcome != "failed":
                raise ActionCommitError("a failed action can only be ruled not applied")
            override_id = f"override:{action_key}:h{int(action.get('handoffs') or 0)}"
            actor = {"actor_type": "user", "actor_id": principal.principal_id}
            record = {
                "override_id": override_id,
                "mission_id": action["mission_id"],
                "principal": principal.to_json(),
                "action": "resolve_unknown_action",
                "subject": action_key,
                "outcome": outcome,
                "basis": basis,
                "evidence": dict(evidence),
                "scope": "this action version only",
                "at": self._store.now,
            }
            self._store.insert_override(record)
            self._emit(
                "HumanOverride",
                str(action["mission_id"]),
                key=override_id,
                task_id=action.get("task_id"),
                payload=record,
                **actor,
            )
            if action["state"] == "UNKNOWN":
                # 裁"已生效"：同事务给动作一份人裁定回执（谁、何时、凭什么），结果审阅读到的就是它，
                # 不再是空；人已经出面了，动作不再标"等人"。裁"没生效"没有回执可言。
                ruling = human_ruling_receipt(action, record) if outcome == "succeeded" else None
                action = self._resolve_action(
                    action,
                    "SUCCEEDED" if outcome == "succeeded" else "FAILED",
                    receipt=ruling,
                    error="" if outcome == "succeeded" else "human_ruled_failed",
                    extra={"resolved_by": principal.principal_id, "override_id": override_id},
                    actor=actor,
                )
                if ruling is not None:
                    action = self._update_action(action_key, needs_human=False)
            if outcome == "failed" and linked:
                # The ruling is the proof, in this same transaction: the operation gate
                # opens and the effect can be offered again (阶段 B 裁决第 3 类).
                action = self.record_human_nonapplication(
                    action_key, override=record, principal_id=principal.principal_id
                )
            return action

    # ------------------------------------------------------------ closure (D7-2'' / D7-7')
    def record_criteria_judgment(
        self,
        mission_id: str,
        key: str,
        judgments: Sequence[Mapping[str, Any]],
        *,
        summary: str,
    ) -> None:
        """D7-7' ①: the non-action criteria are judged once per integrated tree and the
        judgment is on the books — waiting for a person never re-runs pytest or a Critic."""

        with self._store.transaction():
            self._emit(
                "MissionCriteriaJudged",
                mission_id,
                key=f"{mission_id}:{key}",
                payload={
                    "tree_key": key,
                    "judgments": [dict(item) for item in judgments],
                    "summary": summary,
                },
            )

    def criteria_judgment(
        self, mission_id: str, key: str
    ) -> tuple[list[dict[str, Any]], str] | None:
        for event in reversed(self._store.list_events(mission_id)):
            if event.type == "MissionCriteriaJudged" and event.payload.get("tree_key") == key:
                return (
                    [dict(item) for item in event.payload.get("judgments", [])],
                    str(event.payload.get("summary", "")),
                )
        return None

    def action_for_criterion(
        self, mission_id: str, criterion: str, connectors: Mapping[str, Any]
    ) -> dict[str, Any] | None:
        """The latest non-REFUSED version of the business action an ``action:`` criterion names."""

        parsed = parse_action_criterion(criterion)
        if parsed is None:
            return None
        name, operation, target = parsed
        action_id = business_action_id(
            mission_id, name, operation, _normalize(connectors.get(name), target)
        )
        live = [v for v in self._store.list_action_versions(action_id) if v["state"] != "REFUSED"]
        return live[-1] if live else None

    def cancel_open_actions(self, mission_id: str, *, reason: str) -> list[dict[str, Any]]:
        """D7-4' / D7-5': a Mission that ends (cancelled, failed) or work that is replaced
        closes its *open* actions and requests as CANCELLED.  Handed-off and UNKNOWN actions
        are never touched — reality may already have moved; reconciliation continues."""

        with self._store.transaction():
            return self._cancel_open_actions(mission_id, reason=reason)

    def _cancel_open_actions(self, mission_id: str, *, reason: str) -> list[dict[str, Any]]:
        cancelled = []
        for action in self._store.list_actions(mission_id, *sorted(OPEN_ACTION_STATES)):
            cancelled.append(
                self._set_action_state(action["action_key"], "CANCELLED", reason=reason)
            )
            self._emit(  # step 8 (plan D8-2', review P0-1): the cancellation is on record
                "ActionCancelled",
                mission_id,
                key=str(action["action_key"]),
                task_id=action.get("task_id"),
                payload={"action_key": action["action_key"], "reason": reason},
            )
        for request in self._store.list_approvals(mission_id, "PENDING", "GRANTED"):
            if request["kind"] != "action" and request["state"] != "PENDING":
                continue  # a decided review / arbitration stays as decided
            if request["kind"] == "action":
                subject = self._store.get_action(str(request["subject_key"]))
                if subject is not None and subject["state"] != "CANCELLED":
                    continue  # handed off: the grant stays as the audit of what ran
            request.update(
                state="CANCELLED",
                closed_at=request.get("closed_at") or self._store.now,
                version=int(request["version"]) + 1,
                reason=reason,
            )
            self._store.put_approval(request)
            self._emit(
                "ApprovalCancelled",
                mission_id,
                key=str(request["request_id"]),
                payload={"request_id": request["request_id"], "reason": reason},
            )
        return cancelled


__all__ = (
    "CLOSED_ACTION_STATES",
    "IN_FLIGHT_ACTION_STATES",
    "OPEN_ACTION_STATES",
    "HANDOFF_READY_STATES",
    "MAX_HANDOFFS_PER_ACTION",
    "ActionCommitError",
    "ActionCommitsMixin",
    "CandidateRejected",
    "allowed_actions",
    "business_action_id",
    "check_candidate",
    "judgment_key",
    "receipt_mismatch",
    "validate_candidate",
)
