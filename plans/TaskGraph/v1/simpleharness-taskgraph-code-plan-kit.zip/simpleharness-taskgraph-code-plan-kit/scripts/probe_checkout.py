#!/usr/bin/env python3
"""Read-only local source preflight. Does not fetch, switch, reset or edit a repository."""
from __future__ import annotations
import argparse,ast,hashlib,json,subprocess,sys
from pathlib import Path

REQUIRED={
 'src/agent_orchestrator/storage/htn_store.py':['HtnStore','get_task_semantics','get_method_instance','list_child_occurrences','active_plan_revision'],
 'src/agent_orchestrator/graph/task_network.py':['TaskNetworkSnapshot','execution_projection'],
 'src/agent_orchestrator/graph/eligibility.py':['evaluate_readiness','admit_for_dispatch'],
 'src/agent_orchestrator/artifacts/input_bindings.py':['resolve_declared_inputs','InputManifest'],
 'src/agent_orchestrator/planning/htn/validation.py':['validate_delta'],
 'src/agent_orchestrator/orchestrator/plan_commits.py':['commit_plan_revision'],
 'src/agent_orchestrator/governance/budgets.py':['BudgetLedger','account','reserve'],
 'src/agent_orchestrator/storage/schema.py':['Migration'],
}
H1_SEAMS={
 'src/agent_orchestrator/governance/planning_authorization.py':['build_planning_authorization'],
 'src/agent_orchestrator/runtime/planning_operations.py':['build_operation_snapshot','read_running_work'],
 'src/agent_orchestrator/planning/plan_preview.py':['preview_candidate'],
 'src/agent_orchestrator/orchestrator/planning_admission_commits.py':['commit_admitted_plan'],
}
def git(path:Path,*args:str)->str:
    p=subprocess.run(['git','-C',str(path),*args],capture_output=True,text=True,timeout=20)
    if p.returncode:raise RuntimeError(p.stderr.strip() or 'git command failed')
    return p.stdout.strip()
def inspect(path:Path,expected:list[str])->dict:
    if not path.is_file():return {'exists':False,'missing_symbols':expected}
    raw=path.read_bytes();tree=ast.parse(raw,filename=str(path))
    symbols={n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
    return {'exists':True,'sha256':hashlib.sha256(raw).hexdigest(),'missing_symbols':sorted(set(expected)-symbols)}
def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk',required=True,type=Path);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();root=args.sdk.expanduser().resolve()
    if not root.is_dir():parser.error('SDK checkout does not exist on this machine')
    report={'spec':'TG-EXEC-2.0','read_only':True,'sdk':str(root),'head':git(root,'rev-parse','HEAD'),
      'branch':git(root,'symbolic-ref','--short','HEAD'),'status_porcelain':git(root,'status','--porcelain=v1'),
      'diff_numstat':git(root,'diff','--numstat'),'staged_numstat':git(root,'diff','--cached','--numstat'),
      'legacy_source':{p:inspect(root/p,n) for p,n in REQUIRED.items()},
      'h1h_dependencies':{p:inspect(root/p,n) for p,n in H1_SEAMS.items()},
      'runtime_test_status':'NOT_RUN_BY_PREFLIGHT'}
    allrows=list(report['legacy_source'].values())+list(report['h1h_dependencies'].values())
    report['source_symbols_complete']=all(x['exists'] and not x['missing_symbols'] for x in allrows)
    report['required_next_step']='Compare actual schema keys/checksums and fill local source-map; missing equivalent symbols need explicit mapping, never assume a pass.'
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"preflight written: {args.out}; source complete={report['source_symbols_complete']}")
    return 0 if report['source_symbols_complete'] else 3
if __name__=='__main__':raise SystemExit(main())
